<?php

class GlobalSettingsControllerBK_cl
{

    public function __construct() {}

    /*
     * for ajax call
     */
    public static function routes($action, $args)
    {
        $result = false;
        switch ($action) {
            case 'cl_save_global_settings':
                $result = self::save_settings($args);
                break;
            case 'cl_save_new_model_settings':
                $result = self::save_new_model_settings($args);
                break;
        }

        return $result;
    }
    /*
         * 
         */
    public function index()
    {
        $urlArgs = $_REQUEST;

        $settingsModelId    = isset($urlArgs['settings_model_id']) ? $urlArgs['settings_model_id'] : 0;
        $compoName          = isset($urlArgs['compo']) ? $urlArgs['compo'] : 'product';

        $settings           = AdminCompo_cl::getSettings($compoName, $settingsModelId);

        switch ($compoName) {
            case 'mystore':
                MystoreSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'header':
                HeaderSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'footer':
                FooterSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'sales_funnel':
                SalesFunnelSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'category':
                CategorySettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'product':
                ProductSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'qty_offers':
                QtyOffersSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'variations':
                VariationsSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'checkout':
                CheckoutSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'cart':
                CartSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'thankyou':
                ThankyouSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'listing':    
            case 'plist1':
                PList1SettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            // thnkyou upsell
            case 'plist5':
                PList5SettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'categories_listing':
                CategoriesListingSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'whatsapp':
                WhatsappSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'google_sheet':
                SheetSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'order_statuses':
                OrderStatusesSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'shipping_options':
                ShippingOptionsSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'tracking':
                TrackingSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'color_palette':
                ColorPaletteSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
            case 'insights':
                InsightsSettingsControllerBK_cl::index($settingsModelId, $settings, $urlArgs);
                break;
        }
    }

    /*
         * This is the main action triggered for ajax call for saving settings
         */
    public static function save_new_model_settings($args)
    {
        $response = SettingsModelBK_cl::insert($args);

        if ($response->code == 1) {
            $settingCreatedLink = get_site_url() . '/wp-admin/admin.php?page=cl_global_settings&settings_model_id=' . $response->res['insert_id'];
            $response->res['redirect_to'] = $settingCreatedLink;
        }

        return $response;
    }

    /*
         * This is the main action triggered for ajax call for saving settings
         */
    public static function save_settings($args)
    {
        $compoName = $args['comp_name'];
        $settingsModelId = isset( $args['settings_model_id'] ) ? $args['settings_model_id'] : 0;

        // you should create a static function for every component
        $funcName = $compoName . '_save_settings';
        if (method_exists(get_called_class(), $funcName)) {
            $response_cl = self::$funcName($compoName, $settingsModelId, $args);
            
            if ($response_cl) {
                return $response_cl;
            }
        }

        return response_cl(1, Lang_cl::__('Settings updated successfully', 'cl'), null);
    }
    /*
         * here is the functions for component that should be triggered after the save_settings function in this class
         */
    public static function mystore_save_settings($compoName, $settingsModelId, $args)
    {
        $response = MystoreSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }
    
    public static function header_save_settings($compoName, $settingsModelId, $args)
    {
        $response = HeaderSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }
    
    public static function footer_save_settings($compoName, $settingsModelId, $args)
    {
        $response = FooterSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }
    
    public static function sales_funnel_save_settings($compoName, $settingsModelId, $args)
    {
        $response = SalesFunnelSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }
    
    public static function category_save_settings($compoName, $settingsModelId, $args)
    {
        $response = CategorySettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);

        if( $response ) {
            return $response;
        }
    }
    
    public static function product_save_settings($compoName, $settingsModelId, $args)
    {
        $response = ProductSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }

    public static function qty_offers_save_settings($compoName, $settingsModelId, $args)
    {
        $response = QtyOffersSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }
    
    public static function variations_save_settings($compoName, $settingsModelId, $args)
    {
        $response = VariationsSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }
    
    public static function cart_save_settings($compoName, $settingsModelId, $args)
    {
        $response = CartSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }
    
    public static function checkout_save_settings($compoName, $settingsModelId, $args)
    {
        $response = CheckoutSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }
    
    public static function thankyou_save_settings($compoName, $settingsModelId, $args)
    {
        $response = ThankyouSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }
    
    public static function whatsapp_save_settings($compoName, $settingsModelId, $args)
    {
        $response = WhatsappSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }

    public static function google_sheet_save_settings($compoName, $settingsModelId, $args)
    {
        $response =  SheetSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        return $response;
    }

    public static function order_status_save_settings($compoName, $settingsModelId, $args)
    {
        $response =  OrderStatusSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        return $response;
    }
    
    public static function shipping_options_save_settings($compoName, $settingsModelId, $args)
    {
        $response = ShippingOptionsSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        return $response;
    }

    public static function plist1_save_settings($compoName, $settingsModelId, $args)
    {
        $response = PList1SettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }

    // thankyou upsell products
    public static function plist5_save_settings($compoName, $settingsModelId, $args)
    {
        $response = PList5SettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }
    
    public static function categories_listing_save_settings($compoName, $settingsModelId, $args)
    {
        $response = CategoriesListingSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }

    public static function tracking_save_settings($compoName, $settingsModelId, $args)
    {
        $response = TrackingSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }
    
    public static function color_palette_save_settings($compoName, $settingsModelId, $args)
    {
        $response = ColorPaletteSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }

    public static function insights_save_settings($compoName, $settingsModelId, $args)
    {
        $response = InsightsSettingsControllerBK_cl::save_settings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }
}