<?php

/**
 * Manage Global actions from any compo in the system
 */
class GlobalControllerBK_cl {

    /*
     * Ajax Routes
     */
    public static function routes($action, $args) {
        $response = false;
        switch ($action) {
            case 'cl_get_icons_modal':
                $response = self::saveUpdate($args);
                break;
        }

        return $response;
    }
    
    /**
     * Display the add new icon form
     */
    public static function getIconsModalList() {
        $icons = get_option('cl_icons_svg');

        
        ob_start();
        include MainApp_cl::$compsPath.'Icons/backend/views/ajax/icons_select.php';
        $result = ob_get_clean(); 
        
        
        return response_cl(1, Lang_cl::__('', 'cl'), $result);
    }
    
}