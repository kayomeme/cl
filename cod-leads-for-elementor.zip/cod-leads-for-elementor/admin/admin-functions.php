<?php

    function IsCompoSettingPage($compoName) {
        $response = false;
        if (isset($_REQUEST['page']) && isset($_REQUEST['compo'])) {
            if ($_REQUEST['compo'] === $compoName) {
                return true;
            }
        }

        if ($compoName == 'checkout' && isset($_REQUEST['page']) && $_REQUEST['page'] == 'cl_global_settings') {
            return true;
        }

        return $response;
    }

    /*
     * 
     */

    function IsClfePages() {
        $response = false;
        if (isset($_REQUEST['page'])) {
            $pageName = explode('_', $_REQUEST['page']);
            if (isset($pageName[0]) && $pageName[0] == 'cl') {
                return true;
            }
        }
        return $response;
    }

    /*
     * pagesSlugs array of slugs pages
     */

    function IsInCurrentPages($pagesSlug) {
        if (isset($_REQUEST['page']) && in_array($_REQUEST['page'], $pagesSlug)) {
            return true;
        } else {
            return false;
        }
    }
   