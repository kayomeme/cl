<?php

class adminUtils_cl {
    /* this will fix the error related to the conflict between the json quotes "{"elements":{"0" ... and the input quote */

    public static function cleanInput($setting) {
        // If it's an array, recursively process each element
        if (is_array($setting)) {
            $result = [];
            foreach ($setting as $key => $value) {
                $result[$key] = self::cleanInput($value); // Recursively clean each element
            }
            return $result;
        }
        // If it's a string, apply htmlspecialchars
        else if (is_string($setting)) {
            return htmlspecialchars($setting);
        }
        // For other types (null, boolean, integer, etc.), return as is
        else {
            return $setting;
        }
    }

    /*
     * 
     */

    public static function ajaxReturn($result) {
        echo json_encode($result);
        exit();
    }

    public static function getSimulatorNoProductsMessage() {
        ob_start();
        ?>
        <div class="notice notice-info inline" style="text-align: center; padding: 2rem 1rem;">
            <h2 class="wp-heading-inline"> 
                <span class="dashicons dashicons-store"></span> <br/><br/>
                <?= Lang_cl::_e('No Products Found', 'cl') ?> 
            </h2>
            <p>
                <?= Lang_cl::_e('There are currently no products in your shop to display in the simulator.', 'cl') ?>
            </p>
            <br/>

            <a href="<?php echo esc_url(admin_url('post-new.php?post_type=product')); ?>" 
               class="button button-primary">
                <span class="dashicons dashicons-plus-alt" style="margin: 4px 4px 0 0;"></span>
                <?= Lang_cl::_e('Add New Product', 'cl') ?>
            </a>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function getPages($limit) {
        global $wpdb;

        $query = "SELECT ID, post_title, post_name FROM $wpdb->posts where post_type = 'page' ORDER BY ID DESC LIMIT {$limit}";
        $result = $wpdb->get_results($query);

        return $result;
    }

    /*
     * 
     */

    public static function getElementsOrder($defaultElementsOrder, $savedElementsOrder) {
        $defaultElementsOrder = explode(',', $defaultElementsOrder);
        $savedElementsOrder = explode(',', $savedElementsOrder);

        foreach ($savedElementsOrder as $key => $element) {
            if (!in_array($element, $defaultElementsOrder)) {
                unset($savedElementsOrder[$key]);
            }
        }

        foreach ($defaultElementsOrder as $key => $element) {
            if (!in_array($element, $savedElementsOrder)) {
                $savedElementsOrder[] = $element;
            }
        }

        return $savedElementsOrder;
    }

    /*
     * 
     */

    public static function textExistsIn($textToCheck, $searchText) {
        // Use strpos() to search for the first occurrence of $searchText within $textToCheck
        $position = strpos($searchText, $textToCheck);

        // If $position is not false (meaning $searchText was found), return true
        return $position !== false;
    }

    public static function unsetUnwantedDatas($requestDatas) {
        // First remove unwanted keys
        $unwanted_keys = [
            'comp_name',
            'action',
            'cl_action_name',
            'cl_controller',
            'cl_action',
            'tab_name',
            'only_tab',
            '_wpnonce',
            'woocommerce-login-nonce',
            'woocommerce-reset-password-nonce'
        ];

        foreach ($unwanted_keys as $key) {
            unset($requestDatas[$key]);
        }

        return $requestDatas;
    }

    /**
     * Sanitizes array values with special handling for WordPress emoji HTML conversion.
     * 
     * This function handles two main tasks:
     * 1. Recursively processes all array values to handle nested arrays
     * 2. Converts WordPress emoji HTML (<img class="emoji"...>) into plain emoji characters
     * 
     * Example of conversion:
     * From: <img class="emoji" src="/.../1f525.svg" alt="🔥" /> 
     * To:   🔥
     * 
     * This conversion is necessary because WordPress emoji HTML can cause serialization
     * issues when saving to the database, especially with update_option().
     * 
     * @param array|mixed $array The input array or value to sanitize
     * @return array|mixed The sanitized array or value
     */
    public static function sanitizeArrayValues($array) {
        // If not an array, return as is
        if (!is_array($array)) {
            return $array;
        }

        foreach ($array as $key => $value) {
            if (is_array($value)) {
                // Recursively handle nested arrays
                $array[$key] = self::sanitizeArrayValues($value);
            } else if (is_string($value)) {
                // Only process strings
                // Check if string contains WordPress emoji HTML
                if (strpos($value, 'class="emoji"') !== false) {
                    // Replace WordPress emoji HTML with the actual emoji character
                    // Pattern explained:
                    // <img       - Start of img tag
                    // [^>]*      - Any attributes before alt
                    // alt="(.*?)" - The alt attribute containing the emoji
                    // [^>]*      - Any attributes after alt
                    // class="emoji" - The emoji class
                    // [^>]*      - Any remaining attributes
                    // >          - End of img tag
                    $value = preg_replace(
                            '/<img[^>]*alt="(.*?)"[^>]*class="emoji"[^>]*>/i',
                            '$1', // Replace with just the emoji from alt attribute
                            $value
                    );

                    // Ensure proper emoji encoding
                    $value = wp_encode_emoji($value);
                }

                // Sanitize remaining HTML while preserving basic structure
                $array[$key] = wp_kses(
                        $value,
                        array(
                            'p' => array(),
                            'br' => array(),
                            'b' => array(),
                            'strong' => array(),
                            'span' => array(
                                'style' => array(),
                                'class' => array()
                            )
                        )
                );

                // Clean up any HTML entities to prevent double encoding
                $array[$key] = html_entity_decode($array[$key], ENT_QUOTES, 'UTF-8');
            }
        }

        return $array;
    }

    public static function sanitizeSlugstring($string) {
        //$string = sanitize_title($string);
        $char_map = [
            'أ' => 'a', 'إ' => 'a', 'آ' => 'a', 'ا' => 'a', 'ء' => 'a', 'ب' => 'b', 'ت' => 't', 'ث' => 't', 'ج' => 'j', 'ح' => 'h', 'خ' => 'k', 'د' => 'd', 'ذ' => 'd', 'ر' => 'r', 'ز' => 'z', 'س' => 's', 'ش' => 's', 'ص' => 's', 'ض' => 'd', 'ط' => 't', 'ظ' => 'z', 'ع' => 'a',
            'غ' => 'g', 'ف' => 'f', 'ق' => 'k', 'ك' => 'k', 'ل' => 'l', 'م' => 'm', 'ن' => 'n', 'ه' => 'h', 'ة' => 'h', 'و' => 'w', 'ؤ' => 'w', 'ي' => 'y', 'ى' => 'y', 'ئ' => 'y', 'ـا' => 'a', 'ـب' => 'b', 'ـت' => 't', 'ـث' => 't', 'ـج' => 'j', 'ـح' => 'h', 'ـخ' => 'k', 'ـد' => 'd', 'ـذ' => 'd', 'ـر' => 'r', 'ـز' => 'z', 'ـس' => 's', 'ـش' => 's', 'ـص' => 's', 'ـض' => 'd', 'ـط' => 't', 'ـظ' => 'z', 'ـع' => 'a', 'ـغ' => 'g', 'ـف' => 'f', 'ـق' => 'k', 'ـك' => 'k', 'ـل' => 'l', 'ـم' => 'm', 'ـن' => 'n', 'ـه' => 'h', 'ـو' => 'w', 'ـي' => 'y', 'َ' => 'a', 'ُ' => 'u', 'ِ' => 'i', 'ّ' => '', 'ْ' => '', 'ً' => 'n', 'ٌ' => 'n', 'ٍ' => 'n',
            'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e', 'à' => 'a', 'â' => 'a', 'ä' => 'a', 'î' => 'i', 'ï' => 'i', 'ô' => 'o', 'ö' => 'o', 'ù' => 'u', 'û' => 'u', 'ü' => 'u', 'ÿ' => 'y', 'ç' => 'c',
            'ä' => 'a', 'ö' => 'o', 'ü' => 'u', 'ß' => 's',
            'ñ' => 'n', 'á' => 'a', 'í' => 'i', 'ó' => 'o', 'ú' => 'u',
            ' ' => '-', '_' => '-', '.' => '-', ',' => '-', '/' => '-', '\\' => '-', '|' => '-', '&' => 'n', '@' => 'a', '+' => 'p'
        ];

        // Apply additional transliteration if needed
        $string = strtr($string, $char_map);

        // Clean up any remaining issues
        //$string = sanitize_title($string);

        return $string;
    }
    /*
     * 
     */

    public static function isJsonString($json_str) {
        if (is_array($json_str)) {
            return false;
        }
        json_decode(stripslashes($json_str));

        return (json_last_error() == JSON_ERROR_NONE);
    }

    /*
     * 
     */

    /*
     * 
     */

    public static function getPluginLangCode() {
        //$wpLang = get_bloginfo('language');
        $wpLang = get_locale();

        $arabLangs = ['ar', 'ary', 'arq'];
        if (in_array($wpLang, $arabLangs)) {
            return 'ar';
        }

        // englsih
        if (strpos($wpLang, 'en_') !== false) {
            return 'en';
        }

        // french
        if (strpos($wpLang, 'fr_') !== false) {
            return 'fr';
        }

        // Spanish
        if (strpos($wpLang, 'es_') !== false) {
            return 'es';
        }

        // italy
        if (strpos($wpLang, 'it_') !== false) {
            return 'it';
        }

        // Portuguese 
        if (strpos($wpLang, 'pt_') !== false) {
            return 'pt';
        }

        return 'en';
    }

    public static function setPermalinkStructureToPostnameAndFlushRules() {
        global $wp_rewrite;
        //Write the rule
        $wp_rewrite->set_permalink_structure('/%postname%/');
        //Set the option
        update_option("rewrite_rules", FALSE);
        //Flush the rules and tell it to write htaccess
        $wp_rewrite->flush_rules(true);
    }

    public static function setWoocommerceDefaultSettings() {
        // this will skip the conflict between a wp post id and an order id
        // this can be changed manually here ?page=wc-settings&compo=advanced&section=features
        update_option('woocommerce_custom_orders_table_data_sync_enabled', 'no');
    }

    // Define a helper function to check if a string contains error/warning keywords
    public static function isValideGeneratedCss($generatedCSS) {
        $errorKeywords = array('<font', '<table', 'xe-warning');
        $generatedCSS = strtolower($generatedCSS);

        $existError = false;
        foreach ($errorKeywords as $keyword) {
            if (strpos($generatedCSS, strtolower($keyword)) !== false) {
                $existError = true;
                break;
            }
        }
        // Check if the generated CSS is valid
        if ($existError) {

            // If invalid, find and output the errors/warnings
            preg_match_all('/<(font|table).*?>(.*?)<\/(font|table)>/s', $generatedCSS, $matches);

            foreach ($matches[2] as $match) {
                //$match . "\n";
                adminDB_cl::insert('cl_logs', [
                    'content' => $match
                ]);
            }

            return false;
        }

        return true;
    }

public static function minify_css($input) {
    if (trim($input) === "") {
        return $input;
    }
    
    // Break the input into style blocks and process each one
    $pattern = '/<style>([\s\S]*?)<\/style>/';
    preg_match_all($pattern, $input, $matches);
    
    $result = "";
    
    if (!empty($matches[0])) {
        foreach ($matches[1] as $styleContent) {
            // Apply minification only to the CSS content between style tags
            $minified = preg_replace(
                array(
                    // Remove comment(s)
                    '#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')|\/\*(?!\!)(?>.*?\*\/)|^\s*|\s*$#s',
                    // Remove unused white-space(s)
                    '#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\'|\/\*(?>.*?\*\/))|\s*+;\s*+(})\s*+|\s*+([*$~^|]?+=|[{};,>~]|\s(?![0-9\.])|!important\b)\s*+|([[(:])\s++|\s++([])])|\s++(:)\s*+(?!(?>[^{}"\']++|"(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')*+{)|^\s++|\s++\z|(\s)\s+#si',
                    // Replace `0(cm|em|ex|in|mm|pc|pt|px|vh|vw|%)` with `0`
                    '#(?<=[\s:])(0)(cm|em|ex|in|mm|pc|pt|px|vh|vw|%)#si',
                    // Replace `:0 0 0 0` with `:0`
                    '#:(0\s+0|0\s+0\s+0\s+0)(?=[;\}]|\!important)#i',
                    // Replace `background-position:0` with `background-position:0 0`
                    '#(background-position):0(?=[;\}])#si',
                    // Replace `0.6` with `.6`, but only when preceded by `:`, `,`, `-` or a white-space
                    '#(?<=[\s:,\-])0+\.(\d+)#s',
                    // Minify string value
                    '#(\/\*(?>.*?\*\/))|(?<!content\:)([\'"])([a-z_][a-z0-9\-_]*?)\2(?=[\s\{\}\];,])#si',
                    '#(\/\*(?>.*?\*\/))|(\burl\()([\'"])([^\s]+?)\3(\))#si',
                    // Minify HEX color code
                    '#(?<=[\s:,\-]\#)([a-f0-6]+)\1([a-f0-6]+)\2([a-f0-6]+)\3#i',
                    // Replace `(border|outline):none` with `(border|outline):0`
                    '#(?<=[\{;])(border|outline):none(?=[;\}\!])#',
                    // Remove empty selector(s)
                    '#(\/\*(?>.*?\*\/))|(^|[\{\}])(?:[^\s\{\}]+)\{\}#s'
                ),
                array(
                    '$1',
                    '$1$2$3$4$5$6$7',
                    '$1',
                    ':0',
                    '$1:0 0',
                    '.$1',
                    '$1$3',
                    '$1$2$4$5',
                    '$1$2$3',
                    '$1:0',
                    '$1$2'
                ),
                $styleContent
            );
            
            // Add the minified content with style tags
            $result .= "<style>" . $minified . "</style>";
        }
    }
    
    return $result;
}
    
    /*public static function minify_css($input) {
        if (trim($input) === "")
            return $input;
        return preg_replace(
                array(
                    // Remove comment(s)
                    '#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')|\/\*(?!\!)(?>.*?\*\/)|^\s*|\s*$#s',
                    // Remove unused white-space(s)
                    '#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\'|\/\*(?>.*?\*\/))|\s*+;\s*+(})\s*+|\s*+([*$~^|]?+=|[{};,>~]|\s(?![0-9\.])|!important\b)\s*+|([[(:])\s++|\s++([])])|\s++(:)\s*+(?!(?>[^{}"\']++|"(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')*+{)|^\s++|\s++\z|(\s)\s+#si',
                    // Replace `0(cm|em|ex|in|mm|pc|pt|px|vh|vw|%)` with `0`
                    '#(?<=[\s:])(0)(cm|em|ex|in|mm|pc|pt|px|vh|vw|%)#si',
                    // Replace `:0 0 0 0` with `:0`
                    '#:(0\s+0|0\s+0\s+0\s+0)(?=[;\}]|\!important)#i',
                    // Replace `background-position:0` with `background-position:0 0`
                    '#(background-position):0(?=[;\}])#si',
                    // Replace `0.6` with `.6`, but only when preceded by `:`, `,`, `-` or a white-space
                    '#(?<=[\s:,\-])0+\.(\d+)#s',
                    // Minify string value
                    '#(\/\*(?>.*?\*\/))|(?<!content\:)([\'"])([a-z_][a-z0-9\-_]*?)\2(?=[\s\{\}\];,])#si',
                    '#(\/\*(?>.*?\*\/))|(\burl\()([\'"])([^\s]+?)\3(\))#si',
                    // Minify HEX color code
                    '#(?<=[\s:,\-]\#)([a-f0-6]+)\1([a-f0-6]+)\2([a-f0-6]+)\3#i',
                    // Replace `(border|outline):none` with `(border|outline):0`
                    '#(?<=[\{;])(border|outline):none(?=[;\}\!])#',
                    // Remove empty selector(s)
                    '#(\/\*(?>.*?\*\/))|(^|[\{\}])(?:[^\s\{\}]+)\{\}#s'
                ),
                array(
                    '$1',
                    '$1$2$3$4$5$6$7',
                    '$1',
                    ':0',
                    '$1:0 0',
                    '.$1',
                    '$1$3',
                    '$1$2$4$5',
                    '$1$2$3',
                    '$1:0',
                    '$1$2'
                ),
                $input
        );
    }*/
}
