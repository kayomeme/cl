<?php
require 'admin_init.php';
require 'admin_head.php';
require 'admin_menu.php';
require 'wp_dashboard_setup.php';

if( isset( $_REQUEST['taxonomy'] ) && $_REQUEST['taxonomy'] == 'product_cat' ) {
    require 'category_image.php';
}