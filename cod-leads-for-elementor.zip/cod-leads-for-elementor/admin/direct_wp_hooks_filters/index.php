<?php
require 'admin_init.php';

if( isset( $_REQUEST['taxonomy'] ) && $_REQUEST['taxonomy'] == 'product_cat' ) {
    require 'category_image.php';
}