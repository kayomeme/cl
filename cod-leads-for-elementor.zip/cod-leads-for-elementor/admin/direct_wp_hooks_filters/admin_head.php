<?php

function hide_admin_notices_cl() {
    // Check if we're on the main dashboard page
    global $pagenow;
    //var_dump($pagenow);
    $pages = ['index.php', 'edit.php', 'post.php', 'post-new.php', 'edit-tags.php', 'users.php', 'term.php'];
    if ( IsClfePages() || in_array($pagenow, $pages) ) {
        
        remove_all_actions('admin_notices');
        remove_all_actions('all_admin_notices');
    }
}
add_action('admin_head', 'hide_admin_notices_cl');

