<?php

function reorder_menus_cl() {
    global $menu;
    
    // Find the Articles menu item
    foreach ($menu as $key => $item) {
        if (isset($item[5]) && $item[5] == 'menu-posts') {
            // Remove it from current position
            $articles_menu = $menu[$key];
            unset($menu[$key]);
            
            // Add it back at new position (e.g., position 15)
            $menu[21] = $articles_menu;
            break;
        }
        
        //menu-media
    }
    
    // Re-sort the menu array
    ksort($menu);
}
add_action('admin_menu', 'reorder_menus_cl', 999);