<?php
function remove_dashboard_widgets_cl() {
    // Check if we're on the main dashboard page
    global $pagenow;
    if ($pagenow !== 'index.php') {
        return;
    }
    
    // Remove WordPress welcome panel
    remove_action('welcome_panel', 'wp_welcome_panel');
    
    // Remove default WordPress dashboard widgets
    remove_meta_box('dashboard_incoming_links', 'dashboard', 'normal');
    remove_meta_box('dashboard_plugins', 'dashboard', 'normal');
    remove_meta_box('dashboard_primary', 'dashboard', 'side');
    remove_meta_box('dashboard_secondary', 'dashboard', 'normal');
    remove_meta_box('dashboard_quick_press', 'dashboard', 'side');
    remove_meta_box('dashboard_recent_drafts', 'dashboard', 'side');
    remove_meta_box('dashboard_recent_comments', 'dashboard', 'normal');
    remove_meta_box('dashboard_right_now', 'dashboard', 'normal');
    remove_meta_box('dashboard_activity', 'dashboard', 'normal');
    remove_meta_box('dashboard_site_health', 'dashboard', 'normal');
    
    
    // Remove plugin-specific widgets (like Elementor)
    remove_meta_box('e-dashboard-overview', 'dashboard', 'normal');
    remove_meta_box('elementor_dashboard_overview', 'dashboard', 'normal');
    
    // Add custom dashboard widget with your template
    wp_add_dashboard_widget(
        'custom_admin_template',
        Lang_cl::__('COD Leads for WordPress', 'cl'),
        'display_custom_admin_template'
    );
}

function display_custom_admin_template() {
    // Include your custom template file
    $template_path = AdminApp_cl::$viewsPath . 'welcome_page/index.php';
    
    // Check if file exists before including
    if (file_exists($template_path)) {
        include $template_path;
    } else {
        echo '<p>Template file not found.</p>';
    }
}

add_action('wp_dashboard_setup', 'remove_dashboard_widgets_cl');
