<?php

function cl_taxonomy_add_custom_field() { ?>
    <div class="form-field term-image-wrap">
        <label>
            <?= Lang_cl::_e('Category image', 'cl') ?>
        </label>
        <p>
            <a href="#" class="button button-secondary cl-image-selector">
                <?= Lang_cl::_e('Upload an image to this category', 'cl') ?>
                
                <img src="" width="100px" class="cl_img_url" style="display:none;" />
                <input type="hidden" name="thumbnail_id" class="cl_img_id" />
            </a>
        </p>


    </div>
    <?php
}

add_action('product_cat_add_form_fields', 'cl_taxonomy_add_custom_field', 10, 2);

function cl_taxonomy_edit_custom_field($term) {
    $image_id = get_term_meta($term->term_id, 'thumbnail_id', true);
    $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'medium') : '';
    ?>
    <tr class="form-field term-image-wrap">
        <th scope="row">
            <label for="thumbnail_id">
                <?= Lang_cl::_e('Category image', 'cl') ?>
            </label>
        </th>
        <td>
            <p>
                <a href="#" class="button button-secondary cl-image-selector">
                    <?= Lang_cl::_e('Upload an image to this category', 'cl') ?>

                    <img src="<?= $image_url ?>" width="100px" class="cl_img_url" <?= !$image_id ? 'style="display:none;"' : '' ?> />
                    <input type="hidden" name="thumbnail_id" class="cl_img_id" value="<?= $image_id ?>" />
                </a>
                <?php if ($image_id): ?>
                    <a href="#" class="button button-secondary cl_remove_category_img" style="margin-left:10px;">
                        <?= Lang_cl::_e('Remove image', 'cl') ?>
                    </a>
                <?php endif; ?>
            </p><br/>

        </td>
    </tr>
    <?php
}

add_action('product_cat_edit_form_fields', 'cl_taxonomy_edit_custom_field', 10, 2);

function cl_save_taxonomy_custom_meta_field($term_id) {
    if (isset($_POST['thumbnail_id'])) {
        $image_id = intval($_POST['thumbnail_id']);
        if ($image_id > 0) {
            update_term_meta($term_id, 'thumbnail_id', $image_id);
        } else {
            delete_term_meta($term_id, 'thumbnail_id');
        }
    }
}

add_action('edited_product_cat', 'cl_save_taxonomy_custom_meta_field', 10, 2);
add_action('create_product_cat', 'cl_save_taxonomy_custom_meta_field', 10, 2);

// Helper function to get category image
function cl_get_category_image($term_id, $size = 'medium') {
    $image_id = get_term_meta($term_id, 'thumbnail_id', true);
    if ($image_id) {
        return wp_get_attachment_image_url($image_id, $size);
    }
    return false;
}