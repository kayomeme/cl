<?php

function clfe_taxonomy_add_custom_field() { ?>
    <div class="form-field term-image-wrap clfe_category_img_url">
        <label>
            <?= Lang_clfe::_e('Category image', 'clfe') ?>
        </label>
        <p>
            <a href="#" class="button button-secondary clfe_select_category_img">
                <?= Lang_clfe::_e('Upload an image to this category', 'clfe') ?>
            </a>
        </p>
        
        <img src="" width="100px" class="clfe_category_img_url" />
        <input type="hidden" name="clfe_category_img_url" />
    </div>
    <?php
}
add_action( 'product_cat_add_form_fields', 'clfe_taxonomy_add_custom_field', 10, 2 );

function clfe_taxonomy_edit_custom_field($term) {
    $image_url = get_term_meta($term->term_id, 'clfe_category_img_url', true);
    ?>
    <tr class="form-field term-image-wrap clfe_category_img_url">
        <th scope="row">
            <label for="clfe_category_img_url">
                <?= Lang_clfe::_e('Category image', 'clfe') ?>
            </label>
        </th>
        <td>
            <p>
                <a href="#" class="button button-secondary clfe_select_category_img">
                    <?= Lang_clfe::_e('Upload an image to this category', 'clfe') ?>
                </a>
            </p><br/>
            <img src="<?= $image_url ?>" width="100px" class="clfe_category_img_url" />
            <input type="hidden" name="clfe_category_img_url" value="<?= $image_url ?>" />
        </td>
    </tr>
    <?php
}
add_action( 'product_cat_edit_form_fields', 'clfe_taxonomy_edit_custom_field', 10, 2 );

function clfe_save_taxonomy_custom_meta_field( $term_id ) {
    if ( isset( $_POST['clfe_category_img_url'] ) ) {
        update_term_meta($term_id, 'clfe_category_img_url', $_POST['clfe_category_img_url']);
    }
}  
add_action( 'edited_product_cat', 'clfe_save_taxonomy_custom_meta_field', 10, 2 );  
add_action( 'create_product_cat', 'clfe_save_taxonomy_custom_meta_field', 10, 2 );


/*$term_id = 39;
$image = get_term_meta($term_id, 'clfe_category_img_url', true);
echo '<img src="'.$image.'" />';*/