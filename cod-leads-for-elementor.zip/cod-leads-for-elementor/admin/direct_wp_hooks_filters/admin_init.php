<?php

function clfe_create_product_and_redirect() {
    if ( isset( $_REQUEST['clfe_add_new_product'] ) ) {
        // Gather post data.
        $new_product = [
            'post_title'    => 'nes product',
            'post_content'  => '',
            'post_status'   => 'draft'
        ];

        // Insert the post into the database.
        $product_id = wp_insert_post( $new_product );
        if( $product_id ) {
            wp_safe_redirect( '/wp-admin/admin.php?page=clfe_product_settings&compo=product_details&product_id='.$product_id ); 
            exit;
        }
    }
}

add_action( 'admin_init', 'clfe_create_product_and_redirect', 1 );