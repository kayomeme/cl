(function ($) {
    /**
     * GlobalSettings function
     */
    GlobalSettingsFn_cl = {

        init: function () {

        },
        addNewSettingsModel: function () {
            const cl_controller = 'cl_global_settings';
            const cl_action = 'cl_save_new_model_settings';
            const formdata = this.getFormDatas(cl_action);

            const celement = $(".model-settings-form .model-settings-content").clone(true);
            const modalElement = $('<div class="cl-modal-container" id="' + cl_action + '"></div>');

            modalElement.append(celement);
            modalElement.dialog({
                title: $(this).attr('modal_title'),
                modal: true,
                width: "60%",
                buttons: {
                    "Cancel": function () {
                        $(this).dialog("close");
                    },
                    "Save": function () {
                        AdminFn_cl.beforeSendAjaxRequest(cl_action);
                        AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formdata);
                    }
                },
                close: function () {
                    $(this).dialog("destroy");
                }
            });
        }
    };

    $(function () {
        GlobalSettingsFn_cl.init();
    });

    $(document).ready(function () {



        /*
         * Add new settings model
         */
        $(".cl-add-new-settings-model").on('click', function () {
            GlobalSettingsFn_cl.addNewSettingsModel();
        });





    });



})(jQuery);