(function( $ ) {
    //'use strict';
    DynamicElements_clfe = {

        init: function () {
        },
        addNew: function(modalTitle, dynamicElContainer) {
            const celement = $("."+dynamicElContainer+" .clfe-empty-elements .c-element").first().clone(true);

            // skip the popup for sheet columns
            const skipDynamicElements = ['google-sheet-columns', 'order-status'];
            if(  skipDynamicElements.includes(dynamicElContainer) ) {
                $(celement).find(".c-element-panel").show();
                $("."+dynamicElContainer+" .dynamic-elements").append(celement);
                return;
            }

            // hide other
            $("."+dynamicElContainer).find(".c-element-panel").hide();


            celement.find(".clfe-accordion-panel").show();
            celement.find(".clfe-element-buttons").hide();
            const modalElement = $('<div class="clfe-modal-container"></div>');
            modalElement.empty();
            modalElement.append(celement);

            // special for variations
            celement.find(".variations-select option[value='selectbox']").prop("selected", true);
            celement.find(".variations-select").change();

            modalElement.dialog({
                title: modalTitle,
                resizable: true,
                height: "auto",
                width: $(window).width() > 900 ? 800 : 'auto',
                modal: true,
                buttons: {
                    "Cancel": function() {
                        $( this ).dialog( "close" );
                    },
                    "Save": function() {
                        $("."+dynamicElContainer+" .dynamic-elements").append(celement);
                        celement.find(".clfe-element-buttons").show();

                        DynamicElements_clfe.setDatas();

                        //$(".clfe-save-global-settings").click();
                        $( this ).dialog( "close" );
                    }
                },
                close: function() { 
                    $( this ).dialog( "destroy" );
                }
            });
        },
        setDatas: function () {
            //--- dynamique elements retrieve data
            $(".dynamic-elements").each(function (index, node) {
                const attachedSettingName = $(node).attr("attachedSettingName");
                const elements = {}; 

                $(node).find(".c-element").each(function (index, node) {
                    const element = {}; 
                    var addThisElement = true;
                    $(node).find("[elementName]").each(function (index, node) {
                        var isRequired = $(node).attr("isRequired");
                        var isSubElements = $(node).attr("isSubElements");

                        // for sub elements like the Variations
                        if( isSubElements == 'yes' ) {

                            $(node).parent().find(".sub-dynamic-elements").each(function (subIndex, subNode) {
                                const subElements = {}; 

                                $(subNode).find(".c-sub-element").each(function (subIndex, subNode) {
                                    const subElement = {}; 
                                    var addThisSubElement = true;
                                    $(subNode).find("[subElementName]").each(function (subIndex, subNode) {
                                        var isRequired = $(subNode).attr("isRequired");
                                        subElement[$(subNode).attr("subElementName")] = subNode.value;

                                        if( isRequired == 'yes' &&  subNode.value == '' ) {
                                            addThisSubElement = false;
                                        }
                                    });
                                    if( addThisSubElement == true &&  Object.keys(subElement).length !== 0 ) {
                                        subElements[subIndex] = subElement;
                                    }
                                });
                                element[$(node).attr("elementName")] = subElements;
                            });

                        } else {
                            element[$(node).attr("elementName")] = node.value;
                        }

                        if( isRequired == 'yes' &&  node.value == '' ) {
                            addThisElement = false;
                        }
                    });
                    if( addThisElement == true &&  Object.keys(element).length !== 0 ) {
                        elements[index] = element;
                        
                    }


                });
                $("input[name="+attachedSettingName+"]").val( JSON.stringify({ 'elements' : elements }) );
                $("input[name="+attachedSettingName+"]").change();
            });
        }
    };

        $(window).on("load", function () {
            $('.select_display_condition').change();
            $(".nav-tab-active").click();
            //$(".sub-nav-tab-active").click();
        });

        $(document).ready( function () {

            // tab system -----------------------------------
            $(".clfe-sidetab-nav > button").on('click', function(e) {
                e.preventDefault();
                const tab      = $(this).attr('tab');

                $(".clfe-sidetab-nav > button").removeClass('nav-tab-active');
                $(".clfe-single-tab").hide();
                $("#"+tab).show();
                $(this).addClass('nav-tab-active');

                currentUrlParms.set('tab', tab);
                window.history.replaceState(null, null, '?'+currentUrlParms.toString());
                
                if( $('.clfe-sidetab-submenu[attachedButonTab='+tab+']').length === 0 ) {
                    currentUrlParms.delete('subtab');
                }

                
                // submenu tab
                $('.clfe-sidetab-nav .clfe-sidetab-submenu').hide();
                $('.clfe-sidetab-submenu[attachedButonTab='+tab+']').show();
                if( !currentUrlParms.has('subtab') ) {
                    $('.clfe-sidetab-submenu[attachedButonTab='+tab+'] li:first-child').click();
                }
            });

            if( currentUrlParms.has('tab') ) {
                $(".clfe-sidetab-nav button[tab="+currentUrlParms.get('tab')+"]").click();
            } else {
                $(".clfe-sidetab-nav button:first-child").click();
            }
            
            $(".clfe-sidetab-submenu > li").on('click', function(e) {
                e.preventDefault();
                const tab      = $(this).attr('tab');

                $(".clfe-sidetab-submenu > li").removeClass('sub-nav-tab-active');
                $(".clfe-subtab").hide();
                $("#"+tab).closest(".clfe-single-tab").show();
                $("#"+tab).show();
                $(this).addClass('sub-nav-tab-active');

                currentUrlParms.set('subtab', tab);
                window.history.replaceState(null, null, '?'+currentUrlParms.toString());
            });
            if( currentUrlParms.has('subtab') ) {
                $(".clfe-sidetab-submenu li[tab="+currentUrlParms.get('subtab')+"]").click();
            }
            

            
            // accordion ---------------------------
            $(".clfe-accordion").on('click', function() {
                $(this).addClass("active");
                if ( $(this).next().is(':hidden') ) {
                    $(this).next().show();
                } else {
                    $(this).next().hide();
                }
            });
            
            
            // switch button system ----------------------------------------
            $(".clfe-switch input[type=checkbox]").on('change', function(ev) {
                const AttachedSettingInput = $(this).parent(".clfe-switch").find("input[type=hidden]");
                var sidbarButtonSelector = 'clfe_'+AttachedSettingInput.attr('name').replace('is_active', "tab");

                if( $(this).is(':checked') ) {
                    const customYes = $(this).attr("customYes") || "yes";
                    AttachedSettingInput.val(customYes);
                    
                    $(`button[tab="${sidbarButtonSelector}"]`).removeClass('is-disabled-block');
                    $(`button[tab="${sidbarButtonSelector}"]`).addClass('is-active-block');
                } else {
                    const customNo = $(this).attr("customNo") || "no";
                    AttachedSettingInput.val(customNo);
                    
                    $(`button[tab="${sidbarButtonSelector}"]`).removeClass('is-active-block');
                    $(`button[tab="${sidbarButtonSelector}"]`).addClass('is-disabled-block');
                }
                
                console.log(sidbarButtonSelector);

                AdminFn_clfe.addChangedAttribute(AttachedSettingInput);
            }); 
            
            /**
            * Blocks hide/show system based on select value
            * Usage:
            * <select blocks-to-hide=".elements-to-hide">
            *     <option block-to-show=".element1">Option 1</option>
            *     <option block-to-show=".element2, .element3">Option 2</option>
            * </select>
            * 
            * Attributes:
            * - blocks-to-hide: Selector for all elements that should be hidden initially
            * - block-to-show: Selector for elements to show when option is selected
            * 
            * Note: Multiple selectors can be comma-separated in block-to-show
            */
            $(document).on('change', 'select[blocks-to-hide]', function() {
               // Hide all blocks first
               $($(this).attr('blocks-to-hide')).hide();

               // Get selector for blocks to show
               const showSelector = $(this).find('option:selected').attr('block-to-show');

               // Show selected blocks if any
               if(showSelector) {
                   $(showSelector).show();
               }
            });
            $('select[blocks-to-hide]').change();
            
            
            /*
             * dynamic-elements
             */
            $(".clfe-add-dynamic-element").on('click', function() {
                const modalTitle        = $(this).attr('modalTitle');
                const dynamicElContainer  = $(this).attr("dynamic-elements-container");

                DynamicElements_clfe.addNew(modalTitle, dynamicElContainer);
            });
            
            /*$(".updateElement").on('click', function() {
                $(".is-a-sub-array-elements").hide();
                $(this).closest(".c-element").find(".is-a-sub-array-elements").show();
                $(this).closest(".c-element").find(".is-a-sub-array-elements .clfe-accordion").click();
                
                $(".c-element").find(".updateElement").show();
                $(this).hide();
            });*/
            
            
            
            $(".dynamic-elements .deleteElement").on('click', function($e) {
                const skip_normal_delete = $(this).attr("skip_normal_delete");
                if( skip_normal_delete != "yes" &&  confirm(jsLang.delete_confirm_msg) == true ) {
                    $(this).closest(".c-element").remove();
                }
                
            });

            
            //--- Add new sub dynamique elements
            $(".clfe-add-dynamic-subelement").on('click', function($e) {
                const subElement = $(this).closest(".variations-subelements").find(".c-sub-element").last().clone(true);
                
                $(subElement).find("[subElementName]").each(function (index, node) {
                    var defaultValue = $(node).attr('defaultValue');
                    $(node).val(defaultValue);
                });
                
                $(this).closest(".variations-subelements").find(".sub-dynamic-elements").append(subElement);
            });
            
            $(".deleteSubElement").on('click', function() {
                $(this).closest(".c-sub-element").remove();
            });
            

            // Handle the click event on the image selection button
            $('.clfe-image-selector').click(function() {
                var btElement = $(this);
                // Create a new media frame
                var mediaFrame = wp.media({
                    title: 'Select Custom Image',
                    multiple: false,
                    library: { type: 'image' },
                    button: { text: 'Select'}
                });

                // Handle image selection
                mediaFrame.on('select', function() {
                    var attachment = mediaFrame.state().get('selection').first().toJSON();
                    btElement.find(".clfe_img_id").val(attachment.id);
                    btElement.find(".clfe_img_url").val(attachment.url);
                    btElement.find("img").attr("src",attachment.url);
                });

                btElement.find("input").change();


                // Open the media frame
                mediaFrame.open();
            });

        } );

})( jQuery );