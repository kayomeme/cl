(function ($) {
    //'use strict';
    DynamicElements_cl = {

        init: function () {
        },
        addNew: function (modal_title, dynamicElContainer) {
            const celement = $("." + dynamicElContainer + " .cl-empty-elements .c-element").first().clone(true);

            // skip the popup for sheet columns
            const skipDynamicElements = ['google-sheet-columns', 'order-status'];
            if (skipDynamicElements.includes(dynamicElContainer)) {
                $(celement).find(".c-element-panel").show();
                $("." + dynamicElContainer + " .dynamic-elements").append(celement);
                return;
            }

            // hide other
            $("." + dynamicElContainer).find(".c-element-panel").hide();
            
            celement.find(".cl-element-buttons").hide();
            const modalElement = $('<div class="cl-modal-container"></div>');
            modalElement.empty();
            modalElement.append(celement);

            // special for variations
            celement.find(".variations-select option[value='selectbox']").prop("selected", true);
            celement.find(".variations-select").change();

            modalElement.dialog({
                title: modal_title,
                resizable: true,
                height: "auto",
                width: $(window).width() > 900 ? 800 : 'auto',
                modal: true,
                buttons: {
                    "Cancel": function () {
                        $(this).dialog("close");
                    },
                    "Save": function () {
                        $("." + dynamicElContainer + " .dynamic-elements").append(celement);
                        celement.find(".cl-element-buttons").show();

                        DynamicElements_cl.setDatas();

                        //$(".cl-save-global-settings").click();
                        $(this).dialog("close");
                    }
                },
                close: function () {
                    $(this).dialog("destroy");
                }
            });
        },
        setDatas: function () {
            //--- dynamique elements retrieve data
            $(".dynamic-elements").each(function (index, node) {
                const attachedSettingName = $(node).attr("attachedSettingName");
                const elements = {};

                $(node).find(".c-element").each(function (index, node) {
                    const canBeSaved = $(node).find("[elementName=is_active_in_this_product]").val();

                    // only save in the db the elements active by the used like variations
                    if (canBeSaved !== 'no') {
                        const element = {};
                        var addThisElement = true;
                        $(node).find("[elementName]").each(function (index, node) {
                            var isRequired = $(node).attr("isRequired");
                            var isSubElements = $(node).attr("isSubElements");

                            // for sub elements like the Variations
                            if (isSubElements == 'yes') {

                                $(node).parent().find(".sub-dynamic-elements").each(function (subIndex, subNode) {
                                    const subElements = {};

                                    $(subNode).find(".c-sub-element").each(function (subIndex, subNode) {
                                        const subElement = {};
                                        var addThisSubElement = true;
                                        $(subNode).find("[subElementName]").each(function (subIndex, subNode) {
                                            var isRequired = $(subNode).attr("isRequired");
                                            subElement[$(subNode).attr("subElementName")] = subNode.value;

                                            if (isRequired == 'yes' && subNode.value == '') {
                                                addThisSubElement = false;
                                            }
                                        });
                                        if (addThisSubElement == true && Object.keys(subElement).length !== 0) {
                                            subElements[subIndex] = subElement;
                                        }
                                    });
                                    element[$(node).attr("elementName")] = subElements;
                                });

                            } else {
                                element[$(node).attr("elementName")] = node.value;
                            }

                            if (isRequired == 'yes' && node.value == '') {
                                addThisElement = false;
                            }
                        });
                        if (addThisElement == true && Object.keys(element).length !== 0) {
                            elements[index] = element;
                        }
                    }


                });

                /*this final*/
                const elementsArray = Object.values(elements);
                $("input[name=" + attachedSettingName + "]").val(JSON.stringify(elementsArray));

                //$("input[name="+attachedSettingName+"]").val( JSON.stringify({ 'elements' : elements }) );
                $("input[name=" + attachedSettingName + "]").change();
            });
        }
    };

    $(window).on("load", function () {
        $('.select_display_condition').change();
        $(".nav-tab-active").click();
        //$(".sub-nav-tab-active").click();
    });

    $(document).ready(function () {

        // tab system -----------------------------------
        $(".cl-sidetab-nav > button").on('click', function (e) {
            e.preventDefault();
            const tab = $(this).attr('tab');

            $(".cl-sidetab-nav > button").removeClass('nav-tab-active');
            $(".cl-single-tab").hide();
            $("#" + tab).show();
            $(this).addClass('nav-tab-active');

            currentUrlParms.set('tab', tab);
            window.history.replaceState(null, null, '?' + currentUrlParms.toString());
            
            if ($('.cl-sidetab-submenu[attachedButonTab=' + tab + ']').length === 0) {
                currentUrlParms.delete('subtab');
                
            }


            // submenu tab
            $('.cl-sidetab-nav .cl-sidetab-submenu').hide();
            $('.cl-sidetab-submenu[attachedButonTab=' + tab + ']').show();
            
            if (!currentUrlParms.has('subtab') ) {
                $('.cl-sidetab-submenu[attachedButonTab=' + tab + '] li:first-child').click(); 
            } else {
                const subtab = currentUrlParms.get('subtab');
                if ($('.cl-sidetab-submenu[attachedButonTab=' + tab + '] li[tab=' + subtab + ']').length === 0) {
                    $('.cl-sidetab-submenu[attachedButonTab=' + tab + '] li:first-child').click();
                   } else {
                       $(".cl-sidetab-submenu li[tab=" + subtab + "]").click();
                   }
            }
        });

        if (currentUrlParms.has('tab')) {
            $(".cl-sidetab-nav button[tab=" + currentUrlParms.get('tab') + "]").click();
        } else {
            $(".cl-sidetab-nav button:first-child").click();
        }

        $(".cl-sidetab-submenu > li").on('click', function (e) {
            e.preventDefault();
            const tab = $(this).attr('tab');

            $(".cl-sidetab-submenu > li").removeClass('sub-nav-tab-active');
            $(".cl-subtab").hide();
            $("#" + tab).closest(".cl-single-tab").show();
            $("#" + tab).show();
            $(this).addClass('sub-nav-tab-active');

            currentUrlParms.set('subtab', tab);
            window.history.replaceState(null, null, '?' + currentUrlParms.toString());
        });


        // switch button system ----------------------------------------
        $(".cl-switch input[type=checkbox]").on('change', function (ev) {
            const AttachedSettingInput = $(this).parent(".cl-switch").find("input[type=hidden]");
            var sidbarButtonSelector = 'cl_' + AttachedSettingInput.attr('name').replace('is_active', "tab");

            if ($(this).is(':checked')) {
                const customYes = $(this).attr("customYes") || "yes";
                AttachedSettingInput.val(customYes);

                $(`button[tab="${sidbarButtonSelector}"]`).removeClass('is-disabled-block');
                $(`button[tab="${sidbarButtonSelector}"]`).addClass('is-active-block');
            } else {
                const customNo = $(this).attr("customNo") || "no";
                AttachedSettingInput.val(customNo);

                $(`button[tab="${sidbarButtonSelector}"]`).removeClass('is-active-block');
                $(`button[tab="${sidbarButtonSelector}"]`).addClass('is-disabled-block');
            }

            AdminFn_cl.addChangedAttribute(AttachedSettingInput);
        });

        /**
         * Blocks hide/show system based on select value
         * Usage:
         * <select blocks-to-hide=".elements-to-hide">
         *     <option block-to-show=".element1">Option 1</option>
         *     <option block-to-show=".element2, .element3">Option 2</option>
         * </select>
         * 
         * Attributes:
         * - blocks-to-hide: Selector for all elements that should be hidden initially
         * - block-to-show: Selector for elements to show when option is selected
         * 
         * Note: Multiple selectors can be comma-separated in block-to-show
         */
        $(document).on('change', 'select[blocks-to-hide]', function () {
            // Hide all blocks first
            $($(this).attr('blocks-to-hide')).hide();

            // Get selector for blocks to show
            const showSelector = $(this).find('option:selected').attr('block-to-show');

            // Show selected blocks if any
            if (showSelector) {
                $(showSelector).show();
            }
        });
        $('select[blocks-to-hide]').change();



        // dynamic-elements
        $(".cl-add-dynamic-element").on('click', function () {
            const actionToDo = $(this).attr('actionToDo');

            switch (actionToDo) {
                case 'duplicate':
                    const $container = $(this).closest(".variations-elements");
                    const element = $container.find(".c-element").last().clone(true);

                    // Reset form elements to defaults
                    element.find("[elementName]").each(function () {
                        $(this).val($(this).attr('defaultValue'));
                    });

                    $container.find(".dynamic-elements").append(element);

                    break;

                case 'showModal':
                default:
                    const modal_title = $(this).attr('modal_title');
                    const dynamicElContainer = $(this).attr("dynamic-elements-container");
                    DynamicElements_cl.addNew(modal_title, dynamicElContainer);
            }


        });

        $(".dynamic-elements .deleteElement").on('click', function ($e) {
            const skip_normal_delete = $(this).attr("skip_normal_delete");
            if (skip_normal_delete != "yes" && confirm(jsLang.delete_confirm_msg) == true) {
                $(this).closest(".c-element").remove();
            }

        });


        //--- Add new sub dynamique elements
        $(".cl-add-dynamic-subelement").on('click', function ($e) {
            const subElement = $(this).closest(".c-element").find(".c-sub-element").last().clone(true);

            $(subElement).find("[subElementName]").each(function (index, node) {
                var defaultValue = $(node).attr('defaultValue');
                $(node).val(defaultValue);
            });

            $(this).closest(".c-element").find(".sub-dynamic-elements").append(subElement);
        });

        $(".deleteSubElement").on('click', function () {
            $(this).closest(".c-sub-element").remove();
        });


        // Handle the click event on the image selection button
        $('.cl-image-selector').click(function () {
            var btElement = $(this);
            // Create a new media frame
            var mediaFrame = wp.media({
                title: 'Select Custom Image',
                multiple: false,
                library: {type: 'image'},
                button: {text: 'Select'}
            });

            // Handle image selection
            mediaFrame.on('select', function () {
                var attachment = mediaFrame.state().get('selection').first().toJSON();
                btElement.find(".cl_img_id").val(attachment.id);
                btElement.find(".cl_img_url").val(attachment.url);
                btElement.find("img").attr("src", attachment.url);
            });

            btElement.find("input").change();


            // Open the media frame
            mediaFrame.open();
        });

    });

})(jQuery);