jQuery(function($){
    $('body').on('click', '.clfe_select_category_img', function(e) {
        e.preventDefault();
        aw_uploader = wp.media({
            title: 'Custom image',
            button: {
                text: 'Use this image'
            },
            multiple: false
        }).on('select', function() {
            var attachment = aw_uploader.state().get('selection').first().toJSON();
            $(".clfe_category_img_url img").attr("src", attachment.url);
            $('.clfe_category_img_url input').val(attachment.url);
        })
        .open();
    });
});