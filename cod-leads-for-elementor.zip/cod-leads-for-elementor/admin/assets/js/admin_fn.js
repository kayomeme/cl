(function ($) {
    /**
     * Admin function
     *
     * @since x.x.x
     */
    AdminFn_clfe = {

        init: function () {

        },
        autoSaveSettings: function () {
            $('.clfe-save-global-settings').click();
        },
        closeActiveModals: function () {
            $(".ui-dialog .ui-dialog-buttonset .ui-button:first-child").click();
        },
        addChangedAttribute: function (el) {
            el.attr('clfe_ischanged', 'yes');
        },
        getFormDatas: function (containerId) {
            var formData = {};
            var existRequiredElement = false;

            // dynamique elements retrieve data
            DynamicElements_clfe.setDatas();

            const container = '#' + containerId;

            $(container).find(".clfe_sys_params input[name]").each(function (index, node) {
                var isRequired = $(this).attr("isRequired");

                if (isRequired == 'yes' && node.value === '') {
                    existRequiredElement = true;
                }

                formData[node.name] = AdminFn_clfe.special_char_replace(node.value);
            });


            $(container).find("input[clfe_ischanged]").each(function (index, node) {
                var isRequired = $(this).attr("isRequired");

                if (isRequired == 'yes' && node.value === '') {
                    existRequiredElement = true;
                }

                // check if style element input
                if ($(this).hasClass('clfe-style-value')) {
                    formData[node.name] = node.value;
                } else {
                    formData[node.name] = AdminFn_clfe.special_char_replace(node.value);
                }

            });

            $(container).find("select[clfe_ischanged]").each(function (index, node) {
                var isRequired = $(this).attr("isRequired");

                if (isRequired == 'yes' && node.value === '') {
                    existRequiredElement = true;
                }
                formData[node.name] = AdminFn_clfe.special_char_replace(node.value);
            });

            $(container).find("textarea[name]").each(function (index, node) {
                var isRequired = $(this).attr("isRequired");
                if (isRequired == 'yes' && node.value === '') {
                    existRequiredElement = true;
                }

                // if is wp tinyMCE
                if ($(this).hasClass("wp-editor-area")) {
                    formData[node.name] = AdminFn_clfe.getTinyMCE_content($(this).attr("id"));
                } else {
                    formData[node.name] = node.value;
                }
            });

            if (existRequiredElement) {
                return false;
            } else {
                return formData;
            }
        },
        openStyleModal: function (clickedEl, ev) {
            AdminFn_clfe.closeActiveModals();

            ev.preventDefault();
            const targetModalID = clickedEl.attr('href');
            const modalTitle = clickedEl.attr('modalTitle');
            const celement = $(targetModalID);

            //celement.parent().find("fieldset:first-child .clfe-accordion").addClass("active");
            celement.dialog({
                open: function (event, ui) {
                    // Make the element interactable
                    $(".clfe-preview-container").css("pointer-events", "auto");
                },
                create: function (event, ui) {
                    // Set maxWidth
                    $(this).css("maxWidth", "660px");
                },
                classes: {
                    "ui-dialog": "highlight"
                },
                title: modalTitle,
                resizable: false,
                height: "auto",
                width: $(window).width() > 800 ? 500 : 'auto',
                modal: false,
                buttons: {
                    "Cancel": function () {
                        $(this).dialog("close");
                    },
                    "Save": function () {
                        $(this).dialog("close");
                        $(".clfe-save-global-settings").click();
                    }
                },
                close: function () {
                    $(this).dialog("destroy");
                }
            });
        },
        /*
         * 
         */
        getTinyMCE_content: function (idTextarea) {
            // get the content of the wp_editor
            var content = '';
            if (typeof tinyMCE !== 'undefined' && tinyMCE.get(idTextarea) && !tinyMCE.get(idTextarea).isHidden()) {
                content = tinyMCE.get(idTextarea).getContent();
            } else {
                content = $('#' + idTextarea).val();
            }

            return content;
        },
        special_char_replace: function (stringg) {
            stringg = stringg.replace(/&quot;/g, '"');
            //stringg=stringg.replace(/'/g , "&#39;");  
            return stringg;
        },
        sendAjaxRequest: function (clfe_controller, clfe_action, formdata) {
            //var formdata = AdminFn_clfe.getFormDatas(clfe_action);

            formdata['clfe_controller'] = clfe_controller;
            formdata['clfe_action'] = clfe_action;

            formdata['action'] = jsArgs.ajax_admin_action;
            $.ajax({
                url: jsArgs.ajax_url,
                type: "POST",
                async: true,
                data: formdata,
                success: function (data, textStatus, jqXHR) {
                    // You can craft something here to handle the message return
                    if (data == '') {
                        var data = '{"code":0,"msg":"Undefined error try again","result":null}';
                    }

                    var extract_data = data.match(/{"code"(.*)}/).pop();
                    extract_data = '{"code"' + extract_data + '}';
                    var response = jQuery.parseJSON(extract_data);

                    jsArgs['message'] = response.msg;
                    jsArgs.lastResponse = response;

                    // Trigger a custom event to detect the jsArgs change in other js files
                    document.dispatchEvent(new Event(clfe_action + 'lastResponse'));


                    //fn_success(response);
                    AdminFn_clfe.msgSuccessAjax(response, clfe_action);
                    AdminFn_clfe.afterSendAjaxRequest(clfe_action, response);

                    var res = response.res;

                    if (res && res.reload) {
                        location.reload();
                    }
                    if (res && res.redirect_to) {
                        window.location = res.redirect_to;
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    AdminFn_clfe.msgErrorAjax(clfe_action, jqXHR);
                }
            });
        },
        beforeSendAjaxRequest: function(clfe_action) {
           const selector = $(`#${clfe_action} .clfe-user-fedback`).length ? `#${clfe_action}` : '#clfe-sticky-bottom-bar';
           const waitHtml = `<div class="clfe-wait"><img src="${jsArgs.site_url}/wp-admin/images/wpspin_light.gif" alt="Please wait..." title="Please wait..." /></div>`;

           $(`${selector} .clfe-user-fedback`).removeClass('error-fedback success-fedback').html(waitHtml);
        },
        afterSendAjaxRequest: function (clfe_action, response) {
            if (clfe_action) {
                if (response.msg != '') {
                    $("#" + clfe_action + " .clfe-user-fedback:last").show();
                    $("#" + clfe_action + " .clfe-user-fedback:last .clfe-msg_box .alert").html(response.msg);
                    $("#" + clfe_action + " .content_save_button:last").css({'display': 'block'});
                }
            }

            /*
             * reLoad the checkout preview after each settings save and ajax end request
             */
            if (clfe_action == 'clfe_save_global_settings') {
                $('#bt-load-preview').click();
                $('#bt-load-preview').click();
            }
        },
        msgSuccessAjax: function (response, clfe_action) {
            const selector = $(`#${clfe_action} .clfe-user-fedback`).length ? `#${clfe_action}` : '#clfe-sticky-bottom-bar';

            const usedFeeback = $(`${selector} .clfe-user-fedback`);
            usedFeeback.removeClass(`${response.code === 1 ? 'error-fedback' : 'success-fedback'}`);
            usedFeeback.addClass(`${response.code === 1 ? 'success-fedback' : 'error-fedback'}`);
            usedFeeback.html(response.msg).show();
        },
        msgErrorAjax: function (clfe_action, jqXHR) {
            const selector = $(`#${clfe_action} .clfe-user-fedback`).length ? `#${clfe_action}` : '#clfe-sticky-bottom-bar';
            
            let errorMessage = 'An error occurred while loading data.';
   
            if (jqXHR.status === 404) {
                errorMessage = 'The requested resource was not found.';
            } else if (jqXHR.status === 500) {
                errorMessage = 'A server error occurred.';
            } else if (jqXHR.status === 403) {
                errorMessage = 'Access denied.';
            }

            const usedFeeback = $(`${selector} .clfe-user-fedback`);
            usedFeeback.removeClass('success-fedback').addClass('error-fedback').html(errorMessage).show();
        },
        removeDomElementWithAnimation: function (selector) {
           $(selector).animate(
               {opacity: 0, marginLeft: '0%'}, 
               900, 
               function() {
                   $(this).slideUp(600, function() {
                       $(this).remove();
                   });
               }
           );
        }
    };

    $(function () {
        AdminFn_clfe.init();
    });

    $(document).ready(function () {
        // start : clfe_ischanged to-do
        $('body').on('change', 'input, select, textarea', function () {
            const $this = $(this);

            AdminFn_clfe.addChangedAttribute($this);
        });

        // Function to monitor changes and add an attribute automatically
        function monitorInputChanges(selector, attributeName, attributeValue) {
            // Select the inputs based on the selector
            const inputs = document.querySelectorAll(selector);

            inputs.forEach(input => {
                // Store the original value property descriptor
                const originalDescriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');

                // Redefine the property
                Object.defineProperty(input, 'value', {
                    get() {
                        return originalDescriptor.get.call(this);
                    },
                    set(newValue) {
                        // Call the original setter
                        originalDescriptor.set.call(this, newValue);

                        // Add the custom attribute
                        this.setAttribute(attributeName, attributeValue);
                    }
                });
            });
        }
        // Usage: Add "clfe_ischanged='yes'" to all inputs when their value is changed programmatically
        monitorInputChanges('input', 'clfe_ischanged', 'yes');
        // end : clfe_ischanged

        // Dynamic vars copy system
        $(document).on('click', '.clfe-var-list li', function() {
            const $this = $(this);
            const text = $this.text();

            const temp = $('<div>').html(text).attr('contenteditable', true).appendTo('body');
            const range = document.createRange();
            const sel = window.getSelection();

            range.selectNodeContents(temp[0]);
            sel.removeAllRanges();
            sel.addRange(range);
            document.execCommand('copy');

            temp.remove();
            $this.text('Copied!');
            setTimeout(() => $this.text(text), 2000);
        });


    });

})(jQuery);