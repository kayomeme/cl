(function ($) {
    /**
     * Admin function
     *
     * @since x.x.x
     */
    AdminFn_cl = {

        init: function () {
            
        },
        autoSaveSettings: function () {
            $('.cl-save-global-settings').click();
        },
        closeActiveModals: function () {
            $(".ui-dialog .ui-dialog-buttonset .ui-button:first-child").click();
        },
        addChangedAttribute: function (el) {
            el.attr('cl-ischanged', 'yes');
        },
        getFormDatas: function (containerId) {
            var formData = {};
            var existRequiredElement = false;

            // dynamique elements retrieve data
            DynamicElements_cl.setDatas();

            const container = '#' + containerId;

            $(container).find(".cl_sys_params input[name]").each(function (index, node) {
                var isRequired = $(this).attr("isRequired");

                if (isRequired == 'yes' && node.value === '') {
                    existRequiredElement = true;
                }

                formData[node.name] = AdminFn_cl.special_char_replace(node.value);
            });


            $(container).find("input[cl-ischanged]").each(function (index, node) {
                var isRequired = $(this).attr("isRequired");

                if (isRequired == 'yes' && node.value === '') {
                    existRequiredElement = true;
                }

                // check if style element input
                if ($(this).hasClass('cl-style-value')) {
                    formData[node.name] = node.value;
                } else {
                    formData[node.name] = AdminFn_cl.special_char_replace(node.value);
                }

            });

            $(container).find("select[cl-ischanged]").each(function (index, node) {
                var isRequired = $(this).attr("isRequired");

                if (isRequired == 'yes' && node.value === '') {
                    existRequiredElement = true;
                }
                formData[node.name] = AdminFn_cl.special_char_replace(node.value);
            });

            $(container).find("textarea[name]").each(function (index, node) {
                var isRequired = $(this).attr("isRequired");
                if (isRequired == 'yes' && node.value === '') {
                    existRequiredElement = true;
                }

                // if is wp tinyMCE
                if ($(this).hasClass("wp-editor-area")) {
                    formData[node.name] = AdminFn_cl.getTinyMCE_content($(this).attr("id"));
                } else {
                    formData[node.name] = node.value;
                }
            });

            if (existRequiredElement) {
                return false;
            } else {
                return formData;
            }
        },
        /*
         * 
         */
        getTinyMCE_content: function (idTextarea) {
            // get the content of the wp_editor
            var content = '';
            if (typeof tinyMCE !== 'undefined' && tinyMCE.get(idTextarea) && !tinyMCE.get(idTextarea).isHidden()) {
                content = tinyMCE.get(idTextarea).getContent();
            } else {
                content = $('#' + idTextarea).val();
            }

            return content;
        },
        special_char_replace: function (stringg) {
            stringg = stringg.replace(/&quot;/g, '"');
            //stringg=stringg.replace(/'/g , "&#39;");  
            return stringg;
        },
        sendAjaxRequest: function (cl_controller, cl_action, formdata) {
            //var formdata = AdminFn_cl.getFormDatas(cl_action);

            formdata['cl_controller'] = cl_controller;
            formdata['cl_action'] = cl_action;
            
            //this will be used to class loader to test the current page
            formdata['page'] = currentUrlParms?.get('page') || '';

            formdata['action'] = jsArgs.ajax_admin_action;
            $.ajax({
                url: jsArgs.ajax_url,
                type: "POST",
                async: true,
                data: formdata,
                success: function (data, textStatus, jqXHR) {
                    // You can craft something here to handle the message return
                    if (data == '') {
                        var data = '{"code":0,"msg":"Undefined error try again","result":null}';
                    }

                    var extract_data = data.match(/{"code"(.*)}/).pop();
                    extract_data = '{"code"' + extract_data + '}';
                    var response = jQuery.parseJSON(extract_data);

                    jsArgs['message'] = response.msg;
                    jsArgs.lastResponse = response;

                    // Trigger a custom event to detect the jsArgs change in other js files
                    document.dispatchEvent(new Event(cl_action + 'lastResponse'));


                    //fn_success(response);
                    AdminFn_cl.msgSuccessAjax(response, cl_action);
                    AdminFn_cl.afterSendAjaxRequest(cl_action, response);

                    var res = response.res;

                    if (res && res.reload) {
                        location.reload();
                    }
                    if (res && res.redirect_to) {
                        window.location = res.redirect_to;
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    AdminFn_cl.msgErrorAjax(cl_action, jqXHR);
                }
            });
        },
        beforeSendAjaxRequest: function(cl_action) {
           const selector = $(`#${cl_action} .cl-user-fedback`).length ? `#${cl_action}` : '#cl-sticky-bottom-bar';
           const waitHtml = `<div class="cl-wait"><img src="${jsArgs.site_url}/wp-admin/images/wpspin_light.gif" alt="Please wait..." title="Please wait..." /></div>`;

           $(`${selector} .cl-user-fedback`).removeClass('error-fedback success-fedback').html(waitHtml);
        },
        afterSendAjaxRequest: function (cl_action, response) {
            if (cl_action) {
                if (response.msg != '') {
                    $("#" + cl_action + " .cl-user-fedback:last").show();
                    $("#" + cl_action + " .cl-user-fedback:last .cl-msg_box .alert").html(response.msg);
                    $("#" + cl_action + " .content_save_button:last").css({'display': 'block'});
                }
            }

            /*
             * reLoad the checkout preview after each settings save and ajax end request
             */
            if (cl_action == 'cl_save_global_settings') {
                $('#bt-load-preview').click();
                $('#bt-load-preview').click();
            }
        },
        msgSuccessAjax: function (response, cl_action) {
            const selector = $(`#${cl_action} .cl-user-fedback`).length ? `#${cl_action}` : '#cl-sticky-bottom-bar';

            const usedFeeback = $(`${selector} .cl-user-fedback`);
            usedFeeback.removeClass(`${response.code === 1 ? 'error-fedback' : 'success-fedback'}`);
            usedFeeback.addClass(`${response.code === 1 ? 'success-fedback' : 'error-fedback'}`);
            usedFeeback.html(response.msg).show();
        },
        msgErrorAjax: function (cl_action, jqXHR) {
            const selector = $(`#${cl_action} .cl-user-fedback`).length ? `#${cl_action}` : '#cl-sticky-bottom-bar';
            
            let errorMessage = 'An error occurred while loading data.';
   
            if (jqXHR.status === 404) {
                errorMessage = 'The requested resource was not found.';
            } else if (jqXHR.status === 500) {
                errorMessage = 'A server error occurred.';
            } else if (jqXHR.status === 403) {
                errorMessage = 'Access denied.';
            }

            const usedFeeback = $(`${selector} .cl-user-fedback`);
            usedFeeback.removeClass('success-fedback').addClass('error-fedback').html(errorMessage).show();
        },
        removeDomElementWithAnimation: function (selector) {
           $(selector).animate(
               {opacity: 0, marginLeft: '0%'}, 
               900, 
               function() {
                   $(this).slideUp(600, function() {
                       $(this).remove();
                   });
               }
           );
        },
        setCookie: function(name, value, days = 30) {
            const expires = new Date();
            expires.setTime(expires.getTime() + (days * 24 * 60 * 60 * 1000));
            document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
        },
        getCookie: function(name) {
            const nameEQ = name + "=";
            const ca = document.cookie.split(';');
            for(let i = 0; i < ca.length; i++) {
                let c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
            }
            return null;
        }
    };

    $(function () {
        AdminFn_cl.init();
    });

    $(document).ready(function () {
        // start : cl-ischanged to-do
        $('body').on('change', 'input, select, textarea', function () {
            const $this = $(this);

            AdminFn_cl.addChangedAttribute($this);
        });
        
        
        /*------toggle and toogle checkout sections-------*/
        $(".admin_toggle_header").on('click', function (ev) {

            const $toggleHeader = $(this);
            
            const $toggleContainer = $toggleHeader.closest(".admin_toggle_block");
            const $toggleBody = $toggleContainer.find(".admin_toggle_body");

            const is_open = $toggleContainer.attr("is_open");
            const newState = is_open === "yes" ? "no" : "yes";

            // CSS handles the visibility based on state
            $toggleContainer.attr("is_open", newState);

            // Handle modal display type
            $toggleHeader.next('.admin_modal').css("display", newState === "yes" ? "block" : "none");
            
            $toggleContainer.next('.admin_toggle_block').attr("is_open", 'no');
            $toggleContainer.prev('.admin_toggle_block').attr("is_open", 'no');

            ev.preventDefault();
            ev.stopPropagation();
        });
        
        /*----------toogle system-----------*/
        
        /*---------- Admin modal system-----------*/      
        $(".admin_modal").on('click', function (e) {
            // Close modal only if clicking on the modal backdrop (not inside the modal body)
            if (e.target === this) {
                $(this).prev('.cl_toggle_header').click();
                $(this).hide();
            }
        });
        
        $(".admin_modal_close").on('click', function () {
            $(this).closest(".admin_modal").prev('.cl_toggle_header').click();
            $(this).closest(".admin_modal").hide();
        });
        
        /*---------- Admin Modal system-----------*/
        

        // Function to monitor changes and add an attribute automatically
        function monitorInputChanges(selector, attributeName, attributeValue) {
            // Select the inputs based on the selector
            const inputs = document.querySelectorAll(selector);

            inputs.forEach(input => {
                // Store the original value property descriptor
                const originalDescriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');

                // Redefine the property
                Object.defineProperty(input, 'value', {
                    get() {
                        return originalDescriptor.get.call(this);
                    },
                    set(newValue) {
                        // Call the original setter
                        originalDescriptor.set.call(this, newValue);

                        // Add the custom attribute
                        this.setAttribute(attributeName, attributeValue);
                    }
                });
            });
        }
        // Usage: Add "cl-ischanged='yes'" to all inputs when their value is changed programmatically
        monitorInputChanges('input', 'cl-ischanged', 'yes');
        // end : cl-ischanged

        // Dynamic vars copy system
        $(document).on('click', '.cl-var-list li', function() {
            const $this = $(this);
            const text = $this.text();

            const temp = $('<div>').html(text).attr('contenteditable', true).appendTo('body');
            const range = document.createRange();
            const sel = window.getSelection();

            range.selectNodeContents(temp[0]);
            sel.removeAllRanges();
            sel.addRange(range);
            document.execCommand('copy');

            temp.remove();
            $this.text('Copied!');
            setTimeout(() => $this.text(text), 2000);
        });
    });
    
    $(window).on('load', function () {

    });

})(jQuery);