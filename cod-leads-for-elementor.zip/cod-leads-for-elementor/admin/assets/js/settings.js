(function ($) {
    /**
     * GlobalSettings function
     */
    GlobalSettingsFn_clfe = {

        init: function () {

        },
        addNewSettingsModel: function () {
            const clfe_controller = 'clfe_global_settings';
            const clfe_action = 'clfe_save_new_model_settings';
            const formdata = this.getFormDatas(clfe_action);

            const celement = $(".model-settings-form .model-settings-content").clone(true);
            const modalElement = $('<div class="clfe-modal-container" id="' + clfe_action + '"></div>');

            modalElement.append(celement);
            modalElement.dialog({
                title: $(this).attr('modalTitle'),
                modal: true,
                width: "60%",
                buttons: {
                    "Cancel": function () {
                        $(this).dialog("close");
                    },
                    "Save": function () {
                        AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
                        AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formdata);
                    }
                },
                close: function () {
                    $(this).dialog("destroy");
                }
            });
        },
        updateSingleCssPropertyInStyleString: function (styleString, fullProperty) {
            // Extract property name from the full property string
            const propertyName = fullProperty.split(':')[0];

            // Split the style string into individual properties
            let properties = styleString.split(';')
                .filter(prop => prop.trim() !== '');

            // Find and update the matching property
            let found = false;
            let updatedProperties = properties.map(prop => {
                if (prop.trim().startsWith(propertyName + ':')) {
                    found = true;
                    return fullProperty;
                }
                return prop;
            });

            // If property wasn't found, add it
            if (!found) {
                updatedProperties.push(fullProperty);
            }

            // Join properties back together
            return updatedProperties.join(';') + ';';
        }
    };

    $(function () {
        GlobalSettingsFn_clfe.init();
    });

    /*let currentUrl = window.location.search; 
     let currentUrlParms = new URLSearchParams(currentUrl);*/

    $(document).ready(function () {

        $('.clfe-style input[type="number"]').niceNumber({
            autoSize: true,
            // the number of extra character
            autoSizeBuffer: 1,
            buttonDecrement: '-',
            buttonIncrement: "+",
            buttonPosition: 'around', // 'around', 'left', or 'right'
            onDecrement: function (ev) {
                $(ev).change();
            },
            onIncrement: function (ev) {
                $(ev).change();
            }

        });

        $('.clfe-style-color').minicolors({
            animationSpeed: 50,
            animationEasing: 'swing', // easing function
            // defers the change event from firing while the user makes a selection
            changeDelay: 0,
            control: 'hue', // hue, brightness, saturation, or wheel
            defaultValue: '',
            format: 'hex', // hex or rgb
            showSpeed: 100, // show/hide speed
            hideSpeed: 100,
            inline: false,
            keywords: 'transparent', // should accept (e.g. inherit, transparent, initial)
            letterCase: 'lowercase',
            opacity: true,
            position: 'bottom left',
            theme: 'default',
            // an array of colors that will show up under the main color
            swatches: [
                '#008744', '#0057e7', '#d62d20', '#ffa700',
                '#4b3832', '#854442', '#fff4e6', '#3c2f2f', '#be9b7b',
                '#d9534f', '#f9f9f9', '#5bc0de', '#5cb85c', '#428bca',
                '#3399ff', '#ff80ed', '#065535', '#ffc0cb', '#eeeeee', '#ff7f50', '#ffa500',
                '#a0db8e', '#bada55', '#333333', '#ffffff', '#133337', '#ffc0cb', '#c39797',
                '#cc0000', '#088da5', '#daa520', '#008000', '#f08080', '#faebd7', '#ffff66',
            ]

        });

        // dragable elemnts
        $(".google-sheet-columns .dynamic-elements").sortable();
        $(".variations-container .dynamic-elements").sortable();
        $(".qty-offers-container .dynamic-elements").sortable();


        if (!currentUrlParms.has('compo') && currentUrlParms.get('page') == 'clfe_global_settings') {
            currentUrlParms.set('tab', 'clfe_title_and_image_tab');
            currentUrlParms.set('compo', 'product');
            window.history.replaceState(null, null, '?' + currentUrlParms.toString());
        }

        if (!currentUrlParms.has('settings_model_id') && currentUrlParms.get('page') == 'clfe_global_settings') {
            currentUrlParms.set('settings_model_id', '0');
            window.history.replaceState(null, null, '?' + currentUrlParms.toString());
        }

        $(".global-select-setting-models").on('change', function () {
            currentUrlParms.set('settings_model_id', $(this).val());
            window.history.replaceState(null, null, '?' + currentUrlParms.toString());
            location.reload();
        });

        /*
         * Add new settings model
         */
        $(".clfe-add-new-settings-model").on('click', function () {
            GlobalSettingsFn_clfe.addNewSettingsModel();
        });



        /*
         * style modal system
         */
        $('.clfe-button-style').on('click', function (ev) {
            AdminFn_clfe.openStyleModal($(this), ev);
        });

        /*
         * save global settings
         */
        $('.clfe-save-global-settings').on('click', function (ev) {
            ev.preventDefault();

            const clfe_controller = 'clfe_global_settings';
            const clfe_action = 'clfe_save_global_settings';

            const formdata = AdminFn_clfe.getFormDatas(clfe_action);

            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formdata);

        });



        $('.clfe-copy-textarea-text').on("click", function () {
            const attachedTextareaName = $(this).attr("attachedTextarea");
            $("textarea[name=" + attachedTextareaName + "]").select();
            document.execCommand("copy");
            alert("Content copied to clipboard!");
        });

        // kayo accordion for glabal settings
        $(".clfe-accordion-container fieldset").find(".clfe-accordion-panel").hide();
        $(".clfe-direct-style fieldset").find(".clfe-accordion-panel").show();

        $(".clfe-style .clfe-accordion").on('click', function () {
            $(this).closest(".clfe-accordion-container").find(".clfe-accordion-panel").hide();
            $(this).closest(".clfe-accordion-container").find(".clfe-accordion").removeClass("active");
            $(this).closest("fieldset").find(".clfe-accordion-panel").show();
            $(this).closest("fieldset").find(".clfe-accordion").addClass("active");

        });


        // Optimize the use settings setup
        /*
         * Add a custom CSS class to the current section settings to provide the user with a visual focus.
         */
        $('.clfe-row').on('click', function (ev) {
            $('.clfe-row').removeClass('clfe-row-is-active');
            $(this).addClass('clfe-row-is-active');

        });


        /*
         * Single css property
         */
        $('.clfe-single-css-property input').on('change', function() {
            const $this = $(this);
            const $parent = $this.closest('.clfe-single-css-property');
            const $target = $(`input[name=${$parent.attr('style_name')}]`);

            const property = `${$this.attr('style_key')}:${$this.val()}${$this.attr('ext')};`;

            $target.val(GlobalSettingsFn_clfe.updateSingleCssPropertyInStyleString($target.val(), property)).trigger('change');
        });
        
        //style system management-----------------------------------
        //init all the select box option with the the choosing value
        $("select.clfe-style-element").each(function (index, node) {
            var selectValue = $(this).attr('value');
            $(this).find("option").each(function () {
                var optionValue = $(this).val();
                if (selectValue == optionValue) {
                    $(this).attr('selected', 'selected');
                }
            });
        });
        
        $(".clfe-style-element").on('change', function() {
            const $container = $(this).closest(".clfe-style");
            const $styleValue = $container.find(".clfe-style-value");
            const styleName = $styleValue.attr('name');

            const mainStyles = $container.find(".clfe-style-element").map(function() {
                const value = $(this).val();
                if (value !== '' && value != null) {
                    return $(this).attr("style_key") + ":" + value + $(this).attr("ext");
                }
            }).get().filter(Boolean);

            const singleStyles = $(`.clfe-single-css-property[style_name=${styleName}] .clfe-single-style-element`).map(function() {
                const value = $(this).val();
                if (value !== '' && value != null) {
                    return $(this).attr("style_key") + ":" + value + $(this).attr("ext");
                }
            }).get().filter(Boolean);

            // Combine all styles and update
            const combinedStyles = mainStyles.concat(singleStyles).join(';') + ';';
            $styleValue.val(combinedStyles).trigger('change');
        });
        
        // fontsize extion handler
        $(".clfe-size-ext").on('change', function() {
             const $container = $(this).closest(".clfe-size-input-container");
             $container.find(".clfe-style-number").attr('ext', $(this).val());
             
             $(".clfe-style-element").change();
        });

        // box-shadow generator
        $(".clfe-box-shadow .key input").on('change', function () {
            var generated_style = "";

            var horizontalshadowlength = $(this).closest(".clfe-box-shadow").find(".horizontal-shadow-length").val() + "px";
            var verticalshadowlength = $(this).closest(".clfe-box-shadow").find(".vertical-shadow-length").val() + "px";
            var blurradius = $(this).closest(".clfe-box-shadow").find(".blur-radius").val() + "px";
            var spreadradius = $(this).closest(".clfe-box-shadow").find(".spread-radius").val() + "px";
            var shadowColor = $(this).closest(".clfe-box-shadow").find(".shadow-Color").val();

            generated_style = horizontalshadowlength + " " + verticalshadowlength + " " + blurradius + " " + spreadradius + " " + shadowColor + ";";

            $(this).closest(".clfe-box-shadow").find("input[style_key=box-shadow]").val(generated_style);
            $(".clfe-style-element").change();
        });

        // text-shadow generator
        $(".clfe-text-shadow .key input").on('change', function () {
            var generated_style = "";

            var horizontalshadowlength = $(this).closest(".clfe-text-shadow").find(".horizontal-shadow-length").val() + "px";
            var verticalshadowlength = $(this).closest(".clfe-text-shadow").find(".vertical-shadow-length").val() + "px";
            var blurradius = $(this).closest(".clfe-text-shadow").find(".blur-radius").val() + "px";
            //var spreadradius = $(this).closest(".clfe-text-shadow").find(".spread-radius").val()+"px";
            var shadowColor = $(this).closest(".clfe-text-shadow").find(".shadow-Color").val();

            generated_style = horizontalshadowlength + " " + verticalshadowlength + " " + blurradius + " " + shadowColor + ";";

            $(this).closest(".clfe-text-shadow").find("input[style_key=text-shadow]").val(generated_style);
            $(".clfe-style-element").change();
        });


        // linear-gradient generator
        $(".clfe-linear-gradient .key input").on('change', function () {
            var generated_style = "";

            var linearGradientDeg = $(this).closest(".clfe-linear-gradient").find(".linear-gradient-deg").val() + "deg";
            var linearGradientColor1 = $(this).closest(".clfe-linear-gradient").find(".linear-gradient-color1").val();
            var linearGradientColor2 = $(this).closest(".clfe-linear-gradient").find(".linear-gradient-color2").val();

            generated_style = "linear-gradient(" + linearGradientDeg + "," + linearGradientColor1 + "," + linearGradientColor2 + ");";

            $(this).closest(".clfe-linear-gradient").find("input[style_key=background-image]").val(generated_style);
            $(".clfe-style-element").change();
        });

    });



})(jQuery);