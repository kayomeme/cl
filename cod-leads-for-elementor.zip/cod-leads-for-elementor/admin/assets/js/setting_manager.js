(function ($) {
    SettingManager_cl = {
        ///currentCssData: '',

        init: function() {
            // dragable elemnts
            $(".google-sheet-columns .dynamic-elements").sortable();
            $(".variations-container .dynamic-elements").sortable();
            //$(".qtyoffers-container .dynamic-elements").sortable();


            if (!currentUrlParms.has('compo') && currentUrlParms.get('page') == 'cl_global_settings') {
                currentUrlParms.set('tab', 'cl_title_and_image_tab');
                currentUrlParms.set('compo', 'product');
                window.history.replaceState(null, null, '?' + currentUrlParms.toString());
            }

            if (!currentUrlParms.has('settings_model_id') && currentUrlParms.get('page') == 'cl_global_settings') {
                currentUrlParms.set('settings_model_id', '0');
                window.history.replaceState(null, null, '?' + currentUrlParms.toString());
            }

            $(".global-select-setting-models").on('change', function () {
                currentUrlParms.set('settings_model_id', $(this).val());
                window.history.replaceState(null, null, '?' + currentUrlParms.toString());
                location.reload();
            });
        },
        toggleInheritNumberSelect: function ($select) {
            const $input = $select.closest('.cl-td').find('.inherit-number-input');
            if ($select.val() === 'custom') {
                $input.attr('type', 'number').removeClass('cl-hide');
                $input.val($input.attr('default-value')).focus();
            } else { 
                $input.attr('type', 'hidden').addClass('cl-hide').val('inherit');
            }
        }

    };
    
    $(function () {
        SettingManager_cl.init();
    });

    $(document).ready(function () {
        
        /*
         * save global settings
         */
        $('.cl-save-global-settings').on('click', function (ev) {
            ev.preventDefault();

            const cl_controller = 'cl_global_settings';
            const cl_action = 'cl_save_global_settings';

            const formdata = AdminFn_cl.getFormDatas(cl_action);

            AdminFn_cl.beforeSendAjaxRequest(cl_action);
            AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formdata);
            
            // Wait for the custom event before accessing the modified variable
            document.addEventListener(cl_action + 'lastResponse', function (event) {

                if (jsArgs.lastResponse.code === 1) {
                    const $isChanged = $('.cl_select_version').attr('cl-ischanged');
                    if( $isChanged === 'yes' ) {
                        location.reload();
                    }
                }
            });

        });

        // This single event handler works for all '.inherit-number-select' elements,
        $(document).on('change', '.inherit-number-select', function() {
            SettingManager_cl.toggleInheritNumberSelect($(this));
        });
        
        
        $('.cl-copy-textarea-text').on("click", function () {
            const attachedTextareaName = $(this).attr("attachedTextarea");
            $("textarea[name=" + attachedTextareaName + "]").select();
            document.execCommand("copy");
            alert("Content copied to clipboard!");
        });



        // Add a custom CSS class to the current section settings to provide the user with a visual focus.
        $('.cl-row').on('click', function (ev) {
            $('.cl-row').removeClass('cl-row-is-active');
            $(this).addClass('cl-row-is-active');

        });

    });
})(jQuery);