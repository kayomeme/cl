<?php

class SettingsModelBK_cl {
    private static $tableName = 'setting_models';


    public static function insert($args) {   
        $data = [
            'name'                      => $args['model_name'],
            'lang_code'                 => $args['model_lang_code'],
            'lang_direction'            => $args['model_lang_direction'],
            'duplicate_from_model_id'   => (int)$args['duplicate_from_model_id'],
        ];
        
        $response = adminDB_cl::insert(self::$tableName, $data);
        
        if( $response->code == 0 ) {
            $response->msg = Lang_cl::__('Please use a valid name, ensuring that the name is not already in use.', 'cl');
            return $result;
        }
        
        $newModelID = $response->res['insert_id'];
        
        /*
         * create all the compo options for the new model like the checkout, product ..
         * the new model options will be duplicated from the choosing model and the lang
         */
        self::createNewModelCompoOptions($newModelID, $data['duplicate_from_model_id'], $data['lang_code'], $data['lang_direction']);

        return $response;
    }
    
    private static function createNewModelCompoOptions($newModelID, $duplicateFromModelID, $langCode, $langDirection) {
        $langs = require MainApp_cl::$pluginPath.'languages/comps/'.$langCode.'.php';
        
        foreach (MainApp_cl::$compsOptionsNames as $compoName) {
            /*
             * get compo settings from choosing compo to duplicate from
             */
            $dbSettingName = $duplicateFromModelID ? $compoName.'_'.$duplicateFromModelID : $compoName;
            $compoSettings = get_option($dbSettingName);
            
            /*
             * applicate the choosing lang to the new model setting
             */
            foreach ($compoSettings as $key => $value) {
                if( isset( $langs[$compoName][$key] ) ) {
                    $compoSettings[$key] = $langs[$compoName][$key];
                }
            }
            
            // Apply the chosen language settings to the new models.
            if( $compoName == 'cl_system' ) {
                $compoSettings['langue_code']       = $langCode;
                $compoSettings['langue_direction']  = $langDirection;
            }
            
            update_option($compoName.'_'.$newModelID, $compoSettings);
        }
    }
    

    
    public static function deleteAllSettingModels() {
        global $wpdb;
        
        $tableName = $wpdb->prefix.self::$tableName;

        $counRowsDeleted    = $wpdb->query("DELETE FROM {$tableName}");
        return 'setting models deleted rows '.$counRowsDeleted.'------------<br/>';
    }
    
    public static function deleteAllModelsOptions($settingsModelId) {
        global $wpdb;
        
        $optionTableName    = $wpdb->prefix.'options';

        $countDeletedOptions = 0;
        foreach (MainApp_cl::$compsOptionsNames as $compoName) {
            delete_option($compoName.'_'.$settingsModelId);
            $countDeletedOptions++;
        }

        /* dont use for the default_settings that because is not deleting the cache related to each option*/
        // delete the created models options names
        $counRowsDeleted    = $wpdb->query("DELETE FROM {$optionTableName} WHERE `option_name` LIKE '%cl_%'");
        
        return 'options deleted rows '.$countDeletedOptions+$counRowsDeleted.'------------<br/>';
    }
    
    public static function deleteAllProductCustomModelID() {
        global $wpdb;
        
        $postmetaTableName    = $wpdb->prefix.'postmeta';
        $counRowsDeleted    = $wpdb->query("DELETE FROM {$postmetaTableName} WHERE meta_key='cl_settings_model_id'");
        
        return 'postmeta deleted rows '.$counRowsDeleted.'------------<br/>';
    }
    
    public static function GetLastPostId() {
        global $wpdb;

        $query = "SELECT ID FROM $wpdb->posts where post_type = 'post' and post_status = 'publish' ORDER BY ID DESC LIMIT 0,1";

        $result = $wpdb->get_results($query);
        $row = $result[0];
        $id = $row->ID;

        return $id;
    }
    
    public static function getExistingModels($limit) {
        global $wpdb;

        $tableName = $wpdb->prefix.self::$tableName;
        $query = "SELECT * FROM {$tableName} ORDER BY ID DESC LIMIT {$limit}";
        $result = $wpdb->get_results($query);

        return $result;
    }
}
