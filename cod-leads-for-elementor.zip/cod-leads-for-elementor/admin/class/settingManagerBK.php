<?php

class SettingManagerBK_cl {

    public $settings = [];
    public $settingGenerator = [];
    public $settingsPath;

    public function __construct($settings, $settingGenerator) {
        $this->settings = $settings;
        $this->settingGenerator = $settingGenerator;
        $this->settingsPath = AdminApp_cl::$viewsPath . 'setting_generator/';
    }

    
    
    function getInherit($key) {
        $value = $this->settings[$key];
        $type = $this->settingGenerator[$key]['type'];
        $title = $this->settingGenerator[$key]['title'];
        
        switch ($type) {
            case 'select':
                $defaultValues = $this->settingGenerator[$key]['options'];
                include $this->settingsPath . 'inherit/select.php';
                break;
            case 'number':
                $defaultValue = $this->settingGenerator[$key]['default-value'];
                include $this->settingsPath . 'inherit/number.php';
                break;
            
        }
    }
    
    public static function getBlockVersionsTemplate($compoName, $blockName, $currentVersion) {
        $blockFilePath = MainApp_cl::$compsPath . $compoName . '/backend/views/global_settings/blocks/' . $blockName . '/';
        $blockVersionsFile = $blockFilePath . 'versions.php';

        // Check if the versions file exists before requiring it
        if (!file_exists($blockVersionsFile)) {
            return; // or handle the error as appropriate
        }

        $blockVersions = require $blockVersionsFile;

        $versionsTemplateFile = AdminApp_cl::$viewsPath . 'versions_template.php';

        // Check if template file exists and blockVersions is not empty
        if (!empty($blockVersions) && file_exists($versionsTemplateFile)) {
            include $versionsTemplateFile;
        }      
    }







}
