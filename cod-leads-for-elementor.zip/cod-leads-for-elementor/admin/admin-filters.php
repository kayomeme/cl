<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://kayoplugins.com
 * @since      1.0.0
 *
 * @package    cl
 * @subpackage cl/admin-filters
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    cl
 * @subpackage cl/admin-filters
 * @author     Kayo plugins <kayo.plugins@gmail.com>
 */
class AdminFilters_cl {
    
        public $filters = [];

        /**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $filters ) {

            // group by filtername every filter
            foreach ($filters as $key => $filter) {
                $this->filters[$filter['name']][] = $filter;
            } 

	}
        
        /*
         * 
         */
        public function manage_edit_post_columns($columns) {
            if( !isset( $this->filters['manage_edit-post_columns'] ) ) {
                return $columns;
            }
            
            // get the function attached filters
            $filters = $this->filters['manage_edit-post_columns'];
            
            foreach ($filters as $filter) {
                include MainApp_cl::$compsPath.$filter['compName'].'/backend/filters/manage_edit-post_columns.php';
            }
            
            return $columns;
        }

}
