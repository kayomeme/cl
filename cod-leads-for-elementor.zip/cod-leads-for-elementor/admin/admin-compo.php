<?php

class AdminCompo_clfe {

    public function __construct() {
        
    }

    /*public static function getDefaultSettings($compoName) {
        $defaultSetting = require MainApp_clfe::$compsPath . $compoName . '/config/default_setting.php';
        $defaultLang = require MainApp_clfe::$compsPath . $compoName . '/config/default_lang.php';
        $defaultStyle = require MainApp_clfe::$compsPath . $compoName . '/config/default_style.php';
        return array_merge($defaultSetting, $defaultLang, $defaultStyle);
    }*/
    
    public static function getActiveBlocks($compoName) {
        $compoPath = MainApp_clfe::$compsPath . $compoName . '/';
        $fileDefaultSettings = require  $compoPath . 'config.php';
        
        $compoSettings = $fileDefaultSettings['setting'];
        
        // no blocks exist for this compo return only the global default settings
        if( !isset( $compoSettings['active_blocks'] ) ) {
            return [];
        }
        
        
        return explode(',', $compoSettings['active_blocks']);
    }
    
    public static function getDefaultLang($compoName) {
        $compoPath = MainApp_clfe::$compsPath . $compoName . '/';
        $fileDefaultSettings = require  $compoPath . 'config.php';
        $defaultSettingsLang = $fileDefaultSettings['lang'];
        
        $compoSettings = $fileDefaultSettings['setting'];
        
        // no blocks exist for this compo return only the global default settings
        if( !isset( $compoSettings['active_blocks'] ) ) {
            return $defaultSettingsLang;
        }
        
        
        $activeBlocks = explode(',', $compoSettings['active_blocks']);
                
        
        $allBlocksDefaultLang = $defaultSettingsLang;
        foreach ($activeBlocks as $blockName) {
            $blockVersion = isset( $compoSettings[$blockName.'_version'] ) ? $compoSettings[$blockName.'_version'] : 'v1';
            
            $blockDefaultSettings = require  $compoPath . 'backend/views/global_settings/blocks/'.$blockName.'/'.$blockVersion.'/config.php';
            $blockDefaultLang =  $blockDefaultSettings['lang'];
            
            $allBlocksDefaultLang = array_merge($allBlocksDefaultLang, $blockDefaultLang);
        }
        
        return $allBlocksDefaultLang;
    }
    
    /*
     * the $savedSettings is only used to get the version used  for each blocks
     */
    public static function getDefaultSettings($compoName, $savedSettings) {
        $compoPath = MainApp_clfe::$compsPath . $compoName . '/';
        $fileDefaultSettings = require  $compoPath . 'config.php';
        $defaultSettings = array_merge(
            $fileDefaultSettings['setting'], 
            $fileDefaultSettings['lang'], 
            $fileDefaultSettings['style']
        );
        
        // no blocks exist for this compo return only the global default settings
        if( !isset( $defaultSettings['active_blocks'] ) ) {
            return $defaultSettings;
        }
        
        $compoSettings = array_merge($defaultSettings, $savedSettings);
        $activeBlocks = explode(',', $defaultSettings['active_blocks']);
                
        
        $allBlocksDefaultSettings = $defaultSettings;
        foreach ($activeBlocks as $blockName) {
            $blockVersion = isset( $compoSettings[$blockName.'_version'] ) ? $compoSettings[$blockName.'_version'] : 'v1';
            
            $blockDefaultSettings = require  $compoPath . 'backend/views/global_settings/blocks/'.$blockName.'/'.$blockVersion.'/config.php';
            $mergedBlockDefaultSettings = array_merge(
                $blockDefaultSettings['setting'], 
                $blockDefaultSettings['lang'], 
                $blockDefaultSettings['style']
            );
            
            $allBlocksDefaultSettings = array_merge($allBlocksDefaultSettings, $mergedBlockDefaultSettings);
        }
        
        return $allBlocksDefaultSettings;
        
        /*$defaultLang = require MainApp_clfe::$compsPath . $compoName . '/config/default_lang.php';
        $defaultStyle = require MainApp_clfe::$compsPath . $compoName . '/config/default_style.php';
        return array_merge($defaultSetting, $defaultLang, $defaultStyle);*/
    }

    /*
     * save and return all settings and styles and generate css
     */

    public static function saveSettings($compoName, $settingsModelId, $args) {
        // remove all system args before saving in the database
        $args = adminUtils_clfe::unsetUnwantedDatas($args);
        
        $sharedSettings = AdminCompo_clfe::getSharedSettings($settingsModelId);

        $existingSettings = self::getSettings($compoName, $settingsModelId);
        $settings = array_merge($existingSettings, $args);

        $styleSettings = [];
        $regularSetting = [];

        foreach ($settings as $key => $value) {
            if (isset(explode('_style', $key)[1]) && empty(explode('_style', $key)[1])) {
                $styleSettings[$key] = $value;
            } else {
                $regularSetting[$key] = $value;
            }
        }

        // to-do optimize this, only save styles and regenerate css if a style settings is changed
        // save each compo style in a diffrent option
        self::saveCompoStyles($compoName, $styleSettings, $settingsModelId);
        self::saveCompoGeneratedCss($compoName, $settings,$sharedSettings, $settingsModelId);

        $settingsOptionName = 'clfe_' . $compoName . '_' . (int) $settingsModelId;

        //$regularSetting = adminUtils_clfe::sanitizeArrayValues($regularSetting);
        $res = update_option($settingsOptionName, $regularSetting);
        
        /**
        * Error Detection System for Settings Update
        * 
        * Important: update_option() returns false in two cases:
        * - When there's an actual error in the data
        * - When the new value is identical to the existing one 
        * 
        * This code helps identify which specific setting is causing update issues by:
        * 1. Testing each setting individually with a unique timestamp
        * 2. Identifying the exact problematic setting
        * 3. Showing the specific value that needs modification
        * 4. Providing clear guidance to users for fixing the issue
        */
        if (!$res) {
           $errorExistIn = '';
           foreach ($regularSetting as $key => $value) {
               // Add timestamp to force value difference for testing
               $res2 = update_option('clfe_tmp_option', [
                   'key' => $key, 
                   'value' => $value, 
                   'timestamp' => time()  // Ensures we won't get false due to unchanged value
               ]);
               if (!$res2) {
                   $firstPart = Lang_clfe::__('We found an issue with your settings. Please review and modify the text in', 'clfe');
                   $lastPart = Lang_clfe::__('This field might contain special characters or formatting that needs to be adjusted.', 'clfe');
                   $errorExistIn = $firstPart . ' "' . $key . '"' . (is_string($value) ? ': ' . $value : ': ' . json_encode($value)) . '. ' . $lastPart;
                   return response_clfe(0, $errorExistIn, null);
                }
            }
        }
    }

    public static function getSettings($compoName, $settingsModelId) {
        $savedSettings = (array) get_option('clfe_' . $compoName . '_' . (int) $settingsModelId, []);
        $defaultSettings = self::getDefaultSettings($compoName, $savedSettings);
        $savedStyles = (array) get_option('clfe_'.$compoName.'_style_' . (int) $settingsModelId, []);
        
        /* 
         * clean the saved settings and saved styles and remove all no used
         * this should be optimized and only executed once per month
         * you can add a setting 'last_saved_date' 
         */
        foreach ($savedSettings as $key => $value) {
            if( !isset( $defaultSettings[$key] ) ) { unset($savedSettings[$key]); }
        }
        foreach ($savedStyles as $key => $value) {
            if( !isset( $defaultSettings[$key] ) ) { unset($savedStyles[$key]);}
        }
        
        $settings = array_merge($defaultSettings, $savedSettings, $savedStyles);

        // this will strip all slash inside every setting jsoon format
        //return array_map('stripslashes', $settings);
        return self::stripslashesDeep($settings);
    }
    
    // Helper function to recursively apply stripslashes to all string values
    private static function stripslashesDeep($value) {
        if (is_array($value)) {
            return array_map([self::class, 'stripslashesDeep'], $value);
        } else {
            return is_string($value) ? stripslashes($value) : $value;
        }
    }

    /*
     * 
     */
    /*
     * 
     */

    public static function saveSharedSettings($settingsModelId, $compoSharedSetting) {
        $optionName = 'clfe_shared_settings_' . $settingsModelId;
        $allSharedSettings = (array) get_option($optionName, []);
        $newSharedSettings = array_merge($allSharedSettings, $compoSharedSetting);
        update_option($optionName, $newSharedSettings);
    }

    public static function getSharedSettings($settingsModelId) {
        $defaultSharedSettings = [
            'currency_code' => 'USD',
            'default_status' => 'wc-pending',
            'lang_dir' => 'ltr',
            'shipping_label' => 'Shipping fees',
            'shipping_fees' => 0,
            'cart_mode' => 'normal',
            'checkout_mode' => 'normal'
        ];
        $optionName = 'clfe_shared_settings_' . (int) $settingsModelId;

        $settings = get_option($optionName, []);

        return array_merge($defaultSharedSettings, $settings);
    }

    /*
     * To review
     * get the merged global settings and the product setting for each giving compo
     */

    public static function getSettingsForProduct($compoName, $productID) {
        // retrieve the used model settings for the given product
        $settingsModelId = (int) get_post_meta($productID, 'clfe_settings_model_id', true);

        $sheetGlobalSettings = self::getSettings($compoName, $settingsModelId);
        $sheetProductSettings = (array) get_post_meta($productID, 'clfe_' . $compoName, true);

        $sheetSettings = array_merge($sheetGlobalSettings, $sheetProductSettings);

        return $sheetSettings;
    }

    private static function saveCompoStyles($compoName, $styleSettings, $settingsModelId) {
        $optionName = 'clfe_'.$compoName.'_style_' . (int) $settingsModelId;

        update_option($optionName, $styleSettings);
    }

    private static function saveCompoGeneratedCss($compoName, $settings, $sharedSettings, $settingsModelId) {
        $generatedCss = '';
        $cssFilePath = MainApp_clfe::$compsPath . $compoName . '/backend/views/global_settings/generated_css.php';
        if (file_exists($cssFilePath)) {
            ob_start();
            include $cssFilePath;
            $generatedCss = ob_get_contents();
            ob_get_clean();
        }
        
        $isValide = adminUtils_clfe::isValideGeneratedCss($generatedCss);
        if ($isValide) {
            $generatedCss = adminUtils_clfe::minify_css($generatedCss);
            $optionName = 'clfe_'.$compoName.'_generated_css_' . (int) $settingsModelId;
            update_option($optionName, $generatedCss);
        }
    }

    /*
     */

    public static function getGeneratedCss($compoName, $settingsModelId) {
        $optionName = 'clfe_'.$compoName.'_generated_css_' . (int) $settingsModelId;
        $stringcss = get_option($optionName);

        return $stringcss;
    }

    public static function getAllGeneratedCss($settingsModelId) {
        $allModelGeneratedCss = '';
        foreach (MainApp_clfe::$compsNames as $compoName) {
            $optionName = 'clfe_'.$compoName.'_generated_css_' . (int) $settingsModelId;
            $allModelGeneratedCss = $allModelGeneratedCss . get_option($optionName);
        }
        
        return $allModelGeneratedCss;
    }
}
