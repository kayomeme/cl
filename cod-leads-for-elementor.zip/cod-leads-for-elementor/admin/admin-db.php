<?php

/**
 * Description of adminDB
 *
 * @author GIGABYTE
 */
class adminDB_clfe {

    public static function getResults($tableName, $query) {
        global $wpdb;

        $tableName = $wpdb->prefix . $tableName;

        $query = str_replace("table_name", $tableName, $query);

        $result = $wpdb->get_results($query, ARRAY_A);

        return $result;
    }

    public static function getResultsAsObjects($tableName, $query) {
        global $wpdb;

        $tableName = $wpdb->prefix . $tableName;

        $query = str_replace("table_name", $tableName, $query);

        $result = $wpdb->get_results($query);

        return $result;
    }

    public static function getResultsAsArray($tableName, $query) {
        global $wpdb;

        $tableName = $wpdb->prefix . $tableName;

        $query = str_replace("table_name", $tableName, $query);

        $result = $wpdb->get_results($query, ARRAY_A);

        return $result;
    }

    public static function query($tableName, $query) {
        global $wpdb;

        $tableName = $wpdb->prefix . $tableName;

        $query = str_replace("table_name", $tableName, $query);

        $result = $wpdb->query($query);

        return $result;
    }

    public static function insert($tableName, $data) {
        global $wpdb;
        $tableName = $wpdb->prefix . $tableName;

        $response = response_clfe(1, Lang_clfe::__('successfully added', 'clfe'), null);

        $resInsert = $wpdb->insert($tableName, $data);

        if (!$resInsert) {
            $response->code = 0;
            $response->msg = Lang_clfe::__('Error adding the element ', 'clfe') . $wpdb->last_error;

            // toDo : insert this error in a log with all datas so the admin can check why order not inserted
        } else {
            $response->res['insert_id'] = $wpdb->insert_id;
        }

        return $response;
    }

    /*
     * get one result
     */

    public static function getOrderMetaValue($tableName, $meta_key, $order_id) {
        if (!$order_id) {
            return false;
        }

        global $wpdb;

        $tableName = $wpdb->prefix . $tableName;

        $query = "select meta_value from {$tableName} where meta_key='{$meta_key}' and order_id={$order_id} limit 1";

        $result = $wpdb->get_results($query, ARRAY_A);

        if (isset($result[0]['meta_value'])) {
            return $result[0]['meta_value'];
        }

        return false;
    }

    public static function getSingleById($tableName, $id, $columns = '*') {
        global $wpdb;
        $tableName = $wpdb->prefix . $tableName;
        $response = response_clfe(1, Lang_clfe::__('Record found successfully', 'clfe'), null);

        $id = absint($id);

        // Build and execute query
        $query = $wpdb->prepare("SELECT {$columns} FROM {$tableName} WHERE id = %d LIMIT 1", $id);

        $result = $wpdb->get_row($query);

        if ($result === null) {
            $response->code = 0;
            $response->msg = Lang_clfe::__('Record not found', 'clfe');
        } else {
            $response->res = $result;
        }

        return $response;
    }

    public static function getSingleByWhere($tableName, $where = [], $columns = '*') {
        global $wpdb;
        $response = response_clfe(1, Lang_clfe::__('Record found successfully', 'clfe'), null);

        // Example: ['status' => 'active', 'type' => 'user']  Becomes: ["status = %s", "type = %s"]
        $whereConditions = array_map(fn($key) => "$key = %s", array_keys($where));

        // Join conditions with AND Becomes: "status = %s AND type = %s"
        $whereClause = implode(' AND ', $whereConditions);

        // Construct full query
        $query = "SELECT {$columns} FROM {$wpdb->prefix}{$tableName} WHERE {$whereClause} LIMIT 1";

        // Execute with prepared values
        $result = $wpdb->get_row( $wpdb->prepare($query, array_values($where)) );

        if (!$result) {
            $response->code = 0;
            $response->msg = Lang_clfe::__('Record not found', 'clfe');
        } else {
            $response->res = $result;
        }

        return $response;
    }

    public static function update($tableName, $data, $where) {
        // Validate inputs
        if (empty($data)) {
            return response_clfe(0, Lang_clfe::__('No data provided for update', 'clfe'), null);
        }

        if (empty($where)) {
            return response_clfe(0, Lang_clfe::__('No where clause provided for update', 'clfe'), null);
        }
        
        global $wpdb;
        $tableName = $wpdb->prefix . $tableName;
        $response = response_clfe(1, Lang_clfe::__('successfully updated', 'clfe'), null);

        $resUpdate = $wpdb->update($tableName, $data, $where);

        if ($resUpdate === false) {
            $response->code = 0;
            $response->msg = Lang_clfe::__('Error updating the element ', 'clfe').$wpdb->last_error;
        } else {
            $response->res['count_updated'] = $resUpdate;
        }

        return $response;
    }

    public static function delete($tableName, $where) {
        global $wpdb;
        $tableName = $wpdb->prefix . $tableName;

        $response = response_clfe(1, Lang_clfe::__('order deleted', 'clfe'), null);

        $responseDelete = $wpdb->delete($tableName, $where);

        if (!$responseDelete) {
            $response->code = 0;
            $response->msg = Lang_clfe::__('Error deleting order', 'clfe');

            // toDo : insert this error in a log with all datas so the admin can check why order not deleted
        }

        return $response;
    }
    
    public static function getVar($tableName, $column, $where = '') {
        global $wpdb;
        $tableName = $wpdb->prefix . $tableName;

        $query = "SELECT {$column} FROM {$tableName}";

        if (!empty($where)) {
            $query .= " WHERE {$where}";
        }

        $result = $wpdb->get_var($query);

        return $result;
    }
}
