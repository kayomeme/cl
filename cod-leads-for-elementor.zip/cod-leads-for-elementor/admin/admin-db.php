<?php

/**
 * Description of adminDB
 *
 * @author GIGABYTE
 */
class adminDB_cl {

    public static function getResults($tableName, $query) {
        global $wpdb;

        $tableName = $wpdb->prefix . $tableName;

        $query = str_replace("table_name", $tableName, $query);

        $result = $wpdb->get_results($query, ARRAY_A);

        return $result;
    }

    public static function getResultsAsObjects($tableName, $query) {
        global $wpdb;

        $tableName = $wpdb->prefix . $tableName;

        $query = str_replace("table_name", $tableName, $query);

        $result = $wpdb->get_results($query);

        return $result;
    }

    public static function getResultsAsArray($tableName, $query) {
        global $wpdb;

        $tableName = $wpdb->prefix . $tableName;

        $query = str_replace("table_name", $tableName, $query);

        $result = $wpdb->get_results($query, ARRAY_A);

        return $result;
    }

    public static function query($tableName, $query) {
        global $wpdb;

        $tableName = $wpdb->prefix . $tableName;

        $query = str_replace("table_name", $tableName, $query);

        $result = $wpdb->query($query);

        return $result;
    }

    public static function insert($tableName, $data) {
        global $wpdb;
        $tableName = $wpdb->prefix . $tableName;

        $response = response_cl(1, Lang_cl::__('successfully added', 'cl'), null);

        $resInsert = $wpdb->insert($tableName, $data);

        if (!$resInsert) {
            $response->code = 0;
            $response->msg = Lang_cl::__('Error adding the element ', 'cl') . $wpdb->last_error;

            // toDo : insert this error in a log with all datas so the admin can check why order not inserted
        } else {
            $response->res['insert_id'] = $wpdb->insert_id;
        }

        return $response;
    }

    /*
     * get one result
     */

    public static function getOrderMetaValue($tableName, $meta_key, $order_id) {
        if (!$order_id) {
            return false;
        }

        global $wpdb;

        $tableName = $wpdb->prefix . $tableName;

        $query = "select meta_value from {$tableName} where meta_key='{$meta_key}' and order_id={$order_id} limit 1";

        $result = $wpdb->get_results($query, ARRAY_A);

        if (isset($result[0]['meta_value'])) {
            return $result[0]['meta_value'];
        }

        return false;
    }

    public static function getSingleById($tableName, $id, $columns = '*') {
        global $wpdb;
        $tableName = $wpdb->prefix . $tableName;
        $response = response_cl(1, Lang_cl::__('Record found successfully', 'cl'), null);

        $id = absint($id);

        // Build and execute query
        $query = $wpdb->prepare("SELECT {$columns} FROM {$tableName} WHERE id = %d LIMIT 1", $id);

        $result = $wpdb->get_row($query);

        if ($result === null) {
            $response->code = 0;
            $response->msg = Lang_cl::__('Record not found', 'cl');
        } else {
            $response->res = $result;
        }

        return $response;
    }
    
    public static function getSingleByIdAsArray($tableName, $id, $columns = '*') {
        global $wpdb;
        $tableName = $wpdb->prefix . $tableName;
        $response = response_cl(1, Lang_cl::__('Record found successfully', 'cl'), null);
        $id = absint($id);

        // Build and execute query
        $query = $wpdb->prepare("SELECT {$columns} FROM {$tableName} WHERE id = %d LIMIT 1", $id);
        $result = $wpdb->get_row($query, ARRAY_A); // Changed to ARRAY_A

        if ($result === null) {
            $response->code = 0;
            $response->msg = Lang_cl::__('Record not found', 'cl');
        } else {
            $response->res = $result;
        }

        return $response;
    }

    public static function getSingleByWhere($tableName, $where = [], $columns = '*') {
        global $wpdb;
        $response = response_cl(1, Lang_cl::__('Record found successfully', 'cl'), null);

        // Example: ['status' => 'active', 'type' => 'user']  Becomes: ["status = %s", "type = %s"]
        $whereConditions = array_map(fn($key) => "$key = %s", array_keys($where));

        // Join conditions with AND Becomes: "status = %s AND type = %s"
        $whereClause = implode(' AND ', $whereConditions);

        // Construct full query
        $query = "SELECT {$columns} FROM {$wpdb->prefix}{$tableName} WHERE {$whereClause} LIMIT 1";

        // Execute with prepared values
        $result = $wpdb->get_row( $wpdb->prepare($query, array_values($where)) );

        if (!$result) {
            $response->code = 0;
            $response->msg = Lang_cl::__('Record not found', 'cl');
        } else {
            $response->res = $result;
        }

        return $response;
    }

    public static function update($tableName, $data, $where) {
        // Validate inputs
        if (empty($data)) {
            return response_cl(0, Lang_cl::__('No data provided for update', 'cl'), null);
        }

        if (empty($where)) {
            return response_cl(0, Lang_cl::__('No where clause provided for update', 'cl'), null);
        }
        
        global $wpdb;
        $tableName = $wpdb->prefix . $tableName;
        $response = response_cl(1, Lang_cl::__('successfully updated', 'cl'), null);

        $resUpdate = $wpdb->update($tableName, $data, $where);

        if ($resUpdate === false) {
            $response->code = 0;
            $response->msg = Lang_cl::__('Error updating the element ', 'cl').$wpdb->last_error;
        } else {
            $response->res['count_updated'] = $resUpdate;
        }

        return $response;
    }

    public static function delete($tableName, $where) {
        global $wpdb;
        $tableName = $wpdb->prefix . $tableName;

        $response = response_cl(1, Lang_cl::__('order deleted', 'cl'), null);

        $responseDelete = $wpdb->delete($tableName, $where);

        if (!$responseDelete) {
            $response->code = 0;
            $response->msg = Lang_cl::__('Error deleting order', 'cl');

            // toDo : insert this error in a log with all datas so the admin can check why order not deleted
        }

        return $response;
    }
    
    public static function getVar($tableName, $column, $where = '') {
        global $wpdb;
        $tableName = $wpdb->prefix . $tableName;

        $query = "SELECT {$column} FROM {$tableName}";

        if (!empty($where)) {
            $query .= " WHERE {$where}";
        }

        $result = $wpdb->get_var($query);

        return $result;
    }
}
