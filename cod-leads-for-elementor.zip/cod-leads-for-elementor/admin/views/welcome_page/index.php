<div class="wrap">
    <div class="clfe-flex-center" style="height: 400px">
        <div>
            <a href="<?= get_site_url() ?>/wp-admin/post-new.php" class="page-title-action">Add New Landing page</a>
        </div>
        <div>
            <a href="<?= get_site_url().'/wp-admin/admin.php?page=clfe_global_settings&compo=checkout' ?>" class="page-title-action">Update the global settings</a>
        </div>
    </div>
</div>

