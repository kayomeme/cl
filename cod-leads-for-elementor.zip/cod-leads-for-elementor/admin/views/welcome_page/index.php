<?php
// Ensure we're in WordPress admin
if (!defined('ABSPATH'))
    exit;

// --- OPTIMIZED PHP ---
// Get stats only if WooCommerce is active to prevent errors
$product_count = 0;
$category_count = 0;

if (is_plugin_active('woocommerce/woocommerce.php')) {
    if (function_exists('wp_count_posts')) {
        $products = wp_count_posts('product');
        $product_count = $products ? $products->publish : 0;
    }

    if (function_exists('get_terms')) {
        // Getting the count directly is more efficient than counting the array
        $category_count = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
            'fields' => 'count' // This directly returns the number of terms
        ));
        // Ensure it's not a WP_Error object before using it
        if (is_wp_error($category_count)) {
            $category_count = 0;
        }
    }
}
?>

<style>
    /*----remove wp title page---*/
    h1 {
        display: none;
    }
    .wrap {
        margin: 0 !important;
        border: 0 !important;
        padding: 0 !important;
    }
    .postbox-header {
        display: none;
    }
    #dashboard-widgets .meta-box-sortables {
        margin: 0;
    }
    .postbox {
        border: 0;
    }
    #dashboard-widgets .postbox .inside{
        padding: 0 !important;
        margin: 0 !important;
        border: 0 !important;
    }
    #dashboard-widgets-wrap, #dashboard-widgets-wrap .postbox-container {
        width: 100% !important;
        margin: 0;
    }


    /* --- ENHANCEMENT: CSS Variables for easy themeing --- */
    :root {
        --cl-grad-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        --cl-grad-primary-hover: linear-gradient(135deg, #5a6fd8, #6a4190);
        --cl-grad-settings: linear-gradient(135deg, #3498db, #2980b9);
        --cl-grad-orders: linear-gradient(135deg, #e74c3c, #c0392b);
        --cl-grad-products: linear-gradient(135deg, #27ae60, #2ecc71);
        --cl-grad-shipping: linear-gradient(135deg, #f39c12, #e67e22);
        --cl-grad-design: linear-gradient(135deg, #9b59b6, #8e44ad);
        --cl-grad-analytics: linear-gradient(135deg, #1abc9c, #16a085);
        --cl-grad-tools: linear-gradient(135deg, #34495e, #2c3e50);
        --cl-grad-stats: linear-gradient(135deg, #e67e22, #d35400);

        --cl-text-dark: #2c3e50;
        --cl-text-light: #7f8c8d;
        --cl-bg-light: #ecf0f1;
        --cl-bg-very-light: #f8f9fa;
        --cl-white: #fff;
        --cl-danger: #e74c3c;
    }

    #wpcontent {
        background: var(--cl-grad-primary);
    }
    /* --- FIX: Adjusted margins and removed min-height to prevent scrolling --- */
    .cl-dashboard {
        background: var(--cl-grad-primary);
        min-height: calc(100vh - 80px);
        padding-right: 20px !important;
    }

    .dashboard-header {
        text-align: center;
        color: var(--cl-white);
        margin-bottom: 40px;
    }

    .dashboard-header h1 {
        font-size: 2.5rem;
        font-weight: 300;
        margin-bottom: 10px;
    }

    .dashboard-header p {
        font-size: 1.1rem;
        opacity: 0.9;
    }

    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 25px;
        max-width: 1400px;
        margin: 0 auto;
    }

    .dashboard-card {
        background: var(--cl-white);
        border-radius: 15px;
        padding: 30px 20px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
        display: flex; /* Added for better vertical alignment */
        flex-direction: column; /* Added for better vertical alignment */
    }

    .dashboard-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    }

    .dashboard-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        /* The main gradient is a good default */
        background: var(--cl-grad-primary);
    }

    .card-header {
        display: flex;
        align-items: flex-start;
        gap: 15px;
        margin-bottom: 20px;
    }

    /* --- ENHANCEMENT: Using built-in WordPress Dashicons for consistency --- */
    .card-icon {
        width: 60px;
        height: 60px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 32px; /* Adjusted for Dashicons */
        color: var(--cl-white);
        flex-shrink: 0;
        position: relative;
    }

    .card-icon .dashicons {
        width: auto;
        height: auto;
        font-size: inherit; /* Inherit size from parent */
    }

    .card-content {
        flex: 1;
    }

    .card-title {
        font-size: 1.3rem;
        font-weight: 600;
        color: var(--cl-text-dark);
        margin-bottom: 10px;
    }

    .card-description {
        color: var(--cl-text-light);
        line-height: 1.6;
        margin-bottom: 0;
        flex-grow: 1; /* Pushes actions to the bottom */
    }

    .card-actions {
        margin-top: 20px; /* Add space above the buttons */
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .count-badge {
        position: absolute;
        top: -8px;
        right: -8px;
        background: var(--cl-danger);
        color: var(--cl-white);
        border-radius: 50%;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        font-weight: bold;
        border: 2px solid var(--cl-white);
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
        margin-top: 20px;
    }

    .stat-box {
        text-align: center;
        padding: 15px;
        background: var(--cl-bg-very-light);
        border-radius: 8px;
    }

    .stat-number {
        display: block;
        font-size: 2rem;
        font-weight: bold;
        color: var(--cl-text-dark);
    }

    .stat-label {
        font-size: 0.9rem;
        color: var(--cl-text-light);
    }

    /* --- Button Styles --- */
    .btn {
        padding: 10px 16px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 500;
        font-size: 0.9rem;
        transition: all 0.3s ease;
        border: none;
        cursor: pointer;
        display: inline-block;
        text-align: center;
    }

    .btn-primary {
        background: var(--cl-grad-primary);
        color: var(--cl-white);
    }

    .btn-primary:hover {
        background: var(--cl-grad-primary-hover);
        transform: translateY(-2px);
        color: var(--cl-white);
    }

    .btn-secondary {
        background: var(--cl-bg-light);
        color: var(--cl-text-dark);
    }

    .btn-secondary:hover {
        background: #d5dbdb;
        color: var(--cl-text-dark);
    }

    /* --- OPTIMIZED: Using a more standard WP breakpoint --- */
    @media (max-width: 782px) {
        .cl-dashboard {
            padding: 20px 10px;
            margin: -12px -10px -10px -10px;
        }

        .dashboard-header h1 {
            font-size: 2rem;
        }

        .dashboard-grid {
            grid-template-columns: 1fr;
        }

        .card-actions {
            flex-direction: column;
        }
        .btn {
            width: 100%;
        }
    }
</style>

<div class="cl-dashboard wrap"> <!-- Added .wrap for better compatibility, though our negative margins override it -->
    <div class="dashboard-header">
        <!-- FIXED: Used a semantic H1 tag -->
        <h1>Welcome to COD Leads</h1>
        <p>Manage your e-commerce operations from one central dashboard</p>
    </div>

    <div class="dashboard-grid">
        <!-- Core Settings -->
        <div class="dashboard-card">
            <div class="card-header">
                <!-- ENHANCEMENT: Using Dashicons -->
                <div class="card-icon" style="background: var(--cl-grad-settings);">
                    <span class="dashicons dashicons-admin-settings"></span>
                </div>
                <div class="card-content">
                    <div class="card-title">Global Settings</div>
                    <p class="card-description">Configure your main plugin settings and preferences.</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_global_settings')); ?>" class="btn btn-primary">Configure Settings</a>
            </div>
        </div>

        <!-- Orders Management -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: var(--cl-grad-orders);">
                    <span class="dashicons dashicons-archive"></span>
                </div>
                <div class="card-content">
                    <div class="card-title">Orders</div>
                    <p class="card-description">View, manage and track all your customer orders.</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_orders')); ?>" class="btn btn-primary">Manage Orders</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_order_statuses')); ?>" class="btn btn-secondary">Order Statuses</a>
            </div>
        </div>

        <!-- Products Management -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: var(--cl-grad-products);">
                    <span class="dashicons dashicons-cart"></span>
                    <?php if ($product_count > 0) : ?>
                        <span class="count-badge"><?php echo esc_html($product_count); ?></span>
<?php endif; ?>
                </div>
                <div class="card-content">
                    <div class="card-title">Products</div>
                    <p class="card-description">Add, edit and organize your product catalog.</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('post-new.php?post_type=product')); ?>" class="btn btn-primary">Add New</a>
                <a href="<?php echo esc_url(admin_url('edit.php?post_type=product')); ?>" class="btn btn-secondary">All Products</a>
                <a href="<?php echo esc_url(admin_url('edit-tags.php?taxonomy=product_cat&post_type=product')); ?>" class="btn btn-secondary">Categories</a>
            </div>
        </div>

        <!-- Shipping & Checkout -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: var(--cl-grad-shipping);">
                    <span class="dashicons dashicons-airplane"></span>
                </div>
                <div class="card-content">
                    <div class="card-title">Shipping & Checkout</div>
                    <p class="card-description">Configure shipping options and checkout fields.</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_shipping_options')); ?>" class="btn btn-primary">Shipping Options</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_checkout_fields')); ?>" class="btn btn-secondary">Checkout Fields</a>
            </div>
        </div>

        <!-- Customization -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: var(--cl-grad-design);">
                    <span class="dashicons dashicons-admin-customizer"></span>
                </div>
                <div class="card-content">
                    <div class="card-title">Design & Customization</div>
                    <p class="card-description">Customize colors, icons and variations.</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_color_palette')); ?>" class="btn btn-primary">Color Palette</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_icons')); ?>" class="btn btn-secondary">Icons Manager</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_global_variations')); ?>" class="btn btn-secondary">Variations</a>
            </div>
        </div>

        <!-- Analytics & Insights -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: var(--cl-grad-analytics);">
                    <span class="dashicons dashicons-chart-area"></span>
                </div>
                <div class="card-content">
                    <div class="card-title">Analytics</div>
                    <p class="card-description">Track performance and get valuable insights.</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_insights')); ?>" class="btn btn-primary">View Insights</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_logs')); ?>" class="btn btn-secondary">View Logs</a>
            </div>
        </div>

        <!-- Tools & Utilities -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: var(--cl-grad-tools);">
                    <span class="dashicons dashicons-admin-tools"></span>
                </div>
                <div class="card-content">
                    <div class="card-title">Tools & Utilities</div>
                    <p class="card-description">Import/export settings and access useful tools.</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_tools')); ?>" class="btn btn-primary">Tools</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_import_export')); ?>" class="btn btn-secondary">Import/Export</a>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: var(--cl-grad-stats);">
                    <span class="dashicons dashicons-performance"></span>
                </div>
                <div class="card-content">
                    <div class="card-title">Quick Stats</div>
                    <p class="card-description">An at-a-glance overview of your store.</p>
                </div>
            </div>
            <div class="stats-grid">
                <div class="stat-box">
                    <span class="stat-number"><?php echo esc_html($product_count); ?></span>
                    <span class="stat-label">Products</span>
                </div>
                <div class="stat-box">
                    <span class="stat-number"><?php echo esc_html($category_count); ?></span>
                    <span class="stat-label">Categories</span>
                </div>
            </div>
        </div>
    </div>
</div>