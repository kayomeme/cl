<?php
// Ensure we're in WordPress admin
if (!defined('ABSPATH')) exit;

// Get stats safely
$product_count = 0;
$category_count = 0;

if (function_exists('wp_count_posts')) {
    $products = wp_count_posts('product');
    $product_count = $products ? $products->publish : 0;
}

if (function_exists('get_terms')) {
    $categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'hide_empty' => false,
        'count' => true
    ));
    $category_count = is_array($categories) ? count($categories) : 0;
}
?>

<style>
    .cl-dashboard {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        margin: -20px -20px -20px -2px;
        padding: 40px 20px;
        min-height: calc(100vh - 60px);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }

    .dashboard-header {
        text-align: center;
        color: white;
        margin-bottom: 40px;
    }

    .dashboard-header h1 {
        font-size: 2.5rem;
        font-weight: 300;
        margin-bottom: 10px;
    }

    .dashboard-header p {
        font-size: 1.1rem;
        opacity: 0.9;
    }

    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 25px;
        max-width: 1400px;
        margin: 0 auto;
    }

    .dashboard-card {
        background: white;
        border-radius: 15px;
        padding: 30px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    .dashboard-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    }

    .dashboard-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, #667eea, #764ba2);
    }

    .card-header {
        display: flex;
        align-items: flex-start;
        gap: 15px;
        margin-bottom: 20px;
    }

    .card-icon {
        width: 60px;
        height: 60px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        color: white;
        flex-shrink: 0;
        position: relative;
    }

    .card-content {
        flex: 1;
    }

    .card-title {
        font-size: 1.3rem;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 10px;
    }

    .card-description {
        color: #7f8c8d;
        line-height: 1.6;
        margin-bottom: 0;
    }

    .count-badge {
        position: absolute;
        top: -8px;
        right: -8px;
        background: #e74c3c;
        color: white;
        border-radius: 50%;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        font-weight: bold;
        border: 2px solid white;
    }

    .card-stats {
        margin-bottom: 20px;
    }

    .stat-item {
        display: inline-block;
        padding: 5px 12px;
        background: #ecf0f1;
        border-radius: 20px;
        font-size: 0.9rem;
        color: #34495e;
        margin-right: 10px;
    }

    .card-actions {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .btn {
        padding: 10px 16px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 500;
        font-size: 0.9rem;
        transition: all 0.3s ease;
        border: none;
        cursor: pointer;
        display: inline-block;
    }

    .btn-primary {
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
    }

    .btn-primary:hover {
        background: linear-gradient(135deg, #5a6fd8, #6a4190);
        transform: translateY(-2px);
        color: white;
    }

    .btn-secondary {
        background: #ecf0f1;
        color: #34495e;
    }

    .btn-secondary:hover {
        background: #d5dbdb;
        color: #2c3e50;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
        margin-top: 20px;
    }

    .stat-box {
        text-align: center;
        padding: 15px;
        background: #f8f9fa;
        border-radius: 8px;
    }

    .stat-number {
        display: block;
        font-size: 2rem;
        font-weight: bold;
        color: #2c3e50;
    }

    .stat-label {
        font-size: 0.9rem;
        color: #7f8c8d;
    }

            @media (max-width: 768px) {
        .cl-dashboard {
            padding: 20px 10px;
        }
        
        .dashboard-header .main-title {
            font-size: 2rem;
        }
        
        .dashboard-grid {
            grid-template-columns: 1fr;
        }
        
        .card-actions {
            flex-direction: column;
        }
    }
</style>

<div class="cl-dashboard">
    <div class="dashboard-header">
        <div class="main-title">Welcome to COD Leads</div>
        <p>Manage your e-commerce operations from one central dashboard</p>
    </div>

    <div class="dashboard-grid">
        <!-- Core Settings -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: linear-gradient(135deg, #3498db, #2980b9);">
                    ⚙️
                </div>
                <div class="card-content">
                    <div class="card-title">Global Settings</div>
                    <p class="card-description">Configure your main plugin settings and preferences</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_global_settings')); ?>" class="btn btn-primary">Configure Settings</a>
            </div>
        </div>

        <!-- Orders Management -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: linear-gradient(135deg, #e74c3c, #c0392b);">
                    📦
                </div>
                <div class="card-content">
                    <div class="card-title">Orders</div>
                    <p class="card-description">View, manage and track all your customer orders</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_orders')); ?>" class="btn btn-primary">Manage Orders</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_order_statuses')); ?>" class="btn btn-secondary">Order Statuses</a>
            </div>
        </div>

        <!-- Products Management -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: linear-gradient(135deg, #27ae60, #2ecc71);">
                    🛍️
                    <?php if ($product_count > 0): ?>
                        <span class="count-badge"><?php echo esc_html($product_count); ?></span>
                    <?php endif; ?>
                </div>
                <div class="card-content">
                    <div class="card-title">Products</div>
                    <p class="card-description">Add, edit and organize your product catalog</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('post-new.php?post_type=product')); ?>" class="btn btn-primary">Add New Product</a>
                <a href="<?php echo esc_url(admin_url('edit.php?post_type=product')); ?>" class="btn btn-secondary">All Products</a>
                <a href="<?php echo esc_url(admin_url('edit-tags.php?taxonomy=product_cat&post_type=product')); ?>" class="btn btn-secondary">Categories</a>
            </div>
        </div>

        <!-- Shipping & Checkout -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: linear-gradient(135deg, #f39c12, #e67e22);">
                    🚚
                </div>
                <div class="card-content">
                    <div class="card-title">Shipping & Checkout</div>
                    <p class="card-description">Configure shipping options and checkout fields</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_shipping_options')); ?>" class="btn btn-primary">Shipping Options</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_checkout_fields')); ?>" class="btn btn-secondary">Checkout Fields</a>
            </div>
        </div>

        <!-- Customization -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: linear-gradient(135deg, #9b59b6, #8e44ad);">
                    🎨
                </div>
                <div class="card-content">
                    <div class="card-title">Design & Customization</div>
                    <p class="card-description">Customize colors, icons and variations</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_color_palette')); ?>" class="btn btn-primary">Color Palette</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_icons')); ?>" class="btn btn-secondary">Icons Manager</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_global_variations')); ?>" class="btn btn-secondary">Variations</a>
            </div>
        </div>

        <!-- Analytics & Insights -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: linear-gradient(135deg, #1abc9c, #16a085);">
                    📊
                </div>
                <div class="card-content">
                    <div class="card-title">Analytics</div>
                    <p class="card-description">Track performance and get valuable insights</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_insights')); ?>" class="btn btn-primary">View Insights</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_logs')); ?>" class="btn btn-secondary">View Logs</a>
            </div>
        </div>

        <!-- Tools & Utilities -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: linear-gradient(135deg, #34495e, #2c3e50);">
                    🔧
                </div>
                <div class="card-content">
                    <div class="card-title">Tools & Utilities</div>
                    <p class="card-description">Import/export settings and access useful tools</p>
                </div>
            </div>
            <div class="card-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_tools')); ?>" class="btn btn-primary">Tools</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=cl_import_export')); ?>" class="btn btn-secondary">Import/Export</a>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="card-icon" style="background: linear-gradient(135deg, #e67e22, #d35400);">
                    📈
                </div>
                <div class="card-content">
                    <div class="card-title">Quick Stats</div>
                    <p class="card-description">Overview of your store statistics</p>
                </div>
            </div>
            <div class="stats-grid">
                <div class="stat-box">
                    <span class="stat-number"><?php echo esc_html($product_count); ?></span>
                    <span class="stat-label">Products</span>
                </div>
                <div class="stat-box">
                    <span class="stat-number"><?php echo esc_html($category_count); ?></span>
                    <span class="stat-label">Categories</span>
                </div>
            </div>
        </div>
    </div>
</div>