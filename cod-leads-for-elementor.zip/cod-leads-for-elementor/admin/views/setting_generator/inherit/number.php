<div class="cl-row">
    <div class="cl-th">
        <?= $title ?>
    </div>
    <div class="cl-td cl-style-container">
        <select class="inherit-number-select">
            <option value="inherit" <?php selected($value, 'inherit'); ?>>
                <?= Lang_cl::__('Inherit', 'cl') ?>
            </option>
            <option value="custom" <?php selected($value, 'custom', false); ?>>
                <?= Lang_cl::__('Custom', 'cl') ?>
            </option>
        </select>
        
        <input type="<?= $value === 'inherit' ? 'hidden' : 'number' ?>" name="<?= $key ?>" value="<?= $value ?>" default-value="<?= $defaultValue ?>"
            class="inherit-number-input <?= $value === 'inherit' ? 'cl-hide' : '' ?>" 
        />
    </div>
</div>