<div class="cl-row">
    <div class="cl-th">
        <?= $title ?>
    </div>
    <div class="cl-td">
        <select name="<?= $key ?>">
            <option value="inherit" <?= $value === 'inherit' ? 'selected' : '' ?>><?= Lang_cl::__('Inherit', 'cl') ?></option>
            <?php foreach ($defaultValues as $optionValue => $optionLabel): ?>
                <option value="<?= $optionValue ?>" <?= $value == $optionValue ? 'selected' : '' ?>><?= $optionLabel ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>

