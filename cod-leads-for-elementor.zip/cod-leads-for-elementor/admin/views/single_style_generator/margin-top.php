<div class="clfe-th">
    <label>
        <?= Lang_clfe::__('Margin top', 'clfe') ?>
    </label>
</div>
<div class="clfe-td clfe-overlay-container">
    <input class="clfe-single-style-element" type="number" style_key="margin-top" ext="px" value="<?= $singleStyleValue ?>">
    <span class="clfe-overlay-text">px</span>
</div>