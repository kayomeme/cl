<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Choose Your block versions', 'cl') ?>
    </div>
    <div class="cl-td">
        <select name="<?= $blockName.'_version' ?>" class="cl-style-element cl_select_version" value="<?= $currentVersion?>">
            <?php foreach ($blockVersions as $key => $value) { 
                if(file_exists($blockFilePath.$key) ) {
                ?>
                <option value="<?= $key ?>" <?= $key == $currentVersion ? 'selected' : '' ?>>
                    <?= $value['title'] ?>
                </option>
            <?php 
                }
            
            } ?>
            
        </select> 
    </div>
</div>