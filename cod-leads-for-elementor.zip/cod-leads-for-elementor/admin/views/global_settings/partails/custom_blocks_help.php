
<div class="cl-info-section">
    <div class="cl-info-header">
        <span class="dashicons dashicons-info"></span>
        <p><?= Lang_cl::_e('You have two options for content:', 'cl') ?></p>
    </div>
    <div class="cl-info-workflow">
        <h4><?= Lang_cl::_e('Option 1: Simple Text', 'cl') ?></h4>
        <p><?= Lang_cl::_e('Type your message directly in the textarea above.', 'cl') ?></p>
        
        <h4><?= Lang_cl::_e('Option 2: Custom Blocks', 'cl') ?></h4>
        <p><?= Lang_cl::_e('Create/edit a block, then copy its shortcode and paste it above (e.g., [custom_block id="123"]).', 'cl') ?></p>
    </div>
    <div class="cl-info-links">
        <a href="edit.php?post_type=custom_block" target="_blank">
            <span><?= Lang_cl::_e('Go to Custom Blocks', 'cl') ?></span>
            <span class="arrow">→</span>
        </a>
    </div>
</div>