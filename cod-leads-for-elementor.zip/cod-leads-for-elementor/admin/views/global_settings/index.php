<div class="clfe-global-settings <?= 'clfe_' . $compoName ?>">

    <?php
    /* you should mouve the model settings to a separate page for more optimization

        $settingModels  = SettingsModelBK_clfe::getExistingModels($limit=100);
        $langs_clfe      = require MainApp_clfe::$pluginPath.'languages/comps/langs_clfe.php'; 
        include 'header.php'; 

        */
    ?>

    <div class="clfe-settings-navtop">
        <?php include 'topbar.php'; ?>
    </div>

    <div class="">
        <?php
        switch ($compoName) {
            case 'plist1':
            case 'categories_listing':
                include 'compo_subnav/listing.php';
                break;
            case 'sales_funnel':
            case 'product':
            case 'cart':
            case 'checkout':
            case 'thankyou':    
                include 'compo_subnav/sales_funnel.php';
                break;
        }
        
        
        ?>
    </div>

    <div class="clfe-global-settings-body">
        <div class="clfe-sidetab-nav">
        <?php include MainApp_clfe::$compsPath . $compoName . '/backend/views/global_settings/sidebar.php'; ?>
        </div>
        <div id="clfe_save_global_settings" class="clfe-content-tabs">
            <?php include MainApp_clfe::$compsPath . $compoName . '/backend/views/global_settings/index.php'; ?>

            <div id="clfe-sticky-bottom-bar">
                <div class="clfe-container">
                    <div class="clfe-user-fedback"></div>
                    <input type="submit" class="button button-primary clfe-save-global-settings" value="<?= Lang_clfe::_e('Save Changes', 'clfe') ?>">
                </div>

            </div>


            <div class="clfe-hide- clfe_sys_params">
                <input type="hidden" name="tab_name" value="<?= $compoName ?>" />
                <input type="hidden" name="comp_name" value="<?= $compoName ?>" />
                <input type="hidden" name="settings_model_id" value="<?= $settingsModelId ?>" />
            </div>
        </div>
    </div>

    <?php include MainApp_clfe::$compsPath . 'simulator/backend/views/preview_sidebar.php' ?>
</div>