<div class="cl-global-settings <?= 'cl_' . $compoName ?>">

    <?php
    /* you should mouve the model settings to a separate page for more optimization

        $settingModels  = SettingsModelBK_cl::getExistingModels($limit=100);
        $langs_cl      = require MainApp_cl::$pluginPath.'languages/comps/langs_cl.php'; 
        include 'header.php'; 

        */
    ?>

    <div class="cl-settings-navtop">
        <?php include 'topbar.php'; ?>
    </div>

    <div class="">
        <?php
        switch ($compoName) {
            case 'mystore':
            case 'footer':    
            case 'header':
            case 'header_mobile':    
                include 'compo_subnav/mystore_header_footer.php';
                break;
            case 'plist1':
            case 'plist5':    
            case 'categories_listing':
                include 'compo_subnav/listing.php';
                break;
            case 'sales_funnel':
            case 'category':    
            case 'product':
            case 'cart':
            case 'checkout':
            case 'thankyou':    
                include MainApp_cl::$compsPath . 'sales_funnel/backend/views/global_settings/cart_checkout_modes.php';
                break;
        }
        
        
        ?>
    </div>

    <div class="cl-global-settings-body">
        <div class="cl-sidetab-nav">
        <?php include MainApp_cl::$compsPath . $compoName . '/backend/views/global_settings/sidebar.php'; ?>
        </div>
        <div id="cl_save_global_settings" class="cl-content-tabs">
            <?php include MainApp_cl::$compsPath . $compoName . '/backend/views/global_settings/index.php'; ?>

            <div id="cl-sticky-bottom-bar">
                <div class="cl-container">
                    <div class="cl-user-fedback"></div>
                    <input type="submit" class="button button-primary cl-save-global-settings" value="<?= Lang_cl::_e('Save Changes', 'cl') ?>">
                </div>

            </div>


            <div class="cl-hide- cl_sys_params">
                <input type="hidden" name="tab_name" value="<?= $compoName ?>" />
                <input type="hidden" name="comp_name" value="<?= $compoName ?>" />
                <input type="hidden" name="settings_model_id" value="<?= $settingsModelId ?>" />
            </div>
        </div>
    </div>

    <?php include MainApp_cl::$compsPath . 'simulator/backend/views/preview_sidebar.php' ?>
</div>