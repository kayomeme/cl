<div class="clfe-settings-header">

    <div class="clfe-flex-center">
        <div>
            <?= Lang_clfe::__('Current settings model : ', 'clfe') ?> <br/>

            <select class="global-select-setting-models">
                <option value="0" <?= $settingsModelId == 0 ? 'selected="selected"' : '' ?>>
                    <?= Lang_clfe::_e('Default settings', 'clfe') ?>
                </option>
                <?php foreach ($settingModels as $settingModel) { ?>
                <option value="<?= $settingModel->id ?>"  <?= $settingsModelId == $settingModel->id ? 'selected="selected"' : '' ?>>
                        <?= $settingModel->name ?>
                </option>
                <?php } ?>
            </select>
        </div>
        <div>

        </div>
        <div>
            <button type="button" class="clfe-add-new-settings-model" modalTitle="<?= Lang_clfe::_e('Add New Settings model', 'clfe') ?>">
                <span class="dashicons dashicons-plus"></span>
                <?= Lang_clfe::_e('Add New Settings model', 'clfe') ?>
            </button>
        </div>
    </div>

    
    <!-- Add new model settings modal : is hided by default -->
    <div class="model-settings-form clfe-hide">
        <div class="model-settings-content">
            <div>
                <?= Lang_clfe::_e('Settings model name', 'clfe') ?><br/>
                <input type="text" name="model_name" isRequired="yes" value="" /> <br/>
                <p>
                    <?= Lang_clfe::_e('Choose a name that clearly describes the purpose of creating this settings model. For instance, if you are using this model to sell products in the African market, you could name it "Settings for the African Market." ', 'clfe') ?>
                </p>
            </div>
            
            <div>
                <?= Lang_clfe::_e('Duplicate from', 'clfe') ?><br/>
                <select name="duplicate_from_model_id">
                    <option value="0" selected="selected">
                        <?= Lang_clfe::_e('Default settings', 'clfe') ?>
                    </option>
                    <?php foreach ($settingModels as $settingModel) { ?>
                    <option value="<?= $settingModel->id ?>"> <?= $settingModel->name ?></option>
                    <?php } ?>
                </select>
                <p>
                    <?= Lang_clfe::_e('', 'clfe') ?>
                </p>
            </div>
            
            <div>
                <?= Lang_clfe::_e('Settings model lang', 'clfe') ?><br/>
                <select name="model_lang_code"><br/>
                    <?php foreach ($langs_clfe as $langCode => $lang) { ?>
                        <option value="<?= $langCode ?>" langdir="<?= $lang['dir'] ?>">
                            <?= $lang['name'] ?>
                        </option>
                    <?php }  ?>
                </select>
                <p>
                    <?= Lang_clfe::_e('', 'clfe') ?>
                </p>
            </div>
            
            <div>
                <?= Lang_clfe::_e('Settings model lang direction', 'clfe') ?><br/>
                <select name="model_lang_direction"><br/>
                    <option value="ltr"><?= Lang_clfe::_e('Left to right', 'clfe') ?></option>
                    <option value="rtl"><?= Lang_clfe::_e('Right to left', 'clfe') ?></option>
                </select>
                <p>
                    <?= Lang_clfe::_e('', 'clfe') ?>
                </p>
            </div>
            
            <div class="clfe-user-fedback">
                <div class="clfe-msg_box">
                    <div class="alert"></div>
                </div>
            </div>
        </div> 
    </div>
    
</div>