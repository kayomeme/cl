<div class="cl-settings-header">

    <div class="cl-flex-center">
        <div>
            <?= Lang_cl::__('Current settings model : ', 'cl') ?> <br/>

            <select class="global-select-setting-models">
                <option value="0" <?= $settingsModelId == 0 ? 'selected="selected"' : '' ?>>
                    <?= Lang_cl::_e('Default settings', 'cl') ?>
                </option>
                <?php foreach ($settingModels as $settingModel) { ?>
                <option value="<?= $settingModel->id ?>"  <?= $settingsModelId == $settingModel->id ? 'selected="selected"' : '' ?>>
                        <?= $settingModel->name ?>
                </option>
                <?php } ?>
            </select>
        </div>
        <div>

        </div>
        <div>
            <button type="button" class="cl-add-new-settings-model" modal_title="<?= Lang_cl::_e('Add New Settings model', 'cl') ?>">
                <span class="dashicons dashicons-plus"></span>
                <?= Lang_cl::_e('Add New Settings model', 'cl') ?>
            </button>
        </div>
    </div>

    
    <!-- Add new model settings modal : is hided by default -->
    <div class="model-settings-form cl-hide">
        <div class="model-settings-content">
            <div>
                <?= Lang_cl::_e('Settings model name', 'cl') ?><br/>
                <input type="text" name="model_name" isRequired="yes" value="" /> <br/>
                <p>
                    <?= Lang_cl::_e('Choose a name that clearly describes the purpose of creating this settings model. For instance, if you are using this model to sell products in the African market, you could name it "Settings for the African Market." ', 'cl') ?>
                </p>
            </div>
            
            <div>
                <?= Lang_cl::_e('Duplicate from', 'cl') ?><br/>
                <select name="duplicate_from_model_id">
                    <option value="0" selected="selected">
                        <?= Lang_cl::_e('Default settings', 'cl') ?>
                    </option>
                    <?php foreach ($settingModels as $settingModel) { ?>
                    <option value="<?= $settingModel->id ?>"> <?= $settingModel->name ?></option>
                    <?php } ?>
                </select>
                <p>
                    <?= Lang_cl::_e('', 'cl') ?>
                </p>
            </div>
            
            <div>
                <?= Lang_cl::_e('Settings model lang', 'cl') ?><br/>
                <select name="model_lang_code"><br/>
                    <?php foreach ($langs_cl as $langCode => $lang) { ?>
                        <option value="<?= $langCode ?>" langdir="<?= $lang['dir'] ?>">
                            <?= $lang['name'] ?>
                        </option>
                    <?php }  ?>
                </select>
                <p>
                    <?= Lang_cl::_e('', 'cl') ?>
                </p>
            </div>
            
            <div>
                <?= Lang_cl::_e('Settings model lang direction', 'cl') ?><br/>
                <select name="model_lang_direction"><br/>
                    <option value="ltr"><?= Lang_cl::_e('Left to right', 'cl') ?></option>
                    <option value="rtl"><?= Lang_cl::_e('Right to left', 'cl') ?></option>
                </select>
                <p>
                    <?= Lang_cl::_e('', 'cl') ?>
                </p>
            </div>
            
            <div class="cl-user-fedback">
                <div class="cl-msg_box">
                    <div class="alert"></div>
                </div>
            </div>
        </div> 
    </div>
    
</div>