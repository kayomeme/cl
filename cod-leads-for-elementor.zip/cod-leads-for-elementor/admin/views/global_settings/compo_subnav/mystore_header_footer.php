<div class="cl-compo-navtop">
<a href="?page=cl_global_settings&compo=mystore&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'mystore' ? 'cl-active' : '' ?>">
    <?= Lang_cl::_e('General', 'cl') ?>
</a>

<a href="?page=cl_global_settings&compo=header&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'header' ? 'cl-active' : '' ?>">
    <?= Lang_cl::_e('Header [Desktop]', 'cl') ?>
</a>
    
<a href="?page=cl_global_settings&compo=footer&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'footer' ? 'cl-active' : '' ?>">
    <?= Lang_cl::_e('Footer', 'cl') ?>
</a>
    
</div>