<?php 
//var_dump($sharedSettings);
?>
<div class="sale-funnel-parms">
    <div class="clfe-cart-and-checkout">
        <div>
            <span><?= Lang_clfe::_e('Cart System', 'clfe') ?></span><br/>
            <select name="cart_mode" value="<?= $sharedSettings['cart_mode'] ?>">
                <option value="modal_left" <?= $sharedSettings['cart_mode'] == 'modal_left' ? 'selected' : '' ?>>
                    <?= Lang_clfe::_e('Side left', 'clfe') ?>
                </option>
                <option value="modal_right" <?= $sharedSettings['cart_mode'] == 'modal_right' ? 'selected' : '' ?>>
                    <?= Lang_clfe::_e('Side right', 'clfe') ?>
                </option>
                <option value="in_product" <?= $sharedSettings['cart_mode'] == 'in_product' ? 'selected' : '' ?>>
                    <?= Lang_clfe::_e('Direct in the product', 'clfe') ?>
                </option>
                <option value="in_page" <?= $sharedSettings['cart_mode'] == 'in_page' ? 'selected' : '' ?>>
                    <?= Lang_clfe::_e('Redirect To cart page', 'clfe') ?>
                </option>
            </select>
        </div>
        <div>
            <span><?= Lang_clfe::_e('Checkout System', 'clfe') ?></span><br/>
            <select name="checkout_mode" value="<?= $sharedSettings['checkout_mode'] ?>">
                <option value="modal" <?= $sharedSettings['checkout_mode'] == 'modal' ? 'selected' : '' ?>>
                    <?= Lang_clfe::_e('Modal', 'clfe') ?>
                </option>
                <option value="in_product" <?= $sharedSettings['checkout_mode'] == 'in_product' ? 'selected' : '' ?>>
                    <?= Lang_clfe::_e('Direct in the product', 'clfe') ?>
                </option>
                <option value="in_page" <?= $sharedSettings['checkout_mode'] == 'in_page' ? 'selected' : '' ?>>
                    <?= Lang_clfe::_e('Redirect To checkout page', 'clfe') ?>
                </option>
            </select>
        </div>

            




   
    </div>
    <div class="clfe-compo-navtop">
        <a href="?page=clfe_global_settings&compo=sales_funnel&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'sales_funnel' ? 'clfe-active' : '' ?>">
            <?= Lang_clfe::_e('General', 'clfe') ?>
        </a>
        <a href="?page=clfe_global_settings&compo=product&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'product' ? 'clfe-active' : '' ?>">
            <?= Lang_clfe::_e('Product page', 'clfe') ?>
        </a>

        <a href="?page=clfe_global_settings&compo=cart&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'cart' ? 'clfe-active' : '' ?>">
            <?= Lang_clfe::_e('Cart', 'clfe') ?>
        </a>

        <a href="?page=clfe_global_settings&compo=checkout&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'checkout' ? 'clfe-active' : '' ?>">
            <?= Lang_clfe::_e('Checkout', 'clfe') ?>
        </a>

        <a href="?page=clfe_global_settings&compo=thankyou&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'thankyou' ? 'clfe-active' : '' ?>">
            <?= Lang_clfe::_e('Thankyou', 'clfe') ?>
        </a>
    </div>
</div>