<div class="cl-compo-navtop">
<a href="?page=cl_global_settings&compo=plist1&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'plist1' ? 'cl-active' : '' ?>">
    <?= Lang_cl::_e('Products Listing [default]', 'cl') ?>
</a>

<a href="?page=cl_global_settings&compo=plist5&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'plist5' ? 'cl-active' : '' ?>">
    <?= Lang_cl::_e('Products Listing [Thankyou upsell]', 'cl') ?>
</a>
    
<a href="?page=cl_global_settings&compo=categories_listing&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'categories_listing' ? 'cl-active' : '' ?>">
    <?= Lang_cl::_e('Categories Listing', 'cl') ?>
</a>
</div>