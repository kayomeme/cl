<div class="clfe-compo-navtop">
<a href="?page=clfe_global_settings&compo=plist1&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'plist1' ? 'clfe-active' : '' ?>">
    <?= Lang_clfe::_e('Products Listing', 'clfe') ?>
</a>

<a href="?page=clfe_global_settings&compo=categories_listing&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'categories_listing' ? 'clfe-active' : '' ?>">
    <?= Lang_clfe::_e('Categories Listing', 'clfe') ?>
</a>
</div>