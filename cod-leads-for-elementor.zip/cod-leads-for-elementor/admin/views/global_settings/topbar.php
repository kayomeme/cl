<a href="?page=cl_global_settings&compo=mystore&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'mystore' ? 'cl-navtab-active' : '' ?>">
    <span class="dashicons dashicons-store"></span>
    <?= Lang_cl::_e('My Store', 'cl') ?>
</a>
<a href="?page=cl_global_settings&compo=sales_funnel&settings_model_id=<?= $settingsModelId ?>" class="<?= in_array($compoName, ['sales_funnel', 'product', 'cart', 'checkout', 'thankyou']) ? 'cl-navtab-active' : '' ?>">
    <span class="dashicons dashicons-welcome-widgets-menus"></span>
    <?= Lang_cl::_e('Sales Funnel', 'cl') ?>
</a>
<a href="?page=cl_global_settings&compo=google_sheet&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'google_sheet' ? 'cl-navtab-active' : '' ?>">
    <?= Lang_cl::_e('Sheet', 'cl') ?>
</a>
<!--<a href="?page=cl_global_settings&compo=order_status&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'order_statuses' ? 'cl-navtab-active' : '' ?>">
    <?= Lang_cl::_e('Order statuses', 'cl') ?>
</a>-->
<a href="?page=cl_global_settings&compo=plist1&settings_model_id=<?= $settingsModelId ?>" class="<?= in_array($compoName, ['plist1', 'categories_listing']) ? 'cl-navtab-active' : '' ?>">
    <?= Lang_cl::_e('Listing', 'cl') ?>
</a>
<a href="?page=cl_global_settings&compo=whatsapp&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'whatsapp' ? 'cl-navtab-active' : '' ?>">
    <?= Lang_cl::_e('Whatsapp', 'cl') ?>
</a>
<a href="?page=cl_global_settings&compo=tracking&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'tracking' ? 'cl-navtab-active' : '' ?>">
    <span class="dashicons dashicons-buddicons-tracking"></span>
    <?= Lang_cl::_e('Tracking', 'cl') ?>
</a>
<a href="?page=cl_global_settings&compo=insights&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'insights' ? 'cl-navtab-active' : '' ?>">
    <?= Lang_cl::_e('Insights', 'cl') ?>
</a>