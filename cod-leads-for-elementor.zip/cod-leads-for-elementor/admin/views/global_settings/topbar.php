<a href="?page=clfe_global_settings&compo=mystore&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'mystore' ? 'clfe-navtab-active' : '' ?>">
    <span class="dashicons dashicons-store"></span>
    <?= Lang_clfe::_e('My Store', 'clfe') ?>
</a>
<a href="?page=clfe_global_settings&compo=sales_funnel&settings_model_id=<?= $settingsModelId ?>" class="<?= in_array($compoName, ['sales_funnel', 'product', 'cart', 'checkout', 'thankyou']) ? 'clfe-navtab-active' : '' ?>">
    <span class="dashicons dashicons-welcome-widgets-menus"></span>
    <?= Lang_clfe::_e('Sales Funnel', 'clfe') ?>
</a>
<a href="?page=clfe_global_settings&compo=google_sheet&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'google_sheet' ? 'clfe-navtab-active' : '' ?>">
    <?= Lang_clfe::_e('Sheet', 'clfe') ?>
</a>
<!--<a href="?page=clfe_global_settings&compo=order_status&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'order_statuses' ? 'clfe-navtab-active' : '' ?>">
    <?= Lang_clfe::_e('Order statuses', 'clfe') ?>
</a>-->
<a href="?page=clfe_global_settings&compo=plist1&settings_model_id=<?= $settingsModelId ?>" class="<?= in_array($compoName, ['plist1', 'categories_listing']) ? 'clfe-navtab-active' : '' ?>">
    <?= Lang_clfe::_e('Listing', 'clfe') ?>
</a>
<a href="?page=clfe_global_settings&compo=whatsapp&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'whatsapp' ? 'clfe-navtab-active' : '' ?>">
    <?= Lang_clfe::_e('Whatsapp', 'clfe') ?>
</a>
<a href="?page=clfe_global_settings&compo=top_bar&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'top_bar' ? 'clfe-navtab-active' : '' ?>">
    <?= Lang_clfe::_e('Top bar', 'clfe') ?>
</a>
<a href="?page=clfe_global_settings&compo=tracking&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'tracking' ? 'clfe-navtab-active' : '' ?>">
    <span class="dashicons dashicons-buddicons-tracking"></span>
    <?= Lang_clfe::_e('Tracking', 'clfe') ?>
</a>
<a href="?page=clfe_global_settings&compo=insights&settings_model_id=<?= $settingsModelId ?>" class="<?= $compoName == 'insights' ? 'clfe-navtab-active' : '' ?>">
    <?= Lang_clfe::_e('Insights', 'clfe') ?>
</a>