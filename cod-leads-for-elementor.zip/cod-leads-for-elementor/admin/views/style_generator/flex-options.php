<?php 
// Check if flex-options is defined and is an array
$flexOptions = isset($activeOptions['flex-options']) && is_array($activeOptions['flex-options']) 
    ? $activeOptions['flex-options'] 
    : [];

// Don't render anything if no flex options are enabled
if (empty($flexOptions)) {
    return;
}
?>

<fieldset>
    <legend class="clfe-accordion">
        <span class="clfe-label-draggable">
            <?= isset( $flexOptions['blockTitle'] ) ? $flexOptions['blockTitle'] : Lang_clfe::_e('Flex options', 'clfe') ?>
        </span>
        <div class="clfe-draggable-icons-container">
            <span class="dashicons dashicons-sort"></span>
        </div>
    </legend>
    <div class="clfe-accordion-panel">

            <?php if (isset($flexOptions['flex-direction']) && $flexOptions['flex-direction']): ?>
            <div class="key">
                <span class="clfe-key-label">
                    <?= $flexOptions['flex-direction'] != 'yes' ? $flexOptions['flex-direction'] : Lang_clfe::_e('Direction', 'clfe') ?>
                </span>
                <select class="clfe-style-element" style_key="flex-direction" ext="" value="<?= isset($newArray['flex-direction']) ? $newArray['flex-direction'] : 'row' ?>">
                    <option value="row" <?= (isset($newArray['flex-direction']) && $newArray['flex-direction'] == 'row') ? 'selected' : '' ?>><?= Lang_clfe::_e('Row', 'clfe') ?></option>
                    <option value="row-reverse" <?= (isset($newArray['flex-direction']) && $newArray['flex-direction'] == 'row-reverse') ? 'selected' : '' ?>><?= Lang_clfe::_e('Row Reverse', 'clfe') ?></option>
                    <option value="column" <?= (isset($newArray['flex-direction']) && $newArray['flex-direction'] == 'column') ? 'selected' : '' ?>><?= Lang_clfe::_e('Column', 'clfe') ?></option>
                    <option value="column-reverse" <?= (isset($newArray['flex-direction']) && $newArray['flex-direction'] == 'column-reverse') ? 'selected' : '' ?>><?= Lang_clfe::_e('Column Reverse', 'clfe') ?></option>
                </select>
            </div>
            <?php endif; ?>
            
            <?php if (isset($flexOptions['justify-content']) && $flexOptions['justify-content']): ?>
            <div class="key">
                <span class="clfe-key-label">
                    <?= $flexOptions['justify-content'] != 'yes' ? $flexOptions['justify-content'] : Lang_clfe::_e('Horizontal alignment', 'clfe') ?>
                </span>
                <select class="clfe-style-element" style_key="justify-content" ext="" value="<?= isset($newArray['justify-content']) ? $newArray['justify-content'] : 'flex-start' ?>">
                    <option value="flex-start" <?= (isset($newArray['justify-content']) && $newArray['justify-content'] == 'flex-start') ? 'selected' : '' ?>><?= Lang_clfe::_e('Start', 'clfe') ?></option>
                    <option value="center" <?= (isset($newArray['justify-content']) && $newArray['justify-content'] == 'center') ? 'selected' : '' ?>><?= Lang_clfe::_e('Center', 'clfe') ?></option>
                    <option value="flex-end" <?= (isset($newArray['justify-content']) && $newArray['justify-content'] == 'flex-end') ? 'selected' : '' ?>><?= Lang_clfe::_e('End', 'clfe') ?></option>
                    <option value="space-between" <?= (isset($newArray['justify-content']) && $newArray['justify-content'] == 'space-between') ? 'selected' : '' ?>><?= Lang_clfe::_e('Space Between', 'clfe') ?></option>
                    <option value="space-around" <?= (isset($newArray['justify-content']) && $newArray['justify-content'] == 'space-around') ? 'selected' : '' ?>><?= Lang_clfe::_e('Space Around', 'clfe') ?></option>
                    <option value="space-evenly" <?= (isset($newArray['justify-content']) && $newArray['justify-content'] == 'space-evenly') ? 'selected' : '' ?>><?= Lang_clfe::_e('Space Evenly', 'clfe') ?></option>
                </select>
            </div>
            <?php endif; ?>
            
            <?php if (isset($flexOptions['align-items']) && $flexOptions['align-items']): ?>
            <div class="key">
                <span class="clfe-key-label">
                    <?= $flexOptions['align-items'] != 'yes' ? $flexOptions['align-items'] : Lang_clfe::_e('Vertical alignment', 'clfe') ?>
                </span>
                <select class="clfe-style-element" style_key="align-items" ext="" value="<?= isset($newArray['align-items']) ? $newArray['align-items'] : 'center' ?>">
                    <option value="start" <?= (isset($newArray['align-items']) && $newArray['align-items'] == 'start') ? 'selected' : '' ?>><?= Lang_clfe::_e('Start', 'clfe') ?></option>
                    <option value="center" <?= (isset($newArray['align-items']) && $newArray['align-items'] == 'center') ? 'selected' : '' ?>><?= Lang_clfe::_e('Center', 'clfe') ?></option>
                    <option value="end" <?= (isset($newArray['align-items']) && $newArray['align-items'] == 'end') ? 'selected' : '' ?>><?= Lang_clfe::_e('End', 'clfe') ?></option>
                    <option value="stretch" <?= (isset($newArray['align-items']) && $newArray['align-items'] == 'stretch') ? 'selected' : '' ?>><?= Lang_clfe::_e('Stretch', 'clfe') ?></option>
                    <option value="baseline" <?= (isset($newArray['align-items']) && $newArray['align-items'] == 'baseline') ? 'selected' : '' ?>><?= Lang_clfe::_e('Baseline', 'clfe') ?></option>
                    <option value="normal" <?= (isset($newArray['align-items']) && $newArray['align-items'] == 'normal') ? 'selected' : '' ?>><?= Lang_clfe::_e('Normal', 'clfe') ?></option>
                    <option value="self-start" <?= (isset($newArray['align-items']) && $newArray['align-items'] == 'self-start') ? 'selected' : '' ?>><?= Lang_clfe::_e('Self Start', 'clfe') ?></option>
                    <option value="self-end" <?= (isset($newArray['align-items']) && $newArray['align-items'] == 'self-end') ? 'selected' : '' ?>><?= Lang_clfe::_e('Self End', 'clfe') ?></option>
                    <option value="flex-start" <?= (isset($newArray['align-items']) && $newArray['align-items'] == 'flex-start') ? 'selected' : '' ?>><?= Lang_clfe::_e('Flex Start', 'clfe') ?></option>
                    <option value="flex-end" <?= (isset($newArray['align-items']) && $newArray['align-items'] == 'flex-end') ? 'selected' : '' ?>><?= Lang_clfe::_e('Flex End', 'clfe') ?></option>
                </select>
            </div>
            <?php endif; ?>
            
            <?php if (isset($flexOptions['gap']) && $flexOptions['gap']): ?>
            <div class="key">
                <span class="clfe-key-label">
                    <?= $flexOptions['gap'] != 'yes' ? $flexOptions['gap'] : Lang_clfe::_e('Gap', 'clfe') ?>
                    <span class="clfe-range-value"> : <?= isset($newArray['gap']) ? $newArray['gap'] : '' ?></span>
                </span>

                <input type="number" class="clfe-style-element clfe-style-number" min="0" max="100" value="<?= isset($newArray['gap']) ? $newArray['gap'] : '' ?>" style_key="gap" ext="px" />

            </div>
            <?php endif; ?>
            
            <?php if (isset($flexOptions['flex-wrap']) && $flexOptions['flex-wrap']): ?>
            <div class="key">
                <span class="clfe-key-label">
                    <?= $flexOptions['flex-wrap'] != 'yes' ? $flexOptions['flex-wrap'] : Lang_clfe::_e('Flex Wrap', 'clfe') ?>
                </span>
                <select class="clfe-style-element" style_key="flex-wrap" ext="" value="<?= isset($newArray['flex-wrap']) ? $newArray['flex-wrap'] : 'nowrap' ?>">
                    <option value="nowrap" <?= (isset($newArray['flex-wrap']) && $newArray['flex-wrap'] == 'nowrap') ? 'selected' : '' ?>><?= Lang_clfe::_e('No Wrap', 'clfe') ?></option>
                    <option value="wrap" <?= (isset($newArray['flex-wrap']) && $newArray['flex-wrap'] == 'wrap') ? 'selected' : '' ?>><?= Lang_clfe::_e('Wrap', 'clfe') ?></option>
                    <option value="wrap-reverse" <?= (isset($newArray['flex-wrap']) && $newArray['flex-wrap'] == 'wrap-reverse') ? 'selected' : '' ?>><?= Lang_clfe::_e('Wrap Reverse', 'clfe') ?></option>
                </select>
            </div>
            <?php endif; ?>

    </div>
</fieldset>