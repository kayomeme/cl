<fieldset>
    <legend class="clfe-accordion">
        <span class="clfe-label-draggable">
            <?= Lang_clfe::_e('Border options', 'clfe') ?>
        </span>
        <div class="clfe-draggable-icons-container">
            <span class="dashicons dashicons-sort"></span>
        </div>
    </legend>
    <div class="clfe-accordion-panel">                
        <div class="key" style="width: 98%">
            <span class="clfe-key-label">
                <?= Lang_clfe::_e('border-width', 'clfe') ?>
                <span class="clfe-range-value"> : <?= isset( $newArray['border-width'] ) ? $newArray['border-width'] : '' ?></span>
            </span>
            <div class="clfe-flex-center">
                <div>
                    <?= Lang_clfe::_e('Top', 'clfe') ?>
                    <input type="number" class="clfe-style-element clfe-style-number" min="0" max="10" value="<?= isset( $newArray['border-top-width'] ) ? $newArray['border-top-width'] : '' ?>" style_key="border-top-width" ext="px" /> 
                </div>
                <div>
                   <?= Lang_clfe::_e('Right', 'clfe') ?>
                    <input type="number" class="clfe-style-element clfe-style-number" min="0" max="10" value="<?= isset( $newArray['border-right-width'] ) ? $newArray['border-right-width'] : '' ?>" style_key="border-right-width" ext="px" />
                </div>
                <div>
                   <?= Lang_clfe::_e('Bottom', 'clfe') ?>
                    <input type="number" class="clfe-style-element clfe-style-number" min="0" max="10" value="<?= isset( $newArray['border-bottom-width'] ) ? $newArray['border-bottom-width'] : '' ?>" style_key="border-bottom-width" ext="px" />
                </div>
                <div>
                    <?= Lang_clfe::_e('Left', 'clfe') ?>
                    <input type="number" class="clfe-style-element clfe-style-number" min="0" max="10" value="<?= isset( $newArray['border-left-width'] ) ? $newArray['border-left-width'] : '' ?>" style_key="border-left-width" ext="px" />
                </div>
            </div>
        </div> 

        <div class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('border-color', 'clfe') ?></span>
            <input type="text" class="clfe-style-element clfe-style-color" value="<?= isset( $newArray['border-color'] ) ? $newArray['border-color'] : '' ?>" style_key="border-color" ext="" /> 
        </div> 

        <div class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('border-style', 'clfe') ?> </span>
            <select class="clfe-style-element" value="<?= isset( $newArray['border-style'] ) ? $newArray['border-style'] : '' ?>" style_key="border-style" ext="">
                <option value="solid"><?= Lang_clfe::_e('solid', 'clfe') ?></option>
                <option value="double"><?= Lang_clfe::_e('double', 'clfe') ?></option>
                <option value="dashed"><?= Lang_clfe::_e('dashed', 'clfe') ?></option>
                <option value="dotted"><?= Lang_clfe::_e('dotted', 'clfe') ?></option>
                <option value="ridge"><?= Lang_clfe::_e('ridge', 'clfe') ?></option>
                <option value="none"><?= Lang_clfe::_e('none', 'clfe') ?></option>
            </select> 
        </div>

        <div class="key" style="width: 98%">
            <span class="clfe-key-label"><?= Lang_clfe::_e('border-radius', 'clfe') ?></span>
            <div class="clfe-flex-center">
                <div>
                    <?= Lang_clfe::_e('Top left', 'clfe') ?><br/>
                    <input type="number" class="clfe-style-element" max="150" value="<?= isset( $newArray['border-top-left-radius'] ) ? $newArray['border-top-left-radius'] : '' ?>" style_key="border-top-left-radius" ext="px" />
                </div>
                <div>
                    <?= Lang_clfe::_e('Top right', 'clfe') ?><br/>
                    <input type="number" class="clfe-style-element" max="150" value="<?= isset( $newArray['border-top-right-radius'] ) ? $newArray['border-top-right-radius'] : '' ?>" style_key="border-top-right-radius" ext="px" />
                </div>
                <div>
                    <?= Lang_clfe::_e('Bottom left', 'clfe') ?><br/>
                    <input type="number" class="clfe-style-element" max="150" value="<?= isset( $newArray['border-bottom-left-radius'] ) ? $newArray['border-bottom-left-radius'] : '' ?>" style_key="border-bottom-left-radius" ext="px" />
                </div>
                <div>
                    <?= Lang_clfe::_e('Bottom right', 'clfe') ?><br/>
                    <input type="number" class="clfe-style-element" max="150" value="<?= isset( $newArray['border-bottom-right-radius'] ) ? $newArray['border-bottom-right-radius'] : '' ?>" style_key="border-bottom-right-radius" ext="px" />
                </div>
            </div>
        </div> 
    </div>
</fieldset>