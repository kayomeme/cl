<fieldset>
    <legend class="clfe-accordion">
        <span class="clfe-label-draggable">
            <?= Lang_clfe::_e('Font options', 'clfe') ?>
        </span>
        <div class="clfe-draggable-icons-container">
            <span class="dashicons dashicons-sort"></span>
        </div>
    </legend>
    <div class="clfe-accordion-panel">
        <div class="clfe-flex-center">
            <?php 
            $fontSizeExt = $this->getFontsizeExt($newArray['font-size']);
            ?>
            <div class="key">
                <span class="clfe-key-label">
                    <?= Lang_clfe::_e('Font-size', 'clfe') ?>
                    <span class="clfe-range-value"> : <?= isset($newArray['font-size']) ? $newArray['font-size'] : '' ?></span>
                </span>
                <div class="clfe-size-input-container">
                    <input type="number" class="clfe-style-element clfe-style-number" min="1" max="100" value="<?= isset($newArray['font-size']) ? $newArray['font-size'] : '' ?>" style_key="font-size" ext="<?= $fontSizeExt ?>" />
                    <select class="clfe-size-ext">
                        <option value="px" <?= $fontSizeExt === 'px' ? 'selected' : '' ?>>px</option>
                        <option value="em" <?= $fontSizeExt === 'em' ? 'selected' : '' ?>>em</option>
                        <option value="rem" <?= $fontSizeExt === 'rem' ? 'selected' : '' ?>>rem</option>
                        <option value="%" <?= $fontSizeExt === '%' ? 'selected' : '' ?>>%</option>
                        <option value="vw" <?= $fontSizeExt === 'vw' ? 'selected' : '' ?>>vw</option>
                    </select>
                </div>
            </div> 
            <div class="key">
                <span class="clfe-key-label"><?= Lang_clfe::_e('Text color', 'clfe') ?></span>
                <input type="text" class="clfe-style-element clfe-style-color" value="<?= isset($newArray['color']) ? $newArray['color'] : '' ?>" style_key="color" ext="" /> <br/>
            </div> 
            <div class="key">
                <span class="clfe-key-label"><?= Lang_clfe::_e('Font-weight', 'clfe') ?> </span>
                <select class="clfe-style-element" value="<?= isset($newArray['font-weight']) ? $newArray['font-weight'] : '' ?>" style_key="font-weight" ext="">
                    <option value="700"><?= Lang_clfe::_e('Bold', 'clfe') ?></option>
                    <option value="800"><?= Lang_clfe::_e('Extra-bold', 'clfe') ?></option>
                    <option value="normal"><?= Lang_clfe::_e('Normal', 'clfe') ?></option>
                    <option value="unset"><?= Lang_clfe::_e('None', 'clfe') ?></option>
                </select>
            </div>
        </div>
    </div>
</fieldset>