<fieldset>
    <legend class="clfe-accordion">
        <span class="clfe-label-draggable">
            <?= Lang_clfe::_e('background options', 'clfe') ?>
        </span>
        <div class="clfe-draggable-icons-container">
            <span class="dashicons dashicons-sort"></span>
        </div>
    </legend> 
    <div class="clfe-accordion-panel">
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Background-color', 'clfe') ?></span>
            <input type="text" class="clfe-style-element clfe-style-color" value="<?= isset( $newArray['background-color'] ) ? $newArray['background-color'] : '' ?>" style_key="background-color" ext="" />
        </span> 
    </div>
</fieldset>