<fieldset class="clfe-linear-gradient">
    <legend class="clfe-accordion">
        <span class="clfe-label-draggable">
            <?= Lang_clfe::_e('Background gradient', 'clfe') ?>
        </span>
        <div class="clfe-draggable-icons-container">
            <span class="dashicons dashicons-sort"></span>
        </div>
    </legend> 
    <div class="clfe-accordion-panel">
        <div class="clfe-flex-center">
            <div class="key">
                <span class="clfe-key-label"><?= Lang_clfe::_e('Color 1', 'clfe') ?></span>
                <input type="text" class="linear-gradient-color1 clfe-style-color" value="<?= isset( $linearGradientOptions[1] ) ? $linearGradientOptions[1] : 0 ?>" />
            </div>
            <div class="key">
                <span class="clfe-key-label"><?= Lang_clfe::_e('Color 2', 'clfe') ?></span>
                <input type="text" class="linear-gradient-color2 clfe-style-color" value="<?= isset( $linearGradientOptions[2] ) ? $linearGradientOptions[2] : 1 ?>" />
            </div>
            <div class="key">
                <span class="clfe-key-label"><?= Lang_clfe::_e('Deg', 'clfe') ?></span>
                <input type="number" max="355" class="linear-gradient-deg" value="<?= isset( $linearGradientOptions[0] ) ? $linearGradientOptions[0] : 0 ?>" />
            </div> 
        </div>
        
        <input type="hidden" class="clfe-style-element" value="<?= isset( $newArray['background-image'] ) ? $newArray['background-image'] : '' ?>" style_key="background-image" ext="" />
        <br/>
        <a href="https://cssgenerator.org/box-shadow-css-generator.html">
            <?= Lang_clfe::_e('For more details about shadow options visit this link', 'clfe') ?>
        </a>  
    </div>
</fieldset>