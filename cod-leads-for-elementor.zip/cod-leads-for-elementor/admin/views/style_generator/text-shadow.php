<fieldset class="clfe-text-shadow">
    <legend class="clfe-accordion">
        <span class="clfe-label-draggable">
            <?= Lang_clfe::_e('Text Shadow Options', 'clfe') ?>
        </span>
        <div class="clfe-draggable-icons-container">
            <span class="dashicons dashicons-sort"></span>
        </div>
    </legend> 
    <div class="clfe-accordion-panel">
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Horizontal Shadow Length', 'clfe') ?></span>
            <input type="number" class="horizontal-shadow-length" value="<?= isset( $textShadowOptions[0] ) ? $textShadowOptions[0] : 0 ?>" />
        </span> 
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Vertical Shadow Length', 'clfe') ?></span>
            <input type="number" class="vertical-shadow-length" value="<?= isset( $textShadowOptions[1] ) ? $textShadowOptions[1] : 0 ?>" />
        </span>
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Blur Radius', 'clfe') ?></span>
            <input type="number" class="blur-radius" value="<?= isset( $textShadowOptions[2] ) ? $textShadowOptions[2] : 0 ?>" />
        </span> 
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Shadow Color', 'clfe') ?></span>
            <input type="text" class="shadow-Color clfe-style-color" value="<?= isset( $textShadowOptions[3] ) ? $textShadowOptions[3] : 0 ?>" />
        </span>
        <!--<span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Shadow Color Opacity', 'clfe') ?></span>
            <input type="number" id="price" min="0" max="10" step="0.01" value="0.00">
        </span>
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Inset', 'clfe') ?></span>
            <input type="number" min="0" max="1" step="0.01" value="0.00">
        </span>   -->
        <input type="hidden" class="clfe-style-element" value="<?= isset( $newArray['text-shadow'] ) ? $newArray['text-shadow'] : '' ?>" style_key="text-shadow" ext="" />
        <br/>
        <a href="https://cssgenerator.org/text-shadow-css-generator.html">
            <?= Lang_clfe::_e('For more details about shadow options visit this link', 'clfe') ?>
        </a>
    </div>
</fieldset>