<fieldset class="clfe-box-shadow">
    <legend class="clfe-accordion">
        <span class="clfe-label-draggable">
            <?= Lang_clfe::_e('Box Shadow Options', 'clfe') ?>
        </span>
        <div class="clfe-draggable-icons-container">
            <span class="dashicons dashicons-sort"></span>
        </div>
    </legend> 
    <div class="clfe-accordion-panel">
        <div class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Horizontal Shadow Length', 'clfe') ?></span>
            <input type="number" class="horizontal-shadow-length" value="<?= isset( $boxShadowOptions[0] ) ? $boxShadowOptions[0] : 0 ?>" />
        </div> 
        <div class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Vertical Shadow Length', 'clfe') ?></span>
            <input type="number" class="vertical-shadow-length" value="<?= isset( $boxShadowOptions[1] ) ? $boxShadowOptions[1] : 0 ?>" />
        </div>
        <div class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Blur Radius', 'clfe') ?></span>
            <input type="number" class="blur-radius" value="<?= isset( $boxShadowOptions[2] ) ? $boxShadowOptions[2] : 0 ?>" />
        </div> 
        <div class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Spread Radius', 'clfe') ?></span>
            <input type="number" class="spread-radius" value="<?= isset( $boxShadowOptions[3] ) ? $boxShadowOptions[3] : 0 ?>" />
        </div>
        <div class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Shadow Color', 'clfe') ?></span>
            <input type="text" class="shadow-Color clfe-style-color" value="<?= isset( $boxShadowOptions[4] ) ? $boxShadowOptions[4] : 0 ?>" />
        </div>
        <!--<span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Shadow Color Opacity', 'clfe') ?></span>
            <input type="number" id="price" min="0" max="10" step="0.01" value="0.00">
        </span>
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Inset', 'clfe') ?></span>
            <input type="number" min="0" max="1" step="0.01" value="0.00">
        </span>   -->
        
        <div>
            <a target="_blank" href="https://cssgenerator.org/box-shadow-css-generator.html">
                <?= Lang_clfe::_e('For more details about shadow options visit this link', 'clfe') ?>
            </a>
        </div>
        <input type="hidden" class="clfe-style-element" value="<?= isset( $newArray['box-shadow'] ) ? $newArray['box-shadow'] : '' ?>" style_key="box-shadow" ext="" />
    </div>
</fieldset>