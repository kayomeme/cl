<fieldset>
    <legend class="clfe-accordion">
        <span class="clfe-label-draggable">
            <?= Lang_clfe::_e('Padding options', 'clfe') ?>
        </span>
        <div class="clfe-draggable-icons-container">
            <span class="dashicons dashicons-sort"></span>
        </div>
    </legend> 
    <div class="clfe-accordion-panel">
        <div class="key" style="width: 98%">
            <div class="clfe-flex-center">
                <div>
                    <span class="clfe-key-label"><?= Lang_clfe::_e('Top', 'clfe') ?></span>
                    <input type="number" class="clfe-style-element" max="50" value="<?= isset( $newArray['padding-top'] ) ? $newArray['padding-top'] : '' ?>" style_key="padding-top" ext="px" />
                </div> 
                <div>
                    <span class="clfe-key-label"><?= Lang_clfe::_e('Right', 'clfe') ?></span>
                    <input type="number" class="clfe-style-element" max="50" value="<?= isset( $newArray['padding-right'] ) ? $newArray['padding-right'] : '' ?>" style_key="padding-right" ext="px" />
                </div> 
                <div>
                    <span class="clfe-key-label"><?= Lang_clfe::_e('Bottom', 'clfe') ?></span>
                    <input type="number" class="clfe-style-element" max="50" value="<?= isset( $newArray['padding-bottom'] ) ? $newArray['padding-bottom'] : '' ?>" style_key="padding-bottom" ext="px" />
                </div> 
                <div>
                    <span class="clfe-key-label"><?= Lang_clfe::_e('Left', 'clfe') ?></span>
                    <input type="number" class="clfe-style-element" max="50" value="<?= isset( $newArray['padding-left'] ) ? $newArray['padding-left'] : '' ?>" style_key="padding-left" ext="px" />
                </div> 
            </div>
        </div>
        

    </div>
</fieldset>