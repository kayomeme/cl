<fieldset>
    <legend class="clfe-accordion">
        <span class="clfe-label-draggable">
            <?= Lang_clfe::_e('Margin options', 'clfe') ?>
        </span>
        <div class="clfe-draggable-icons-container">
            <span class="dashicons dashicons-sort"></span>
        </div>
    </legend> 
    <div class="clfe-accordion-panel">
        <div class="key" style="width: 98%">
            <div class="clfe-flex-center">
                <div>
                    <span class="clfe-key-label"><?= Lang_clfe::_e('Top', 'clfe') ?></span>
                    <input type="number" class="clfe-style-element" max="50" value="<?= isset( $newArray['margin-top'] ) ? $newArray['margin-top'] : '' ?>" style_key="margin-top" ext="px" />
                </div> 
                <div>
                    <span class="clfe-key-label"><?= Lang_clfe::_e('Right', 'clfe') ?></span>
                    <input type="number" class="clfe-style-element" max="50" value="<?= isset( $newArray['margin-right'] ) ? $newArray['margin-right'] : '' ?>" style_key="margin-right" ext="px" />
                </div> 
                <div>
                    <span class="clfe-key-label"><?= Lang_clfe::_e('Bottom', 'clfe') ?></span>
                    <input type="number" class="clfe-style-element" max="50" value="<?= isset( $newArray['margin-bottom'] ) ? $newArray['margin-bottom'] : '' ?>" style_key="margin-bottom" ext="px" />
                </div> 
                <div>
                    <span class="clfe-key-label"><?= Lang_clfe::_e('Left', 'clfe') ?></span>
                    <input type="number" class="clfe-style-element" max="50" value="<?= isset( $newArray['margin-left'] ) ? $newArray['margin-left'] : '' ?>" style_key="margin-left" ext="px" />
                </div> 
            </div>
        </div>
        

    </div>
</fieldset>