<fieldset>
    <legend class="clfe-accordion">
        <span class="clfe-label-draggable">
            <?= Lang_clfe::_e('Global options', 'clfe') ?>
        </span>
        <div class="clfe-draggable-icons-container">
            <span class="dashicons dashicons-sort"></span>
        </div>
    </legend>
    <div class="clfe-accordion-panel">
        <?php if( isset( $activeOptions['predefined_width'] ) ) { ?>
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Width', 'clfe') ?> </span>
            <select class="clfe-style-element" value="<?= isset( $newArray['width'] ) ? $newArray['width'] : '' ?>" style_key="width" ext="">
                <option value="auto" ><?= Lang_clfe::_e('Auto', 'clfe') ?></option>
                <option value="100%"><?= Lang_clfe::_e('100%', 'clfe') ?></option>
                <option value="90%"><?= Lang_clfe::_e('90%', 'clfe') ?></option>
                <option value="80%"><?= Lang_clfe::_e('80%', 'clfe') ?></option>
                <option value="70%"><?= Lang_clfe::_e('70%', 'clfe') ?></option>
                <option value="60%"><?= Lang_clfe::_e('70%', 'clfe') ?></option>
                <option value="50%"><?= Lang_clfe::_e('50%', 'clfe') ?></option>
                <option value="40%"><?= Lang_clfe::_e('50%', 'clfe') ?></option>
            </select>
        </span>
        <?php } ?>

        <?php if( isset( $activeOptions['width_pct'] ) ) { ?>
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Width', 'clfe') ?> </span>
            <input type="number" class="clfe-style-element" value="<?= isset( $newArray['width'] ) ? $newArray['width'] : '' ?>" style_key="width" ext="%" min="10" max="100" />% <br/>
        </span>
        <?php } ?>

        <?php if( isset( $activeOptions['width'] ) ) { ?>
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Width', 'clfe') ?> </span>
            <input type="number" class="clfe-style-element" value="<?= isset( $newArray['width'] ) ? $newArray['width'] : '' ?>" style_key="width" ext="px" />px <br/>
        </span>
        <?php } ?>
        
        <?php if( isset( $activeOptions['max-width'] ) ) { ?>
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Max Width', 'clfe') ?> </span>
            <input type="number" class="clfe-style-element" value="<?= isset( $newArray['max-width'] ) ? $newArray['max-width'] : '' ?>" style_key="max-width" ext="px" />px <br/>
        </span>
        <?php } ?>

        <?php if( isset( $activeOptions['height'] ) ) { ?>
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Height', 'clfe') ?> </span>
            <input type="number" class="clfe-style-element" value="<?= isset( $newArray['height'] ) ? $newArray['height'] : '' ?>" style_key="height" ext="px" />px <br/>
        </span>
        <?php } ?>

        <?php if( isset( $activeOptions['max-height'] ) ) { ?>
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Max Height', 'clfe') ?> </span>
            <input type="number" class="clfe-style-element" value="<?= isset( $newArray['max-height'] ) ? $newArray['max-height'] : '' ?>" style_key="max-height" ext="px" />px <br/>
        </span>
        <?php } ?>

        <?php if( isset( $activeOptions['min-height'] ) ) { ?>
        <span class="key">
            <span class="clfe-key-label"><?= Lang_clfe::_e('Min Height', 'clfe') ?> </span>
            <input type="number" class="clfe-style-element" value="<?= isset( $newArray['min-height'] ) ? $newArray['min-height'] : '' ?>" style_key="min-height" ext="px" />px <br/>
        </span>
        <?php } ?>
    </div>
</fieldset>