<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://kayoplugins.com
 * @since      1.0.0
 *
 * @package    cl
 * @subpackage cl/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    cl
 * @subpackage cl/admin
 * @author     Kayo plugins <kayo.plugins@gmail.com>
 */
class AdminApp_cl
{

    public static $viewsPath;
    public static $assetsUrl;
    public static $assetsPath;
    public static $previewComps = ['mystore', 'product', 'cart', 'checkout', 'thankyou', 'plist1', 'plist5', 'categories_listing'];
    //public static $settingPageSlug    = 'cl_global_settings';

    public $activeComps     = [];
    

    public $filters         = [];
    public $hooks           = [];

    /**
     * $this->glVars['assetsUrl']
     */
    public function __construct()
    {

        self::$viewsPath   = plugin_dir_path(__FILE__) . 'views/';
        self::$assetsPath   = plugin_dir_path(__FILE__) . 'assets/';
        self::$assetsUrl   = plugin_dir_url(__FILE__) . 'assets/';

        $this->loadHooksFiltersMenus();
    }

    public function welcome()
    {
        include plugin_dir_path(__FILE__) . '/views/welcome_page/index.php';
    }


    public static function getJsArgs($settingsModelId) {
        global $sharedSettings;
        $siteUrl = get_site_url();

        $jsArgs = array_merge([
            'ajax_admin_action'    => 'cl_ajax_admin_action',
            'ajax_url'              => admin_url("admin-ajax.php"),
            'site_url'              => $siteUrl,
            'ajax_nonce'            => wp_create_nonce('cl_upsell_nonce'),
            'site_id'               => MainApp_cl::getSiteId($siteUrl),
            //'product_edit_link'     => false,
            'last_response'         => ''
        ], $sharedSettings);
        
        
        
        /* if( isset( $_REQUEST['post'] ) && !isset( $_REQUEST['action'] ) ) {
                $jsArgs['product_edit_link'] = $siteUrl."/wp-admin/admin.php?page=cl_product_settings&compo=product_details&product_id=".$_REQUEST['post'];
            }    */
        return json_encode($jsArgs);
    }

    public static function getJsLang()
    {
        $jsLang = [
            'delete_confirm_msg'    => Lang_cl::__("Are you sure you want to delete this?", 'cl'),
            'upsell_description'    => Lang_cl::__("Edit Upsell Description", 'cl'),
            'edit_cart_product'    => Lang_cl::__("Edit cart product", 'cl'),
            'icons_select_modal_title' => Lang_cl::__("Select icon", 'cl'),
        ];
        return json_encode($jsLang);
    }

    /*
         * 
         */
    public function ajaxMainAction()
    {
        if (!is_user_logged_in()) {
            $result = response_cl(0, Lang_cl::__('You should be connected to perform this action', 'cl'), null);
            adminUtils_cl::ajaxReturn($result);
        }

        $args = $_REQUEST;

        $result     = false;
        $controller = $args['cl_controller'];
        $action     = $args['cl_action'];

        switch ($controller) {
            case 'cl_global_settings':
                $result = GlobalSettingsControllerBK_cl::routes($action, $args);
                break;
            case 'cl_global':
                $result = GlobalControllerBK_cl::routes($action, $args);
                break;
            case 'cl_simulator':
                $result = SimulatorControllerBK_cl::routes($action, $args);
                break;
            case 'cl_order_statuses':
                $result = OrderStatusesControllerBK_cl::routes($action, $args);
                break;
            case 'cl_shipping_options':
                $result = ShippingOptionsControllerBK_cl::routes($action, $args);
                break;
            case 'cl_checkout_fields':
            $result = CheckoutFieldsControllerBK_cl::routes($action, $args);
            break;
            case 'cl_global_variations':
            $result = GlobalVariationsControllerBK_cl::routes($action, $args);
            break;
            case 'cl_qty_offers':
                $result = QtyOffersControllerBK_cl::routes($action, $args);
                break;
            case 'cl_color_palette':
                $result = ColorPaletteControllerBK_cl::routes($action, $args);
                break;
            case 'cl_icons':
                $result = IconsControllerBK_cl::routes($action, $args);
                break;
            case 'cl_product':
                $result = ProductControllerBK_cl::routes($action, $args);
                break;
            case 'cl_tools':
                $result = ToolsControllerBK_cl::routes($action, $args);
                break;
            case 'cl_logs':
                $result = LogsControllerBK_cl::routes($action, $args);
                break;
            case 'cl_order':
                $result = OrderControllerBK_cl::routes($action, $args);
                break;
            case 'cl_order_status_history':
                $result = StatusHistoryControllerBK_cl::routes($action, $args);
                break;
            case 'cl_insights':
                $result = InsightsControllerBK_cl::routes($action, $args);
                break;
        }

        if ( $result === false ) {
            $result = response_cl(0, Lang_cl::__('The controller or the action is undefined', 'cl'), null);
        }

        adminUtils_cl::ajaxReturn($result);
    }

    /*
         * 
         */
    public function loadHooksFiltersMenus()
    {
        $admin_filters  = [];
        $admin_hooks    = [];
        $admin_menus    = [];
        $admin_product_metabox_menus    = [];


        foreach (MainApp_cl::$compsConfig as $compoName => $comp) {
            if ($comp['is_active'] == 'yes') {
                foreach ($comp['admin_filters'] as $priority => $filter) {
                    $admin_filters[$priority] = [
                        'name' => $filter,
                        'compName'   => $compoName
                    ];
                }

                foreach ($comp['admin_hooks'] as $priority => $hook) {
                    $admin_hooks[$priority] = [
                        'name' => $hook,
                        'compName'   => $compoName
                    ];
                }

                if (isset($comp['admin_product_metabox_menus'])) {
                    foreach ($comp['admin_product_metabox_menus'] as $priority => $menus) {
                        $admin_product_metabox_menus[$priority] = [
                            'compName'   => $compoName,
                            'menus' => $menus
                        ];
                    }
                }

                $this->activeComps[$compoName] = $comp;
            }
        }

        // sort based in the priority in the config file
        ksort($admin_hooks);
        ksort($admin_filters);
        ksort($admin_product_metabox_menus);

        $this->filters = $admin_filters;
        $this->hooks   = $admin_hooks;
    }
    /*
         * 
         */
    public function getFilters()
    {
        return $this->filters;
    }
    /*
         * 
         */
    public function getHooks()
    {
        return $this->hooks;
    }
}
