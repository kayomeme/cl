<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://kayoplugins.com
 * @since      1.0.0
 *
 * @package    clfe
 * @subpackage clfe/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    clfe
 * @subpackage clfe/admin
 * @author     Kayo plugins <kayo.plugins@gmail.com>
 */
class AdminApp_clfe
{

    public static $viewsPath;
    public static $assetsUrl;
    public static $assetsPath;
    public static $previewComps = ['mystore', 'product', 'cart', 'checkout', 'thankyou', 'plist1', 'categories_listing'];
    //public static $settingPageSlug    = 'clfe_global_settings';

    public $activeComps     = [];
    

    public $filters         = [];
    public $hooks           = [];

    /**
     * $this->glVars['assetsUrl']
     */
    public function __construct()
    {

        self::$viewsPath   = plugin_dir_path(__FILE__) . 'views/';
        self::$assetsPath   = plugin_dir_path(__FILE__) . 'assets/';
        self::$assetsUrl   = plugin_dir_url(__FILE__) . 'assets/';

        $this->loadHooksFiltersMenus();
    }

    public function welcome()
    {
        include plugin_dir_path(__FILE__) . '/views/welcome_page/index.php';
    }


    public static function getJsArgs($settingsModelId)
    {
        $siteUrl = get_site_url();
        $sharedSettings = AdminCompo_clfe::getSharedSettings($settingsModelId);
        $jsArgs = array_merge([
            'ajax_admin_action'    => 'clfe_ajax_admin_action',
            'ajax_url'              => admin_url("admin-ajax.php"),
            'site_url'              => $siteUrl,
            'ajax_nonce'            => wp_create_nonce('clfe_upsell_nonce'),
            'site_id'               => MainApp_clfe::getSiteId($siteUrl),
            //'product_edit_link'     => false,
            'last_response'         => ''
        ], $sharedSettings);
        
        
        
        /* if( isset( $_REQUEST['post'] ) && !isset( $_REQUEST['action'] ) ) {
                $jsArgs['product_edit_link'] = $siteUrl."/wp-admin/admin.php?page=clfe_product_settings&compo=product_details&product_id=".$_REQUEST['post'];
            }    */
        return json_encode($jsArgs);
    }

    public static function getJsLang()
    {
        $jsLang = [
            'delete_confirm_msg'    => Lang_clfe::__("Are you sure you want to delete this?", 'clfe'),
            'upsell_description'    => Lang_clfe::__("Edit Upsell Description", 'clfe'),
            'edit_cart_product'    => Lang_clfe::__("Edit cart product", 'clfe')
        ];
        return json_encode($jsLang);
    }

    /*
         * 
         */
    public function ajaxMainAction()
    {
        if (!is_user_logged_in()) {
            $result = response_clfe(0, Lang_clfe::__('You should be connected to perform this action', 'clfe'), null);
            adminUtils_clfe::ajaxReturn($result);
        }

        $args = $_REQUEST;

        $result     = false;
        $controller = $args['clfe_controller'];
        $action     = $args['clfe_action'];

        switch ($controller) {
            case 'clfe_global_settings':
                $result = GlobalSettingsControllerBK_clfe::routes($action, $args);
                break;
            case 'clfe_simulator':
                $result = SimulatorControllerBK_clfe::routes($action, $args);
                break;
            case 'clfe_order_statuses':
                $result = OrderStatusesControllerBK_clfe::routes($action, $args);
                break;
            case 'clfe_shipping_options':
                $result = ShippingOptionsControllerBK_clfe::routes($action, $args);
                break;
            case 'clfe_product':
                $result = ProductControllerBK_clfe::routes($action, $args);
                break;
            case 'clfe_tools':
                $result = ToolsControllerBK_clfe::routes($action, $args);
                break;
            case 'clfe_logs':
                $result = LogsControllerBK_clfe::routes($action, $args);
                break;
            case 'clfe_order':
                $result = OrderControllerBK_clfe::routes($action, $args);
                break;
            case 'clfe_order_status_history':
                $result = StatusHistoryControllerBK_clfe::routes($action, $args);
                break;
            case 'clfe_insights':
                $result = InsightsControllerBK_clfe::routes($action, $args);
                break;
        }

        if ( $result === false ) {
            $result = response_clfe(0, Lang_clfe::__('The controller or the action is undefined', 'clfe'), null);
        }

        adminUtils_clfe::ajaxReturn($result);
    }

    /*
         * 
         */
    public function loadHooksFiltersMenus()
    {
        $admin_filters  = [];
        $admin_hooks    = [];
        $admin_menus    = [];
        $admin_product_metabox_menus    = [];


        foreach (MainApp_clfe::$compsConfig as $compoName => $comp) {
            if ($comp['is_active'] == 'yes') {
                foreach ($comp['admin_filters'] as $priority => $filter) {
                    $admin_filters[$priority] = [
                        'name' => $filter,
                        'compName'   => $compoName
                    ];
                }

                foreach ($comp['admin_hooks'] as $priority => $hook) {
                    $admin_hooks[$priority] = [
                        'name' => $hook,
                        'compName'   => $compoName
                    ];
                }

                if (isset($comp['admin_product_metabox_menus'])) {
                    foreach ($comp['admin_product_metabox_menus'] as $priority => $menus) {
                        $admin_product_metabox_menus[$priority] = [
                            'compName'   => $compoName,
                            'menus' => $menus
                        ];
                    }
                }

                $this->activeComps[$compoName] = $comp;
            }
        }

        // sort based in the priority in the config file
        ksort($admin_hooks);
        ksort($admin_filters);
        ksort($admin_product_metabox_menus);

        $this->filters = $admin_filters;
        $this->hooks   = $admin_hooks;
    }
    /*
         * 
         */
    public function getFilters()
    {
        return $this->filters;
    }
    /*
         * 
         */
    public function getHooks()
    {
        return $this->hooks;
    }
}
