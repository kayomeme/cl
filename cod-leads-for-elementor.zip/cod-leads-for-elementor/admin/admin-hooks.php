<?php

class AdminHooks_cl {

    public $hooks = [];
    public $currentComp;

    /* public $settingsController;
      public $productMetaboxController; */

    /**
     * 
     */
    public function __construct($hooks) {
        // group by hookname every hook
        foreach ($hooks as $key => $hook) {
            $this->hooks[$hook['name']][] = $hook;
        }
    }

    public function admin_init() {
        global $settingsModelId;
        $settingsModelId = isset($_REQUEST['settings_model_id']) ? $_REQUEST['settings_model_id'] : 0;
        
        global $sharedSettings;
        global $currencyLabel;
        
        $sharedSettings = AdminCompo_cl::getSharedSettings($settingsModelId);
        $currencyLabel = $sharedSettings['currency_label'];
            
        // After plugin activation, check if we need to flush rewrite rules
        if (get_transient('cl_needs_flush_redirect')) {
            // If we're not already on the settings page with flush_rules
            if (!isset($_REQUEST['flush_rules'])) {
                // Remove the temporary flag
                delete_transient('cl_needs_flush_redirect');
                // Redirect to settings page with flush_rules parameter
                wp_redirect(admin_url('admin.php?page=cl_global_settings&compo=mystore&tab=cl_general_tab&settings_model_id=0&flush_rules=yes'));
                exit;
            }
        }
    }

    public function admin_head() {
        global $settingsModelId;
        if (isset($this->hooks['admin_head'])) {
            $hooks = $this->hooks['admin_head'];
            
            echo get_option('cl_color_palette_css_vars_'.$settingsModelId);

            //this is the global javascript varaible that should by existing in all backend pages
            echo "<script> let jsArgs = JSON.parse('" . AdminApp_cl::getJsArgs($settingsModelId) . "');</script>";
            echo "<script> let jsLang = JSON.parse('" . AdminApp_cl::getJsLang() . "');</script>";
            echo "<script> let cl_ajax_nonce = '" . wp_create_nonce('cl_ajax_nonce') . "';</script>";
            
            echo "<script> let currentUrl = window.location.search; 
                let currentUrlParms = new URLSearchParams(currentUrl);</script>";

            $compsPath = MainApp_cl::$compsPath;
            foreach ($hooks as $hook) {
                include MainApp_cl::$compsPath . $hook['compName'] . '/backend/hooks/admin_head.php';
            }
        }
    }

    public function admin_footer() {
        if (isset($this->hooks['admin_footer'])) {


            if (current_user_can('edit_posts') && isset(get_current_screen()->post_type) && get_current_screen()->post_type == 'post' && isset($_REQUEST['post'])) {
                $product_id = (int) $_REQUEST['post'];
                $helpText = Lang_cl::__('COD leads : set product prices', 'cl');
                echo '<div class="cl-product-edit"><a href="/wp-admin/admin.php?page=cl_product_settings&compo=product_details&product_id=' . $product_id . '"> ' . $helpText . ' </a></div>';

                echo "<style>.cl-product-edit {
                        position: fixed;
                        z-index: 100000;
                        float: left;
                        bottom: 30px;
                        left: 0px;
                        background: #101110;
                        padding: 5px;
                        border-radius: 5px;
                    }
                    .cl-product-edit a {
                        color: #fff !important;
                    }
                    </style>";
            }

            $hooks = $this->hooks['admin_footer'];
            $compsPath = MainApp_cl::$compsPath;
            foreach ($hooks as $hook) {
                include MainApp_cl::$compsPath . $hook['compName'] . '/backend/hooks/admin_footer.php';
            }
        }
    }

    /**
     * 
     */
public function admin_menu() {

        // This is the main plugin page
        //  add_menu_page( 'cl_global_settings', Lang_cl::__('Cod Leads', 'cl'), 'edit_posts', 'cl_global_settings', array($this->settingsController, 'settingsIndex'));
        $capability = 'edit_posts';

        //$adminWelcome = array(new AdminApp_cl(), 'welcome');
        $adminWelcome = array(new GlobalSettingsControllerBK_cl(), 'index');
        add_menu_page(Lang_cl::__('Settings : COD Leads', 'cl'), Lang_cl::__('Settings : COD Leads', 'cl'), $capability, 'cl_global_settings', $adminWelcome, $icon_url = '', $position = 2);

       // $adminSettingsIndex = array(new GlobalSettingsControllerBK_cl(), 'index');
       // add_submenu_page('cl_global_settings', Lang_cl::__('Global settings', 'cl'), Lang_cl::__('Global settings', 'cl'), $capability, 'cl_global_settings', $adminSettingsIndex);

        /*
         * this is the old system you should include the controller file
          $productControllerDirectIndex = array(new ProductControllerBKDirect_cl(), 'index');
          add_submenu_page('cl_global_settings', Lang_cl::__('Products', 'cl'), Lang_cl::__('Products', 'cl'), $capability, 'cl_product_settings', $productControllerDirectIndex);
         */

        // Add Global Variations to the Products menu
        $globalVariationsControllerIndex = array(new GlobalVariationsControllerBK_cl(), 'index');
        add_submenu_page(
                'edit.php?post_type=product', // Parent slug for Products menu
                Lang_cl::__('Global Variations', 'cl'),
                Lang_cl::__('Global Variations', 'cl'),
                $capability,
                'cl_global_variations',
                $globalVariationsControllerIndex
        );
        
        // Add Global Quantity Offers to the Products menu
        $qtyOffersControllerIndex = array(new QtyOffersControllerBK_cl(), 'index');
        add_submenu_page(
            'edit.php?post_type=product',
            Lang_cl::__('Global Quantity Offers', 'cl'),
            Lang_cl::__('Quantity Offers', 'cl'),
            'manage_options',
            'cl_qty_offers',
            $qtyOffersControllerIndex
        );

        // Create separate Orders parent menu
        $orderControllerIndex = array(new OrderControllerBK_cl(), 'index');
        add_menu_page(
                Lang_cl::__('Orders', 'cl'), // Page title
                Lang_cl::__('Orders', 'cl'), // Menu title
                $capability, // Capability
                'cl_orders', // Menu slug
                $orderControllerIndex, // Callback function
                'dashicons-clipboard', // Icon
                3 // Position
        );

        // Add Order Statuses as submenu under Orders
        $orderStatusesControllerIndex = array(new OrderStatusesControllerBK_cl(), 'index');
        add_submenu_page(
                'cl_orders', // Parent slug (Orders menu)
                Lang_cl::__('Order Statuses', 'cl'),
                Lang_cl::__('Order Statuses', 'cl'),
                $capability,
                'cl_order_statuses',
                $orderStatusesControllerIndex
        );

        $shippingOptionsControllerIndex = array(new ShippingOptionsControllerBK_cl(), 'index');
        add_submenu_page(
                'cl_global_settings',
                Lang_cl::__('Shipping Options', 'cl'),
                Lang_cl::__('Shipping Options', 'cl'),
                $capability,
                'cl_shipping_options',
                $shippingOptionsControllerIndex
        );

        // Add the Checkout Fields menu
        $checkoutFieldsControllerIndex = array(new CheckoutFieldsControllerBK_cl(), 'index');
        add_submenu_page(
                'cl_global_settings',
                Lang_cl::__('Checkout Fields', 'cl'),
                Lang_cl::__('Checkout Fields', 'cl'),
                $capability,
                'cl_checkout_fields',
                $checkoutFieldsControllerIndex
        );

        // Add the Icons Manager menu
        $iconsControllerIndex = array(new IconsControllerBK_cl(), 'index');
        add_submenu_page(
                'cl_global_settings',
                Lang_cl::__('Icons Manager', 'cl'),
                Lang_cl::__('Icons Manager', 'cl'),
                $capability,
                'cl_icons',
                $iconsControllerIndex
        );
        
        // Add the Color Palette menu
        $colorPaletteControllerIndex = array(new ColorPaletteControllerBK_cl(), 'index');
        add_submenu_page(
                'cl_global_settings',
                Lang_cl::__('Color Palette', 'cl'),
                Lang_cl::__('Color Palette', 'cl'),
                $capability,
                'cl_color_palette',
                $colorPaletteControllerIndex
        );

        $insightControllerIndex = array(new InsightsControllerBK_cl(MainApp_cl::$compsPath), 'index');
        add_submenu_page('cl_global_settings', Lang_cl::__('Insights', 'cl'), Lang_cl::__('Insights', 'cl'), $capability, 'cl_insights', $insightControllerIndex);

        if (isset($this->hooks['admin_menu'])) {
            $hooks = $this->hooks['admin_menu'];
            foreach ($hooks as $hook) {
                include MainApp_cl::$compsPath . $hook['compName'] . '/backend/hooks/admin_menu.php';
            }
        }

        $toolsControllerBK = array(new ToolsControllerBK_cl(), 'index');
        add_submenu_page('cl_global_settings', Lang_cl::__('Tools', 'cl'), Lang_cl::__('Tools', 'cl'), $capability, 'cl_tools', $toolsControllerBK);

        // Create the Import/Export controller callback
        $importExportController = array(new ImportExportControllerBK_cl(), 'index');

        // Add submenu page at same level as Tools
        add_submenu_page(
                'cl_global_settings', // Parent slug
                Lang_cl::__('Import/Export Settings', 'cl'), // Page title
                Lang_cl::__('Import/Export', 'cl'), // Menu title
                $capability, // Capability
                'cl_import_export', // Menu slug
                $importExportController                              // Callback function
        );

        $logsControllerBK = array(new LogsControllerBK_cl(), 'index');
        add_submenu_page('cl_global_settings', Lang_cl::__('Logs', 'cl'), Lang_cl::__('Logs', 'cl'), $capability, 'cl_logs', $logsControllerBK);

        if (is_plugin_active('header-footer-elementor/header-footer-elementor.php')) {
            add_submenu_page('cl_global_settings', Lang_cl::__('Header and Footer', 'cl'), Lang_cl::__('Header and Footer', 'cl'), $capability, 'cl_header_footer_el', function () {
                $url = get_site_url() . '/wp-admin/edit.php?post_type=elementor-hf';
                echo '<script type="text/javascript">jQuery(document).ready( function () {window.location.href = "' . $url . '";} );</script>';
            });
        }
    }

    public function admin_enqueue_scripts() {
        $assetsVersion = MainApp_cl::$assetsVersion;

        if (isset($_REQUEST['taxonomy']) && $_REQUEST['taxonomy'] == 'product_cat') {
            wp_enqueue_media();
            wp_enqueue_script('cl-components-js', AdminApp_cl::$assetsUrl . 'js/components.js', array('jquery', 'jquery-ui-dialog'), $assetsVersion);

        }

        if (isset(get_current_screen()->post_type) && get_current_screen()->post_type == 'product') {
            //wp_enqueue_media(); // for gallery upload
            wp_enqueue_style('cl-admin-css', AdminApp_cl::$assetsUrl . 'css/admin.css', [], $assetsVersion);

            wp_enqueue_script('cl-admin-fn-js', AdminApp_cl::$assetsUrl . 'js/admin_fn.js', array('jquery'), $assetsVersion);
            wp_enqueue_script('cl-components-js', AdminApp_cl::$assetsUrl . 'js/components.js', array('jquery', 'jquery-ui-dialog'), $assetsVersion);

            wp_enqueue_script('jquery-ui-dialog');
            wp_enqueue_style('wp-jquery-ui-dialog');
        }

        // only load in the pages prefixed with cl_
        if (IsClfePages()) {
            wp_enqueue_media(); // for media-upload
            wp_enqueue_style('cl-admin-css', AdminApp_cl::$assetsUrl . 'css/admin.css', [], $assetsVersion);
            wp_enqueue_script('cl-admin-fn-js', AdminApp_cl::$assetsUrl . 'js/admin_fn.js', array('jquery'), $assetsVersion);

            if (IsInCurrentPages(['cl_global_settings'])) {
                wp_enqueue_style('cl-settings-css', AdminApp_cl::$assetsUrl . 'css/global_settings.css', [], $assetsVersion);
                
               // wp_enqueue_script('cl-setting-model-js', AdminApp_cl::$assetsUrl . 'js/setting_model.js', array('jquery', 'jquery-ui-dialog'), $assetsVersion);
                
                wp_enqueue_script('cl-setting-manager-js', AdminApp_cl::$assetsUrl . 'js/setting_manager.js', array('jquery', 'jquery-ui-dialog'), $assetsVersion);
            }

            if (IsInCurrentPages(['cl_global_settings', 'cl_orders', 'cl_order_statuses', 'cl_shipping_options', 'cl_checkout_fields', 'cl_global_variations', 'cl_qty_offers', 'cl_icons', 'cl_color_palette', 'cl_tools', 'cl_insights'])) {
                wp_enqueue_script('cl-components-js', AdminApp_cl::$assetsUrl . 'js/components.js', array('jquery'), $assetsVersion);
            }


            // load jquery dialog
            if (IsInCurrentPages(['cl_global_settings', 'cl_orders', 'cl_checkout_fields'])) {
                wp_enqueue_script('jquery-ui-dialog');
                wp_enqueue_style('wp-jquery-ui-dialog');
            }

            // dragabble elemnts
            wp_enqueue_script('jquery-ui-widget');
        }

        if (isset($this->hooks['admin_enqueue_scripts'])) {
            $hooks = $this->hooks['admin_enqueue_scripts'];
            foreach ($hooks as $hook) {
                include MainApp_cl::$compsPath . $hook['compName'] . '/backend/hooks/admin_enqueue_scripts.php';
            }
        }
    }

    public function save_post_product($productId) {

        //var_dump($post_id);

        if (isset($this->hooks['save_post_product'])) {
            $hooks = $this->hooks['save_post_product'];

            foreach ($hooks as $hook) {
                include MainApp_cl::$compsPath . $hook['compName'] . '/backend/hooks/save_post_product.php';
            }
        }
    }

    public function add_meta_boxes() {
        if (isset($this->hooks['add_meta_boxes'])) {
            $hooks = $this->hooks['add_meta_boxes'];

            foreach ($hooks as $hook) {
                include MainApp_cl::$compsPath . $hook['compName'] . '/backend/hooks/add_meta_boxes.php';
            }
        }
    }

    /*
     * hooks
     */

    public function manage_post_posts_custom_column($column, $post_id) {
        if (isset($this->hooks['manage_post_posts_custom_column'])) {
            $hooks = $this->hooks['manage_post_posts_custom_column'];

            foreach ($hooks as $hook) {
                include MainApp_cl::$compsPath . $hook['compName'] . '/backend/hooks/manage_post_posts_custom_column.php';
            }
        }
    }
}
