<?php

class AdminHooks_clfe {
    
        public $hooks = [];
        public $currentComp;
        
        /*public $settingsController;
        public $productMetaboxController;*/

        /**
	 * 
	 */
	public function __construct($hooks) {   
            // group by hookname every hook
            foreach ($hooks as $key => $hook) {
                $this->hooks[$hook['name']][] = $hook;
            } 
	}
        
        public function admin_init() {
            // After plugin activation, check if we need to flush rewrite rules
            if( get_transient('clfe_needs_flush_redirect') ) {
                // If we're not already on the settings page with flush_rules
                if( !isset( $_REQUEST['flush_rules'] ) ) {
                    // Remove the temporary flag
                    delete_transient('clfe_needs_flush_redirect');
                    // Redirect to settings page with flush_rules parameter
                    wp_redirect(admin_url('admin.php?page=clfe_global_settings&compo=mystore&tab=clfe_general_tab&settings_model_id=0&flush_rules=yes'));
                    exit;
                }
            }
        }
        
        public function admin_head() {
            if( isset( $this->hooks['admin_head'] ) ) {
                global $settingsModelId;

                $settingsModelId = isset( $_REQUEST['settings_model_id'] ) ? $_REQUEST['settings_model_id'] : 0;

                $hooks = $this->hooks['admin_head'];

                //this is the global javascript varaible that should by existing in all backend pages
                echo "<script> let jsArgs = JSON.parse('". AdminApp_clfe::getJsArgs($settingsModelId)."');</script>";
                echo "<script> let jsLang = JSON.parse('". AdminApp_clfe::getJsLang()."');</script>";
                echo "<script> let clfe_ajax_nonce = '".wp_create_nonce('clfe_ajax_nonce')."';</script>";
                echo "<script> let currentUrl = window.location.search; 
                let currentUrlParms = new URLSearchParams(currentUrl);</script>";
                
                $compsPath = MainApp_clfe::$compsPath;
                foreach ($hooks as $hook) {
                    include MainApp_clfe::$compsPath.$hook['compName'].'/backend/hooks/admin_head.php';
                }
            }
        }
        
        public function admin_footer() {
            if( isset( $this->hooks['admin_footer'] ) ) {
                
                
                if( current_user_can('edit_posts') && isset( get_current_screen()->post_type ) && get_current_screen()->post_type == 'post' && isset( $_REQUEST['post'] ) ) {
                    $product_id = (int)$_REQUEST['post'];  
                    $helpText = Lang_clfe::__('COD leads : set product prices', 'clfe');
                    echo '<div class="clfe-product-edit"><a href="/wp-admin/admin.php?page=clfe_product_settings&compo=product_details&product_id='.$product_id.'"> '.$helpText.' </a></div>';
                    
                    echo "<style>.clfe-product-edit {
                        position: fixed;
                        z-index: 100000;
                        float: left;
                        bottom: 30px;
                        left: 0px;
                        background: #101110;
                        padding: 5px;
                        border-radius: 5px;
                    }
                    .clfe-product-edit a {
                        color: #fff !important;
                    }
                    </style>";
                }

                $hooks = $this->hooks['admin_footer'];
                $compsPath = MainApp_clfe::$compsPath;
                foreach ($hooks as $hook) {
                    include MainApp_clfe::$compsPath.$hook['compName'].'/backend/hooks/admin_footer.php';
                }
            }
        } 
        
	/**
	 * 
	 */
	public function admin_menu() {
            
            // This is the main plugin page
          //  add_menu_page( 'clfe_global_settings', Lang_clfe::__('Cod Leads', 'clfe'), 'edit_posts', 'clfe_global_settings', array($this->settingsController, 'settingsIndex'));
            $capability = 'edit_posts';
            
            $adminWelcome = array(new AdminApp_clfe(), 'welcome');
            add_menu_page( Lang_clfe::__('clfe', 'clfe'), Lang_clfe::__('clfe', 'clfe'), $capability, 'clfe_welcome', $adminWelcome, $icon_url = '', $position = 1);
            
            $adminSettingsIndex = array(new GlobalSettingsControllerBK_clfe(), 'index');            
            add_submenu_page('clfe_welcome', Lang_clfe::__('Global settings', 'clfe'), Lang_clfe::__('Global settings', 'clfe'), $capability, 'clfe_global_settings', $adminSettingsIndex);

            /*
             * this is the old system you should include the controller file
            $productControllerDirectIndex = array(new ProductControllerBKDirect_clfe(), 'index');
            add_submenu_page('clfe_welcome', Lang_clfe::__('Products', 'clfe'), Lang_clfe::__('Products', 'clfe'), $capability, 'clfe_product_settings', $productControllerDirectIndex);
            */
            
            $orderControllerIndex = array(new OrderControllerBK_clfe(), 'index');
            add_submenu_page('clfe_welcome', Lang_clfe::__('Orders', 'clfe'), Lang_clfe::__('Orders', 'clfe'), $capability, 'clfe_orders', $orderControllerIndex);
            
            $orderStatusesControllerIndex = array(new OrderStatusesControllerBK_clfe(), 'index');
            add_submenu_page('clfe_welcome', Lang_clfe::__('Order Statuses', 'clfe'), Lang_clfe::__('Order Statuses', 'clfe'), $capability, 'clfe_order_statuses', $orderStatusesControllerIndex);
            
            $shippingOptionsControllerIndex = array(new ShippingOptionsControllerBK_clfe(), 'index');
            add_submenu_page(
                'clfe_welcome', 
                Lang_clfe::__('Shipping Options', 'clfe'), 
                Lang_clfe::__('Shipping Options', 'clfe'), 
                $capability, 
                'clfe_shipping_options', 
                $shippingOptionsControllerIndex
            );
            
            $insightControllerIndex = array(new InsightsControllerBK_clfe(MainApp_clfe::$compsPath), 'index');
            add_submenu_page('clfe_welcome', Lang_clfe::__('Insights', 'clfe'), Lang_clfe::__('Insights', 'clfe'), $capability, 'clfe_insights', $insightControllerIndex);

            
            if( isset( $this->hooks['admin_menu'] ) ) {
                $hooks = $this->hooks['admin_menu'];
                foreach ($hooks as $hook) {
                    include MainApp_clfe::$compsPath.$hook['compName'].'/backend/hooks/admin_menu.php';
                }
            }
            
            $toolsControllerBK = array(new ToolsControllerBK_clfe(), 'index');
            add_submenu_page('clfe_welcome', Lang_clfe::__('Tools', 'clfe'), Lang_clfe::__('Tools', 'clfe'), $capability, 'clfe_tools', $toolsControllerBK);

            $logsControllerBK = array(new LogsControllerBK_clfe(), 'index');
            add_submenu_page('clfe_welcome', Lang_clfe::__('Logs', 'clfe'), Lang_clfe::__('Logs', 'clfe'), $capability, 'clfe_logs', $logsControllerBK);
            
            if ( is_plugin_active( 'header-footer-elementor/header-footer-elementor.php' ) ) {
                add_submenu_page('clfe_welcome', Lang_clfe::__('Header and Footer', 'clfe'), Lang_clfe::__('Header and Footer', 'clfe'), $capability, 'clfe_header_footer_el', function() {
                    $url = get_site_url().'/wp-admin/edit.php?post_type=elementor-hf';
                    echo '<script type="text/javascript">jQuery(document).ready( function () {window.location.href = "'.$url.'";} );</script>';
                });
            } 

            
	}
        
        public function admin_enqueue_scripts() {
            $assetsVersion = MainApp_clfe::$assetsVersion;
            
            if( isset( $_REQUEST['taxonomy'] ) && $_REQUEST['taxonomy'] == 'category' ) {
                wp_enqueue_media();
                wp_enqueue_script( 'clfe-editor-js', AdminApp_clfe::$assetsUrl . 'js/category.js', array( 'jquery' ), $assetsVersion );
            }
            
            if( isset( get_current_screen()->post_type ) && get_current_screen()->post_type == 'product' ) {
                //wp_enqueue_media(); // for gallery upload
                wp_enqueue_style( 'clfe-admin-css', AdminApp_clfe::$assetsUrl . 'css/admin.css', [], $assetsVersion );

                wp_enqueue_script( 'clfe-admin-fn-js', AdminApp_clfe::$assetsUrl . 'js/admin_fn.js', array( 'jquery' ), $assetsVersion );
                wp_enqueue_script( 'clfe-components-js', AdminApp_clfe::$assetsUrl . 'js/components.js', array( 'jquery', 'jquery-ui-dialog' ), $assetsVersion );
                
                wp_enqueue_script('jquery-ui-dialog');
                wp_enqueue_style('wp-jquery-ui-dialog');
            }
            
            // only load in the pages prefixed with clfe_
            if( adminUtils_clfe::IsClfePages() ) {

                if( adminUtils_clfe::IsInCurrentPages(['clfe_global_settings', 'clfe_orders', 'clfe_order_statuses', 'clfe_shipping_options', 'clfe_tools', 'clfe_insights']) ) {
                    wp_enqueue_script( 'clfe-components-js', AdminApp_clfe::$assetsUrl . 'js/components.js', array( 'jquery' ), $assetsVersion );

                    //wp_enqueue_script( 'clfe-table-auto-sorter-filter-js', AdminApp_clfe::$assetsUrl . 'lib/table-auto-sorter-filter/index.js', array( 'jquery', 'jquery-ui-dialog' ), $assetsVersion );
                }
                
                wp_enqueue_media(); // for media-upload
                wp_enqueue_style( 'clfe-admin-css', AdminApp_clfe::$assetsUrl . 'css/admin.css', [], $assetsVersion );
                wp_enqueue_script( 'clfe-admin-fn-js', AdminApp_clfe::$assetsUrl . 'js/admin_fn.js', array( 'jquery' ), $assetsVersion );

                if( adminUtils_clfe::IsInCurrentPages(['clfe_global_settings']) ) {
                    wp_enqueue_style( 'clfe-settings-css', AdminApp_clfe::$assetsUrl . 'css/global_settings.css', [], $assetsVersion );
                    wp_enqueue_script( 'clfe-settings-js', AdminApp_clfe::$assetsUrl . 'js/settings.js', array( 'jquery', 'jquery-ui-dialog' ), $assetsVersion );
                    
                    // color pallete
                    wp_enqueue_script( 'clfe-jquery-mincolors-js', AdminApp_clfe::$assetsUrl . 'lib/jquery-minicolors/jquery.minicolors.min.js', array( 'jquery'), $assetsVersion );
                    wp_enqueue_style( 'clfe-jquery-mincolors-css', AdminApp_clfe::$assetsUrl . 'lib/jquery-minicolors/jquery.minicolors.css',[], $assetsVersion );

                    // nice number
                    wp_enqueue_script( 'clfe-jquery-nice-number-js', AdminApp_clfe::$assetsUrl . 'lib/jquery-nice-number/jquery.nice-number.min.js', array( 'jquery'), $assetsVersion );
                    wp_enqueue_style( 'clfe-jquery-nice-number-css', AdminApp_clfe::$assetsUrl . 'lib/jquery-nice-number/jquery.nice-number.min.css',[], $assetsVersion );

                }
                
                // dragabble elemnts
                wp_enqueue_script( 'jquery-ui-widget' );
                
                // load jquery dialog
                if( adminUtils_clfe::IsInCurrentPages(['clfe_global_settings', 'clfe_orders']) ) {
                    wp_enqueue_script('jquery-ui-dialog');
                    wp_enqueue_style('wp-jquery-ui-dialog');
                }
            }
              
            if( isset( $this->hooks['admin_enqueue_scripts'] ) ) {
                $hooks = $this->hooks['admin_enqueue_scripts'];
                foreach ($hooks as $hook) {
                    include MainApp_clfe::$compsPath.$hook['compName'].'/backend/hooks/admin_enqueue_scripts.php';
                }
            }
        }
        public function save_post_product($productId) {
            
            //var_dump($post_id);
            
            if( isset( $this->hooks['save_post_product'] ) ) {
                $hooks = $this->hooks['save_post_product'];

                foreach ($hooks as $hook) {
                    include MainApp_clfe::$compsPath.$hook['compName'].'/backend/hooks/save_post_product.php';
                }
            }
        } 
        public function add_meta_boxes() {
            if( isset( $this->hooks['add_meta_boxes'] ) ) {
                $hooks = $this->hooks['add_meta_boxes'];

                foreach ($hooks as $hook) {
                    include MainApp_clfe::$compsPath.$hook['compName'].'/backend/hooks/add_meta_boxes.php';
                }
            }
        } 
        /*
         * hooks
         */
        public function manage_post_posts_custom_column($column, $post_id) {
            if( isset( $this->hooks['manage_post_posts_custom_column'] ) ) {
                $hooks = $this->hooks['manage_post_posts_custom_column'];

                foreach ($hooks as $hook) {
                    include MainApp_clfe::$compsPath.$hook['compName'].'/backend/hooks/manage_post_posts_custom_column.php';
                }
            }
        }     

}
