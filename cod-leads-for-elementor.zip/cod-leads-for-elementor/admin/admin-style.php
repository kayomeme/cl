<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://kayoplugins.com
 * @since      1.0.0
 *
 * @package    clfe
 * @subpackage clfe/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    clfe
 * @subpackage clfe/admin
 * @author     Kayo plugins <kayo.plugins@gmail.com>
 */
class AdminStyle_clfe {
        public $defaultSettings     = [];

	public function __construct( $defaultSettings ) {
            $this->defaultSettings = $defaultSettings;
            
        }
        public function getImage($style_name, $saved_style, $activeOptions = null) {
            ?>
            <button type="button" class="clfe-image-selector">
                <span>
                    <?= Lang_clfe::_e('Thumbnail image', 'clfe') ?>
                </span> <br/>
                <img src="<?= isset($value['thumbnail_url']) ? $value['thumbnail_url'] : "" ?>" alt="<?= Lang_clfe::_e('Select offer image', 'clfe') ?>" /> <br/>
                <input type="hidden" class="clfe_img_id" elementName="thumbnail_id" value="<?= isset($value['thumbnail_id']) ? $value['thumbnail_id'] : "" ?>" />
                <input type="hidden" class="clfe_img_url" elementName="thumbnail_url" value="<?= isset($value['thumbnail_url']) ? $value['thumbnail_url'] : "" ?>" />
            </button>
        <?php
        }
        public function getAllCss($style_name, $saved_style, $activeOptions = null) {
            $newArraySaved = [];
            $tmp_saved_style = str_replace('px;', ';', $saved_style);
            $tmp_saved_style = str_replace('%;', ';', $tmp_saved_style);
            
            $arrayStyles = explode(";", $tmp_saved_style);
            

            
            foreach ($arrayStyles as $value) {
                $tmp = explode(":", $value);
                if( isset($tmp[0]) && isset($tmp[1]) ) {
                    $newArraySaved[$tmp[0]] = $tmp[1];
                }
            }
            
            $style_default_settings = $this->defaultSettings[$style_name];
            
            $newArrayDefault = [];
            $tmp_style_default = str_replace('px;', ';', $style_default_settings);
            $arrayStylesDefault = explode(";", $tmp_style_default);
            
            foreach ($arrayStylesDefault as $value) {
                $tmp = explode(":", $value);
                if( isset($tmp[0]) && isset($tmp[1]) ) {
                    $newArrayDefault[$tmp[0]] = $tmp[1];
                }
            }
            
            //var_dump($newArraySaved);
            
            $newArray = array_merge($newArrayDefault, $newArraySaved);
            $newArray = array_map('trim', $newArray);
            
            /*echo '------------------------------------------------<br/>';
            var_dump($newArray);*/
            
            // box-shadow
            if( isset( $activeOptions['box-shadow'] ) && isset( $newArray['box-shadow'] ) ) {
                $boxShadowOptions = str_replace('px', '', $newArray['box-shadow']);
                $boxShadowOptions = explode(" ", $boxShadowOptions);
            }
            
            // text-shadow
            if( isset( $activeOptions['text-shadow'] ) && isset( $newArray['text-shadow'] ) ) {
                $textShadowOptions = str_replace('px', '', $newArray['text-shadow']);
                $textShadowOptions = explode(" ", $textShadowOptions);
            }
            
            if( isset( $activeOptions['linear-gradient'] ) && isset( $newArray['background-image'] ) ) {
                $linearGradientOptions = str_replace('linear-gradient(', '', $newArray['background-image']);
                $linearGradientOptions = str_replace('deg', '', $linearGradientOptions);
                $linearGradientOptions = str_replace(')', '', $linearGradientOptions);
                $linearGradientOptions = explode(",", $linearGradientOptions);
            }

            ?>

            <?php if( !isset( $activeOptions['type'] ) || $activeOptions['type'] != 'direct' ) { ?>
            <button href="#id-<?= $style_name ?>" class="clfe-button-style" modalTitle="<?= isset( $activeOptions['modalTitle'] ) ? $activeOptions['modalTitle'] : ''  ?>" styleAttachedTo="<?= isset( $activeOptions['styleAttachedTo'] ) ? $activeOptions['styleAttachedTo'] : ''  ?>">
                <span class="dashicons dashicons-admin-customizer"></span>
                <?= Lang_clfe::_e('', 'clfe') ?>
            </button>
            <?php } ?>

                <div class="<?= isset( $activeOptions['type'] ) && $activeOptions['type'] == 'direct' ? '' : 'clfe-hide' ?> clfe-admin-style-container">
                <div class="clfe-admin-settings-modal" id="id-<?= $style_name ?>">
                    <div class="clfe-style clfe-accordion-container <?= $style_name ?>">
                        <?php 
                        if( isset( $activeOptions['predefined_width'] ) || isset( $activeOptions['width_pct'] ) || isset( $activeOptions['width'] ) || isset( $activeOptions['max-width'] ) || isset( $activeOptions['height'] ) || isset( $activeOptions['max-height'] ) || isset( $activeOptions['min-height'] ) ) {
                            include 'views/style_generator/general.php';
                        }
                        
                        

                        if( isset( $activeOptions['font'] ) ) {
                            include 'views/style_generator/font.php';
                        } 
                        
                        
                        
                        if( isset( $activeOptions['font-with-align'] ) ) {
                            include 'views/style_generator/font-with-align.php';
                        } 
                        
                        if( isset( $activeOptions['flex-options'] ) ) {
                            include 'views/style_generator/flex-options.php';
                        } 
                        
                        if( isset( $activeOptions['border'] ) ) {
                            include 'views/style_generator/border.php';
                        }

                        if( isset( $activeOptions['background'] ) ) {
                            include 'views/style_generator/background.php';
                        }

                        if( isset( $activeOptions['padding'] ) ) {
                            include 'views/style_generator/padding.php';
                        }

                        if( isset( $activeOptions['margin'] ) ) {
                            include 'views/style_generator/margin.php';
                        } 


                        if( isset( $activeOptions['linear-gradient'] ) ) {
                            include 'views/style_generator/linear-gradient.php';
                        }


                        if( isset( $activeOptions['box-shadow'] ) ) {
                            include 'views/style_generator/box-shadow.php';
                        }
                        
                        if( isset( $activeOptions['text-shadow'] ) ) {
                            include 'views/style_generator/text-shadow.php';
                        } 
                        
                        ?>

                        <input type="text" name="<?= $style_name ?>" value="<?= !empty($saved_style) ? $saved_style : $style_default_settings ?>" class="clfe-style-value" <?= isset( $activeOptions['styleAttachedTo'] ) ? "styleAttachedTo="."'".$activeOptions['styleAttachedTo']."'" : "" ?> />
                    </div>
                </div>
            </div>
          <?php
        }
        
        public function getSingleCss($cssProperty, $style_name, $saved_style) { ?>

            <div class="clfe-row clfe-single-css-property" style_name="<?= $style_name ?>">
                <?php 
                $singleStyleValue = $this->getSingleCssPropertyValue($saved_style, $cssProperty);
                 switch ($cssProperty) {
                     case 'margin-top':
                        include 'views/single_style_generator/margin-top.php';
                         break;
                 }
                
                ?>
            </div>

        <?php
        }

        private function getSingleCssPropertyValue($style_string, $property) {
            // Match any number (including negative) followed by any unit (px, em, rem, etc.)
            if (preg_match('/' . $property . ':(-?\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw)?)/', $style_string, $matches)) {
                // If we just want the numeric value and it's in pixels:
                if (strpos($matches[1], 'px') !== false) {
                    return intval($matches[1]);
                }
                // Return the full value including units
                return $matches[1];
            }
            return 0;
        }
        
        /**
         * Extracts the CSS unit (extension) from a CSS value
         * 
         * @param string $cssValue The CSS value to parse (e.g., "16px", "2em", "1.5rem")
         * @return string The extracted extension or empty string if none found
         */
        private function getFontsizeExt($cssValue) {
            if (empty($cssValue)) {
                return 'px';
            }

            // Match any number (including decimals) followed by non-numeric characters
            if (preg_match('/([\d\.]+)(\D+)$/', $cssValue, $matches)) {
                return $matches[2];
            }

            // If no unit found, return empty string
            return 'px';
        }
        
        
}
