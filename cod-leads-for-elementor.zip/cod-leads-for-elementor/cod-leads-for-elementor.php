<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://kayoplugins.com
 * @since             1.0.0
 * @package           clfe
 *
 * @wordpress-plugin
 * Plugin Name:       COD leads for elementor
 * Plugin URI:        https://kayoplugins.com
 * Description:       cod-leads-elementor
 * Version:           1.0.0
 * Author:            Kayo plugins
 * Author URI:        https://kayoplugins.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       cod-leads-for-elementor
 * Domain Path:       /languages
 */


// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/*var_dump(get_locale());
var_dump(strpos(get_locale(), 'fr_'));*/

$clfe_pluginPath = plugin_dir_path(__FILE__);
$siteURRL = get_site_url();


/**
 * Register codLeads Widget.
 *
 * Include widget file and register widget class.
 *
 * @since 1.0.0
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 * @return void
 */
/*function register_oembed_widget( $widgets_manager ) {
    require_once( __DIR__ . '/elementor/widgets/ElementorCustomForm.php' );
    require_once( __DIR__ . '/elementor/widgets/ElementorPList1.php' );
    $widgets_manager->register( new \Elementor_codLeads_Widget() );
    $widgets_manager->register( new \Elementor_pList1_Widget() );

}
add_action( 'elementor/widgets/register', 'register_oembed_widget' );*/

/*add_filter('submenu_file', function ($submenu_file) {
    global $submenu;

    // Check if we are targeting the correct submenu
    if (isset($_GET['page']) && $_GET['page'] === 'clfe_orders') {
        foreach ($submenu['clfe_welcome'] as &$submenu_item) {
            if ($submenu_item[2] === 'clfe_orders') {
                // Append the parameter to the submenu slug
                $submenu_item[2] .= 'admin.php?page=&action=list';
                break;
            }
        }
    }

    return $submenu_file;
});*/

    
if( $siteURRL == 'http://codleads_elementor.test' || $siteURRL == 'http://version1.test' ) {
    ini_set("xdebug.var_display_max_children", '-1');
    ini_set("xdebug.var_display_max_data", '-1');
    ini_set("xdebug.var_display_max_depth", '-1');
    
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
}    
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    
function response_clfe($code, $msg, $result) {
    $ob = new stdClass();
    $ob->code = $code;
    $ob->msg  = $msg;
    $ob->res = $result;

    return $ob;
}

//you need to reveiw this
//Or as a work around you can temporarily disable the auto pixel injection using the following code snippet:
add_filter( 'facebook_for_woocommerce_integration_pixel_enabled', '__return_false' );

// Close comments on the front-end
add_filter('comments_open', '__return_false', 20, 2);
add_filter('pings_open', '__return_false', 20, 2);
// Hide existing comments
add_filter('comments_array', '__return_empty_array', 10, 2);


function jsonDecode_clfe($value) {
    if (is_array($value)) {
        // If it's already an array, return it directly
        return $value;
    } else if (is_string($value)) {
        // Only apply stripslashes and json_decode if it's a string
        return json_decode(stripslashes($value), true);
    } else {
        // For other types (null, boolean, integer, etc.), return as is
        return $value;
    }
}

function jsonEncode_clfe($value) {
    return addslashes(json_encode($value));
}

function jsonEncodeForJs_clfe($value) {
    return stripcslashes(json_encode($value));
}

function setCookie_clfe($name, $value) {
    $expireInHours = time()+60*60*24*2; // 24*2 hours
    setcookie($name, $value, $expireInHours, '/');
    // "/" means the cookie is available to the entire domain
}

function getCookie_clfe($name) {
    if (isset($_COOKIE[$name])) {
        return $_COOKIE[$name];
    }
    return false;
}

function deleteCookie_clfe($name) {
    // set the expiration date to 5 hours ago
    setcookie($name, "", time() - 3600, '/');
    // "/" means the cookie will be deleted on the entire domain
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class/le-activator.php
 */
function activate_clfe($clfe_pluginPath) {

    // old require_once $clfe_pluginPath . 'includes/class/DbManager_clfe.php';
    
    require_once $clfe_pluginPath . 'includes/database/migration-table.php';
    require_once $clfe_pluginPath . 'includes/database/migration-manager.php';
    
    
    require_once $clfe_pluginPath . 'includes/class/Activator_clfe.php';
    Activator_clfe::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class/le-deactivator.php
 */
function deactivate_clfe($clfe_pluginPath) {
    require_once $clfe_pluginPath . 'includes/class/Deactivator_clfe.php';
    Deactivator_clfe::deactivate();
}

register_activation_hook( __FILE__, 'activate_clfe' );
register_deactivation_hook( __FILE__, 'deactivate_clfe' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */

require $clfe_pluginPath . 'includes/main-utils.php';
require $clfe_pluginPath . 'includes/class/lang.php';
require $clfe_pluginPath . 'includes/main-app.php';


/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
$mainApp = new MainApp_clfe();

// when Woo is not activated
if( !$mainApp::$isWooActivated ) {
    require $clfe_pluginPath . 'includes/content-type/product-content-type.php';
    require $clfe_pluginPath . 'includes/content-type/product-category-content-type.php';
    //require $clfe_pluginPath . 'includes/content-type/order-content-type.php';
}

add_action('init', array($mainApp, 'init'));

/*
 * execute public hook and filter
 */

//require 'includes/register_custom_content_type.php';

/**
 * The class responsible for defining all actions that occur in the public-facing
 * side of the site.
 */

if( $mainApp->isPublicArea() ) { 
    require_once $clfe_pluginPath.'public/direct_wp_hooks_filters/filters/index.php';
    
    require_once $clfe_pluginPath.'public/public-app.php';
    require_once $clfe_pluginPath.'public/public-compo.php';
    require_once $clfe_pluginPath.'public/public-utils.php';
    require_once $clfe_pluginPath.'public/public-hooks.php';
    require_once $clfe_pluginPath.'public/public-filters.php';
    require_once $clfe_pluginPath.'public/public-db.php';
    
    // class public
    require_once $clfe_pluginPath.'public/class/countdownFR.php';

    $publicApp = new PublicApp_clfe();
    $publicFilters = new PublicFilters_clfe( $publicApp->getFilters() );
    add_filter('the_content', array($publicFilters, 'the_content'), 9999);

    $publicHooks = new PublicHooks_clfe( $publicApp->getHooks() );
    
    add_action('template_redirect', array($publicHooks, 'template_redirect'));
    add_action('wp_enqueue_scripts', array($publicHooks, 'wp_enqueue_scripts'));
    add_action('wp_head', array($publicHooks, 'wp_head'));
    add_action('wp_body_open', array($publicHooks, 'wp_body_open'));
    add_action('wp_footer', array($publicHooks, 'wp_footer'));
    
    add_action('wp_ajax_clfe_ajax_public_action', array($publicApp, 'ajaxMainAction')); // This is for authenticated users
    add_action('wp_ajax_nopriv_clfe_ajax_public_action', array($publicApp, 'ajaxMainAction'));
    
    // shortcodes
    $pList1 = new PList1ControllerFR_clfe();
    add_shortcode('clfe_plist1', array($pList1, 'default'));
    
    /*this is triggering an error with menu, it return an empty text , try to use another solution to hide the product title
    to use the clfe settiings for the title
    add_filter('the_title', function($title) { 
        if( is_singular('product') ) { return ''; }
        return $title;
    });*/
}

/**
 * The class responsible for defining all actions that occur in the admin area.
 */
if( $mainApp->isAdminArea() ) {
    require_once $clfe_pluginPath.'admin/direct_wp_hooks_filters/index.php';
    
    require_once $clfe_pluginPath.'admin/admin-utils.php';
    require_once $clfe_pluginPath.'admin/admin-app.php';
    require_once $clfe_pluginPath.'admin/admin-compo.php';
    require_once $clfe_pluginPath.'admin/admin-hooks.php';
    require_once $clfe_pluginPath.'admin/admin-filters.php';
    require_once $clfe_pluginPath.'admin/admin-style.php';
    require_once $clfe_pluginPath.'admin/admin-db.php';
    
    require_once $clfe_pluginPath.'admin/controllers/globalSettingsControllerBK.php';
    require_once $clfe_pluginPath.'admin/models/settingsModelBK.php';

    $adminApp = new AdminApp_clfe();
    
    add_action('wp_ajax_clfe_ajax_admin_action', array($adminApp, 'ajaxMainAction')); // This is for authenticated users
    add_action('wp_ajax_nopriv_clfe_ajax_admin_action', array($adminApp, 'ajaxMainAction'));
    
    $adminHooks = new AdminHooks_clfe( $adminApp->getHooks() );
    
    add_action('admin_init', array($adminHooks, 'admin_init'));
    add_action('admin_head', array($adminHooks, 'admin_head'));
    add_action('admin_footer', array($adminHooks, 'admin_footer'));
    add_action('admin_menu', array($adminHooks, 'admin_menu'), 110);
    add_action('admin_enqueue_scripts', array($adminHooks, 'admin_enqueue_scripts') );
    add_action('add_meta_boxes', array($adminHooks, 'add_meta_boxes'));
    add_action('manage_post_posts_custom_column', array($adminHooks, 'manage_post_posts_custom_column'), 10, 2);
    add_action('save_post_product', array($adminHooks, 'save_post_product'));

    $adminFilters = new AdminFilters_clfe( $adminApp->getFilters() );
    
    add_filter('manage_edit-post_columns', array($adminFilters, 'manage_edit_post_columns'), 9999);
    
    /*
     * this part should be mouved to a compo : wpcustomize
     * hide all others plugins notices in the admin section
     */
    /*add_action( 'admin_notices', function() {
        if( adminUtils_clfe::IsClfePages() ) { remove_all_actions( 'admin_notices' ); }
    }, 0);*/
    
    function clfe_disable_admin_notices() {
        if( adminUtils_clfe::IsClfePages() ) {
            global $wp_filter;

            if ( isset( $wp_filter['user_admin_notices'] ) ) {
                unset( $wp_filter['user_admin_notices'] );
            }
            if ( isset( $wp_filter['admin_notices'] ) ) {
                unset( $wp_filter['admin_notices'] );
            }
            if ( isset( $wp_filter['all_admin_notices'] ) ) {
                unset( $wp_filter['all_admin_notices'] );
            }
        }
    }
    add_action( 'admin_print_scripts', 'clfe_disable_admin_notices' );
    add_action('admin_init', 'clfe_disable_admin_notices');
    
    
    
}


//---------------------------------------------------------------------------------------

//require_once plugin_dir_path(__FILE__) . 'order-system.php';