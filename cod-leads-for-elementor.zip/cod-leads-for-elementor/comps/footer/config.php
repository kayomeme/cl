<?php

/**
 * Footer component configuration.
 */
return array(
    'setting' => [
        'active_blocks' => 'display_rules,main_footer,bottom_footer',
        // Block ordering is disabled for now as per the plan
        // 'footer_blocks_order' => 'main_footer,bottom_footer', 
    ],
    'lang' => [],
    'style' => []
);