<?php

/**
 * Frontend controller for the Footer component.
 */
class FooterControllerFR_cl {
    
    public $settings;
    private $footer_source_to_render = 'plugin'; // Default

    /**
     * Constructor.
     */
    public function __construct() {
        global $settingsModelId;
        $compoName = 'footer';
        $this->settings = PublicCompo_cl::getSettings($compoName, $settingsModelId);
        
        $this->determine_footer_source();
    }
    
    /**
     * Determines which footer source to use based on the unified JSON override setting.
     */
    private function determine_footer_source() {
        $settings = $this->settings;
        $current_page_scope = $this->get_current_page_scope();

        $overrides = json_decode($settings['footer_overrides'], true);
        if (!is_array($overrides)) { 
            $overrides = array(); 
        }

        $rule_to_use = null;

        // Check if there is an active override for the current page type
        if ($current_page_scope && isset($overrides[$current_page_scope]) && isset($overrides[$current_page_scope]['is_active']) && $overrides[$current_page_scope]['is_active'] === 'yes') {
            $rule_to_use = $overrides[$current_page_scope];
        } else {
            // Fall back to the global setting from within the JSON
            $rule_to_use = isset($overrides['global']) ? $overrides['global'] : array('source' => 'plugin'); // Default to plugin if global is somehow missing
        }

        // Set the final source based on the determined rule
        $this->footer_source_to_render = $rule_to_use['source'];
        
        if ($this->footer_source_to_render === 'custom_block') {
            $this->footer_source_to_render = array(
                'type' => 'custom_block',
                'id'   => isset($rule_to_use['custom_block_id']) ? $rule_to_use['custom_block_id'] : ''
            );
        }
    }

    /**
     * Identifies the current page type to check for overrides.
     */
    private function get_current_page_scope() {
        if (is_front_page()) { return 'homepage'; }
        if (is_singular('product')) { return 'single_product'; }
        if (is_tax('product_cat')) { return 'product_cat'; }
        
        if ( is_singular('page') ) {
            $currentPageId = get_the_ID();
            global $salesFunnel_cl;
            if (isset($salesFunnel_cl)) {
                switch ($currentPageId) {
                    case $salesFunnel_cl->cartPageId: return 'cart';
                    case $salesFunnel_cl->checkoutPageId: return 'checkout';
                    case $salesFunnel_cl->thankyouPageId: return 'thankyou';
                }
            }
        }
        
        return null;
    }

    /**
     * Public method to check if the theme's footer should be used.
     */
    public function themeFooterIsSelected() {
        return $this->footer_source_to_render === 'theme';
    }

    /**
     * Main method to render the appropriate footer content.
     */
    public function index() {
        if ($this->footer_source_to_render === 'hide') {
            return; // Render nothing
        }

        if (is_array($this->footer_source_to_render) && $this->footer_source_to_render['type'] === 'custom_block') {
            if (!empty($this->footer_source_to_render['id'])) {
                echo do_shortcode('[custom_block id="' . intval($this->footer_source_to_render['id']) . '"]');
            }
            return;
        }
        
        // If 'plugin', render the Cod Leads footer.
        $settings = $this->settings;
        
        // Get the rendered HTML for global elements from the mystore controller.
        $socialLinksHtml = '';
        $contactInfoHtml = '';
        global $mystore_cl;
        if (isset($mystore_cl)) {
            if ($settings['main_footer_social_links_is_active'] == 'yes') {
                $socialLinksHtml = $mystore_cl->renderSocialLinksHtml();
            }
            if ($settings['main_footer_contact_info_is_active'] == 'yes') {
                $contactInfoHtml = $mystore_cl->renderContactInfoHtml();
            }
        }
        
        $main_footer_menus = array();
        if (!empty($settings['main_footer_menu_ids'])) {
            $menu_ids = explode(',', $settings['main_footer_menu_ids']);
            foreach ($menu_ids as $menu_id) {
                if (empty(trim($menu_id))) continue;
                $menu_object = wp_get_nav_menu_object($menu_id);
                if ($menu_object) {
                    $main_footer_menus[] = array(
                        'title' => $menu_object->name,
                        'items' => wp_get_nav_menu_items(intval($menu_id))
                    );
                }
            }
        }
        
        $bottom_footer_menu_items = !empty($settings['bottom_footer_menu_id'])
            ? wp_get_nav_menu_items($settings['bottom_footer_menu_id'])
            : [];

        require_once MainApp_cl::$compsPath . 'footer/frontend/views/index.php';
    }
}