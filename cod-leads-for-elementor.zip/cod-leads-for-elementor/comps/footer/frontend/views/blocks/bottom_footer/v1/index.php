<?php
/**
 * Frontend view for the Bottom Footer (Socket) block.
 */

// Only render if the block is active.
if ($settings['bottom_footer_is_active'] != 'yes') {
    return;
}

// Replace placeholders in copyright text
$copyright_text = str_replace(
    array('@year', '@site_title'),
    array(date('Y'), get_bloginfo('name')),
    $settings['bottom_footer_copyright_text']
);
?>

<div class="cl-footer-socket">
    <div class="copyright-text">
        <?= wp_kses_post($copyright_text) ?>
    </div>
    
    <?php if (!empty($bottom_footer_menu_items)) { ?>
        <nav class="socket-menu">
            <ul>
                <?php foreach ($bottom_footer_menu_items as $menu_item) { ?>
                    <li><a href="<?= esc_url($menu_item->url) ?>"><?= esc_html($menu_item->title) ?></a></li>
                <?php } ?>
            </ul>
        </nav>
    <?php } ?>
</div>