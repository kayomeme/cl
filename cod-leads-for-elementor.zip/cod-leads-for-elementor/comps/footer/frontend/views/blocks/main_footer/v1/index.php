<?php
/**
 * Frontend view for the Main Footer block.
 */

// Only render if the block is active.
if ($settings['main_footer_is_active'] != 'yes') {
    return;
}

// Prepare branding elements order
$brandingElementsOrder = explode(',', $settings['main_footer_branding_order']);

// Prepare other variables
$active_menu_count = count($main_footer_menus);
$branding_active = $settings['main_footer_branding_is_active'] == 'yes';

?>

<div class="cl-footer-main">
    
    <?php // -- Branding Column --
    if ($branding_active) { ?>
        <div class="footer-branding-col">
            <?php
            // Loop through branding elements and include their view files in the specified order
            foreach ($brandingElementsOrder as $elementName) {
                // Ensure the element name is a valid string to prevent path traversal issues.
                $safeElementName = trim(basename($elementName));
                if (empty($safeElementName)) {
                    continue;
                }
                
                $element_path = __DIR__ . '/branding_elements/' . $safeElementName . '.php';
                if (file_exists($element_path)) {
                    include $element_path;
                }
            }
            ?>
        </div>
    <?php } ?>
    
    <?php // -- Menu Columns --
    if ($active_menu_count > 0) { ?>
        <div class="footer-menus-col">
            <?php foreach ($main_footer_menus as $menu) { ?>
                <div class="footer-menu-widget">
                    <span class="widget-title"><?= esc_html($menu['title']) ?></span>
                    <?php if (!empty($menu['items'])) { ?>
                        <ul>
                            <?php foreach ($menu['items'] as $item) { ?>
                                <li><a href="<?= esc_url($item->url) ?>"><?= esc_html($item->title) ?></a></li>
                            <?php } ?>
                        </ul>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
    <?php } ?>
</div>