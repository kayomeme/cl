<?php
/**
 * Renders the logo element for the branding column.
 */

if (!empty($settings['main_footer_logo_image_url'])) { ?>
    <div class="branding-logo">
        <a href="<?= esc_url(home_url('/')) ?>">
            <img src="<?= esc_url($settings['main_footer_logo_image_url']) ?>" alt="<?= esc_attr(get_bloginfo('name')) ?>">
        </a>
    </div>
<?php } ?>