<?php
/**
 * Renders the description element for the branding column.
 */

if ($settings['main_footer_description_is_active'] == 'yes' && !empty($settings['main_footer_description_text'])) { ?>
    <div class="branding-description">
        <p><?= esc_html($settings['main_footer_description_text']) ?></p>
    </div>
<?php } ?>