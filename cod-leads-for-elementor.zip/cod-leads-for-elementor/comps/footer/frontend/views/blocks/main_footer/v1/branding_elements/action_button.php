<?php
/**
 * Renders the action button element for the branding column.
 */

if ($settings['main_footer_action_button_is_active'] == 'yes' && !empty($settings['main_footer_action_button_text'])) { 
    global $iconsSelectorFR_cl;
    ?>
    <div class="branding-action-button">
        <a href="<?= esc_url($settings['main_footer_action_button_url']) ?>">
            <?php if (!empty($settings['main_footer_action_button_icon_id'])) {
                echo $iconsSelectorFR_cl->getIconCode($settings['main_footer_action_button_icon_id']);
            } ?>
            <span><?= esc_html($settings['main_footer_action_button_text']) ?></span>
        </a>
    </div>
<?php } ?>