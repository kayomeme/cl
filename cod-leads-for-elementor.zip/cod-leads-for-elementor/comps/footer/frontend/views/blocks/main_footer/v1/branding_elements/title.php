<?php
/**
 * Renders the title element for the branding column.
 */

if (!empty($settings['main_footer_title_text'])) { ?>
    <div class="branding-title">
        <?= esc_html($settings['main_footer_title_text']) ?>
    </div>
<?php } ?>