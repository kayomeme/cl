<?php
/**
 * Renders the contact info element for the branding column.
 */

if (!empty($contactInfoHtml)) { ?>
    <div class="branding-contact-info">
        <?php 
        // The contact info is pre-rendered by the mystore component.
        echo $contactInfoHtml; 
        ?>
    </div>
<?php } ?>