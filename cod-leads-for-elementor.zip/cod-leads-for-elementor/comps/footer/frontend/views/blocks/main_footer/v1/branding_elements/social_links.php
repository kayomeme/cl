<?php
/**
 * Renders the social links element for the branding column.
 */

if (!empty($socialLinksHtml)) { ?>
    <div class="branding-social-links">
        <?php if (!empty($settings['main_footer_social_links_text'])) { ?>
            <span class="social-links-text"><?= esc_html($settings['main_footer_social_links_text']) ?></span>
        <?php } ?>

        <div class="footer-social-links">
            <?= $socialLinksHtml ?>
        </div>
    </div>
<?php } ?>