<?php
/**
 * Main frontend view for the Footer component.
 * Renders the footer blocks in a fixed order.
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Get the version numbers for each block from the settings.
$main_footer_version = isset($settings['main_footer_version']) ? $settings['main_footer_version'] : 'v1';
$bottom_footer_version = isset($settings['bottom_footer_version']) ? $settings['bottom_footer_version'] : 'v1';

// Define the paths to the block view files.
$main_footer_path = MainApp_cl::$compsPath . 'footer/frontend/views/blocks/main_footer/' . $main_footer_version . '/index.php';
$bottom_footer_path = MainApp_cl::$compsPath . 'footer/frontend/views/blocks/bottom_footer/' . $bottom_footer_version . '/index.php';
?>

<footer class="cl-site-footer">
    <?php
    // Render the Main Footer block if its view file exists.
    if (file_exists($main_footer_path)) {
        include $main_footer_path;
    }

    // Render the Bottom Footer block if its view file exists.
    if (file_exists($bottom_footer_path)) {
        include $bottom_footer_path;
    }
    ?>
</footer>