/*
 * Dynamic Flex Navigation System
 * 
 * ✅ GLOBAL SCOPE - Ready for use anywhere!
 * 
 * Usage: Simply add 'cl_flexnav' class to any navigation container
 * Works in: Header, Footer, Sidebar, Content areas, Mobile menus, etc.
 * 
 * Required HTML structure:
 * <nav class="cl_flexnav">
 *   <ul><li><a>...</a></li></ul>
 *   <div class="cl_more_flexnav"><button>More <span class="cl_count"></span></button></div>
 *   <div class="cl_dropdown_flexnav"></div>
 * </nav>
 * 
 * Features:
 * - Auto-detects all .cl_flexnav containers on page
 * - Each navigation works independently
 * - Responsive and mobile-friendly
 * - Dynamic content support
 * - Global manager available: window.flexNavInstancesManager
 */

class FlexNav_cl {
    constructor(container) {
        this.container = container;
        this.navList = container.querySelector('ul');
        this.moreMenu = container.querySelector('.cl_more_flexnav');
        this.moreButton = this.moreMenu ? this.moreMenu.querySelector('button') : null;
        this.dropdown = container.querySelector('.cl_dropdown_flexnav');
        this.countElement = this.moreButton ? this.moreButton.querySelector('.cl_count') : null;
        this.navItems = Array.from(this.navList.children);
        this.isDropdownOpen = false;
        
        // Only initialize if all required elements exist
        if (this.navList && this.moreMenu && this.moreButton && this.dropdown) {
            this.init();
        } else {
            console.warn('FlexNav_cl: Missing required elements in container', container);
        }
    }
    
    init() {
        // Hide more menu initially
        this.hideMoreMenu();
        
        // Initialize event listeners
        this.moreButton.addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleDropdown();
        });
        
        // Close dropdown when clicking outside (but only for this instance)
        document.addEventListener('click', (e) => {
            if (!this.container.contains(e.target)) {
                this.closeDropdown();
            }
        });
        
        // Prevent dropdown from closing when clicking inside it
        this.dropdown.addEventListener('click', (e) => {
            e.stopPropagation();
        });
        
        // Handle resize with debouncing for better performance
        let resizeTimeout;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(() => {
                this.handleResize();
            }, 100);
        });
        
        // Initial setup
        this.handleResize();
    }
    
    handleResize() {
        // Reset all items to visible first
        this.showAllItems();
        this.hideMoreMenu();
        
        // Wait for next frame to ensure DOM has updated
        requestAnimationFrame(() => {
            this.adjustMenu();
        });
    }
    
     /**
     * Width Measurement Solution:
     * Problem: getBoundingClientRect().width returns 0 when element has display: none
     * Solution: Temporarily show element → measure width → hide it again
     * 
     * This brief show/hide cycle (happens in milliseconds) is imperceptible to users
     * but allows accurate width measurement for responsive calculations.
     */
    getMoreButtonWidth() {
        this.moreMenu.style.display = 'block';
        const moreMenuWidth = this.moreMenu.getBoundingClientRect().width || 80; // Fallback to 80px
        this.moreMenu.style.display = 'none';
        
        console.log(moreMenuWidth);
        
        return moreMenuWidth;
    }
    
    adjustMenu() {
        const containerRect = this.container.getBoundingClientRect();
        console.log(containerRect.width);
        const padding = 30; // Some padding for safety
        const availableWidth = containerRect.width - this.getMoreButtonWidth() - padding;
        
        let totalWidth = 0;
        let visibleItems = [];
        let hiddenItems = [];
        
        // Calculate which items can fit
        for (let i = 0; i < this.navItems.length; i++) {
            const item = this.navItems[i];
            const itemRect = item.getBoundingClientRect();
            const itemWidth = itemRect.width + 20; // Including margins
            
            if (totalWidth + itemWidth <= availableWidth) {
                totalWidth += itemWidth;
                visibleItems.push(item);
            } else {
                hiddenItems.push(item);
            }
        }
        
        // If all items fit, hide the more menu
        if (hiddenItems.length === 0) {
            this.hideMoreMenu();
            return;
        }
        
        // Show more menu and hide overflow items
        this.showMoreMenu();
        this.moveItemsToDropdown(hiddenItems);
    }
    
    showAllItems() {
        this.navItems.forEach(item => {
            item.classList.remove('cl_hidden_flexnav');
            if (!this.navList.contains(item)) {
                this.navList.appendChild(item);
            }
        });
    }
    
    hideMoreMenu() {
        this.moreMenu.style.display = 'none';
        this.closeDropdown();
    }
    
    showMoreMenu() {
        this.moreMenu.style.display = 'block';
    }
    
    moveItemsToDropdown(items) {
        // Clear dropdown
        this.dropdown.innerHTML = '';
        
        // Hide items from main menu and add to dropdown
        items.forEach(item => {
            item.classList.add('cl_hidden_flexnav');
            
            // Create dropdown link
            const link = item.querySelector('a');
            if (link) {
                const dropdownLink = link.cloneNode(true);
                this.dropdown.appendChild(dropdownLink);
            }
        });
        
        // Update count if count element exists
        if (this.countElement) {
            this.countElement.textContent = `(${items.length})`;
        }
    }
    
    toggleDropdown() {
        this.isDropdownOpen = !this.isDropdownOpen;
        if (this.isDropdownOpen) {
            this.dropdown.classList.add('cl_open_flexnav');
        } else {
            this.dropdown.classList.remove('cl_open_flexnav');
        }
    }
    
    closeDropdown() {
        this.isDropdownOpen = false;
        this.dropdown.classList.remove('cl_open_flexnav');
    }
}

// Manager class to handle multiple flex nav instances
class FlexNavInstances_cl {
    constructor() {
        this.instances = [];
    }
    
    init() {
        // Find all containers with cl_flexnav class
        const containers = document.querySelectorAll('.cl_flexnav');
        
        containers.forEach(container => {
            const instance = new FlexNav_cl(container);
            this.instances.push(instance);
        });
    }
    
    // Method to manually add new flex nav (useful for dynamically added content)
    addFlexNav(container) {
        if (container.classList.contains('cl_flexnav')) {
            const instance = new FlexNav_cl(container);
            this.instances.push(instance);
            return instance;
        } else {
            console.warn('FlexNavInstances_cl: Container must have cl_flexnav class');
            return null;
        }
    }
    
    // Method to refresh all instances (useful after content changes)
    refreshAll() {
        this.instances.forEach(instance => {
            instance.handleResize();
        });
    }
}

// Initialize the flex nav manager when DOM is ready
let flexNavInstancesManager;
document.addEventListener('DOMContentLoaded', () => {
    flexNavInstancesManager = new FlexNavInstances_cl();
    flexNavInstancesManager.init();
});

// Make manager globally available
window.flexNavInstancesManager = flexNavInstancesManager;