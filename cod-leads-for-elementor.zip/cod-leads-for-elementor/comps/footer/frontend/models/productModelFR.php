<?php

class ProductModelFR_cl extends ProductModel_cl {

    public static function getDetailsForAddToCartInJson($product) {
        $productId = $product['product_id'];
        $pdata = [
            'product_id' => $productId,
            'title' => $product['title'],
            'short_image_url' => $product['thumbnail'],
            'regular_price' => $product['_regular_price'],
            'sale_price' => $product['_sale_price'],
            'discount_per_product' => $product['discount_value_fixed'],
            'qty' => 1,
            'added_via' => 'update in js'
        ];

        return jsonEncodeForJs_cl($pdata);
    }

    public static function getDetailsForThankyouUpsellInJson($product) {
        $productId = $product['product_id'];
        $pdata = [
            'product_id' => $productId,
            'title' => $product['title'],
            'short_image_url' => $product['thumbnail'],
            'regular_price' => $product['_regular_price'],
            'sale_price' => $product['_sale_price'],
            'discount_per_product' => $product['discount_value_fixed'],
            //'total_savings' => $product['discount_value_fixed'],
            'qty' => 1,
            'added_via' => 'Thankyou upsell',
            'upsell_success_message' => $product['upsell_success_message']
        ];

        return jsonEncodeForJs_cl($pdata);
    }

    /**
     * Get quantity offers from database for specific product
     * 
     * @param int $productId
     * @param int $settingsModelId
     * @param array $categories
     * @return array
     */
    public static function getQtyOffers($productId, $settingsModelId, $categories = []) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'qty_offers';

        // Prepare category IDs for IN clause
        $category_placeholders = '';
        $query_params = [$settingsModelId, $productId];

        if (!empty($categories)) {
            $category_placeholders = implode(',', array_fill(0, count($categories), '%d'));
            $query_params = array_merge($query_params, $categories);
        }
        
        $selectParms = 'id, offer_type, discount_type, options';

        // Build the query
        $sql = "SELECT {$selectParms} FROM {$table_name} 
            WHERE is_active = 'yes' 
            AND settings_model_id = %d
            AND (
                (application_scope = 'single_product' AND application_target = %d)";

        if (!empty($categories)) {
            $sql .= " OR (application_scope = 'category' AND application_target IN ({$category_placeholders}))";
        }

        $sql .= " OR (application_scope = 'all_products')
            )
            ORDER BY priority ASC
            LIMIT 1";

        // Execute query
        $offer = $wpdb->get_row($wpdb->prepare($sql, $query_params), ARRAY_A);

        // Process the offer
        $processedOffers = [];
        if ($offer && !empty($offer['options'])) {
            $options = jsonDecode_cl($offer['options']);
            unset( $offer['options']);
            if (is_array($options)) {
                $processedOffers = $offer;
                $processedOffers['options'] = $options;
            }
        }

        return $processedOffers;
    }

    public static function getVariations($productID, $settingModelId = 0) {
        /*$variations = get_post_meta($productID, 'cl_variations', true);
        $variations = jsonDecode_cl($variations);
        return $variations;*/
        
        $savedVariations = (array) jsonDecode_cl(get_post_meta($productID, 'cl_variations', true));

        $productVariations = array_column($savedVariations, null, 'slug');

        $globalVariations = get_option('cl_global_variations_' . $settingModelId);

        $variations = [];
        foreach ($productVariations as $key => $variation) {
            if (isset($globalVariations[$key])) {
                $variations[$key] = array_merge($globalVariations[$key], $productVariations[$key]);
            }
        }


        return $variations;
    }
}
