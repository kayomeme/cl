<?php

/**
 * Frontend Model for Quantity Offers
 * Handles pure data retrieval from database
 */
class QtyOffersModelFR_cl {

    /**
     * Get quantity offers from database for specific product
     * This replaces the existing ProductModelFR_cl::getQtyOffers() method
     * 
     * @param int $productId
     * @param int $settingsModelId
     * @param array $categories Product category IDs
     * @return array Raw offer data from database
     */
    public static function getOffersForProduct($productId, $settingsModelId, $categories = []) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'qty_offers';

        // Prepare category IDs for IN clause
        $category_placeholders = '';
        $query_params = [$settingsModelId, $productId];

        if (!empty($categories)) {
            $category_placeholders = implode(',', array_fill(0, count($categories), '%d'));
            $query_params = array_merge($query_params, $categories);
        }
        
        // Select all relevant fields for calculations
        $selectParams = 'id, offer_type, discount_type, options, application_scope, application_target';

        // Build the query - gets the highest priority offer that applies to this product
        $sql = "SELECT {$selectParams} FROM {$table_name} 
            WHERE is_active = 'yes' 
            AND settings_model_id = %d
            AND (
                (application_scope = 'single_product' AND application_target = %d)";

        if (!empty($categories)) {
            $sql .= " OR (application_scope = 'category' AND application_target IN ({$category_placeholders}))";
        }

        $sql .= " OR (application_scope = 'all_products')
            )
            ORDER BY priority ASC
            LIMIT 1";

        // Execute query
        $offer = $wpdb->get_row($wpdb->prepare($sql, $query_params), ARRAY_A);

        // Process and return the offer
        if ($offer && !empty($offer['options'])) {
            // Decode the JSON options
            $options = jsonDecode_cl($offer['options']);
            
            if (is_array($options)) {
                $offer['options'] = $options;
                return $offer;
            }
        }

        // Return empty array if no valid offer found
        return [];
    }
}