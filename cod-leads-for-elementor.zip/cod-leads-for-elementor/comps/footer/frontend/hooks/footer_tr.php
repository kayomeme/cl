<?php
// This hook initializes the footer controller on every page load.
global $footer_cl;
$footer_cl = new FooterControllerFR_cl();