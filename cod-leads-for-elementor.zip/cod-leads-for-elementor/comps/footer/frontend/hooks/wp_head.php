<?php
// This hook is responsible for adding the generated CSS to the page header.
// this is mouved to wp_head global hook
/*if (isset($allCompsGeneratedCss['header'])) {
    echo $allCompsGeneratedCss['header'];
}*/