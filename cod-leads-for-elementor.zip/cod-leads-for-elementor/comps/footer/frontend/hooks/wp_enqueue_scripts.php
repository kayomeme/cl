<?php
// todo - only load when need, based on the settings or the dispplay conditions , now it load in all pages
/*wp_enqueue_style( 'header_css_with_flexnav', MainApp_cl::$compsUrl. 'header/frontend/assets/css/header.css', MainApp_cl::$assetsVersion );
wp_enqueue_script( 'header_js', MainApp_cl::$compsUrl. 'header/frontend/assets/js/header.js', array( 'jquery' ), MainApp_cl::$assetsVersion );*/
