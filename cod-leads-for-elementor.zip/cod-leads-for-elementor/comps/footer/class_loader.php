<?php
$dirPath = plugin_dir_path( __FILE__ );

if( $isAdminAria ) {    
    // Loads the controller for the footer settings page in the WordPress admin area.
    require_once $dirPath . 'backend/controllers/footerSettingsControllerBK.php';
}

if($isPublicAria) {
    // Loads the controller responsible for displaying the footer on the live site.
    require_once $dirPath . 'frontend/controllers/footerControllerFR.php';
}