<?php

class FooterSettingsControllerBK_cl
{
    /**
     * Renders the footer component's settings page in the admin area.
     *
     * @param int $settingsModelId The ID of the settings model.
     * @param array $settings The current settings for the component.
     * @param array $urlArgs URL arguments.
     */
    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'footer';

        // Get default settings to ensure all keys are present.
        $defaultSettings = AdminCompo_cl::getDefaultSettings($compoName, $settings);

        // Process the order of the branding column elements.
        $brandingElementsOrder = adminUtils_cl::getElementsOrder($defaultSettings['main_footer_branding_order'], $settings['main_footer_branding_order']);
        $settings['main_footer_branding_order'] = implode(',', $brandingElementsOrder);
        
        // Get registered menus from WordPress.
        $wpMenus = wp_get_nav_menus();

        // Query WordPress to get all published 'custom_block' posts
        $custom_blocks_query = new WP_Query(array(
            'post_type' => 'custom_block',
            'post_status' => 'publish',
            'posts_per_page' => 200,
        ));
        $custom_blocks = $custom_blocks_query->get_posts();

        // Define the page types for the overrides. This array is passed to the view to generate the collapsible toggle blocks.
        $override_pages = array(
            'homepage'       => Lang_cl::__('Homepage', 'cl'),
            'product_cat'    => Lang_cl::__('Product Category Archives', 'cl'),
            'single_product' => Lang_cl::__('Single Product Page', 'cl'),
            'cart'           => Lang_cl::__('Cart Page', 'cl'),
            'checkout'       => Lang_cl::__('Checkout Page', 'cl'),
            'thankyou'       => Lang_cl::__('Thank You Page', 'cl'),
        );

        // Prepare style generator settings and initialize the style manager.
        $generatorSettings = AdminCompo_cl::getStyleGenerator($compoName, $settings);
        $styleManager = new StyleManagerBK_cl($defaultSettings, $settings, $generatorSettings);

        // Include the main view file for the settings page.
        include AdminApp_cl::$viewsPath . 'global_settings/index.php';
    }

    /**
     * Saves the footer component settings.
     *
     * @param string $compoName The name of the component.
     * @param int $settingsModelId The ID of the settings model.
     * @param array $args The settings data to save.
     * @return mixed The response from the save operation.
     */
    public static function save_settings($compoName, $settingsModelId, $args)
    {
        $response = AdminCompo_cl::saveSettings($compoName, $settingsModelId, $args);
        
        if ($response) {
            return $response;
        }
    }

    /**
     * Placeholder for shared settings if needed in the future.
     */
    private static function getSharedSettings($args)
    {
        $sharedSettings = [];
        return $sharedSettings;
    }
}