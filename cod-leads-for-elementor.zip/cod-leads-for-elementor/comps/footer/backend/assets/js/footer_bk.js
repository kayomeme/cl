(function ($) {
    'use strict';

    $(document).ready(function () {

        // --- Logic for Branding Column Order ---
        $("#cl-branding-elements").sortable({
            update: function( event, ui ) {
                var elementsOrder = $('#cl-branding-elements .cl-row').map(function () { 
                    return $(this).attr("_attachedsection"); 
                });
                $("input[name=main_footer_branding_order]").val(elementsOrder.toArray().join(',')).trigger('change');
            }
        });
        
        // --- Logic for Main Footer Menu Columns ---
        function updateFooterMenuIds() {
            var menuIds = [];
            var columnCount = parseInt($('select[name="main_footer_menu_columns_count"]').val()) || 0;
            
            // Only collect IDs from the visible select boxes
            $('.cl-footer-menu-selector').each(function (index) {
                var $selector = $(this);
                // Check if the parent container is visible, which respects the conditional logic
                if ($selector.closest('.footer-menu-column-selector').is(':visible')) {
                    var selectedId = $selector.val();
                    if (selectedId) {
                        menuIds.push(selectedId);
                    }
                }
            });

            $('input[name="main_footer_menu_ids"]').val(menuIds.join(',')).trigger('change');
        }

        // Update when a menu is selected or when the number of columns changes
        $('select[name="main_footer_menu_columns_count"], .cl-footer-menu-selector').on('change', function () {
            updateFooterMenuIds();
        });

        // --- Logic for Display Rules Overrides ---
        function updateFooterOverridesJson() {
            var overrides = {};

            // 1. Handle the Global rule first
            var globalScope = 'global';
            var $globalContainer = $('#cl-footer-overrides-container [data-override-scope="global"]');
            var globalSource = $globalContainer.find('[data-type="source"]').val();
            var globalCustomBlockId = $globalContainer.find('[data-type="custom_block_id"]').val();

            overrides[globalScope] = {
                'source': globalSource
            };
            if (globalSource === 'custom_block') {
                overrides[globalScope]['custom_block_id'] = globalCustomBlockId;
            }
            
            // 2. Handle the Page-Specific Overrides
            $('#cl-footer-overrides-container .admin_toggle_body .cl-sub-section').each(function() {
                var scope = $(this).data('override-scope');
                var isActive = $(this).find('[data-type="is_active"]').is(':checked');

                // Only add the override to the JSON if it's active
                if (isActive) {
                    var source = $(this).find('[data-type="source"]').val();
                    var customBlockId = $(this).find('[data-type="custom_block_id"]').val();

                    overrides[scope] = {
                        'is_active': 'yes',
                        'source': source
                    };

                    if (source === 'custom_block') {
                        overrides[scope]['custom_block_id'] = customBlockId;
                    }
                }
            });
            
            // 3. Update the hidden input field with the complete JSON string
            $('input[name="footer_overrides"]').val(JSON.stringify(overrides)).trigger('change');
        }

        // Listen for changes on any override control (global or specific)
        $(document).on('change', '#cl-footer-overrides-container input, #cl-footer-overrides-container select, #cl-footer-overrides-container textarea', function() { 
            updateFooterOverridesJson(); 
        });

        // Initial build of the JSON on page load to ensure it's correct
        updateFooterOverridesJson();
    });

})(jQuery);