<?php

if (isset($_REQUEST['page']) && $_REQUEST['page'] == 'cl_global_settings' && isset($_REQUEST['compo']) && $_REQUEST['compo'] == 'footer') {

    /*wp_enqueue_style(
            MainApp_cl::$assetsPrefix . 'footer',
            MainApp_cl::$compsUrl . 'footer/backend/assets/css/footer_bk.css',
            array(), // No dependencies
            $assetsVersion
    );*/

    // Enqueue the backend JavaScript for the footer component
    wp_enqueue_script(MainApp_cl::$assetsPrefix . 'footer',
            MainApp_cl::$compsUrl . 'footer/backend/assets/js/footer_bk.js',
            ['jquery', 'jquery-ui-sortable'], // Add jquery-ui-sortable as a dependency
            $assetsVersion,
            true // Load in footer
    );
}