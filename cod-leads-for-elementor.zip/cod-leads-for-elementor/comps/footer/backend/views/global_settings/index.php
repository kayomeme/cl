<div id="cl_display_rules_tab" class="cl-single-tab">
    <?php include 'blocks/display_rules/' . $settings['display_rules_version'] . '/index.php'; ?>
</div>

<div id="cl_main_footer_tab" class="cl-single-tab">
    <?php include 'blocks/main_footer/' . $settings['main_footer_version'] . '/index.php'; ?>
</div>

<div id="cl_bottom_footer_tab" class="cl-single-tab">
    <?php include 'blocks/bottom_footer/' . $settings['bottom_footer_version'] . '/index.php'; ?>
</div>

<div style="display: none;">
    <input type="text" name="display_rules_version" value="<?= esc_attr($settings['display_rules_version']) ?>">
    <input type="text" name="main_footer_version" value="<?= esc_attr($settings['main_footer_version']) ?>">
    <input type="text" name="bottom_footer_version" value="<?= esc_attr($settings['bottom_footer_version']) ?>">
</div>