<?php

// Include Main Header CSS if active
if ($settings['main_footer_is_active'] == 'yes') {
    include 'blocks/main_footer/' . $settings['main_footer_version'] . '/generated_css.php';
}

// Include Bottom Header CSS if active
if ($settings['bottom_footer_is_active'] == 'yes') {
    include 'blocks/bottom_footer/' . $settings['bottom_footer_version'] . '/generated_css.php';
}
?>