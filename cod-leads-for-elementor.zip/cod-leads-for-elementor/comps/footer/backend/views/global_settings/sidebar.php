<button tab="cl_display_rules_tab" _section="cl_display_rules">
    <span class="dashicons dashicons-admin-settings"></span>
    <?= Lang_cl::_e('Display Rules', 'cl') ?>
</button>

<button tab="cl_main_footer_tab" _section="cl_main_footer">
    <span class="dashicons dashicons-editor-kitchensink"></span>
    <?= Lang_cl::_e('Main Footer', 'cl') ?>
</button>

<button tab="cl_bottom_footer_tab" _section="cl_bottom_footer">
    <span class="dashicons dashicons-minus"></span>
    <?= Lang_cl::_e('Bottom Footer', 'cl') ?>
</button>