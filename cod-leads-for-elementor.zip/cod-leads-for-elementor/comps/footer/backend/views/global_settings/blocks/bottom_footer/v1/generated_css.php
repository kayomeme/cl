<style>
    .cl-footer-socket {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        gap: 20px;
        margin: auto;
        <?= $settings['bottom_footer_container_style'] ?>
    }
    .cl-footer-socket .copyright-text {
        <?= $settings['bottom_footer_copyright_style'] ?>
    }
    .cl-footer-socket .socket-menu ul {
        margin: 0;
        padding: 0;
        list-style: none;
        display: flex;
        flex-wrap: wrap;
        gap: 24px;
    }
    .cl-footer-socket .socket-menu a {
        text-decoration: none;
        <?= $settings['bottom_footer_menu_style'] ?>
    }
</style>