<div class="cl-row" _attachedsection="title">
    <span class="dashicons dashicons-editor-bold"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Title', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>