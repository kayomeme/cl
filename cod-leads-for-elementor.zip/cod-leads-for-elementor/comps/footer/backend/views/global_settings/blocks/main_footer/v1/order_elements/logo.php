<div class="cl-row" _attachedsection="logo">
    <span class="dashicons dashicons-lightbulb"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Logo Image', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>