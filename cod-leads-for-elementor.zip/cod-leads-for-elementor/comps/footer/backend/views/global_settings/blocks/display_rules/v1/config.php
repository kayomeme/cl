<?php return array (
  'setting' => 
  array (
    'display_rules_version' => 'v1',

    // All display rules, including global, are now stored in this single JSON string.
    'footer_overrides' => '{"global":{"source":"plugin"}}', // Default to plugin for global
  ),
  'lang' => 
  array (
  ),
  'style' => 
  array (
  ),
);