<div class="cl-row" _attachedsection="contact_info">
    <span class="dashicons dashicons-id-alt"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Contact Info', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>