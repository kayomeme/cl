    <div class="cl-row">
        <div class="cl-th">
            <?= Lang_cl::_e('Main Footer Section', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Is Active', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getSwitchButton(['name' => 'main_footer_is_active', 'value' => $settings['main_footer_is_active']]);
                        $styleManager->getAllCss('main_footer_container_style');
                        ?>
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Layout', 'cl') ?>
                    </div>
                    <div class="cl-td">
                        <select name="main_footer_layout">
                            <option value="branding-first" <?= selected($settings['main_footer_layout'], 'branding-first', false) ?>>
                                <?= Lang_cl::_e('Branding First, Menus Last', 'cl') ?>
                            </option>
                            <option value="menus-first" <?= selected($settings['main_footer_layout'], 'menus-first', false) ?>>
                                <?= Lang_cl::_e('Menus First, Branding Last', 'cl') ?>
                            </option>
                        </select>
                    </div>
                </div>
                <?php
                $styleManager->getSingleCss('max-width', 'main_footer_container_style');
                $styleManager->getSingleCss('margin-top', 'main_footer_container_style');
                $styleManager->getSingleCss('margin-bottom', 'main_footer_container_style');
                ?>
            </div>
        </div>
    </div>