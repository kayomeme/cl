<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Bottom Footer Section', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton(['name' => 'bottom_footer_is_active', 'value' => $settings['bottom_footer_is_active']]);
                    $styleManager->getAllCss('bottom_footer_container_style');
                    ?>
                </div>
            </div>
            <?php 
                $styleManager->getSingleCss('max-width', 'bottom_footer_container_style');
                $styleManager->getSingleCss('margin-top', 'bottom_footer_container_style');
                $styleManager->getSingleCss('margin-bottom', 'bottom_footer_container_style');
            ?>
        </div>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Copyright Text', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Text Content', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <input type="text" name="bottom_footer_copyright_text" value="<?= esc_attr($settings['bottom_footer_copyright_text']) ?>">
                    <?php $styleManager->getAllCss('bottom_footer_copyright_style'); ?>
                </div>
                <div class="cl-alert cl-alert-info">
                    <?= Lang_cl::_e('You can use the placeholders @year and @site_title which will be replaced automatically.', 'cl') ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Socket Menu', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Select Menu', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                     <select name="bottom_footer_menu_id">
                        <option value=""><?= Lang_cl::_e('-- Select a Menu --', 'cl') ?></option>
                        <?php foreach ($wpMenus as $menu) { ?>
                            <option value="<?= esc_attr($menu->term_id) ?>" <?= selected($settings['bottom_footer_menu_id'], $menu->term_id, false) ?>>
                                <?= esc_html($menu->name) ?>
                            </option>
                        <?php } ?>
                    </select>
                    <?php $styleManager->getAllCss('bottom_footer_menu_style'); ?>
                </div>
            </div>
        </div>
    </div>
</div>