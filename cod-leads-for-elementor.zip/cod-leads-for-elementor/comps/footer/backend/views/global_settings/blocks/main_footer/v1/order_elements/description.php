<div class="cl-row" _attachedsection="description">
    <span class="dashicons dashicons-text-page"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Description', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>