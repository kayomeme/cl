<!-- Menus Info Section -->
<div class="cl-info-section">
    <div class="cl-info-header">
        <span class="dashicons dashicons-info"></span>
        <p><?= Lang_cl::_e('Menus are managed globally in the main WordPress admin area. You can create or edit menus there, and then assign them to the columns below.', 'cl') ?></p>
    </div>

    <div class="cl-info-links">
        <a href="<?= esc_url(admin_url('nav-menus.php')) ?>" >
            <span><?= Lang_cl::_e('Manage Menus', 'cl') ?></span>
            <span class="arrow">→</span>
        </a>
    </div>
</div>
<div class="cl-row">
        <div class="cl-th"><?= Lang_cl::_e('Menu Columns', 'cl') ?></div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th"><?= Lang_cl::_e('Container style', 'cl') ?></div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getAllCss('main_footer_menus_container_style');
                        ?>
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th"><?= Lang_cl::_e('Number of Columns', 'cl') ?></div>
                    <div class="cl-td">
                        <select name="main_footer_menu_columns_count" blocks-to-hide=".footer-menu-column-selector">
                            <option value="1" block-to-show=".footer-menu-col-1" <?= selected($settings['main_footer_menu_columns_count'], '1', false) ?>>1</option>
                            <option value="2" block-to-show=".footer-menu-col-1, .footer-menu-col-2" <?= selected($settings['main_footer_menu_columns_count'], '2', false) ?>>2</option>
                            <option value="3" block-to-show=".footer-menu-col-1, .footer-menu-col-2, .footer-menu-col-3" <?= selected($settings['main_footer_menu_columns_count'], '3', false) ?>>3</option>
                            <option value="4" block-to-show=".footer-menu-col-1, .footer-menu-col-2, .footer-menu-col-3, .footer-menu-col-4" <?= selected($settings['main_footer_menu_columns_count'], '4', false) ?>>4</option>
                            <option value="5" block-to-show=".footer-menu-col-1, .footer-menu-col-2, .footer-menu-col-3, .footer-menu-col-4, .footer-menu-col-5" <?= selected($settings['main_footer_menu_columns_count'], '5', false) ?>>5</option>
                            <option value="6" block-to-show=".footer-menu-col-1, .footer-menu-col-2, .footer-menu-col-3, .footer-menu-col-4, .footer-menu-col-5, .footer-menu-col-6" <?= selected($settings['main_footer_menu_columns_count'], '6', false) ?>>6</option>
                        </select>
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th"><?= Lang_cl::_e('Select Menus', 'cl') ?></div>
                    <div class="cl-td">
                        <div class="form-row-flex" style="gap: 10px; align-items: flex-start;">
                            <?php
                            $selected_menu_ids = explode(',', $settings['main_footer_menu_ids']);
                            for ($i = 1; $i <= 6; $i++) {
                                $current_id = isset($selected_menu_ids[$i - 1]) ? $selected_menu_ids[$i - 1] : '';
                                ?>
                                <div class="cl-group cl-group--flex footer-menu-column-selector footer-menu-col-<?= $i ?>">
                                    <label><?= Lang_cl::_e('Menu Col ', 'cl') . $i ?></label>
                                    <select class="cl-footer-menu-selector">
                                        <option value=""><?= Lang_cl::_e('-- None --', 'cl') ?></option>
                                        <?php foreach ($wpMenus as $menu) { ?>
                                            <option value="<?= esc_attr($menu->term_id) ?>" <?= selected($current_id, $menu->term_id, false) ?>>
                                                <?= esc_html($menu->name) ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            <?php } ?>
                        </div>
                        <input type="hidden" name="main_footer_menu_ids" value="<?= esc_attr($settings['main_footer_menu_ids']) ?>">
                    </div>
                </div>
                <?php $styleManager->getSingleCss('gap', 'main_footer_menus_container_style', [
                    'title' => Lang_cl::__('Space between menus', 'cl')
                ]); ?>
                <div class="cl-row">
                    <div class="cl-th"><?= Lang_cl::_e('Menu Titles Style', 'cl') ?></div>
                    <div class="cl-td cl-style-container">
                        <?php $styleManager->getAllCss('main_footer_menu_title_style'); ?>
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th"><?= Lang_cl::_e('Menu Links Style', 'cl') ?></div>
                    <div class="cl-td cl-style-container">
                        <?php $styleManager->getAllCss('main_footer_menu_link_style'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>