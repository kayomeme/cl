<?php

return array(
    'v1' => [
        'title' => Lang_cl::__('Version 1', '')
    ],
    'v2' => [
        'title' => Lang_cl::__('Version 2', '')
    ],
);
