<?php
return array(
    'main_footer_container_style' => [
        'modal_title' => Lang_cl::__('Main Footer: Container Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main',
        'single_css_supported' => ['max-width', 'margin-top', 'margin-bottom'],
        'border' => 'yes',
        'border-radius' => 'yes',
        'background' => 'yes',
        'padding' => 'yes',
        'box-shadow' => 'yes',
    ],
    
    'main_footer_branding_col_style' => [
        'modal_title' => Lang_cl::__('Branding Column: Container Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main .footer-branding-col',
        'single_css_supported' => ['max-width'],
        'padding' => 'yes',
        'border' => 'yes',
    ],
    
    'main_footer_title_style' => [
        'modal_title' => Lang_cl::__('Branding Column: Title Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main .footer-branding-col .branding-title',
        'single_css_supported' => ['margin-top'],
        'font' => 'yes',
    ],
    
    'main_footer_logo_image_style' => [
        'modal_title' => Lang_cl::__('Branding Column: Logo Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main .footer-branding-col .branding-logo img',
        'single_css_supported' => ['max-width', 'margin-top'],
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    
    'main_footer_description_style' => [
        'modal_title' => Lang_cl::__('Branding Column: Description Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main .footer-branding-col .branding-description',
        'single_css_supported' => ['margin-top'],
        'font' => 'yes',
    ],
    
    'main_footer_contact_info_style' => [
        'modal_title' => Lang_cl::__('Branding Column: Contact Info Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main .footer-branding-col .branding-contact-info .contact-info-list',
        'single_css_supported' => ['margin-top'],
        'font' => 'yes',
    ],
    
    'main_footer_social_links_container_style' => [
        'modal_title' => Lang_cl::__('Branding Column: Social Links Container Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main .footer-branding-col .branding-social-links',
        'single_css_supported' => ['margin-top'],
        'background' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
    ],
    
    'main_footer_social_links_text_style' => [
        'modal_title' => Lang_cl::__('Branding Column: Social Links Text Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main .footer-branding-col .branding-social-links .social-links-text',
        'font' => 'yes',
    ],
    
    'main_footer_social_links_style' => [
        'modal_title' => Lang_cl::__('Branding Column: Social Links Icons Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main .footer-branding-col .branding-social-links .footer-social-links a',
        'font' => 'yes',
        'background' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
    ],
    
    'main_footer_action_button_style' => [
        'modal_title' => Lang_cl::__('Branding Column: Action Button Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main .footer-branding-col .branding-action-button a',
        'single_css_supported' => ['margin-top'],
        'font' => 'yes',
        'background' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes'
    ],

    'main_footer_menus_container_style' => [
        'modal_title' => Lang_cl::__('Menu Columns: Container Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main .footer-menus-col',
        'single_css_supported' => ['gap'],
        'padding' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'box-shadow' => 'yes',
    ],
    
    'main_footer_menu_title_style' => [
        'modal_title' => Lang_cl::__('Menu Columns: Title Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main .footer-menu-widget .widget-title',
        'font' => 'yes',
    ],
    
    'main_footer_menu_link_style' => [
        'modal_title' => Lang_cl::__('Menu Columns: Link Styling', 'cl'),
        'style_attached_to' => '.cl-footer-main .footer-menu-widget ul li a',
        'font' => 'yes',
        'padding' => 'yes',
    ],
);