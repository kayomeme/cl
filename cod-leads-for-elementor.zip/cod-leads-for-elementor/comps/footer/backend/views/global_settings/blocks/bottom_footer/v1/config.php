<?php return array (
  'setting' => 
  array (
    'bottom_footer_version' => 'v1',
    'bottom_footer_is_active' => 'yes',
    'bottom_footer_menu_id' => '',
  ),
  'lang' => 
  array (
    'bottom_footer_copyright_text' => '© @year Hashnode – LinearBytes Inc.',
  ),
  'style' => 
  array (
    'bottom_footer_container_style' => 'max-width:1280px;margin-top:0px;margin-bottom:0px;background-color:#020617;padding-top:24px;padding-right:48px;padding-bottom:24px;padding-left:48px;border-top-width:1px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-top-color:#1e293b;border-style:solid;border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;',
    'bottom_footer_copyright_style' => 'font-size:13px;color:#64748b;',
    'bottom_footer_menu_style' => 'font-size:13px;color:#94a3b8;font-weight:500;',
  ),
);