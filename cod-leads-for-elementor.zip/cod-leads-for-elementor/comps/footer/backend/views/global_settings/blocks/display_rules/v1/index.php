<?php

/**
 * Helper function to render the source selection UI.
 * The form elements here do NOT have a 'name' attribute.
 * Their values are collected by JavaScript into a single JSON object.
 */
function render_footer_source_selector_for_json($scope, $current_rule, $custom_blocks) {

    $selected_source = isset($current_rule['source']) ? $current_rule['source'] : 'plugin';
    $selected_block_id = isset($current_rule['custom_block_id']) ? $current_rule['custom_block_id'] : '';
    ?>
    <div class="cl-row">
        <div class="cl-th"><?= Lang_cl::_e('Footer Source', 'cl') ?></div>
        <div class="cl-td">
            <select data-scope="<?= $scope ?>" data-type="source" blocks-to-hide=".<?= $scope ?>-footer-source-fields">
                <option value="plugin" block-to-show=".<?= $scope ?>-footer-source-plugin" <?= selected($selected_source, 'plugin', false) ?>>
                    <?= Lang_cl::_e('Cod Leads Footer', 'cl') ?>
                </option>
                <option value="theme" block-to-show=".<?= $scope ?>-footer-source-theme" <?= selected($selected_source, 'theme', false) ?>>
                    <?= Lang_cl::_e('Theme Footer', 'cl') ?>
                </option>
                <option value="hide" block-to-show=".<?= $scope ?>-footer-source-hide" <?= selected($selected_source, 'hide', false) ?>>
                    <?= Lang_cl::_e('Hide Footer', 'cl') ?>
                </option>
                <option value="custom_block" block-to-show=".<?= $scope ?>-footer-source-custom_block" <?= selected($selected_source, 'custom_block', false) ?>>
                    <?= Lang_cl::_e('Custom Block', 'cl') ?>
                </option>
            </select>
        </div>
    </div>
    <div class="cl-row <?= $scope ?>-footer-source-fields <?= $scope ?>-footer-source-custom_block">
        <div class="cl-th"><?= Lang_cl::_e('Select Block', 'cl') ?></div>
        <div class="cl-td">
            <select data-scope="<?= $scope ?>" data-type="custom_block_id">
                <option value=""><?= Lang_cl::_e('-- Select a Custom Block --', 'cl') ?></option>
                <?php foreach ($custom_blocks as $block) { ?>
                    <option value="<?= esc_attr($block->ID) ?>" <?= selected($selected_block_id, $block->ID, false) ?>>
                        <?= esc_html($block->post_title) ?>
                    </option>
                <?php } ?>
            </select>
        </div>
    </div>
    <?php
}

$overrides = json_decode($settings['footer_overrides'], true);
if (!is_array($overrides)) {
    $overrides = array();
}
$global_rule = isset($overrides['global']) ? $overrides['global'] : array('source' => 'plugin');
?>

<div id="cl-footer-overrides-container">
    <!-- Menus Info Section -->
    <div class="cl-info-section">
        <div class="cl-info-header">
            <span class="dashicons dashicons-info"></span>
            <p>
                <?= Lang_cl::_e('Set the default global footer for your entire website. You can also enable page-specific overrides below, which will be used instead of the global rule for those pages.', 'cl') ?>
            </p>
        </div>
    </div>

    <!-- Global Display Rules -->
    <div class="cl-row">
        <div class="cl-th">
            <?= Lang_cl::_e('Global Display Rules', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="admin_toggle_block" is_open="yes">
                <div class="admin_toggle_header"><?= Lang_cl::_e('Global scope', 'cl') ?></div>
                <div class="admin_toggle_body" show_in_open>
                    <div class="cl-sub-section" data-override-scope="global">
                        <?php render_footer_source_selector_for_json('global', $global_rule, $custom_blocks); ?>
                    </div>
                </div></div>
        </div>
    </div>

    <!-- Page Specific Overrides -->
    <div class="cl-row">
        <div class="cl-th">
            <?= Lang_cl::_e('Page Specific Overrides', 'cl') ?>
        </div>
        <div class="cl-td">
            <?php
            foreach ($override_pages as $scope => $label) {
                $current_override = isset($overrides[$scope]) ? $overrides[$scope] : array();
                $is_active = isset($current_override['is_active']) && $current_override['is_active'] === 'yes';
                ?>
                <div class="admin_toggle_block" is_open="no">
                    <div class="admin_toggle_header"><?= $label ?></div>
                    <div class="admin_toggle_body" show_in_open>
                        <div class="cl-sub-section" data-override-scope="<?= $scope ?>">
                            <div class="cl-row">
                                <div class="cl-th"><?= Lang_cl::_e('Enable Override', 'cl') ?></div>
                                <div class="cl-td">
                                    <label class="cl-switch">
                                        <input type="checkbox" class="state-on-off" data-scope="<?= $scope ?>" data-type="is_active" <?= checked($is_active, true, false) ?>>
                                        <span class="cl-slider cl-round"></span>
                                    </label>
                                </div>
                            </div>
                            <?php render_footer_source_selector_for_json($scope, $current_override, $custom_blocks); ?>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
        <input type="hidden" name="footer_overrides" value="<?= esc_attr($settings['footer_overrides']) ?>">
    </div>
</div>