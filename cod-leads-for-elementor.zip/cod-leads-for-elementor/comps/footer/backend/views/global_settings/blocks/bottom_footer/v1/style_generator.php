<?php
return array(
    'bottom_footer_container_style' => [
        'modal_title' => Lang_cl::__('Bottom Footer: Container Styling', 'cl'),
        'style_attached_to' => '.cl-footer-socket',
        'single_css_supported' => ['max-width', 'margin-top', 'margin-bottom'],
        'background' => 'yes',
        'border' => 'yes',
        'padding' => 'yes',
        'border-radius' => 'yes',
    ],
    
    'bottom_footer_copyright_style' => [
        'modal_title' => Lang_cl::__('Bottom Footer: Copyright Text Styling', 'cl'),
        'style_attached_to' => '.cl-footer-socket .copyright-text',
        'font' => 'yes',
    ],
    
    'bottom_footer_menu_style' => [
        'modal_title' => Lang_cl::__('Bottom Footer: Menu Link Styling', 'cl'),
        'style_attached_to' => '.cl-footer-socket .socket-menu a',
        'font' => 'yes',
    ],
);