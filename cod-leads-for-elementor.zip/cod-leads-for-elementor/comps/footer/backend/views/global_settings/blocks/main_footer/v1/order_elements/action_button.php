<div class="cl-row" _attachedsection="action_button">
    <span class="dashicons dashicons-admin-links"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Action Button', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>