<div class="cl-row" _attachedsection="social_links">
    <span class="dashicons dashicons-share"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Social Links', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>