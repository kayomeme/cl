<!-- Sub-tab Navigation -->
<ul class="cl-sidetab-submenu" attachedButonTab="cl_main_footer_tab">
    <li tab="cl_main_footer_container">
        <span class="dashicons dashicons-align-wide"></span>
        <?= Lang_cl::_e('Container', 'cl') ?>
    </li>
    <li tab="cl_main_footer_branding">
        <span class="dashicons dashicons-lightbulb"></span>
        <?= Lang_cl::_e('Branding Column', 'cl') ?>
    </li>
    <li tab="cl_main_footer_menus">
        <span class="dashicons dashicons-menu"></span>
        <?= Lang_cl::_e('Menu Columns', 'cl') ?>
    </li>
</ul>

<!-- Sub-tab Content: Container -->
<div id="cl_main_footer_container" class="cl-subtab">
    <?php include 'container_column.php'; ?>
</div>

<!-- Sub-tab Content: Branding Column -->
<div id="cl_main_footer_branding" class="cl-subtab">
    <?php include 'branding_column.php'; ?>
    <input type="hidden" name="main_footer_branding_order" value="<?= esc_attr($settings['main_footer_branding_order']) ?>">
</div>

<!-- Sub-tab Content: Menu Columns -->
<div id="cl_main_footer_menus" class="cl-subtab">
    <?php include 'menus_column.php'; ?>
</div>