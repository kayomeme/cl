<?php
// Determine flex direction based on layout setting
$flex_direction = $settings['main_footer_layout'] === 'menus-first' ? 'row-reverse' : 'row';
$flex_direction_mobile = $settings['main_footer_layout'] === 'menus-first' ? 'column-reverse' : 'column';
?>
<style>
    .cl-footer-main {
        display: flex;
        flex-direction: <?= esc_attr($flex_direction) ?>;
        justify-content: space-between;
        align-items: start;
        margin: auto;
        gap: 48px;
        <?= $settings['main_footer_container_style'] ?>
    }

    /* Branding Column */
    .cl-footer-main .footer-branding-col {
        flex-grow: 1;
        flex-shrink: 1;
        display: flex;
        flex-direction: column; /* Ensure branding elements stack vertically */
        row-gap: 15px;
        <?= $settings['main_footer_branding_col_style'] ?>
    }
    .cl-footer-main .footer-branding-col .branding-title {
        <?= $settings['main_footer_title_style'] ?>
    }
    .cl-footer-main .footer-branding-col .branding-logo img {
        display: block;
        height: auto;
        <?= $settings['main_footer_logo_image_style'] ?>
    }
    .cl-footer-main .footer-branding-col .branding-description {
        <?= $settings['main_footer_description_style'] ?>
    }
    /* Contact Info Styles */
    .cl-footer-main .footer-branding-col .branding-contact-info .contact-info-list {
        display: flex;
        flex-direction: column;
        gap: 8px; /* Spacing between contact items */
        <?= $settings['main_footer_contact_info_style'] ?>
    }
    .cl-footer-main .footer-branding-col .branding-contact-info .contact-item a,
    .cl-footer-main .footer-branding-col .branding-contact-info .contact-item span {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        color: inherit;
    }
    /* Social Links Container */
    .cl-footer-main .footer-branding-col .branding-social-links {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 16px;
        <?= $settings['main_footer_social_links_container_style'] ?>
    }
    .cl-footer-main .footer-branding-col .branding-social-links .social-links-text {
        <?= $settings['main_footer_social_links_text_style'] ?>
    }
    .cl-footer-main .footer-branding-col .branding-social-links .footer-social-links {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 16px;
    }
    .cl-footer-main .footer-branding-col .branding-social-links .footer-social-links a {
        text-decoration: none;
        display: inline-flex;
        <?= $settings['main_footer_social_links_style'] ?>
    }
    /* Action Button Styles */
    .cl-footer-main .footer-branding-col .branding-action-button a {
        width: 100%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        text-decoration: none;
        <?= $settings['main_footer_action_button_style'] ?>
    }

    /* Menu Columns */
    .cl-footer-main .footer-menus-col {
        display: flex;
        flex-wrap: wrap;
        <?= $settings['main_footer_menus_container_style'] ?>
    }
    .cl-footer-main .footer-menu-widget {
        flex-grow: 1;
    }
    .cl-footer-main .footer-menu-widget .widget-title {
        display: block;
        <?= $settings['main_footer_menu_title_style'] ?>
    }
    .cl-footer-main .footer-menu-widget ul {
        margin: 0;
        padding: 0;
        list-style: none;
        display: grid;
        gap: 12px;
    }
    .cl-footer-main .footer-menu-widget ul li a {
        text-decoration: none;
        <?= $settings['main_footer_menu_link_style'] ?>
    }

    /* Mobile Responsive Styles */
    @media (max-width: 768px) {
        .cl-footer-main {
            flex-direction: <?= esc_attr($flex_direction_mobile) ?>;
        }
        .cl-footer-main .footer-branding-col {
            max-width: 100% !important;
        }
        .cl-footer-main .footer-menus-col {
            flex-wrap: wrap;
            justify-content: space-between;
        }
    }
</style>