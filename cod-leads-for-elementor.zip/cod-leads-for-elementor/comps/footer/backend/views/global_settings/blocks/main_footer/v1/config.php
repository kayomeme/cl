<?php return array (
  'setting' => 
  array (
    'main_footer_version' => 'v1',
    'main_footer_is_active' => 'yes',
    'main_footer_layout' => 'branding-first',
    'main_footer_branding_order' => 'title,logo,description,social_links,action_button',

    // Branding Column Settings
    'main_footer_branding_is_active' => 'yes',
    'main_footer_logo_image_id' => '',
    'main_footer_logo_image_url' => '',
    'main_footer_description_is_active' => 'yes',
    'main_footer_contact_info_is_active' => 'no',
    'main_footer_social_links_is_active' => 'yes',
    
    // Action Button Settings
    'main_footer_action_button_is_active' => 'no',
    'main_footer_action_button_url' => '#',
    'main_footer_action_button_icon_id' => '',

    // Menu Column Settings
    'main_footer_menu_columns_count' => '5',
    'main_footer_menu_ids' => '', 
  ),
  'lang' => 
  array (
    'main_footer_title_text' => '',
    'main_footer_description_text' => 'Hassle-free blogging platform that developers and teams love.',
    'main_footer_action_button_text' => 'Talk to an Expert',
    'main_footer_social_links_text' => '',
  ),
  'style' => 
  array (
    // Container
    'main_footer_container_style' => 'max-width:1280px;margin-top:0px;margin-bottom:0px;margin-left:auto;margin-right:auto;background-color:#0f172a;padding-top:64px;padding-right:48px;padding-bottom:48px;padding-left:48px;border-top-width:1px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-top-color:#1e293b;border-style:solid;border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;box-shadow:none;',
    
    // Branding Column
    'main_footer_branding_col_style' => 'max-width:360px;',
    'main_footer_title_style' => 'margin-top:0px;font-size:20px;color:#f8fafc;font-weight:700;',
    'main_footer_logo_image_style' => 'max-width:160px;margin-top:0px;',
    'main_footer_description_style' => 'margin-top:16px;font-size:14px;color:#94a3b8;',
    'main_footer_contact_info_style' => 'margin-top:24px;font-size:14px;color:#cbd5e1;',
    'main_footer_social_links_container_style' => 'margin-top:32px;',
    'main_footer_social_links_text_style' => 'font-size:13px;color:#cbd5e1;font-weight:600;',
    'main_footer_social_links_style' => 'font-size:18px;color:#cbd5e1;border-width:1px;border-color:#334155;border-style:solid;border-radius:8px;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;background-color:#1e293b;',
    'main_footer_action_button_style' => 'margin-top:24px;font-size:14px;color:#ffffff;font-weight:600;border-width:1px;border-color:#6366f1;border-style:solid;border-radius:8px;padding-top:12px;padding-right:24px;padding-bottom:12px;padding-left:24px;background-color:#6366f1;',

    // Menu Columns
    'main_footer_menus_container_style' => 'gap:64px;',
    'main_footer_menu_title_style' => 'font-size:14px;color:#f1f5f9;font-weight:700;',
    'main_footer_menu_link_style' => 'font-size:14px;color:#94a3b8;padding-top:6px;padding-right:0px;padding-bottom:6px;padding-left:0px;',
  ),
);