    <div class="cl-row">
        <div class="cl-th">
            <?= Lang_cl::_e('Branding Column Container', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th"><?= Lang_cl::_e('Is Active', 'cl') ?></div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getSwitchButton(['name' => 'main_footer_branding_is_active', 'value' => $settings['main_footer_branding_is_active']]);
                        $styleManager->getAllCss('main_footer_branding_col_style');
                        ?>
                    </div>
                </div>
                <?php $styleManager->getSingleCss('max-width', 'main_footer_branding_col_style'); ?>
            </div>
        </div>
    </div>

    <div class="cl-row">
        <div class="cl-th">
            <label><?= Lang_cl::_e('Elements Order', 'cl') ?></label>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div id="cl-branding-elements">
                    <?php 
                    foreach ($brandingElementsOrder as $elementName) {
                        $element_path = __DIR__ . '/order_elements/' . $elementName . '.php';
                        if (file_exists($element_path)) {
                            include $element_path;
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
            <div class="cl-alert cl-alert-info">
                <?= Lang_cl::_e('Drag and drop to reorder.', 'cl') ?>
            </div>
    </div>

    <!-- Title Settings Toggle -->
    <div class="admin_toggle_block" is_open="no">
        <div class="admin_toggle_header"><?= Lang_cl::_e('Title', 'cl') ?></div>
        <div class="admin_toggle_body" show_in_open>
            <div class="cl-row">
                <div class="cl-td-full">
                    <div class="cl-sub-section">
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Text', 'cl') ?></div>
                            <div class="cl-td cl-style-container">
                                <input type="text" name="main_footer_title_text" value="<?= esc_attr($settings['main_footer_title_text']) ?>">
                                <?php $styleManager->getAllCss('main_footer_title_style'); ?>
                            </div>
                        </div>
                        <?php $styleManager->getSingleCss('margin-top', 'main_footer_title_style'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Logo Settings Toggle -->
    <div class="admin_toggle_block" is_open="no">
        <div class="admin_toggle_header"><?= Lang_cl::_e('Logo Image', 'cl') ?></div>
        <div class="admin_toggle_body" show_in_open>
            <div class="cl-row">
                <div class="cl-td-full">
                    <div class="cl-sub-section">
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Image', 'cl') ?></div>
                            <div class="cl-td cl-style-container">
                                <button type="button" class="cl-image-selector">
                                    <img src="<?= esc_url($settings['main_footer_logo_image_url']) ?>" alt="<?= Lang_cl::_e('Select image', 'cl') ?>" />
                                    <input type="hidden" class="cl_img_id" name="main_footer_logo_image_id" value="<?= esc_attr($settings['main_footer_logo_image_id']) ?>" />
                                    <input type="hidden" class="cl_img_url" name="main_footer_logo_image_url" value="<?= esc_url($settings['main_footer_logo_image_url']) ?>" />
                                </button>
                                <?php $styleManager->getAllCss('main_footer_logo_image_style'); ?>
                            </div>
                        </div>
                        <?php $styleManager->getSingleCss('margin-top', 'main_footer_logo_image_style'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Description Settings Toggle -->
    <div class="admin_toggle_block" is_open="no">
        <div class="admin_toggle_header"><?= Lang_cl::_e('Description', 'cl') ?></div>
        <div class="admin_toggle_body" show_in_open>
            <div class="cl-row">
                <div class="cl-td-full">
                    <div class="cl-sub-section">
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Is Active', 'cl') ?></div>
                            <div class="cl-td cl-style-container">
                                <?php
                                $styleManager->getSwitchButton(['name' => 'main_footer_description_is_active', 'value' => $settings['main_footer_description_is_active'], 'class' => 'state-on-off']);
                                $styleManager->getAllCss('main_footer_description_style');
                                ?>
                            </div>
                        </div>
                        <?php $styleManager->getSingleCss('margin-top', 'main_footer_description_style'); ?>
                        <div class="cl-row">
                            <div class="cl-td-full">
                                <textarea name="main_footer_description_text" rows="4"><?= esc_textarea($settings['main_footer_description_text']) ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Contact Info Settings Toggle -->
    <div class="admin_toggle_block" is_open="no">
        <div class="admin_toggle_header"><?= Lang_cl::_e('Contact Info', 'cl') ?></div>
        <div class="admin_toggle_body" show_in_open>
            <div class="cl-row">
                <div class="cl-td-full">
                    <div class="cl-sub-section">
                        <div class="cl-alert cl-alert-info">
                            <?= Lang_cl::_e('This controls the display and styling in the footer. To edit the contact details, please go to the global settings.', 'cl') ?>
                            <a href="<?= esc_url(admin_url('admin.php?page=cl_global_settings&compo=mystore&tab=cl_contact_info_tab')) ?>" target="_blank" style="text-decoration: underline;">
                                <?= Lang_cl::_e('Manage Contact Info', 'cl') ?>
                            </a>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Is Active', 'cl') ?></div>
                            <div class="cl-td cl-style-container">
                                <?php
                                $styleManager->getSwitchButton(['name' => 'main_footer_contact_info_is_active', 'value' => $settings['main_footer_contact_info_is_active'], 'class' => 'state-on-off']);
                                $styleManager->getAllCss('main_footer_contact_info_style');
                                ?>
                            </div>
                        </div>
                        <?php $styleManager->getSingleCss('margin-top', 'main_footer_contact_info_style'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Social Links Settings Toggle -->
    <div class="admin_toggle_block" is_open="no">
        <div class="admin_toggle_header"><?= Lang_cl::_e('Social Links', 'cl') ?></div>
        <div class="admin_toggle_body" show_in_open>
            <div class="cl-row">
                <div class="cl-td-full">
                    <div class="cl-sub-section">
                        <div class="cl-alert cl-alert-info">
                            <?= Lang_cl::_e('This controls the display and styling in the footer. To edit the links themselves, please go to the global settings.', 'cl') ?>
                            <a href="<?= esc_url(admin_url('admin.php?page=cl_global_settings&compo=mystore&tab=cl_social_links_tab')) ?>" target="_blank" style="text-decoration: underline;">
                                <?= Lang_cl::_e('Manage Social Links', 'cl') ?>
                            </a>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Is Active', 'cl') ?></div>
                            <div class="cl-td cl-style-container">
                                <?php
                                $styleManager->getSwitchButton(['name' => 'main_footer_social_links_is_active', 'value' => $settings['main_footer_social_links_is_active'], 'class' => 'state-on-off']);
                                $styleManager->getAllCss('main_footer_social_links_container_style');
                                ?>
                            </div>
                        </div>
                        <?php $styleManager->getSingleCss('margin-top', 'main_footer_social_links_container_style'); ?>
                         <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Text', 'cl') ?></div>
                            <div class="cl-td cl-style-container">
                                <input type="text" name="main_footer_social_links_text" value="<?= esc_attr($settings['main_footer_social_links_text']) ?>">
                                <?php $styleManager->getAllCss('main_footer_social_links_text_style'); ?>
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Icons Style', 'cl') ?></div>
                            <div class="cl-td cl-style-container">
                                <?php $styleManager->getAllCss('main_footer_social_links_style'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Action Button Settings Toggle -->
    <div class="admin_toggle_block" is_open="no">
        <div class="admin_toggle_header"><?= Lang_cl::_e('Action Button', 'cl') ?></div>
        <div class="admin_toggle_body" show_in_open>
            <div class="cl-row">
                <div class="cl-td-full">
                    <div class="cl-sub-section">
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Is Active', 'cl') ?></div>
                            <div class="cl-td cl-style-container">
                                <?php
                                $styleManager->getSwitchButton(['name' => 'main_footer_action_button_is_active', 'value' => $settings['main_footer_action_button_is_active'], 'class' => 'state-on-off']);
                                $styleManager->getAllCss('main_footer_action_button_style');
                                ?>
                            </div>
                        </div>
                        <?php $styleManager->getSingleCss('margin-top', 'main_footer_action_button_style'); ?>
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Button Text', 'cl') ?></div>
                            <div class="cl-td">
                                <input type="text" name="main_footer_action_button_text" value="<?= esc_attr($settings['main_footer_action_button_text']) ?>">
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Button URL', 'cl') ?></div>
                            <div class="cl-td">
                                <input type="text" name="main_footer_action_button_url" value="<?= esc_attr($settings['main_footer_action_button_url']) ?>">
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Button Icon', 'cl') ?></div>
                            <div class="cl-td">
                                <?php IconsSelectorBK_cl::getButton(['name' => 'main_footer_action_button_icon_id', 'value' => $settings['main_footer_action_button_icon_id']]); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>