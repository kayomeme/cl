<div id="cl_general_tab" class="cl-single-tab">
    <?php //include 'blocks/general/v1/index.php'; ?>
</div> 

<div id="cl_header_tab" class="cl-single-tab">
    <?php include 'blocks/header/v1/index.php'; ?>
</div> 

<div id="cl_plist_tab" class="cl-single-tab">
    <?php include 'blocks/plist/v1/index.php'; ?>
</div> 

<div id="cl_custom_blocks_tab" class="cl-single-tab">
    <?php include 'custom_blocks.php'; ?>
</div>

<div id="cl_category_blocks_order_tab" class="cl-single-tab">
    <?php include 'blocks_order.php'; ?>
</div>

<div style="display: none !important">
<input type="text" name="header_version" value="<?= $settings['header_version'] ?>">    
<input type="text" name="plist_version" value="<?= $settings['plist_version'] ?>">
<input type="text" name="custom_block1_version" value="<?= $settings['custom_block1_version'] ?>">
<input type="text" name="custom_block2_version" value="<?= $settings['custom_block2_version'] ?>">
</div>