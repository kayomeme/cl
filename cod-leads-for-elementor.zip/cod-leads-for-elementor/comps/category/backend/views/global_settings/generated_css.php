
<?php 
//if ($settings['cart_empty_is_active'] == 'yes') {}
include 'blocks/general/v1/generated_css.php';
include 'blocks/header/v1/generated_css.php';
include 'blocks/plist/v1/generated_css.php';
include 'blocks/custom_block1/v1/generated_css.php';
include 'blocks/custom_block2/v1/generated_css.php';