<div class="cl-row" _attachedsection="custom_block1">
    <span class="dashicons dashicons-yes"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Custom block1', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>