<div class="cl-row" _attachedsection="custom_block2">
    <span class="dashicons dashicons-yes"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Custom block2', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>