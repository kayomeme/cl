<div class="cl-row" _attachedsection="header">
    <span class="dashicons dashicons-list-view"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Header', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>