<!--<button tab="cl_general_tab">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_cl::_e('General', 'cl') ?>
</button>-->

<button tab="cl_header_tab" _section="cl_header" class="<?= $settings['header_is_active'] == 'yes' ? 'is-active-block' : 'is-disabled-block' ?>">
    <span class="dashicons dashicons-heading"></span>
    <?= Lang_cl::_e('Category header', 'cl') ?>
</button>

<button tab="cl_plist_tab" class="is-active-block">
    <span class="dashicons dashicons-grid-view"></span>
    <?= Lang_cl::_e('Products listing', 'cl') ?>
</button>

<button tab="cl_custom_blocks_tab" _section="cl_custom_block1"
        class="<?= $settings['custom_block1_is_active'] == 'yes' ? 'is-active-block' : 'is-disabled-block' ?>">
    <span class="dashicons dashicons-block-default"></span>
    <?= Lang_cl::_e('Custom Blocks', 'cl') ?>
</button>

<button tab="cl_category_blocks_order_tab" _section="cl_category_blocks_order">
    <span class="dashicons dashicons-sort"></span>
    <?= Lang_cl::_e('Category Blocks Order', 'cl') ?>
</button>