<?php return array (
  'setting' => 
  array (
    'header_version' => 'v1',
    'header_is_active' => 'yes',
    'title_is_active' => 'yes',
    'image_is_active' => 'yes',
    'description_is_active' => 'yes',
    'product_count_is_active' => 'yes',
    'image_max_width' => '150px',
  ),
  'lang' => 
  array (
  ),
  'style' => 
  array (
    'header_container_style' => 'margin-bottom:24px;border-radius:12px;padding:24px;background-color:#f9fafb;margin-top:10px;',
    'header_container_layout_style' => 'flex-direction:row;align-items:center;justify-content:flex-start;gap:24px;',
    'title_style' => 'margin-bottom:8px;font-size:28px;font-weight:700;color:#111827;text-align:left;',
    'image_style' => 'max-width:150px;border-radius:12px;box-shadow:0 8px 15px -3px rgb(0 0 0 / 0.1);',
    'description_container_style' => 'color:#4b5563;font-size:14px;margin-top:8px;',
    'product_count_container_style' => 'margin-top:16px;font-size:14px;font-weight:600;color:#475569;text-align:left;border-left-width:3px;border-color:#3b82f6;border-style:solid;background-color:#eff6ff;padding:8px 12px;',
  ),
);