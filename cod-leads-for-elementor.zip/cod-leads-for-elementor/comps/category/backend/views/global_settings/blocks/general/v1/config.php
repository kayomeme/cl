<?php return array (
  'setting' => 
  array (
    'general_version' => 'v1',
  ),
  'lang' => 
  array (
  ),
  'style' => 
  array (

  ),
);