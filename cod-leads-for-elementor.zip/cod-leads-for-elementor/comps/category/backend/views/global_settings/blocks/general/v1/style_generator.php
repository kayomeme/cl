<?php
return array(
    /*'category_container_override_style' => [
        'modal_title' => Lang_cl::__('Category Container Override Style', 'cl'),
        'style_attached_to' => '.archive.category .cl-products-container',
        'width' => 'yes',
        'margin' => 'yes',
        'padding' => 'yes',
    ],*/
);