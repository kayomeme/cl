<?php
return array(
    'header_container_style' => [
        'modal_title' => Lang_cl::__('Header Container style', 'cl'),
        'style_attached_to' => '.is_category_block .cat-header-flex',
        'single_css_supported' => ['margin-top'],
        'border' => 'yes',
        'border-radius' => 'yes', 
        'background' => 'yes',
        'padding' => 'yes',
        'box-shadow' => 'yes'
    ],
    'header_container_layout_style' => [
        'modal_title' => Lang_cl::__('Header Container style', 'cl'),
        'style_attached_to' => '.is_category_block .cat-header-flex',
        'flex-layout' => [
            'title' => Lang_cl::__('Elements Layout', 'cl'),
            'options' => [
                'flex-direction' => [
                    'title' => Lang_cl::__('Direction', 'cl'),
                    'items' => [
                        'row' => Lang_cl::__('Row', 'cl'),
                        'row-reverse' => Lang_cl::__('Row Reverse', 'cl'),
                        'column' => Lang_cl::__('Column', 'cl'),
                        'column-reverse' => Lang_cl::__('Column Reverse', 'cl')
                    ]
                ],
                'align-items' => [
                    'title' => Lang_cl::__('Vertical alignment', 'cl'),
                    'items' => [
                        'flex-start' => Lang_cl::__('Start', 'cl'),
                        'center' => Lang_cl::__('Center', 'cl'),
                        'flex-end' => Lang_cl::__('End', 'cl'),
                        'stretch' => Lang_cl::__('Stretch', 'cl'),
                        'baseline' => Lang_cl::__('Baseline', 'cl')
                    ]
                ],
                'justify-content' => [
                    'title' => Lang_cl::__('Horizontal alignment', 'cl'),
                    'items' => [
                        'flex-start' => Lang_cl::__('Start', 'cl'),
                        'center' => Lang_cl::__('Center', 'cl'),
                        'flex-end' => Lang_cl::__('End', 'cl'),
                        'space-between' => Lang_cl::__('Space Between', 'cl'),
                        'space-around' => Lang_cl::__('Space Around', 'cl'),
                        'space-evenly' => Lang_cl::__('Space Evenly', 'cl')
                    ]
                ],
                'gap' => [
                    'title' => Lang_cl::__('Space between buttons', 'cl'),
                ]
            ]
        ]
    ],
    'title_style' => [
        'modal_title' => Lang_cl::__('Category title Container style', 'cl'),
        'style_attached_to' => '.is_category_block .cat-title',
        'single_css_supported' => ['margin-top'],
        'font-with-align' => 'yes'
    ],
    'image_style' => [
        'modal_title' => Lang_cl::__('Category image Container style', 'cl'),
        'style_attached_to' => '.is_category_block .cat-image',
        'single_css_supported' => ['max-width'],
        'border' => 'yes',
        'border-radius' => 'yes', 
        'box-shadow' => 'yes',
    ],
    'description_container_style' => [
        'modal_title' => Lang_cl::__('Category description Container style', 'cl'),
        'style_attached_to' => '.is_category_block .cat-description',
        'single_css_supported' => ['margin-top'],
        'border' => 'yes',
        'border-radius' => 'yes', 
        'background' => 'yes',
        'padding' => 'yes',
        'box-shadow' => 'yes',
        'margin' => 'yes',
    ],
    'product_count_container_style' => [
        'modal_title' => Lang_cl::__('Category product count Container style', 'cl'),
        'style_attached_to' => '.is_category_block .cat-product-count',
        'single_css_supported' => ['margin-top', 'max-width'],
        'font-with-align' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes', 
        'background' => 'yes',
        'padding' => 'yes',
        'box-shadow' => 'yes',
    ],
);