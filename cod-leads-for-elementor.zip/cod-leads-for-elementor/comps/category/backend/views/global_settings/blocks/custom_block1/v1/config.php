<?php return array (
  'setting' => 
  array (
    'custom_block1_is_active' => 'no',
    'custom_block1_version' => 'v1',
  ),
  'lang' => 
  array (
    'custom_block1_content' => '',
  ),
  'style' => 
  array (
    'custom_block1_container_style' => '',
  ),
);