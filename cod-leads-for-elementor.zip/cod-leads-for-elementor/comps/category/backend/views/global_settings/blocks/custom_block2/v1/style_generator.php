<?php
return array(
    'custom_block2_container_style' => [
        'modal_title' => Lang_cl::__('Custom block 2 Container style', 'cl'),
        'style_attached_to' => '#cl_custom_block2',
        'single_css_supported' => ['margin-top'],
        'border' => 'yes',
        'border-radius' => 'yes', 
        'linear-gradient' => 'yes',
        'padding' => 'yes',
        'box-shadow' => 'yes',
    ],
);