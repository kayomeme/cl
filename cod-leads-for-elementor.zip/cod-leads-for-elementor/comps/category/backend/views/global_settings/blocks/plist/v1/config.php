<?php return array (
  'setting' => 
  array (
    'plist_version' => 'v1',
    'plist_model' => 'plist1',
    'product_box_layout' => 'inherit',
    'desktop_columns' => 'inherit',
    'mobile_columns' => 'inherit',
    'posts_per_page' => 'inherit',
    'pagination_type' => 'inherit',
  ),
  'lang' => 
  array (
  ),
  'style' => 
  array (
  ),
);