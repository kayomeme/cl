<style>
    /* 
    * Category override styles - only applied on category pages 
    * Note : don't remove the media for both desktop and mobile for inherit settings
    */

    <?php if (isset($settings['desktop_columns']) && $settings['desktop_columns'] !== 'inherit') { ?>
    @media (min-width: 768px) {
        .archive .<?= $settings['plist_model'] ?> .cl_list {
            grid-template-columns: <?php 
                if ($settings['desktop_columns'] === 'auto') {
                    echo 'repeat(auto-fill, minmax(220px, 1fr))';
                } else {
                    echo 'repeat(' . $settings['desktop_columns'] . ', 1fr)';
                }
            ?>;
        }
    }
    <?php } ?>

    <?php if (isset($settings['mobile_columns']) && $settings['mobile_columns'] !== 'inherit') { ?>

    @media (max-width: 767px) {
        .archive .<?= $settings['plist_model'] ?> .cl_list {
            grid-template-columns: <?= 'repeat(' . $settings['mobile_columns'] . ', 1fr)'?>;
        }
    }
    <?php } ?>
</style>