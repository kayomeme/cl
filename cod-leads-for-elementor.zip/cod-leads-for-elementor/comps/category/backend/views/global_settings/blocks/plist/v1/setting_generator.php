<?php

return array(
    'plist_model' => [
        'title' => Lang_cl::__('Product Listing Model', 'cl'),
        'type'  => 'select',
        'options' => [
            'plist1' => Lang_cl::__('Plist1', 'cl'),
            'plist2' => Lang_cl::__('Plist2', 'cl')
        ]
    ],
    'product_box_layout' => [
        'title' => Lang_cl::__('Product Box Layout', 'cl'),
        'type'  => 'select',
        'options' => [
            'vertical' => Lang_cl::__('Vertical', 'cl'),
            'horizontal' => Lang_cl::__('Horizontal', 'cl')
        ]
    ],
    'desktop_columns' => [
        'title' => Lang_cl::__('Desktop Columns', 'cl'),
        'type'  => 'select',
        'options' => [
            '1' => '1 ' . Lang_cl::__('column', 'cl'),
            '2' => '2 ' . Lang_cl::__('columns', 'cl'),
            '3' => '3 ' . Lang_cl::__('columns', 'cl'),
            '4' => '4 ' . Lang_cl::__('columns', 'cl'),
            '5' => '5 ' . Lang_cl::__('columns', 'cl')
        ]
    ],
    'mobile_columns' => [
        'title' => Lang_cl::__('Mobile Columns', 'cl'),
        'type'  => 'select',
        'options' => [
            '1' => '1 ' . Lang_cl::__('column', 'cl'),
            '2' => '2 ' . Lang_cl::__('columns', 'cl')
        ]
    ],
    'posts_per_page' => [
        'title' => Lang_cl::__('Products per Page', 'cl'),
        'type'  => 'number',
        'default-value' => 9
    ],
    'pagination_type' => [
        'title' => Lang_cl::__('Pagination Type', 'cl'),
        'type'  => 'select',
        'options' => [
            'load_more_button' => Lang_cl::__('Load More Button', 'cl'),
            'pagination_number' => Lang_cl::__('Number Pagination', 'cl'),
            'infinite_scroll' => Lang_cl::__('Infinite Scroll', 'cl'),
            'none' => Lang_cl::__('Hidden (No Navigation)', 'cl')
        ],
        'description' => Lang_cl::__('Choose how users navigate through products: Load More Button, Number Pagination, Infinite Scroll, or Hidden', 'cl')
    ]
    
);