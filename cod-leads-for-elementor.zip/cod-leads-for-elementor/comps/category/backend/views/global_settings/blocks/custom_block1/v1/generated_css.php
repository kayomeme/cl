<style>
    <?php if( $settings['custom_block1_is_active'] == 'yes' ) { ?>
        .archive #cl_custom_block1 {
            width: 100%;
            <?= $settings['custom_block1_container_style'] ?>
        }
    <?php } ?>
</style>