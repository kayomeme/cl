<?php return array (
  'setting' => 
  array (
    'custom_block2_is_active' => 'no',
    'custom_block2_version' => 'v1',
  ),
  'lang' => 
  array (
    'custom_block2_content' => '',
  ),
  'style' => 
  array (
    'custom_block2_container_style' => '',
  ),
);