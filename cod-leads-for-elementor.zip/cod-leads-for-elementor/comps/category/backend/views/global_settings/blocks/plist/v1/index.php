<!-- Category Override Info Section -->
<div class="cl-info-section">
    <div class="cl-info-header">
        <span class="dashicons dashicons-info"></span>
        <p><?= Lang_cl::_e('These settings override the products listing settings only on category pages. To modify the base product listing settings, use the link below:', 'cl') ?></p>
    </div>
    <div class="cl-info-links">
        <a href="admin.php?page=cl_global_settings&compo=<?= $settings['plist_model'] ?>&settings_model_id=<?= $settingsModelId ?>" target="_blank">
            <span><?= Lang_cl::_e('Product Listing Settings', 'cl') ?></span>
            <span class="arrow">→</span>
        </a>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Category Override Settings', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <?php
            $settingManager->getInherit('plist_model');
            $settingManager->getInherit('product_box_layout');
            $settingManager->getInherit('desktop_columns');
            $settingManager->getInherit('mobile_columns');
            $settingManager->getInherit('posts_per_page');
            $settingManager->getInherit('pagination_type');
            
            ?>
        </div>
    </div>
</div>