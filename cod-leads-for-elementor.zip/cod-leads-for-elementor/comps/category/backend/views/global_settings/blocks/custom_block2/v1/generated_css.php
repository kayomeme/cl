<style>
    <?php if( $settings['custom_block2_is_active'] == 'yes' ) { ?>
        .archive #cl_custom_block2 {
            width: 100%;
            <?= $settings['custom_block2_container_style'] ?>
        }
    <?php } ?>
</style>