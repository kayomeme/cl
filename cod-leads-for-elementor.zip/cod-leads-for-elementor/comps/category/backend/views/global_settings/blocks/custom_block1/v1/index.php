<div id="cl_custom_block1_tab" class="cl-subtab">
    <div class="cl-row ">
        <div class="cl-th">
            <?= Lang_cl::_e('Custom block 1', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Is active', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getSwitchButton([
                            'name' => 'custom_block1_is_active',
                            'value' => $settings['custom_block1_is_active']
                        ]);
                        $styleManager->getAllCss('custom_block1_container_style');
                        ?>
                    </div>
                </div>
                <?php $styleManager->getSingleCss('margin-top', 'custom_block1_container_style'); ?>
                <div class="cl-row">
                    <div class="cl-td-full">
                        <textarea name="custom_block1_content" rows="2"><?= $settings['custom_block1_content'] ?></textarea>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>