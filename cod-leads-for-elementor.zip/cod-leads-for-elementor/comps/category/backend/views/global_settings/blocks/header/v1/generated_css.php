<style>
    /* Flex layout for header */
    .is_category_block .cat-header-flex {
        display: flex;
        <?= $settings['header_container_layout_style'] ?>
        <?= $settings['header_container_style'] ?>
    }

    /* Info container */
    .is_category_block .cat-info-container {
        flex-grow: 1;
    }

    <?php if ($settings['title_is_active'] == 'yes') { ?>
    .is_category_block h1.cat-title {
        margin: 0;
        <?= $settings['title_style'] ?>
    }
    <?php } ?>

    <?php if ($settings['image_is_active'] == 'yes') { ?>
    .is_category_block .cat-image img {
        min-width: 20px;
        <?= $settings['image_style'] ?>
    }
    <?php } ?>

    <?php if ($settings['description_is_active'] == 'yes') { ?>
    .is_category_block .cat-description {
        <?= $settings['description_container_style'] ?>
    }
    <?php } ?>

    <?php if ($settings['product_count_is_active'] == 'yes') { ?>
    .is_category_block .cat-product-count {
        <?= $settings['product_count_container_style'] ?>
    }
    <?php } ?>

    /* Responsive behavior */
    @media (max-width: 768px) {
        .is_category_block .cat-header-flex {
            flex-wrap: wrap;
        }
    }
</style>