<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Category Header infos', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'header_is_active',
                        'value' => $settings['header_is_active']
                    ]);
                    $styleManager->getAllCss('header_container_style'); 
                    ?>
                </div>
            </div>
            <?php $styleManager->getSingleCss('margin-top', 'header_container_style'); ?>
            <?php $styleManager->getFlexLayout('header_container_layout_style'); ?>
        </div>
    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Category title', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'title_is_active',
                        'value' => $settings['title_is_active']
                    ]);
                    $styleManager->getAllCss('title_style'); 
                    ?>
                </div>
            </div>
            <?php $styleManager->getSingleCss('margin-top', 'title_style'); ?>
        </div>
    </div>
</div>


<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Category image', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'image_is_active',
                        'value' => $settings['image_is_active']
                    ]);
                    $styleManager->getAllCss('image_style'); 
                    ?>
                </div>
            </div>
            <?php $styleManager->getSingleCss('max-width', 'image_style'); ?>
        </div>
    </div>
</div>


<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Description container', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'description_is_active',
                        'value' => $settings['description_is_active']
                    ]);
                    $styleManager->getAllCss('description_container_style'); 
                    ?>
                </div>
            </div>
            <?php $styleManager->getSingleCss('margin-top', 'description_container_style'); ?>
        </div>
    </div>
</div>


<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Product count', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'product_count_is_active',
                        'value' => $settings['product_count_is_active']
                    ]);
                    $styleManager->getAllCss('product_count_container_style'); 
                    ?>
                </div>
            </div>
            <?php $styleManager->getSingleCss('margin-top', 'product_count_container_style'); ?>
            <?php $styleManager->getSingleCss('max-width', 'product_count_container_style'); ?>
        </div>
    </div>
</div>
