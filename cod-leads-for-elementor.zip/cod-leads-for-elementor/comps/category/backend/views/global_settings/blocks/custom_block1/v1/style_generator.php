<?php
return array(
    'custom_block1_container_style' => [
        'modal_title' => Lang_cl::__('Custom block 1 Container style', 'cl'),
        'style_attached_to' => '.cl-checkout-sections #cl_custom_block1',
        'border' => 'yes',
        'border-radius' => 'yes',
        'linear-gradient' => 'yes',
        'padding' => 'yes',
        'box-shadow' => 'yes',
    ],
);