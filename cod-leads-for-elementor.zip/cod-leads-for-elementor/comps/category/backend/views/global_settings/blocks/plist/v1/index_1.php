<!-- Category Override Info Section -->
<div class="cl-info-section">
    <div class="cl-info-header">
        <span class="dashicons dashicons-info"></span>
        <p><?= Lang_cl::_e('These settings override the products listing settings only on category pages. To modify the base product listing settings, use the link below:', 'cl') ?></p>
    </div>
    <div class="cl-info-links">
    <a href="admin.php?page=cl_global_settings&compo=<?= $settings['plist_model'] ?>&settings_model_id=<?= $settingsModelId ?>" target="_blank">
        <span><?= Lang_cl::_e('Product Listing Settings', 'cl') ?></span>
        <span class="arrow">→</span>
    </a>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Category Override Settings', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Product Listing Model', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select name="plist_model" cl-ischanged="yes">
                        <option value="inherit" <?= $settings['plist_model'] === 'inherit' ? 'selected' : '' ?>><?= Lang_cl::_e('Inherit', 'cl') ?></option>
                        <option value="plist1" <?= $settings['plist_model'] === 'plist1' ? 'selected' : '' ?>><?= Lang_cl::_e('Plist1', 'cl') ?></option>
                        <option value="plist2" <?= $settings['plist_model'] === 'plist2' ? 'selected' : '' ?>><?= Lang_cl::_e('Plist2', 'cl') ?></option>
                    </select>
                </div>
            </div>
            
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Product Box Layout', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select name="product_box_layout" cl-ischanged="yes">
                        <option value="inherit" <?= $settings['product_box_layout'] === 'inherit' ? 'selected' : '' ?>><?= Lang_cl::_e('Inherit', 'cl') ?></option>
                        <option value="vertical" <?= $settings['product_box_layout'] === 'vertical' ? 'selected' : '' ?>><?= Lang_cl::_e('Vertical', 'cl') ?></option>
                        <option value="horizontal" <?= $settings['product_box_layout'] === 'horizontal' ? 'selected' : '' ?>><?= Lang_cl::_e('Horizontal', 'cl') ?></option>
                    </select>
                </div>
            </div>
            
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Desktop Columns', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select name="desktop_columns" cl-ischanged="yes">
                        <option value="inherit" <?= $settings['desktop_columns'] === 'inherit' ? 'selected' : '' ?>><?= Lang_cl::_e('Inherit', 'cl') ?></option>
                        <option value="1" <?= $settings['desktop_columns'] === '1' ? 'selected' : '' ?>>1 <?= Lang_cl::_e('column', 'cl') ?></option>
                        <option value="2" <?= $settings['desktop_columns'] === '2' ? 'selected' : '' ?>>2 <?= Lang_cl::_e('columns', 'cl') ?></option>
                        <option value="3" <?= $settings['desktop_columns'] === '3' ? 'selected' : '' ?>>3 <?= Lang_cl::_e('columns', 'cl') ?></option>
                        <option value="4" <?= $settings['desktop_columns'] === '4' ? 'selected' : '' ?>>4 <?= Lang_cl::_e('columns', 'cl') ?></option>
                        <option value="5" <?= $settings['desktop_columns'] === '5' ? 'selected' : '' ?>>5 <?= Lang_cl::_e('columns', 'cl') ?></option>
                    </select>
                </div>
            </div>
            
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Mobile Columns', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select name="mobile_columns" cl-ischanged="yes">
                        <option value="inherit" <?= $settings['mobile_columns'] === 'inherit' ? 'selected' : '' ?>><?= Lang_cl::_e('Inherit', 'cl') ?></option>
                        <option value="1" <?= $settings['mobile_columns'] === '1' ? 'selected' : '' ?>>1 <?= Lang_cl::_e('column', 'cl') ?></option>
                        <option value="2" <?= $settings['mobile_columns'] === '2' ? 'selected' : '' ?>>2 <?= Lang_cl::_e('columns', 'cl') ?></option>
                    </select>
                </div>
            </div>
            
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Products per Page', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select name="posts_per_page" cl-ischanged="yes">
                        <option value="inherit" <?= $settings['posts_per_page'] === 'inherit' ? 'selected' : '' ?>><?= Lang_cl::_e('Inherit', 'cl') ?></option>
                        <option value="2" <?= $settings['posts_per_page'] === '2' ? 'selected' : '' ?>>2 <?= Lang_cl::_e('products', 'cl') ?></option>
                        <option value="4" <?= $settings['posts_per_page'] === '4' ? 'selected' : '' ?>>4 <?= Lang_cl::_e('products', 'cl') ?></option>
                        <option value="6" <?= $settings['posts_per_page'] === '6' ? 'selected' : '' ?>>6 <?= Lang_cl::_e('products', 'cl') ?></option>
                        <option value="8" <?= $settings['posts_per_page'] === '8' ? 'selected' : '' ?>>8 <?= Lang_cl::_e('products', 'cl') ?></option>
                        <option value="12" <?= $settings['posts_per_page'] === '12' ? 'selected' : '' ?>>12 <?= Lang_cl::_e('products', 'cl') ?></option>
                    </select>
                </div>
            </div>
        </div>
    </div>
</div>