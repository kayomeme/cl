<ul class="cl-sidetab-submenu" attachedButonTab="cl_custom_blocks_tab">
    <li tab="cl_custom_block1_tab" _section="cl_custom_block1">
        <?= Lang_cl::_e('Block 1', 'cl') ?>
    </li>
    <li tab="cl_custom_block2_tab" _section="cl_custom_block2">
        <?= Lang_cl::_e('Block 2', 'cl') ?>
    </li>
</ul>    

<?php 
include 'blocks/custom_block1/'.$settings['custom_block1_version'].'/index.php'; 
include 'blocks/custom_block2/'.$settings['custom_block2_version'].'/index.php';

include AdminApp_cl::$viewsPath.'global_settings/partails/custom_blocks_help.php'
?>
