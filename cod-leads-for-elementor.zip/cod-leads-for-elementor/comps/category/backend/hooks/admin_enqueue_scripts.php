<?php

if( isset($_REQUEST['page']) && $_REQUEST['page'] == 'cl_global_settings' && isset($_REQUEST['compo']) && $_REQUEST['compo'] == 'category' ) {
    // Enqueue category-specific admin scripts and styles only on category settings page
    wp_enqueue_script( MainApp_cl::$assetsPrefix.$hook['compName'], MainApp_cl::$compsUrl.$hook['compName']. '/backend/assets/js/category_bk.js', array( 'jquery' ), MainApp_cl::$assetsVersion );
    //wp_enqueue_style( MainApp_cl::$assetsPrefix.$hook['compName'], MainApp_cl::$compsUrl.$hook['compName']. '/backend/assets/css/category_bk.css', [], MainApp_cl::$assetsVersion );
} 
