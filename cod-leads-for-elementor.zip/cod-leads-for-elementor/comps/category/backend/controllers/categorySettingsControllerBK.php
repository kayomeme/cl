<?php

class CategorySettingsControllerBK_cl {

    /**
     * Display category settings page
     * 
     * @param int $settingsModelId Settings model ID
     * @param array $settings Current settings
     * @param array $urlArgs URL arguments
     */
    public static function index($settingsModelId, $settings, $urlArgs) {
        $compoName = 'category';
        $tabName = isset($_GET['tab']) ? $_GET['tab'] : 'category';
        
        $defaultSettings = AdminCompo_cl::getDefaultSettings($compoName, $settings);
        
        $categoryBlocksOrder = adminUtils_cl::getElementsOrder($defaultSettings['category_blocks_order'], $settings['category_blocks_order']);   
        $settings['category_blocks_order'] = implode(',', $categoryBlocksOrder);
        
        $styleGenerator = AdminCompo_cl::getStyleGenerator($compoName, $settings);
        $styleManager = new StyleManagerBK_cl($defaultSettings, $settings, $styleGenerator);
        
        $settingGenerator = AdminCompo_cl::getSettingGenerator($compoName, $settings);
        $settingManager = new SettingManagerBK_cl($settings, $settingGenerator);
        //var_dump($settings);

        include AdminApp_cl::$viewsPath . 'global_settings/index.php';
    }

    /**
     * Save category settings
     * 
     * @param string $compoName Component name
     * @param int $settingsModelId Settings model ID
     * @param array $args Form arguments
     * @return mixed Response
     */
    public static function save_settings($compoName, $settingsModelId, $args) {
        $response = AdminCompo_cl::saveSettings($compoName, $settingsModelId, $args);
        
        if ($response) {
            return $response;
        }
    }

    /**
     * Get shared settings (if any needed for category component)
     * 
     * @param array $args Form arguments
     * @return array Shared settings
     */
    private static function getSharedSettings($args) {
        $sharedSettings = [];
        
        // Add any shared settings here if needed
        
        return $sharedSettings;
    }
}