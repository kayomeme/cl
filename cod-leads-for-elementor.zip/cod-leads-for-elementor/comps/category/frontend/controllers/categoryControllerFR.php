<?php

/**
 * Category Controller Frontend
 */
class CategoryControllerFR_cl {

    public $settings;
    public $theCategory;
    public $plistModel = 'plist1';
    public $plistArgs = [];
    public $defaultPlistArgs = [
        'container_max_width' => 'inherit',
        'container_space_between_blocks' => 'inherit',
        'product_box_layout' => 'inherit',
        'desktop_columns' => 'inherit',
        'mobile_columns' => 'inherit',
        'posts_per_page' => 'inherit',
        'pagination_type' => 'inherit',
    ];

    /**
     * Constructor
     * 
     * @param array $additionalSettings Additional settings to merge
     */
    public function __construct($categoryId, $additionalSettings = null) {
        global $settingsModelId;
        $compoName = 'category';
        $settings = PublicCompo_cl::getSettings($compoName, $settingsModelId);
        
        // Merge with additional settings if provided
        if (is_array($additionalSettings)) {
            $settings = array_merge($settings, $additionalSettings);
        }
        
        $this->theCategory = get_term($categoryId, 'product_cat');
        $this->settings = $settings;
        
        $this->plistArgs['category_id'] = $categoryId;
        // Only include settings that are not "inherit"
        foreach ($this->defaultPlistArgs as $key => $defaultValue) {
            if (isset($this->settings[$key]) && $this->settings[$key] !== 'inherit') {
                $this->plistArgs[$key] = $this->settings[$key];
            }
        }
    }

    /**
     * Get settings
     * 
     * @return array Settings
     */
    public function getSettings() {
        return $this->settings;
    }

    /**
     * Get the category object
     * 
     * @return object Category object
     */
    public function getCategory() {
        return $this->theCategory;
    }

    /**
     * Get JavaScript object for frontend
     * 
     * @return string JSON encoded JavaScript object
     */
    public function getJsCategory() {
        $jsCategory = [];
        
        return jsonEncodeForJs_cl($jsCategory);
    }

    /**
     * Main index method
     */
    public function index() {
        $settings = $this->settings;
        $theCategory = $this->theCategory;
        
        // Get category image URL if image is active
        $categoryImageUrl = null;
        if ($settings['image_is_active'] == 'yes') {
            $categoryImageUrl = CategoryModelFR_cl::getCategoryImageUrl($theCategory->term_id);
        }

        $atts = $this->plistArgs;
        switch ($this->plistModel) {
            case 'plist1':
            $plistController = new PList1ControllerFR_cl();
            break;
        }

        require_once MainApp_cl::$compsPath . 'category/frontend/views/index.php';
    }
}