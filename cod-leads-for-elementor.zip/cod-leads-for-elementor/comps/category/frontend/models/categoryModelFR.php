<?php

/**
 * Category Model Frontend
 */
class CategoryModelFR_cl {

    /**
     * Get category image URL
     * 
     * @param int $categoryId Category term ID
     * @return string|false Image URL or false if no image
     */
    public static function getCategoryImageUrl($categoryId) {
        $thumbnail_id = get_term_meta($categoryId, 'thumbnail_id', true);
        if ($thumbnail_id) {
            $image_url = wp_get_attachment_url($thumbnail_id);
            if ($image_url) {
                return $image_url;
            }
        }
        return false;
    }
}