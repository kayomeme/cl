<?php
global $settingsModelId;

$cssFileSystemPath = MainApp_cl::$compsPath . 'category/frontend/assets/css/category.css';
// Check if main CSS file is empty
if (file_exists($cssFileSystemPath) && filesize($cssFileSystemPath) > 10) {
    // Main file has content - use it
    wp_enqueue_style('cl_category_css', MainApp_cl::$compsUrl . 'category/frontend/assets/css/category.css', [], MainApp_cl::$assetsVersion);
} else {
    // Main file is empty - generate and use inline CSS
    wp_register_style('cl_category_css', false);
    wp_enqueue_style('cl_category_css');
    
    $categoryCss = PublicCompo_cl::getGeneratedCssForComps($settingsModelId, ['category']);
    
    if (!empty($categoryCss)) {
        $categoryCss = str_replace(['<style>', '</style>'], '', $categoryCss);
        wp_add_inline_style('cl_category_css', $categoryCss);
    }
}