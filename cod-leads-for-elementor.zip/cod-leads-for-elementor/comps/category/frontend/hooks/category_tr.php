<?php
// This hook file is executed when template_redirect action is triggered
// It follows the same pattern as other component hooks
// Check if we're on a category page and initialize category overrides
if (is_archive() && (is_tax('product_cat') || is_post_type_archive('product'))) {
    // Initialize the category controller for this request
    global $category_cl;
    $categoryId = get_queried_object_id();
    $category_cl = new CategoryControllerFR_cl($categoryId);
    
    // Set a global flag that we're on a category page
    global $isCategoryPage;
    $isCategoryPage = true;
}