<?php
if( $settings['header_is_active'] != 'yes' ) {
    return;
}
?>
<div id="cl_header" _attachedsection="header" class="is_category_block">
    <div class="cat-header-flex">
        <?php if ($categoryImageUrl) { ?>
                <div class="cat-image cl_editor_content">
                    <img src="<?= esc_url($categoryImageUrl) ?>" alt="<?= esc_attr($theCategory->name) ?>" />
                </div>
        <?php } ?>

        <div class="cat-info-container">
            <?php if ($settings['title_is_active'] == 'yes' && !empty($theCategory->name)) { ?>
                    <h1 class="cat-title cl_editor_content"><?= esc_html($theCategory->name) ?></h1>
            <?php } ?>

            <?php if ($settings['description_is_active'] == 'yes' && !empty($theCategory->description) && strlen(trim($theCategory->description)) > 5) { ?>
                <div class="cat-description cl_editor_content">
                    <?= $theCategory->description ?> 
                </div>
            <?php } ?>

            <?php if ($settings['product_count_is_active'] == 'yes' && $theCategory->count > 0) { ?>
                <div class="cat-product-count cl_editor_content">
                    <?php 
                        echo sprintf(_n('%d product', '%d products', $theCategory->count, 'cl'), $theCategory->count);
                    ?>
                </div>
            <?php } ?>
        </div>
    </div>
</div>