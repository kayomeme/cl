<?php if ($settings['custom_block2_is_active'] == 'yes' && strlen($settings['custom_block2_content']) > 2 ) { ?>
    <div id="cl_custom_block2" _attachedsection="custom_block2" class="cl_custom_block2 is_category_block">
        <div class="cl-custom-blocks cl_editor_content">
            <?= do_shortcode($settings['custom_block2_content']) ?> 
        </div>
    </div>
<?php } ?>

