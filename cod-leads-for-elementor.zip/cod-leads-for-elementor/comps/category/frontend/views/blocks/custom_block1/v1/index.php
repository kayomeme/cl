<?php if ($settings['custom_block1_is_active'] == 'yes' && strlen($settings['custom_block1_content']) > 1 ) { ?>
    <div id="cl_custom_block1" _attachedsection="custom_block1" class="cl_custom_block2 is_category_block">
        <div class="cl-custom-blocks cl_editor_content">
            <?= do_shortcode($settings['custom_block1_content']) ?> 
        </div>
    </div>
<?php } ?>

