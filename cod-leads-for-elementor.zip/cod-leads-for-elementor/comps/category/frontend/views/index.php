<div class="cl-category-container">
    <?php
    $category_blocks_order = explode(',', $settings['category_blocks_order']);

    foreach ($category_blocks_order as $categoryElement) {
        include_once 'blocks/' . $categoryElement . '/' . $settings[$categoryElement . '_version'] . '/index.php';
    }
    ?>
</div>