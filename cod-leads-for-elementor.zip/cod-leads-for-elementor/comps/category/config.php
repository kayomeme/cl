<?php

/**
 * Category component configuration
 * This component handles category page settings overrides for plist1
 */
return array(
    'setting' => [
        'active_blocks' => 'header,custom_block1,plist,custom_block2',  
        'category_blocks_order' => 'header,custom_block1,plist,custom_block2',
    ],
    'lang' => [
        // Language strings for the component
    ],
    'style' => [

    ]
); 
