<?php
$dirPath = plugin_dir_path( __FILE__ );

if( $isAdminAria ) {
    // Backend files - only load in admin area
    require_once $dirPath . 'backend/controllers/categorySettingsControllerBK.php';
    require_once $dirPath . 'backend/models/categoryModelBK.php';
}

if($isPublicAria) {
    // Frontend files - only load in public area
    require_once $dirPath . 'frontend/controllers/categoryControllerFR.php';
    require_once $dirPath . 'frontend/models/categoryModelFR.php';
}