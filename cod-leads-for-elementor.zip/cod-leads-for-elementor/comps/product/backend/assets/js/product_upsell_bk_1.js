(function ($) {


    $(document).ready(function () {
        let searchTimeout;

        // Search products
        $('#upsell-search').on('input', function () {
            var searchInput = $(this);
            var searchResults = $('.upsell-search-results');

            clearTimeout(searchTimeout);

            if (searchInput.val().length < 2) {
                searchResults.hide().empty();
                return;
            }

            searchTimeout = setTimeout(function () {
                $.ajax({
                    url: jsArgs.ajax_url,
                    type: 'POST',
                    data: {
                        action: jsArgs.ajax_admin_action,
                        clfe_controller: 'clfe_product',
                        clfe_action: 'clfe_get_upsell_search_products',
                        //nonce: jsArgs.ajax_nonce,
                        search: searchInput.val(),
                        exclude: getSelectedProductIds()
                    },
                    success: function (data) {
                        var response = jQuery.parseJSON(data);
                        const products = response.res;
                        console.log(products);
                        if (products) {
                            var results = '';
                            products.forEach(function (product) {
                                // Only show in search if not already selected
                                //if (!$('.upsell-product[data-id="' + product.id + '"]').hasClass('selected')) {
                                    results += `<div class="upsell-search-item" data-id="${product.id}">
                                        <span class="product-title">${product.title}</span>
                                        <span class="product-price"> - ${product.price}</span>
                                        <button type="button" class="remove-upsell">×</button></div>`;
                               // }
                                
                                console.log(product);
                            });
                            searchResults.html(results).show();
                        }
                    }
                });
            }, 300);
        });




        /*$('#upsell-search').on('input', function (ev) {
            //ev.preventDefault();

            var searchInput = $(this);
            var searchResults = $('.upsell-search-results');

            clearTimeout(searchTimeout);

            if (searchInput.val().length < 2) {
                searchResults.hide().empty();
                return;
            }

            const clfe_controller = 'clfe_product';
            const clfe_action = 'clfe_get_upsell_search_products';

            const currentTabName = $("input[name=current_tab_name]").val();
            const containerId = 'clfe_' + currentTabName + '_tab';


            var formData = {};
            formData['product_id'] = $("input[name=product_id]").val();
            //formData['current_tab_name'] = currentTabName;
            
            formData['nonce'] = jsArgs.ajax_nonce;
            formData['search'] = searchInput.val();
            formData['exclude'] = getSelectedProductIds();

            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);
        });*/


    // Add product from search
    $(document).on('click', '.upsell-search-item', function() {
        var productToAdd = $(this);
        productToAdd.removeClass('upsell-search-item');
        productToAdd.addClass('upsell-product');
        $('.upsell-products').append(productToAdd);
        
        $('input[name=clfe_upsell_ids]').val(getSelectedProductIds());
        
        $('#upsell-search').val('');
        $('.upsell-search-results').hide().empty();
    });

    // Remove product
    $(document).on('click', '.remove-upsell', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to remove this upsell product?')) {
            $(this).closest('.upsell-product').remove();
            $('input[name=clfe_upsell_ids]').val(getSelectedProductIds());
        }
    });

    // Hide search results when clicking outside
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.upsell-search-wrapper').length) {
            $('.upsell-search-results').hide().empty();
        }
    });

    function getSelectedProductIds() {
       return $('.upsell-product').map(function() {
           return $(this).data('id');
       }).get().join(',');
    }




    });
})(jQuery);