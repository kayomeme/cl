/**
 * Upsell Product Selection Module
 * Handles product search, selection and removal functionality
 */
(function ($) {
    const SEARCH_MIN_LENGTH = 2;
    const SEARCH_DELAY = 300;
    const SELECTORS = {
        search: '#upsell-search',
        searchResults: '.upsell-search-results',
        upsellProducts: '.upsell-products',
        upsellIds: 'input[name=clfe_upsell_ids]',
        searchWrapper: '.upsell-search-wrapper',
        descriptionModal: '#clfe_upsell_description_modal',
        descriptionEditor: '#clfe_upsell_description'
    };

    // Core utility functions
    function getSelectedProductIds() {
        return $('.upsell-product').map(function () {
            return $(this).data('id');
        }).get().join(',');
    }

    function updateUpsellProductIds() {
        $(SELECTORS.upsellIds).val(getSelectedProductIds());
    }

    // AJAX and response handlers
    function sendProductSearchRequest(searchValue, $searchResults) {
        const requestData = {
            action: jsArgs.ajax_admin_action,
            clfe_controller: 'clfe_product',
            clfe_action: 'clfe_get_upsell_search_products',
            search: searchValue,
            exclude: getSelectedProductIds()
        };

        $.ajax({
            url: jsArgs.ajax_url,
            type: 'POST',
            data: requestData,
            success: function (data) {
                handleProductSearchResponse(data, $searchResults);
            }
        });
    }

    function handleProductSearchResponse(data, $searchResults) {
        const response = jQuery.parseJSON(data);
        const products = response.res;
        if (!products)
            return;

        const resultsHtml = products.map(product =>
                `<div class="upsell-search-item" data-id="${product.id}">
                <span class="product-title">${product.title}</span>
                <span class="product-price"> - ${product.price}</span>
                <button type="button" class="remove-upsell">×</button>
            </div>`
        ).join('');
        $searchResults.html(resultsHtml).show();
    }

    function initializeProductSearch() {
        let searchTimeout;
        $(SELECTORS.search).on('input', function () {
            const $searchInput = $(this);
            const $searchResults = $(SELECTORS.searchResults);
            clearTimeout(searchTimeout);

            if ($searchInput.val().length < SEARCH_MIN_LENGTH) {
                $searchResults.hide().empty();
                return;
            }

            searchTimeout = setTimeout(() => {
                sendProductSearchRequest($searchInput.val(), $searchResults);
            }, SEARCH_DELAY);
        });
    }

    function initializeProductEventListeners() {
        // Add product
        $(document).on('click', '.upsell-search-item', function () {
            const $product = $(this);
            $product.removeClass('upsell-search-item').addClass('upsell-product');
            $(SELECTORS.upsellProducts).append($product);

            updateUpsellProductIds();

            $(SELECTORS.search).val('');
            $(SELECTORS.searchResults).hide().empty();
        });

        // Remove product
        $(document).on('click', '.remove-upsell', function (e) {
            e.preventDefault();
            if (confirm('Are you sure you want to remove this upsell product?')) {
                $(this).closest('.upsell-product').remove();
                updateUpsellProductIds();
            }
        });

        $(document).on('click', '.update-upsell-desc', function (e) {
            e.preventDefault();
            const productId = $(this).closest('.upsell-product').data('id');
            const $dialog = $('#clfe_upsell_description_modal');

            // Set product ID to dialog
            $dialog.data('product_id', productId);

            // Create dialog
            $dialog.dialog({
                title: 'Edit Upsell Description',
                width: 800,
                modal: true,
                buttons: {
                    'Save': function () {
                        $.ajax({
                            url: jsArgs.ajax_url,
                            type: 'POST',
                            data: {
                                action: jsArgs.ajax_admin_action,
                                clfe_controller: 'clfe_product',
                                clfe_action: 'clfe_save_upsell_description',
                                product_id: productId,
                                description: AdminFn_clfe.getTinyMCE_content( 'clfe_upsell_description' )
                            },
                            success: function (response) {
                                $dialog.dialog('close');
                            }
                        });
                    },
                    'Cancel': function () {
                        $(this).dialog('close');
                    }
                },
                open: function () {
                    // Load content
                    $.ajax({
                        url: jsArgs.ajax_url,
                        type: 'POST',
                        data: {
                            action: jsArgs.ajax_admin_action,
                            clfe_controller: 'clfe_product',
                            clfe_action: 'clfe_get_upsell_description',
                            product_id: productId
                        },
                        success: function (response) {
                            
                            const data = jQuery.parseJSON(response);
                            console.log(data);
                            if (data.code === 1) {
                                //setTimeout(function() {}, 100);
                                console.log(data.res);
                                //$('#clfe_upsell_description').val(data.res);
                                AdminFn_clfe.setTinyMCE_content('clfe_upsell_description', data.res);
                                

                            }
                        }
                    });
                }
            });
        });


    }

    // Initialize everything when document is ready
    $(document).ready(function () {
        initializeProductSearch();
        initializeProductEventListeners();

        // Click outside handler
        $(document).on('click', function (e) {
            if (!$(e.target).closest(SELECTORS.searchWrapper).length) {
                $(SELECTORS.searchResults).hide().empty();
            }
        });
    });
})(jQuery);