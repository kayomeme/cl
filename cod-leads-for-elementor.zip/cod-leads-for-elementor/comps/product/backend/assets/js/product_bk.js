(function ($) {
    /**
     * Product function
     */
    ProductFn_clfe = {

        init: function () {
        },
        autoSaveSettings: function() {
            $('.clfe-save-global-settings').click();
        },
        closeActiveModals: function () {
             $( ".ui-dialog .ui-dialog-buttonset .ui-button:first-child" ).click();
        },
        galleryOpenImagesSelection: function (galleryTitle) {
            const product_image_gallery = jQuery('input[name=_product_image_gallery]').val();
            //const attachments = JSON.parse(product_image_gallery);
            const attachments = product_image_gallery.split(',').map(id => ({ id: parseInt(id) }));
            let attachmentsIds = [];
            
            attachmentsIds.push(attachments.map(attchement => attchement.id));
            attachmentsIds = attachmentsIds[0];
            
            // Create a new media frame
            var mediaFrame = wp.media({
                title: galleryTitle,
                //multiple: true,
                //select multiple images without using ctrl
                multiple: 'add',
                library: { 
                    type: 'image',
                   // post__in: attachmentsIds
                },
                button: { text: 'Select'}
            });

            // Handle image selection
            mediaFrame.on('select', function() {
                const cleanAttachementsSelected = [];
                var attachmentsSelected = mediaFrame.state().get('selection').toJSON();

                const listImages = $("<ul> </ul>");
                attachmentsSelected.map(function (item) { 
                    if( parseInt(item.id) > 0 ) { 
                        cleanAttachementsSelected.push(item.id);

                        var elImage = $('<li><img src="'+item.url+'" /> </li>');
                        listImages.append(elImage);
                    }
                });

                if( cleanAttachementsSelected.length > 0 ) {
                    $("input[name=_product_image_gallery]").val( cleanAttachementsSelected.join(",") );
                    //$("input[name=_product_image_gallery]").val(JSON.stringify(cleanAttachementsSelected));

                    $("#clfe_gallery_tab ul").remove();
                    $("#clfe_gallery_tab").append(listImages);

                    ProductFn_clfe.gallerySaveSelectedImages();
                }

            });
            
            // re-select old images
            mediaFrame.on('open',function() {
                var selection = mediaFrame.state().get('selection');
                attachmentsIds.forEach(function(id) {
                    attachment = wp.media.attachment(id);
                    attachment.fetch();
                    selection.add(attachment ? [attachment] : []);   
                });
                
                
                /*
                 * Add selected images in the top of the media
                 * see the file ressource_for_dev/gallery_images  
                 */       
                var lib = mediaFrame.state().get('library');
                lib.comparator = function( a, b ) {
                    var aInQuery = !! this.mirroring.get( a.cid ), bInQuery = !! this.mirroring.get( b.cid );
                    if ( ! aInQuery && bInQuery ) {
                        return -1;
                    } else if ( aInQuery && ! bInQuery ) {
                        return 1;
                    } else {
                        return 0;
                    }
                };

                attachmentsIds.forEach(function(id){
                    attachment = wp.media.attachment(id);
                    attachment.fetch();
                    lib.add( attachment ? [ attachment ] : [] );
                });

            });
            
            // Open the media frame
            mediaFrame.open();
        },
        gallerySaveSelectedImages: function () {
            const oldTabName = $('input[name=current_tab_name]').val();
            
            $('input[name=current_tab_name]').val('gallery');
            $('.clfe-save-product-settings').click();
            $('input[name=current_tab_name]').val(oldTabName);
        }

    };

    $(function () {
        ProductFn_clfe.init();
    });

    $( window ).load(function() {
        $(".dynamic-elements .c-element:first-child").find(".c-element-panel").show();
    });

    $(document).ready( function () {
        
        // single product
        $(".single-select-setting-models").on('change', function() {
            const urlString = $(".link-to-global-settings").attr('href');
            const url = new URL(urlString);

            url.searchParams.set('settings_model_id', $(this).val());
            
            $(".link-to-global-settings").attr('href', url.href)
            
            $(".clfe-save-product-settings").click();
        } );
        
        /*
         * save global settings
         */
        $('.clfe-save-product-settings').on('click', function(ev) {
            ev.preventDefault();
            
            //setProductshort_description();
            
            const clfe_controller  = 'clfe_product';
            const clfe_action  = 'clfe_save_product_settings';

            const containerId = $("input[name=current_tab_name]").val();

            var formData = AdminFn_clfe.getFormDatas(containerId);
            
            formData['product_id'] = $("input[name=product_id]").val();
            formData['current_tab_name'] = containerId;

            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);
        }); 

        $('.clfe-sidetab-nav button').on('click', function(ev) {
            const tabName = $(this).attr("tab");
            $('.clfe-content-tabs input[name=current_tab_name]').val(tabName);
        }); 

        // gallery upload
        $('#upload_gallery_images_button').click(function() {
            ProductFn_clfe.galleryOpenImagesSelection($(this).attr('galleryTitle'));
        });

        $("input[type=submit]").hover( function() {
            DynamicElements_clfe.setDatas();
        });
        
        // dynamique elements Variations for sub-elements
        $("select.variations-select").on('change', function() {
            var variationType = $('option:selected', this).attr('variationType');
            const optionToAdd = $(".clfe-empty-elements ."+variationType).clone(true);
            $(this).closest(".c-element").find(".variations-subelements").html(optionToAdd);
            $(this).closest(".c-element").find(".is-a-sub-array-elements").show();
            $(this).closest(".c-element").find(".variations-subelements .clfe-accordion-panel").show();
        });

    } );
})(jQuery);