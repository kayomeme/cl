<?php

$productController = new ProductControllerBK_clfe();

add_meta_box(
    'clfe_product_metabox',
    Lang_clfe::__('Cod leads : Product Data', 'clfe'),
    array($productController, 'metaBoxCallback'),
    'product',
    'normal',
    'high'
);

add_meta_box(
    'clfe_gallery_metabox',
    Lang_clfe::__('Gallery images', 'clfe'),
    array($productController, 'metaBoxGalleryCallback'),
    'product',
    'side',
    'high'
);