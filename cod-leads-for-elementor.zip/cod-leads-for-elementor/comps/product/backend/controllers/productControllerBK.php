<?php

/**
 */
class ProductControllerBK_clfe {
    
    private $editorArgs = [
        'textarea_rows'  => 15,
        'teeny' => false,
        'quicktags' => true,
        'media_buttons' => true,
        'tinymce'       => [
            'directionality' => 'ltr',
            'toolbar1'      => 'bullist,numlist,forecolor,bold,italic,underline,separator,alignleft,aligncenter,alignright,separator,link,unlink,undo,redo',
            'toolbar2'      => '',
            'toolbar3'      => '',
        ],
    ];
    
    /*
     * for ajax call
     */
    public static function routes($action, $args) {
        $result = false;
        switch ($action) {
            case 'clfe_save_product_settings':
                $result = self::save_settings($args);
                break;
            case 'clfe_get_upsell_search_products':
                $result = self::get_searched_upsell_products($args);
                break;
            case 'clfe_get_upsell_description':
                $result = self::get_upsell_description($args);
                break;
            case 'clfe_save_upsell_description':
                $result = self::save_upsell_description($args);
                break;
        }

        //var_dump($result);
        
        return $result;
    }
    
    public function metaBoxGalleryCallback($post) {
        $compsPath = MainApp_clfe::$compsPath;

        // $galleryImages_ids = get_post_meta($post->ID, '_product_image_gallery', true);

        $galleryImages = ProductModelBK_clfe::getGalleryImage($post->ID);

        $galleryImages_ids = array_map(function($image) { 
            return $image['id']; 
        }, $galleryImages);

        $galleryImages_ids = implode(",", $galleryImages_ids);

        
        include $compsPath.'product/backend/views/metabox/gallery.php';
    }
    
    public function metaBoxCallback($post) {
        $compsPath = MainApp_clfe::$compsPath;

        $productId = $post->ID;
        $productStatus = $post->post_status;

        $tabName = isset( $_REQUEST['clfe_tab'] ) ? $_REQUEST['clfe_tab'] : 'general';
        
        
        $productGeneralSettings = ProductUtils_clfe::getGeneralSettings($productId);


        $settingsModelId = $productGeneralSettings['settings_model_id'];
        $settingSlug = $settingsModelId ? '_'.$settingsModelId : '';
        $sharedSettings = (array) get_option('clfe_shared_settings_'.$settingsModelId, []);

        $settingModels = SettingsModelBK_clfe::getExistingModels($limit=100);

        $this->editorArgs['tinymce']['directionality'] = $sharedSettings['lang_dir'];
        $editorArgs = $this->editorArgs;
               
        $productDetails = ProductModelBK_clfe::getDetails($productId);
        $shortDescription   = $post->post_excerpt;
        $longDescription   = get_post_meta($productId, 'clfe_long_description', true);
  
        $variations     = ProductModelBK_clfe::getVariations($productId);       
        $qtyOffers      = ProductModelBK_clfe::getQtyOffers($productId, $productDetails);  
        $whatsapp       = ProductModelBK_clfe::getWhatsapp($productId);
        $googleSheet    = ProductModelBK_clfe::getGoogleSheet($productId);
        $upsellProductsIds = ProductModelBK_clfe::getUpsellProductsIds($productId);
        
        //exit();

        $compoName = 'product';
        include $compsPath.'product/backend/views/metabox/index.php';
    }
    
    // ajax call
    public static function get_searched_upsell_products($args) {
        //check_ajax_referer('clfe_upsell_nonce', 'nonce');
        
        $search = sanitize_text_field($args['search']);
        //$exclude = isset($args['exclude']) ? array_map('intval', $args['exclude']) : [];
        $exclude = explode(',', $args['exclude']);
        
        $products = get_posts([
            'post_type' => 'product',
            'posts_per_page' => 15,
            'post__not_in' => $exclude,
            's' => $search,
            'orderby' => 'title',
            'order' => 'ASC'
        ]);
        $results = array_map(function($product) {
            $price = get_post_meta($product->ID, '_regular_price', true);
            return [
                'id' => $product->ID,
                'title' => $product->post_title,
                'price' => $price ? $price : Lang_clfe::__('No price set', 'clfe')
            ];
        }, $products);
        
        return response_clfe(1, Lang_clfe::__('Settings updated successfully', 'clfe'), $results);
        //return wp_send_json_success(['products' => $results]);
    }
    
    
    public static function get_upsell_description($args) {
        if (!isset($args['product_id'])) {
            return response_clfe(0, Lang_clfe::__('Invalid product ID', 'clfe'), null);
        }

        $product_id = intval($args['product_id']);
        $description = get_post_meta($product_id, 'clfe_upsell_description', true);

        return response_clfe(1, Lang_clfe::__('Description retrieved successfully2', 'clfe'), $description);
    }

    public static function save_upsell_description($args) {
        if (!isset($args['product_id']) || !isset($args['description'])) {
            return response_clfe(0, Lang_clfe::__('Missing required parameters', 'clfe'), null);
        }

        $product_id = intval($args['product_id']);
        $description = $args['description'];

        update_post_meta($product_id, 'clfe_upsell_description', $description);

        return response_clfe(1, Lang_clfe::__('Description updated successfully', 'clfe'), null);
    }
    
    /*
     * save settings functions
     */
    public static function save_settings($args) {        
        $tabName = strtr($args['current_tab_name'], ['_tab' => '','clfe_' => '' ]);
        
        $productId = (int)$args['product_id'];
        
        // create a new product
        if( $productId == 0 ) {
            return response_clfe(0, Lang_clfe::__('you cant access directly to this section, invalide product id', 'clfe'), null);
        }

        // update general settings attached to each tab in the product settings
        self::updateGeneralSettings($args, $productId);
        
        // save every tab in a separate postmeta
        unset( $args['product_id'] );
        foreach (ProductUtils_clfe::$defaultGeneralSettings as $key => $value) {
            if( isset( $args[$key] ) ) {
                unset($args[$key]);
            }
        }

        $funcName = $tabName.'_save_settings';
        if( method_exists(get_called_class(), $funcName) ) {
            $response_clfe = self::$funcName($tabName, $args, $productId);
            if( $response_clfe ) {
                return $response_clfe;
            }
        }
        
        return response_clfe(1, Lang_clfe::__('Settings updated successfully', 'clfe'), null);
    }
    
    public static function updateGeneralSettings($args, $productId) {
        $productGeneralSettingsToUpdate = [];
        foreach (ProductUtils_clfe::$defaultGeneralSettings as $key => $value) {
            if( isset( $args[$key] ) ) {
                $productGeneralSettingsToUpdate[$key] = $args[$key];
            }
        }
        
        if( !empty( $productGeneralSettingsToUpdate ) ) {
            $existingGeneralSettings = (array)get_post_meta($productId, 'clfe_product_general_settings', true);
            update_post_meta($productId, 'clfe_product_general_settings', array_merge($existingGeneralSettings, $productGeneralSettingsToUpdate));
            
        }
    }
    
    public static function pricing_and_inventory_save_settings($tabName, $args, $productId) {
        
        if ($args['_sale_price'] > 0 && $args['_sale_price'] >= $args['_regular_price']) {
            return response_clfe(0, Lang_clfe::__('Sale price cannot be greater than or equal to regular price', 'clfe'));
        }
        
        if( isset( $args['settings_model_id'] ) ) {
            update_post_meta($productId, 'clfe_settings_model_id', $args['settings_model_id']);
        }
        
        ProductModelBK_clfe::saveDetails($productId, $args);
    }

    public static function gallery_save_settings($tabName, $args, $productId) {
        if ( isset($args['_product_image_gallery']) ) {
            ProductModelBK_clfe::updateGalleryImages($productId, $args['_product_image_gallery']);
        }
        
        return response_clfe(1, Lang_clfe::__('Gallery updated successfully', 'clfe'), null);
    }
    
    public static function variations_save_settings($tabName, $args, $productId) {
        
        ProductModelBK_clfe::saveVariations($productId, $args['clfe_variations']);
    }
    
    public static function qty_offers_save_settings($tabName, $args, $productId) {
        ProductModelBK_clfe::saveQtyOffers($productId, $args['clfe_qty_offers']);
    }
    
    public static function long_description_save_settings($tabName, $args, $productId) {
        update_post_meta($productId, 'clfe_long_description', $args['clfe_long_description']);
    }
    
    public static function short_description_save_settings($tabName, $args, $productId) {
        $args = [
              'ID'           => $productId,
              'post_excerpt' => $args['excerpt'],
        ];
        
        wp_update_post( $args );
    }
    
    public static function google_sheet_save_settings($tabName, $args, $productId) {
        
        $settings = get_option('clfe_google_sheet');

        // first_sheet mean that the order will be inserted in sheet name: cod_lead_orders    
        $settings['sheet_name'] = strlen($args['sheet_name']) > 1 ? $args['sheet_name'] : 'first_sheet';

        if( !isset( $settings['sheet_web_app_url'] ) || !isset( $settings['sheet_columns'] ) ) {
            adminUtils_clfe::ajaxReturn(0, Lang_clfe::__('First, try setting the Google Sheet settings on the global settings page.', 'clfe'), null);
        }

        $sheetColumns = jsonDecode_clfe($settings['sheet_columns']);
        $statusColumnPosition = SheetUtils_clfe::getStatusColumnPosition($sheetColumns);

        if( !isset( $sheetColumns['elements'] ) || empty($sheetColumns['elements']) ) {
            $errorMsg = Lang_clfe::__('Please consider adding at least one additional column, and ensure that column names do not include any special characters.', 'clfe');
            adminUtils_clfe::ajaxReturn(0, $errorMsg , null);
        }

        $sheetColNames = [];
        foreach ($sheetColumns['elements'] as $value) {
            if( isset( $value['col_name'] ) && isset( $value['col_value'] ) ) {
                $sheetColNames[] = $value['col_name'];
            }
        }

        // action => modify_header / add_row_to_top / add_row_to_bottom
        //$data = [  ];
        $data [] = [
            'action' => 'modify_header',
            'sheet_name' => $settings['sheet_name'],
            'sheet_row_bg_color' => $settings['sheet_head_bg_color'],
            'sheet_row_font_color' => $settings['sheet_head_font_color'],
            'site_url' => get_site_url(),
            'status_column_position' => $statusColumnPosition
        ];

        $data [] = array_values($sheetColNames);

        $response = SheetUtils_clfe::sendCurlPost($settings['sheet_web_app_url'], $data);
        
        if( $response->code == 1 ) {
            ProductModelBK_clfe::saveGoogleSheet($productId, $args);
        }

        return response_clfe($response->code, $response->msg, $response->result);
    }
    
    public static function whatsapp_save_settings($tabName, $args, $productId) {
        ProductModelBK_clfe::saveWhatsapp($productId, $args);
    }
    
    public static function upsell_save_settings($tabName, $args, $productId) {
        if ( isset($args['clfe_upsell_ids']) ) {
            $upsellIds = [];
            if (!empty($args['clfe_upsell_ids'])) {
                $upsellIds = explode(',', $args['clfe_upsell_ids']);
            }
            
            ProductModelBK_clfe::saveUpsell($productId, $upsellIds);
        }
    }
}
