<?php
$dirPath = plugin_dir_path( __FILE__ );

if( $isAdminAria ) {
    require_once $dirPath  . 'backend/controllers/insightsSettingsControllerBK.php';

    require_once $dirPath  . 'backend/controllers/insightsControllerBK.php';
    require_once $dirPath  . 'backend/models/campaignsInsightModel.php';
    require_once $dirPath  . 'backend/models/product-insight.php';
}

if($isPublicAria) {
    require_once $dirPath  . 'frontend/insightsUtilsFR.php';
    require_once $dirPath  . 'frontend/models/insightsModelFR.php';
    require_once $dirPath  . 'frontend/controllers/insightsControllerFR.php';
}