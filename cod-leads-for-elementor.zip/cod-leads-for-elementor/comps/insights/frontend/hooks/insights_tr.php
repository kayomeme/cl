<?php

    /*if( $isProductPage && isset( $_REQUEST['utm_source'] ) ) {
        global $product_clfe;
        global $checkout_clfe;
        global $insight_id;
        global $insight_order_source_infos;
        global $insight_user_location;
        
        $productDatas = $product_clfe->getDatasForInsights();
        
        $insightUtils = new InsightsUtilsFR_clfe();
        $utmDatasFromUrl        = $insightUtils->getUtmDatasFromUrl();
        $requestDatasFromServer = $insightUtils->getRequestDatasFromServer();
        $cloudFHeaderDatas      = $insightUtils->getCloudFHeaderDatas();
        
        $insightDatas = array_merge($productDatas, $utmDatasFromUrl, $requestDatasFromServer, $cloudFHeaderDatas);
        $insight_id = InsightsControllerFR_clfe::create($insightDatas);
        
        $insight_order_source_infos = $utmDatasFromUrl['utm_source'].' / '.$utmDatasFromUrl['campaign_name'];
        $insight_user_location = $cloudFHeaderDatas['city_detection'];
    } */

    if( isset( $_REQUEST['utm_source'] ) && $product_id ) {
        $productDatas = $product_clfe->getDatasForInsights();

        global $insights_clfe;
        $insights_clfe = new InsightsControllerFR_clfe($productDatas);
    }
    
    if( isset( $_REQUEST['my_dev'] ) ) {
        
       // var_dump();
        foreach ($_SERVER as $key => $value) {
            echo $key.' => '.$value;
            echo '<br/>';
        }
        
        exit();
        
    }