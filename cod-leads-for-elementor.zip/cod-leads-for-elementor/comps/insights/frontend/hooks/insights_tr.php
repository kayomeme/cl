<?php

    /*if( $isProductPage && isset( $_REQUEST['utm_source'] ) ) {
        global $product_cl;
        global $checkout_cl;
        global $insight_id;
        global $insight_order_source_infos;
        global $insight_user_location;
        
        $productDatas = $product_cl->getDatasForInsights();
        
        $insightUtils = new InsightsUtilsFR_cl();
        $utmDatasFromUrl        = $insightUtils->getUtmDatasFromUrl();
        $requestDatasFromServer = $insightUtils->getRequestDatasFromServer();
        $cloudFHeaderDatas      = $insightUtils->getCloudFHeaderDatas();
        
        $insightDatas = array_merge($productDatas, $utmDatasFromUrl, $requestDatasFromServer, $cloudFHeaderDatas);
        $insight_id = InsightsControllerFR_cl::create($insightDatas);
        
        $insight_order_source_infos = $utmDatasFromUrl['utm_source'].' / '.$utmDatasFromUrl['campaign_name'];
        $insight_user_location = $cloudFHeaderDatas['city_detection'];
    } */

    if( isset( $_REQUEST['utm_source'] ) && $product_id ) {
        $productDatas = $product_cl->getDatasForInsights();

        global $insights_cl;
        $insights_cl = new InsightsControllerFR_cl($productDatas);
    }
    
    if( isset( $_REQUEST['my_dev'] ) ) {
        
       // var_dump();
        foreach ($_SERVER as $key => $value) {
            echo $key.' => '.$value;
            echo '<br/>';
        }
        
        exit();
        
    }