<?php

/**
 * Description of insightsModel
 *
 * @author GIGABYTE
 */
class insightsModelFR_cl {
   
    public static function insert($insightsDatas) {
        global $wpdb;
  
        $tbFbInsights   = $wpdb->prefix.'cl_insights';
        
        $wpdb->insert($tbFbInsights, $insightsDatas);
        $insights_id = $wpdb->insert_id ? (int)$wpdb->insert_id : 0;

        return $insights_id;
    }
}
