<?php

class InsightsControllerFR_cl {
    
    public $id;
    public $orderSourceInfos;
    public $userLocation;


    public function __construct($productDatas) {
        $insightUtils = new InsightsUtilsFR_cl();
        
        $utmDatasFromUrl        = $insightUtils->getUtmDatasFromUrl();
        $requestDatasFromServer = $insightUtils->getRequestDatasFromServer();
        $cloudFHeaderDatas      = $insightUtils->getCloudFHeaderDatas();
        
        $insightDatas = array_merge($productDatas, $utmDatasFromUrl, $requestDatasFromServer, $cloudFHeaderDatas);
        
        $this->id = insightsModelFR_cl::insert($insightDatas);
        
        $this->orderSourceInfos = $utmDatasFromUrl['utm_source'].' / '.$utmDatasFromUrl['campaign_name'];
        $this->userLocation     = $cloudFHeaderDatas['city_detection'];
    }

    
    public static function updateAfterSubmitOrder($insight_id, $orderData, $cookiesDatas = null ) {
        global $wpdb; 
        
        $whereUpFbInsights  = false;
        if( $insight_id > 0 ) {
            $whereUpFbInsights = "id=$insight_id";
        } else {
            $fbclid = "";
            if( isset($cookiesDatas['_fbc']) ) {
                $strParts   = explode('.', $cookiesDatas['_fbc']);
                $fbclid     = isset( $strParts[count($strParts)-1] ) ? $strParts[count($strParts)-1] : "";
            }

            $userCurrentIp  = $orderData['ip_address'];
            if($userCurrentIp || $fbclid) {
                $whereUpFbInsights = "user_ip= '$userCurrentIp' or fbclid='$fbclid'";
            }
        }
        
        // Update insights table
        if( $whereUpFbInsights ) {
            $tb_insights = $wpdb->prefix.'insights';
            $where = "where ".$whereUpFbInsights;
            $set = "set order_id='".$orderData['order_id']."',";
            $set = $set."order_total='".$orderData['total']."',";
            $set = $set."currency_code='".$orderData['currency_code']."',";
            $set = $set."product_qty='".$orderData['product_qty']."',";
            $set = $set."city='".$orderData['city']."',";
            $set = $set."status='".$orderData['status']."'";
            
            $wpdb->query("UPDATE ".$tb_insights." ".$set." ".$where );
        } 
    }
    


    
    
}
