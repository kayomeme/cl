<?php

/**
	id mediumint(9) AUTO_INCREMENT,
                settings_model_id mediumint(9) DEFAULT 0,
                setting_model_name varchar(200) DEFAULT '',
                ad_click_id varchar(800) DEFAULT '',
                utm_source_link varchar(500) DEFAULT '',
                utm_sub_source_name varchar(50) DEFAULT '',
                campaign_name varchar(500) DEFAULT '',
                utm_term varchar(500) DEFAULT '',
                utm_content_creative varchar(500) DEFAULT '',
                campaign_id varchar(300) DEFAULT '',
                adset_id varchar(300) DEFAULT '',
                adset_name varchar(300) DEFAULT '',
                ad_id varchar(300) DEFAULT '',
                ad_name varchar(300) DEFAULT '',
                ad_placement varchar(300) DEFAULT '',
                referer varchar(100) DEFAULT '',
                other_data varchar(400) DEFAULT '',
                product_id mediumint(9),
                product_name varchar(300) DEFAULT '',
                product_regular_price float DEFAULT 0,
                product_sale_price float DEFAULT 0,
                product_buy_price float DEFAULT 0,
                product_cat varchar(100) DEFAULT '',
                is_test_product mediumint(9) DEFAULT 0,
                product_qty mediumint(9) DEFAULT 1,
                order_id varchar(100) DEFAULT 0,
                status varchar(100) DEFAULT '',
                status_cost float DEFAULT 0,
                order_total float DEFAULT 0,
                shipping_fees mediumint(9) DEFAULT 0,
                customer_city varchar(100) DEFAULT '',
                customer_id mediumint(9) DEFAULT 0,
                user_agent varchar(400) DEFAULT '',
                user_browser varchar(100) DEFAULT '',
                user_ip varchar(50) DEFAULT '',
                user_os varchar(100) DEFAULT '',
 * 
 * Description of insights-utils-le
 *
 * @author me
 */
class InsightsUtilsFR_cl {
    public $userAgent;
    
    public function __construct() {
        $this->userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    }

    public function getUtmDatasFromUrl() {
        $utmDatas = [
            'utm_source'       => isset( $_REQUEST['utm_source'] )         ? $_REQUEST['utm_source'] : '',
            'utm_sub_source'   => isset( $_REQUEST['utm_sub_source'] )     ? $_REQUEST['utm_sub_source'] : '',
            'utm_medium'            => isset( $_REQUEST['utm_medium'] )         ? $_REQUEST['utm_medium'] : '',
            'ad_manager_name'       => isset( $_REQUEST['ad_manager_name'] )    ? $_REQUEST['ad_manager_name'] : '',
            'campaign_name'         => isset( $_REQUEST['utm_campaign'] )      ? $_REQUEST['utm_campaign'] : '',
            'campaign_id'           => isset( $_REQUEST['campaign_id'] )        ? $_REQUEST['campaign_id'] : '',
            'adset_name'            => isset( $_REQUEST['utm_term'] )         ? $_REQUEST['utm_term'] : '',
            'adset_id'              => isset( $_REQUEST['adset_id'] )           ? $_REQUEST['adset_id'] : '',
            'ad_name'               => isset( $_REQUEST['utm_content'] )            ? $_REQUEST['utm_content'] : '',
            'ad_id'                 => isset( $_REQUEST['ad_id'] )              ? $_REQUEST['ad_id'] : '',
            'ad_type'               => isset( $_REQUEST['ad_type'] )              ? $_REQUEST['ad_type'] : '',
            'ad_placement'          => isset( $_REQUEST['placement'] )          ? $_REQUEST['placement'] : '',
            'utm_site_id'          => isset( $_REQUEST['utm_site_id'] )          ? $_REQUEST['utm_site_id'] : '',
        ];
        
        return $utmDatas;
    }

    public function getRequestDatasFromServer() {
        $requestDatas = [
            'referer' => $this->getReferer(),
            'user_agent' => $this->getUserAgent(),
            'user_ip' => $this->getUserIpAddr(),
            'user_os' => $this->getUserOS(),
            'user_browser' => $this->getUserBrowser()
            
        ];

        return $requestDatas;
    }
    
    public function getCloudFHeaderDatas() {
        $cloudFHeaderDatas = [];
        $cloudFHeaderDatas['city_detection'] = '';
        
        if( isset( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
            $cloudFHeaderDatas['user_ip'] = $_SERVER['HTTP_CF_CONNECTING_IP'];
        }
        if( isset( $_SERVER['HTTP_CF_IPCITY'] ) ) {
            $cloudFHeaderDatas['city'] = $_SERVER['HTTP_CF_IPCITY'];
            $cloudFHeaderDatas['city_detection'] = $_SERVER['HTTP_CF_IPCITY'];  
        }
        
        if( isset( $_SERVER['HTTP_CF_IPCOUNTRY'] ) ) {
            $cloudFHeaderDatas['country'] = $_SERVER['HTTP_CF_IPCOUNTRY'];
        }
        
        if( isset( $_SERVER['HTTP_CF_REGION'] ) ) {
            $cloudFHeaderDatas['region'] = $_SERVER['HTTP_CF_REGION'];
        }
        
        if( isset( $_SERVER['HTTP_CF_IPLATITUDE'] ) ) {
            $cloudFHeaderDatas['latitude'] = $_SERVER['HTTP_CF_IPLATITUDE'];
        }
        
        if( isset( $_SERVER['HTTP_CF_IPLONGITUDE'] ) ) {
            $cloudFHeaderDatas['longitude'] = $_SERVER['HTTP_CF_IPLONGITUDE'];
        }
        
        return $cloudFHeaderDatas;
    }
    
    public function isAfacebookUser() {
        if( isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], 'facebook.com') !== false ) {
            return true;
        }
        return false;
    }

    public function isVisitorBot() {
       return strpos($this->userAgent, 'facebookexternalhit') !== false;
    }
    
    public function getUserAgent() {
        return $this->userAgent;
    }
    
    public function getReferer() {
        $referer = "none";
        if (isset($_SERVER['HTTP_REFERER'])) {
            $referer = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
            $referer = strtolower($referer);
            $referer = sanitize_text_field($referer);
        }
        return $referer;
    }

    function getUserIpAddr(){
        $ip = "";
        if(!empty($_SERVER['HTTP_CLIENT_IP'])){
            //ip from share internet
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
            //ip pass from proxy
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        }else{
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }    
    function getUserOS() {
        $os_array = [
            '/windows nt 10/i'      =>  'Windows 10',
            '/windows phone 10/i'   =>  'Windows Phone 10',
            '/windows phone 8.1/i'  =>  'Windows Phone 8.1',
            '/windows phone 8/i'    =>  'Windows Phone 8',
            '/windows nt 6.3/i'     =>  'Windows 8.1',
            '/windows nt 6.2/i'     =>  'Windows 8',
            '/windows nt 6.1/i'     =>  'Windows 7',
            '/windows nt 6.0/i'     =>  'Windows Vista',
            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
            '/windows nt 5.1/i'     =>  'Windows XP',
            '/windows xp/i'         =>  'Windows XP',
            '/windows nt 5.0/i'     =>  'Windows 2000',
            '/windows me/i'         =>  'Windows ME',
            '/win98/i'              =>  'Windows 98',
            '/win95/i'              =>  'Windows 95',
            '/win16/i'              =>  'Windows 3.11',
            '/macintosh|mac os x/i' =>  'Mac OS X',
            '/mac_powerpc/i'        =>  'Mac OS 9',
            '/iphone/i'             =>  'iPhone',
            '/ipod/i'               =>  'iPod',
            '/ipad/i'               =>  'iPad',
            '/android/i'            =>  'Android',
            '/linux/i'              =>  'Linux',
            '/ubuntu/i'             =>  'Ubuntu',
            '/blackberry/i'         =>  'BlackBerry',
            '/webos/i'              =>  'Mobile'
        ];

        foreach ($os_array as $regex => $value) { 
            if (preg_match($regex, $this->userAgent) ) {
                return $value;
            }
        }   
        return 'OS not detected';
    }  
    function getUserBrowser() {
        $browser_array = [
            '/mobile/i'     =>  'Handheld Browser',
            '/msie/i'       =>  'Internet Explorer',
            '/firefox/i'    =>  'Firefox',
            '/safari/i'     =>  'Safari',
            '/chrome/i'     =>  'Chrome',
            '/edge/i'       =>  'Edge',
            '/opera/i'      =>  'Opera',
            '/netscape/i'   =>  'Netscape',
            '/maxthon/i'    =>  'Maxthon',
            '/konqueror/i'  =>  'Konqueror'
        ];

        foreach ($browser_array as $regex => $value) { 
            if (preg_match($regex, $this->userAgent ) ) {
                $browser = $value;
            }
        }

        return $browser == "" ? "browser not detected" : $browser;
    }
}
