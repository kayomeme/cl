<?php

/**
 * general
 */
return array(
    'setting' => [
  'fb_utm_code' => 'utm_source=meta&utm_sub_source={{site_source_name}}&utm_medium=social&ad_manager_name=me&utm_campaign={{campaign.name}}&campaign_id={{campaign.id}}&utm_term={{adset.name}}&adset_id={{adset.id}}&utm_content={{ad.name}}&ad_id={{ad.id}}&placement={{placement}}',
    'tiktok_utm_code' => 'utm_source=tiktok&utm_medium=social&ad_manager_name=me&utm_campaign=__CAMPAIGN_NAME__&campaign_id=__CAMPAIGN_ID__&utm_term=__AID_NAME__&adset_id=__AID__&utm_content=__CID_NAME__&ad_id=__CID__&ad_type=__CTYPE__&placement=__PLACEMENT__'
 
    ],
    'lang' => [

    ],
    'style' => [
        
    ]
    );
