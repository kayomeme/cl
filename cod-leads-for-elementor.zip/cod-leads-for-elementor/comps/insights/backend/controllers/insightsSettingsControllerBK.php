<?php

class InsightsSettingsControllerBK_cl {
    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'insights';
        $tabName = isset($urlArgs['tab']) ? $urlArgs['tab'] : 'fb_utm_generator';
                    
        $fbUtmVars = ['{{campaign.id}}', '{{campaign.name}}', '{{adset.id}}', '{{adset.name}}','{{ad.id}}', '{{ad.name}}', '{{placement}}', '{{site_source_name}}'];
        $tiktokUtmVars = ['__CAMPAIGN_NAME__', '__CAMPAIGN_ID__', '__AID_NAME__', '__AID__','__CID_NAME__', '__CID__', '__PLACEMENT__', '__CSITE__', '__CTYPE__'];

        include AdminApp_cl::$viewsPath . 'global_settings/index.php';
    }
        public static function save_settings($compoName, $settingsModelId, $args) {
            

            $response = AdminCompo_cl::saveSettings($compoName, $settingsModelId, $args);
            
            if( $response ) {
                return $response;
            }
        }
        
        private static function getSharedSettings($args) {
            $sharedSettings = [];

            return $sharedSettings;
        }
        

        

}
