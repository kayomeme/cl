<?php

/**
 */
class InsightsControllerBK_clfe {

    public function __construct() {

    }
    
    /*
     * for ajax call
     */
    public static function routes($action, $args) {
        $result = false;
        switch ($action) {
            case 'clfe_get_adsets_by_campaign_id':
                $result = self::getAdsetsByCampaignId($args);
                break;
        }

        return $result;
    }
    
function getCampaignData($visitsCount, $ordersCount) {
// Create a new array to hold the converted keys
$newArrayOrdersCount = array();

    // Loop through the original array
    foreach ($ordersCount as $item) {
        // Assign the value of 'campaign_id' as the key and 'orders_count' as the value
        $newArrayOrdersCount[$item['campaign_id']] = $item['orders_count'];
    }
    
    
    $campaignData = [];

    foreach ($visitsCount as $item) {
        $campaignId = $item['campaign_id'];
        $visitCount = intval($item['visits_count']);
        $campaignName = $item['campaign_name'];

        // Initialize campaign data if not already exists
        if (!isset($campaignData[$campaignId])) {
            $campaignData[$campaignId] = [
                'visit_count' => $visitCount,
                'campaign_names' => [$campaignName],
                'utm_source' => $item['utm_source']
            ];
        } else {
            // Update visit count if the campaign_id exists
            $campaignData[$campaignId]['visit_count'] += $visitCount;

            // Add unique campaign_name
            if (!in_array($campaignName, $campaignData[$campaignId]['campaign_names'])) {
                $campaignData[$campaignId]['campaign_names'][] = $campaignName;
            }
        }
    }

    // Format the result
    $result = [];
    foreach ($campaignData as $campaignId => $visitsCount) {
        $orders_count = isset( $newArrayOrdersCount[$campaignId] ) ? $newArrayOrdersCount[$campaignId] : 0;
        $visits_count  = $visitsCount['visit_count'];
        
        $rate = $visits_count > 0 ? $orders_count / $visits_count*100 : 0;
        $result[$campaignId] = [
            'campaign_id' => $campaignId,
            'visits_count' => $visits_count,
            'orders_count' => $orders_count,
            'rate' => number_format($rate, 2),
            'campaign_names' => implode(' + ', $visitsCount['campaign_names']),
            'utm_source' => $visitsCount['utm_source']
        ];
    }

    return $result;
}
    
    public function index() {
        $args = $_GET;
        
        unset( $args['campaign_id'] );
        
        if( !isset( $args['product_id'] ) ) {
            $args['product_id'] = 1;
        }
        $productTitle = get_the_title($args['product_id']);
        $productImgUrl = get_the_post_thumbnail_url($args['product_id'], 'thumbnail');
        
        $args['start_date'] = isset( $args['start_date'] )  ? date('Y-m-d H:i:s', strtotime($args['start_date'])) : date('Y-m-d H:i:s');
        $args['end_date']   = isset( $args['end_date'] )    ? date('Y-m-d H:i:s', strtotime($args['end_date'])) : date('Y-m-d H:i:s');
 
        /*
         * synchro before display the insights
         
        ProductInsights_clfe::syncroWithOrders($args['product_id']);*/
        $currentProductId = $args['product_id'];
        $settingModels = SettingsModelBK_clfe::getExistingModels($limit=20);
        $currentsettings_model_id = isset( $args['settings_model_id'] ) ? $args['settings_model_id'] : 0;
        $currentDateRange = isset( $args['date_range'] ) ? $args['date_range'] : 'today';
        $currentOrderStatus = isset( $args['status'] ) ? $args['status'] : '';
        
        $lastedProducts = ProductModelBK_clfe::getLastPosts(100);
        $productorder_status = ProductInsights_clfe::getorderStatus($args['product_id']);
        $productOrderCount = ProductInsights_clfe::getOrderCount($args);
        /*------------------------------------------------*/
        $campaignsVisitsCount = CampaignsInsightModel::getVisitsCount($args);
        $campaignsOrdersCount = CampaignsInsightModel::getOrdersCount($args);
        
        $conversionByCompaigns = $this->getCampaignData($campaignsVisitsCount, $campaignsOrdersCount);
        
       // exit();
        
        
        /*$campaign_id_visitCount = ProductInsights_clfe::getVisitCountGroupBy($args, 'campaign_id');
        $campaign_id_orderCount = ProductInsights_clfe::getOrderCountGroupBy($args, 'campaign_id');
        
        $conversionByCompaigns = [];
        
        foreach ($campaign_id_visitCount as $value) {
            $conversionByCompaigns[$value['campaign_id']] = [
                'campaign_name' => ProductInsights_clfe::getCampaignNamesByCampaignId($value['campaign_id']),
                'visits_count'  => $value['visits_count'],
                'orders_count'  => 0,
                'rate' => 0
            ];
        }

        foreach ($campaign_id_orderCount as $value) {
            $conversionByCompaigns[$value['campaign_id']]['orders_count'] = $value['orders_count'];
            $rate = $value['orders_count'] / ($conversionByCompaigns[$value['campaign_id']]['visits_count'])*100;
            $conversionByCompaigns[$value['campaign_id']]['rate'] = number_format($rate, 2);
        }*/

        $compoName = "insights";
        include MainApp_clfe::$compsPath.$compoName.'/backend/views/insights/by_campaign.php';
    }
    /*
     * 
     */
    public static function getAdsetsByCampaignId($args) {
        $compoName = "insights";
        
        $adset_id_visitCount = ProductInsights_clfe::getVisitCountGroupBy($args, 'adset_id');
        $adset_id_orderCount = ProductInsights_clfe::getOrderCountGroupBy($args, 'adset_id');
        
        $conversionByAdsets = [];
        
        foreach ($adset_id_visitCount as $value) {
            $conversionByAdsets[$value['adset_id']] = [
                'adset_name' => ProductInsights_clfe::getAdsetNamesByAdsetId($value['adset_id']),
                'visits_count'  => $value['visits_count'],
                'orders_count'  => 0,
                'rate' => 0
            ];
        }

        foreach ($adset_id_orderCount as $value) {
            $conversionByAdsets[$value['adset_id']]['orders_count'] = $value['orders_count'];
            $rate = $value['orders_count'] / ($conversionByAdsets[$value['adset_id']]['visits_count'])*100;
            $conversionByAdsets[$value['adset_id']]['rate'] = number_format($rate, 2);
        }
        
        ob_start();
        include MainApp_clfe::$compsPath.$compoName.'/backend/views/insights/ajax_call/by_adsets.php';
        $content = ob_get_contents();
        ob_get_clean();
        
        return response_clfe(1, Lang_clfe::__('Campaign adsets loaded successfully', 'clfe'), $content);
    }
    
}
