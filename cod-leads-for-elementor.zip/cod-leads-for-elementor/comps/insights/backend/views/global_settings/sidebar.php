<button tab="clfe_fb_utm_generator_tab">
    <span class="dashicons dashicons-facebook"></span>
    <?= Lang_clfe::_e('Facebook URL insights generator', 'clfe') ?>
</button>

<button tab="clfe_tiktok_utm_generator_tab">
    <?= Lang_clfe::_e('Tiktok URL insights generator', 'clfe') ?>
</button>