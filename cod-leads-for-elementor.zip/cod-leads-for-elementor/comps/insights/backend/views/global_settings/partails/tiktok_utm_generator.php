<div class="insights-generator-container">
    <div class="cl-row">
        <div class="cl-td-full">
            <div class="cl-flex-center">
                <div>
                    <label>
                        <?= Lang_cl::_e('UTM Source', 'cl') ?>
                    </label>
                </div>
                <div>
                    <input type="text" class="utm-var-value" name="utm_source" value="tiktok" disabled="disabled" />
                    <input type="hidden" class="utm-var-value" name="utm_site_id" value="__CSITE__" disabled="disabled" />
                </div>
                <div></div>
            </div>
        </div>
    </div>
    
    
    <div class="cl-row">
        <div class="cl-td-full">
            <div class="cl-flex-center">
                <div>
                    <label><?= Lang_cl::_e('utm medium', 'cl') ?></label>
                </div>
                <div>
                    <select class="utm-select-var-type" dynamic-default="social">
                        <option value="static">Static</option>
                        <option value="dynamic" selected="selected">Dynamic</option>
                    </select>
                </div>
                <div>
                    <input class="utm-var-value cl-hide" type="text" name="utm_medium" value="social" />
                    <select class="utm-select-vars">
                            <option value="video">video</option>
                            <option value="link">link</option>
                            <option value="social" >social</option>
                            <option value="organic" >organic</option>
                            <option value="cpc" >cpc</option>
                            <option value="banner" >banner</option>
                            <option value="display" >display</option>
                            <option value="retargeting" >retargeting</option>
                    </select>
                </div>
            </div>
        </div>
    </div>


    <div class="cl-row">
        <div class="cl-td-full">
            <div class="cl-flex-center">
                <div>
                    <label>
                        <?= Lang_cl::_e('Ads manager name', 'cl') ?>
                    </label>
                </div>
                <div>
                    <input class="utm-var-value" type="text" name="ad_manager_name" value="" />
                </div>
                <div></div>
            </div>
            <div class="cl-help-text">
                <?= Lang_cl::_e('The person or agency responsible for managing these ads.', 'cl') ?>
            </div>
        </div>
    </div>

    <div class="cl-row">
        <div class="cl-td-full">
            <div class="cl-flex-center">
                <div>
                    <label><?= Lang_cl::_e('Campaign name', 'cl') ?></label>
                </div>
                <div>
                    <select class="utm-select-var-type" dynamic-default="__CAMPAIGN_NAME__">
                        <option value="static">Static</option>
                        <option value="dynamic" selected="selected">Dynamic</option>
                    </select>
                </div>
                <div>
                    <input class="utm-var-value cl-hide" type="text" name="utm_campaign" value="__CAMPAIGN_NAME__" />
                    <select class="utm-select-vars">
                        <?php foreach ($tiktokUtmVars as $key => $value) { ?>
                            <option value="<?= $value ?>" <?= $value == '__CAMPAIGN_NAME__' ? 'selected="selected"' : '' ?>>
                                <?= $value ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="cl-row">
        <div class="cl-td-full">
            <div class="cl-flex-center">
                <div>
                    <label><?= Lang_cl::_e('Campaign id', 'cl') ?></label>
                </div>
                <div>
                    <select class="utm-select-var-type" dynamic-default="__CAMPAIGN_ID__">
                        <option value="static">Static</option>
                        <option value="dynamic" selected="selected">Dynamic</option>
                    </select>
                </div>
                <div>
                    <input class="utm-var-value cl-hide" type="text" name="campaign_id" value="__CAMPAIGN_ID__" />
                    <select class="utm-select-vars">
                        <?php foreach ($tiktokUtmVars as $key => $value) { ?>
                            <option value="<?= $value ?>" <?= $value == '__CAMPAIGN_ID__' ? 'selected="selected"' : '' ?>>
                                <?= $value ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
    </div>
    
    <div class="cl-row">
        <div class="cl-td-full">
            <div class="cl-flex-center">
                <div>
                    <label><?= Lang_cl::_e('Adset name', 'cl') ?></label>
                </div>
                <div>
                    <select class="utm-select-var-type" dynamic-default="__AID_NAME__">
                        <option value="static">Static</option>
                        <option value="dynamic" selected="selected">Dynamic</option>
                    </select>
                </div>
                <div>
                    <input class="utm-var-value cl-hide" type="text" name="utm_term" value="__AID_NAME__" />
                    <select class="utm-select-vars">
                        <?php foreach ($tiktokUtmVars as $key => $value) { ?>
                            <option value="<?= $value ?>" <?= $value == '__AID_NAME__' ? 'selected="selected"' : '' ?>>
                                <?= $value ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="cl-row">
        <div class="cl-td-full">
            <div class="cl-flex-center">
                <div>
                    <label><?= Lang_cl::_e('Adset id', 'cl') ?></label>
                </div>
                <div>
                    <select class="utm-select-var-type" dynamic-default="__AID__">
                        <option value="static">Static</option>
                        <option value="dynamic" selected="selected">Dynamic</option>
                    </select>
                </div>
                <div>
                    <input class="utm-var-value cl-hide" type="text" name="adset_id" value="__AID__" />
                    <select class="utm-select-vars">
                        <?php foreach ($tiktokUtmVars as $key => $value) { ?>
                            <option value="<?= $value ?>" <?= $value == '__AID__' ? 'selected="selected"' : '' ?>>
                                <?= $value ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="cl-row">
        <div class="cl-td-full">
            <div class="cl-flex-center">
                <div>
                    <label><?= Lang_cl::_e('Ad name', 'cl') ?></label>
                </div>
                <div>
                    <select class="utm-select-var-type" dynamic-default="__CID_NAME__">
                        <option value="static">Static</option>
                        <option value="dynamic" selected="selected">Dynamic</option>
                    </select>
                </div>
                <div>
                    <input class="utm-var-value cl-hide" type="text" name="utm_content" value="__CID_NAME__" />
                    <select class="utm-select-vars">
                        <?php foreach ($tiktokUtmVars as $key => $value) { ?>
                            <option value="<?= $value ?>" <?= $value == '__CID_NAME__' ? 'selected="selected"' : '' ?>>
                                <?= $value ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="cl-row">
        <div class="cl-td-full">
            <div class="cl-flex-center">
                <div>
                    <label><?= Lang_cl::_e('Ad id', 'cl') ?></label>
                </div>
                <div>
                    <select class="utm-select-var-type" dynamic-default="__CID__">
                        <option value="static">Static</option>
                        <option value="dynamic" selected="selected">Dynamic</option>
                    </select>
                </div>
                <div>
                    <input class="utm-var-value cl-hide" type="text" name="ad_id" value="__CID__" />
                    <select class="utm-select-vars">
                        <?php foreach ($tiktokUtmVars as $key => $value) { ?>
                            <option value="<?= $value ?>" <?= $value == '__CID__' ? 'selected="selected"' : '' ?>>
                                <?= $value ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
    </div>
    
    <div class="cl-row">
        <div class="cl-td-full">
            <div class="cl-flex-center">
                <div>
                    <label><?= Lang_cl::_e('The type of ad', 'cl') ?></label>
                </div>
                <div>
                    <select class="utm-select-var-type" dynamic-default="__CTYPE__">
                        <option value="static">Static</option>
                        <option value="dynamic" selected="selected">Dynamic</option>
                    </select>
                </div>
                <div>
                    <input class="utm-var-value cl-hide" type="text" name="ad_type" value="__CTYPE__" />
                    <select class="utm-select-vars">
                        <?php foreach ($tiktokUtmVars as $key => $value) { ?>
                            <option value="<?= $value ?>" <?= $value == '__CTYPE__' ? 'selected="selected"' : '' ?>>
                                <?= $value ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="cl-row">
        <div class="cl-td-full">
            <div class="cl-flex-center">
                <div>
                    <label><?= Lang_cl::_e('Ad placement', 'cl') ?></label>
                </div>
                <div>
                    <select class="utm-select-var-type" dynamic-default="__PLACEMENT__">
                        <option value="static">Static</option>
                        <option value="dynamic" selected="selected">Dynamic</option>
                    </select>
                </div>
                <div>
                    <input class="utm-var-value cl-hide" type="text" name="placement" value="__PLACEMENT__" />
                    <select class="utm-select-vars">
                        <?php foreach ($tiktokUtmVars as $key => $value) { ?>
                            <option value="<?= $value ?>" <?= $value == '__PLACEMENT__' ? 'selected="selected"' : '' ?>>
                                <?= $value ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
    </div>
   

    <input type="hidden" class="utm-var-value" name="utm_site_id" value="__CSITE__" disabled="disabled" />

    <div class="cl-row">
        <div class="cl-th-full">
            <label>
                <?= Lang_cl::_e('Tiktok URL insights template', 'cl') ?>
            </label>
            <button class="button button-primary cl-copy-textarea-text" attachedTextarea="tiktok_utm_code">
                <?= Lang_cl::_e('Copy the generated url', 'cl') ?>
            </button>
        </div>
        <div class="cl-td-full">
            <textarea rows="4" name="tiktok_utm_code"><?= $settings['tiktok_utm_code'] ?></textarea>
            <br/><br/>
            <div class="cl-alert cl-alert-info">
                <span><?= Lang_cl::_e('Copy the text above and set it in Facebook Tracking box , see the screenshot below for more infos', 'cl') ?></span>
                <div class="cl-img-container">
                    <img src="img/tiktok_utm_example.png" />
                </div>
            </div>
        </div>
    </div>
</div>