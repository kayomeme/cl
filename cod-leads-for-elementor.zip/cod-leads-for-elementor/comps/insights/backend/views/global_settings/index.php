<div id="cl_fb_utm_generator_tab" class="cl-single-tab">
    <?php include 'partails/fb_utm_generator.php'; ?>
</div>
<div id="cl_tiktok_utm_generator" class="cl-single-tab">
    <?php include 'partails/tiktok_utm_generator.php'; ?>
</div>
