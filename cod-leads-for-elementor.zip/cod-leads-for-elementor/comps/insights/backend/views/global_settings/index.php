<div id="clfe_fb_utm_generator_tab" class="clfe-single-tab">
    <?php include 'partails/fb_utm_generator.php'; ?>
</div>
<div id="clfe_tiktok_utm_generator" class="clfe-single-tab">
    <?php include 'partails/tiktok_utm_generator.php'; ?>
</div>
