
    <table id="conversion-rate-by-adsets" class="insight-table tablesearch-table tablesort">
        <thead>
            <tr>
                <th data-tablesort-type="string"><?= Lang_cl::_e('Adset ID', 'cl') ?></th>
                <th data-tablesort-type="string"><?= Lang_cl::_e('Adset name', 'cl') ?></th>
                <th data-tablesort-type="int"><?= Lang_cl::_e('Total visits', 'cl') ?></th>
                <th data-tablesort-type="int"><?= Lang_cl::_e('Total orders', 'cl') ?></th>
                <th data-tablesort-type="int"><?= Lang_cl::_e('Conversion rate', 'cl') ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($conversionByAdsets as $adset_id => $adset) { ?>
            <tr>
                <td data-tablesearch-text="<?= $adset_id ?>"><?= $adset_id ?></td>
                <td data-tablesearch-text="<?= $adset['adset_name'] ?>"><?= $adset['adset_name'] ?></td>
                <td data-tablesearch-text="<?= $adset['visits_count'] ?>"><?= $adset['visits_count'] ?></td>
                <td data-tablesearch-text="<?= $adset['orders_count'] ?>"><?= $adset['orders_count'] ?></td>
                <td data-tablesearch-text="<?= $adset['rate'] ?>"><?= $adset['rate'] ?>%</td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
    
    
