<div class="insight-filter-section">
    <form method="get" action="" id="clfe_insight_campaign">
        <input type="hidden" name="page" value="<?=  $args['page'] ?>" />
          
        <div class="clfe-flex-center">
            <div>
                <label><?= Lang_clfe::_e('Select date range', 'clfe') ?></label> :
                <select id="dateRange" name="date_range">
                    <option value="today" <?= $currentDateRange == 'today' ? 'selected="selected"' : '' ?>>Today</option>
                    <option value="yesterday" <?= $currentDateRange == 'yesterday' ? 'selected="selected"' : '' ?>>Yesterday</option>
                    <option value="last7days" <?= $currentDateRange == 'last7days' ? 'selected="selected"' : '' ?>>Last 7 Days</option>
                    <option value="lastMonth" <?= $currentDateRange == 'lastMonth' ? 'selected="selected"' : '' ?>>Last Month</option>
                </select>
            </div>
            <div>
              <label><?= Lang_clfe::_e('Start date', 'clfe') ?></label> : 
              <input type="datetime-local" name="start_date" placeholder="Date début" value="<?= isset( $_REQUEST['start_date'] ) ? $_REQUEST['start_date'] : '' ?>" />
            </div>
            <div>
              <label><?= Lang_clfe::_e('End date', 'clfe') ?> : </label>
              <input type="datetime-local" name="end_date" placeholder="Date Fin" value="<?= isset( $_REQUEST['end_date'] ) ? $_REQUEST['end_date'] : '' ?>" />
            </div>
        </div>
        <div class="clfe-flex-center">
            <div>
                <label>
                    <?= Lang_clfe::__('Settings model', 'clfe') ?> :
                </label>

                <select name="settings_model_id">
                    <option value="0" <?= $currentsettings_model_id == 0 ? 'selected="selected"' : '' ?>>
                        <?= Lang_clfe::_e('Default settings', 'clfe') ?>
                    </option>
                    <?php foreach ($settingModels as $settingModel) { ?>
                    <option value="<?= $settingModel->id ?>"  <?= $currentsettings_model_id == $settingModel->id ? 'selected="selected"' : '' ?>>
                            <?= $settingModel->name ?>
                    </option>
                    <?php } ?>
                </select> 
            </div>
            <div>
                <label><?= Lang_clfe::_e('Product', 'clfe') ?></label>
                <select name="product_id">
                    <option value=""><?= Lang_clfe::_e('Select another product.', 'clfe') ?></option>
                    <?php foreach ($lastedProducts as $product) { ?>
                    <option value="<?= $product->ID ?>" <?= $currentProductId == $product->ID ? 'selected="selected"' : '' ?>>
                        <?= $product->post_title ?>
                    </option>
                    <?php } ?>
                </select>
            </div>
            <div>
                <label><?= Lang_clfe::_e('Order status', 'clfe') ?></label>
                <select name="status">
                    <option value=""><?= Lang_clfe::_e('Select order status', 'clfe') ?></option>
                    <?php foreach ($productorder_status as $ob) { ?>
                    <option value="<?= $ob->status ?>" <?= $currentOrderStatus == $ob->status ? 'selected="selected"' : '' ?>>
                        <?= $ob->status ?>
                    </option>
                    <?php } ?>
                </select>
            </div>
        </div>
        <div class="clfe-flex-center">
            <div>
                <input type="submit" value="<?= Lang_clfe::_e('Filter your search results', 'clfe') ?>" class="button button-primary button-large" />
            </div>
        </div>
          
    </form>
</div> 

<div class="insight-table-wrap">
    
    <div class="insight-card-product">
        <div class="insight-img-product">
            <img src="<?= $productImgUrl ?>" />
        </div>
        <div class="insight-product-infos">
            <p>
                <strong> <?= $productTitle; ?>  </strong> : <span class="selected-status"><?= isset( $args['status'] ) ? $args['status'] : '' ?></span>
            </p>
            <p class="insight-product-totalOrder">
                <?= Lang_clfe::_e('Total orders : ', 'clfe') ?><?= $productOrderCount ?>
            </p>
        </div>
    </div>
    
    
    <h2><?= Lang_clfe::_e('Conversion rate by Campaigns', 'clfe') ?></h2>
    <input type="text" class="tablesearch-input" data-tablesearch-table="#conversion-rate-by-campaigns" placeholder="<?= Lang_clfe::_e('Tap your search here', 'clfe') ?>">
    <table id="conversion-rate-by-campaigns" class="insight-table tablesearch-table tablesort">
        <thead>
            <tr>
                <th data-tablesort-type="string"><?= Lang_clfe::_e('Source', 'clfe') ?></th>
                <th data-tablesort-type="string"><?= Lang_clfe::_e('Campaign ID', 'clfe') ?></th>
                <th data-tablesort-type="string"><?= Lang_clfe::_e('Campaign name', 'clfe') ?></th>
                <th data-tablesort-type="int"><?= Lang_clfe::_e('Total visits', 'clfe') ?></th>
                <th data-tablesort-type="int"><?= Lang_clfe::_e('Total orders', 'clfe') ?></th>
                <th data-tablesort-type="int"><?= Lang_clfe::_e('Conversion rate', 'clfe') ?></th>
                <th><?= Lang_clfe::_e('Actions', 'clfe') ?></th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $detailAdsetsPopups = "";
            foreach ($conversionByCompaigns as $campaign_id => $campaign) { 
                $popupTitle = Lang_clfe::_e('Conversion rate by Adsets related to ', 'clfe').' : '.$campaign['campaign_names'];
                $detailAdsetsPopups = $detailAdsetsPopups.'<div id="'.$campaign_id.'" campaign_name="'.$popupTitle.'"> </div>';
                
                ?>
            <tr>
                <td data-tablesearch-text="<?= $campaign['utm_source'] ?>"><?= $campaign['utm_source'] ?></td>
                <td data-tablesearch-text="<?= $campaign_id ?>"><?= $campaign_id ?></td>
                <td data-tablesearch-text="<?= $campaign['campaign_names'] ?>"><?= $campaign['campaign_names'] ?></td>
                <td data-tablesearch-text="<?= $campaign['visits_count'] ?>"><?= $campaign['visits_count'] ?></td>
                <td data-tablesearch-text="<?= $campaign['orders_count'] ?>"><?= $campaign['orders_count'] ?></td>
                <td data-tablesearch-text="<?= $campaign['rate'] ?>"><?= $campaign['rate'] ?>%</td>
                <td>
                    <input type="submit" value="<?= Lang_clfe::_e('Load adsets', 'clfe') ?>" campaign_id="<?= $campaign_id ?>" class="button button-primary button-large row-campaign-id">
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table> 
</div>

<div id="clfe_get_adsets_by_campaign_id">
    
    <input type="text" name="campaign_id" />
    <input type="text" name="start_date" value="<?= isset( $_REQUEST['start_date'] ) ? $_REQUEST['start_date'] : '' ?>" />
    <input type="text" name="end_date" value="<?= isset( $_REQUEST['end_date'] ) ? $_REQUEST['end_date'] : '' ?>" />
    <input type="text" name="product_id" value="<?= $currentProductId ?>" />
    <input type="text" name="status" value="<?= $currentOrderStatus ?>" />
    <input type="text" name="settings_model_id" value="<?= $currentsettings_model_id ?>" />
    
    
    <div class="clfe-user-fedback">
        <div class="clfe-msg_box">
            <div class="clfe-wait_msg"></div>
            <div class="alert"></div>
        </div>
    </div>
</div>

<div style="display: none">
<?= $detailAdsetsPopups ?>
</div>