<?php

/**
 * 
 */
class ProductInsights_cl {
    /*
     * 
     */
    public static function getVisitCountGroupBy($args, $groupby) {
        global $wpdb;

        $insights         = $wpdb->prefix. 'insights';
        

        $where = " where product_id=".$args['product_id'];
        
        if( isset( $args['campaign_id'] )  ) {
            $where = $where." and campaign_id =".$args['campaign_id'];
        }
        
        $where = $where." and created_at >= '".$args['start_date']."'";
        $where = $where." and created_at <= '".$args['end_date']."'";
        
        /*if( isset( $args['status'] ) && !empty($args['status']) ) {
            $where = $where." and status = '".$args['status']."'";
        }*/
        
        $where = $where." and ".$groupby." != ''";
        
        $query = "select count(*) as 'visits_count', $groupby from ".$insights.$where." group by $groupby";
        
        $result = $wpdb->get_results($query, ARRAY_A );
        
        return $result;
    }
    
    /*
     * 
     */
    public static function getOrderCountGroupBy($args, $groupby) {
        global $wpdb;

        $insights         = $wpdb->prefix. 'insights';
        

        $where = " where order_id > 0 and product_id=".$args['product_id'];
        
        if( isset( $args['campaign_id'] )  ) {
            $where = $where." and campaign_id =".$args['campaign_id'];
        }
        
        $where = $where." and created_at >= '".$args['start_date']."'";
        $where = $where." and created_at <= '".$args['end_date']."'";
        
        if( isset( $args['status'] ) && !empty($args['status']) ) {
            $where = $where." and status = '".$args['status']."'";
        }
        
        $where = $where." and ".$groupby." != ''";
        
        $query = "select count(*) as 'orders_count', $groupby from ".$insights.$where." group by $groupby";
        
        $result = $wpdb->get_results($query, ARRAY_A );
        
        return $result;
    }
    
    
    public static function getOrderCount($args) {
        global $wpdb;
        $orderTable         = $wpdb->prefix. 'cl_orders';
        
        $where = "where 1";
        
        if( isset( $args['product_id'] ) ) {
            $where = $where." and product_id=".$args['product_id'];
        }

        if( isset( $args['status'] ) && !empty($args['status']) ) {
            $where = $where." and status = '".$args['status']."'";
        }
        
        if( isset( $args['start_date'] ) && isset( $args['end_date'] ) ) {
            $where = $where." and created_at >= '".$args['start_date']."'";
            $where = $where." and created_at <= '".$args['end_date']."'";
        }

        
        $query = "SELECT DISTINCT count(id) FROM {$orderTable} ".$where;
        return $wpdb->get_var($query);
        
        /*$query = "SELECT DISTINCT count(id) FROM {$orderTable} WHERE status = '%s' AND created_at >= '%s' AND created_at < '%s' AND product_id = %d";
        return $wpdb->get_var( $wpdb->prepare($query, $status, $args['start_date'], $args['end_date'], $product_id ) );*/
    }
    
    public static function getCampaignNamesByCampaignId($campaign_id) {
        global $wpdb;

        $insightsTable         = $wpdb->prefix. 'insights';
        
        $query = "select distinct campaign_name from {$insightsTable} where campaign_id='{$campaign_id}'";
        $result = $wpdb->get_results($query, ARRAY_A );
        
        $stringResu = "";
        foreach ($result as $value) {
            $stringResu = $stringResu.$value['campaign_name'].' | ';
        }
        
        return $stringResu;
    }
    
    public static function getAdsetNamesByAdsetId($adset_id) {
        global $wpdb;

        $insightsTable         = $wpdb->prefix. 'insights';
        
        $query = "select distinct adset_name from {$insightsTable} where adset_id='{$adset_id}'";
        $result = $wpdb->get_results($query, ARRAY_A );
        
        $stringResu = "";
        foreach ($result as $value) {
            $stringResu = $stringResu.$value['adset_name'].' | ';
        }
        
        return $stringResu;
    }
    
    public static function getorderStatus($productID) {
        global $wpdb;

        $insightsTable         = $wpdb->prefix. 'insights';
        
        $query = "select distinct status from {$insightsTable} where product_id={$productID}";
        $result = $wpdb->get_results($query );
        
        
        return $result;
    }
    /*
     * 
     *
    public static function syncroWithOrders($productID) {
        global $wpdb;
        
        $prefixe            = $wpdb->prefix.'cl_';
        $insightsTable      = $prefixe. 'insights';
        $orderTable         = $prefixe. 'orders';

        $limit = 100;
        
        $query = "SELECT id,insight_id,status,total,product_qty,currency_code,phone,city,country FROM {$orderTable} where product_id={$productID} and insight_is_sync=0 ORDER BY ID DESC LIMIT {$limit}";
        $orders = $wpdb->get_results($query);

 
        if( is_array($orders) ) {
            foreach ($orders as $order) {
                $wpdb->query( "update {$insightsTable} set order_id={$order->id}, status='{$order->status}' where id={$order->insight_id} ;" );
                $wpdb->query( "update {$orderTable} set insight_is_sync=1 where id={$order->id} and insight_is_sync=0" );
            }
        }

    }*/
    
}
