(function( $ ) {
	'use strict';

    $(document).ready(function() {
        
            /*----------- insights gloabl settings---------------*/
            $(".utm-select-var-type").on('change', function() {
                var selectType = $(this).val();
                if( selectType === 'static' ) {
                    $(this).closest('.clfe-row').find('select.utm-select-vars').addClass('clfe-hide');
                    $(this).closest('.clfe-row').find('input.utm-var-value').removeClass('clfe-hide');
                    $(this).closest('.clfe-row').find('input.utm-var-value').val( $(this).attr('dynamic-default') ); 
                } else {
                    $(this).closest('.clfe-row').find('input.utm-var-value').addClass('clfe-hide');
                    $(this).closest('.clfe-row').find('select.utm-select-vars').removeClass('clfe-hide'); 
                }
            } );
            $('.utm-select-vars').on('change', function() {
                $(this).parent().find('input.utm-var-value').val( $(this).val() );
                $(this).closest(".insights-generator-container").find("textarea").val(generateInsightsUrl());
            } );
            
            $('.utm-var-value').on( "input", function() {
                $(this).closest(".insights-generator-container").find("textarea").val(generateInsightsUrl());
            } );
            
            function generateInsightsUrl () {
                var tabID = "clfe_"+currentUrlParms.get('tab');
                var urlGenerated = "";
                $("#"+tabID+" .insights-generator-container .utm-var-value").each(function (index, node) {
                    urlGenerated = urlGenerated + "&" + $(this).attr('name')+"="+node.value;
                });

                return urlGenerated.replace("&utm_source", "utm_source");
            }
            /*--------insights gloabl settings---------*/

    });


})( jQuery );