(function( $ ) {
	'use strict';

    $(document).ready(function() {
        
            /*----------- insights gloabl settings---------------*/
            $(".utm-select-var-type").on('change', function() {
                var selectType = $(this).val();
                if( selectType === 'static' ) {
                    $(this).closest('.cl-row').find('select.utm-select-vars').addClass('cl-hide');
                    $(this).closest('.cl-row').find('input.utm-var-value').removeClass('cl-hide');
                    $(this).closest('.cl-row').find('input.utm-var-value').val( $(this).attr('dynamic-default') ); 
                } else {
                    $(this).closest('.cl-row').find('input.utm-var-value').addClass('cl-hide');
                    $(this).closest('.cl-row').find('select.utm-select-vars').removeClass('cl-hide'); 
                }
            } );
            $('.utm-select-vars').on('change', function() {
                $(this).parent().find('input.utm-var-value').val( $(this).val() );
                $(this).closest(".insights-generator-container").find("textarea").val(generateInsightsUrl());
            } );
            
            $('.utm-var-value').on( "input", function() {
                $(this).closest(".insights-generator-container").find("textarea").val(generateInsightsUrl());
            } );
            
            function generateInsightsUrl () {
                var tabID = "cl_"+currentUrlParms.get('tab');
                var urlGenerated = "";
                $("#"+tabID+" .insights-generator-container .utm-var-value").each(function (index, node) {
                    urlGenerated = urlGenerated + "&" + $(this).attr('name')+"="+node.value;
                });

                return urlGenerated.replace("&utm_source", "utm_source");
            }
            /*--------insights gloabl settings---------*/

    });


})( jQuery );