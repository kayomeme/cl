(function( $ ) {
	'use strict';

    $(document).ready(function() {
        
        /*
         * save global settings
         */
        $('.row-campaign-id').on('click', function(ev) {
            ev.preventDefault();
            
            const campaign_id = $(this).attr("campaign_id");
            $("input[name=campaign_id]").val(campaign_id);
            
            const clfe_controller   = 'clfe_insights';
            const clfe_action       = 'clfe_get_adsets_by_campaign_id';

            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action);

            // Wait for the custom event before accessing the modified variable
            document.addEventListener(clfe_action+'lastResponse', function (event) {

                if( jsArgs.lastResponse.code == 1 ) {
                    const currentRowID = $("input[name=campaign_id]").val();
                    $("#"+currentRowID).html(jsArgs.lastResponse.res);

                    $("#"+currentRowID).dialog({
                        title: $("#"+currentRowID).attr('campaign_name'),
                        resizable: true,
                        height: "auto",
                        width: "auto",
                        modal: true,
                        buttons: {
                            "Cancel": function() {
                                $( this ).dialog( "close" );
                            }
                        },
                        close: function() { 
                            $( this ).dialog( "destroy" );
                        }
                    });
                    
                    
                }
            });

        }); 
        
        $("#dateRange").change(function() {
            var today = new Date();
            var yesterday = new Date(today.getTime() - (1 * 24 * 60 * 60 * 1000));
            var lastWeek = new Date(today.getTime() - (7 * 24 * 60 * 60 * 1000));
            var firstDayLastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
            var lastDayLastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 0);

            var selectedRange = $(this).val();

            function formatDate(currentDate,h,m,s) {
                /*var dateForDateTimeLocal = currentDate.getFullYear() +
                "-" + (((currentDate.getMonth())+1)<10?'0':'') + ((currentDate.getMonth())+1) +
                "-" + (currentDate.getDate()<10?'0':'') + currentDate.getDate() +
                "T" + (currentDate.getHours()<10?'0':'') + currentDate.getHours() +
                ":" + (currentDate.getMinutes()<10?'0':'') + currentDate.getMinutes() +
                ":" + (currentDate.getSeconds()<10?'0':'') + currentDate.getSeconds();*/
                var dateForDateTimeLocal = currentDate.getFullYear() +
                "-" + (((currentDate.getMonth())+1)<10?'0':'') + ((currentDate.getMonth())+1) +
                "-" + (currentDate.getDate()<10?'0':'') + currentDate.getDate() +
                "T" + h +
                ":" + m +
                ":" + s;   
                return dateForDateTimeLocal;
            }

            switch (selectedRange) {
                case "today":
                    $("input[name=start_date]").val(formatDate(today, '00','00','00'));
                    $("input[name=end_date]").val(formatDate(today, '23','59','00'));
                    break;
                case "yesterday":
                    $("input[name=start_date]").val(formatDate(yesterday, '00','00','00'));
                    $("input[name=end_date]").val(formatDate(yesterday, '23','59','00'));
                    break;
                case "last7days":
                    $("input[name=start_date]").val(formatDate(lastWeek, '00','00','00'));
                    $("input[name=end_date]").val(formatDate(today, '23','59','00'));
                    break;
                case "lastMonth":
                    $("input[name=start_date]").val(formatDate(firstDayLastMonth, '00','00','00'));
                    $("input[name=end_date]").val(formatDate(lastDayLastMonth, '23','59','00'));
                    break;
            }
        });
    });


})( jQuery );