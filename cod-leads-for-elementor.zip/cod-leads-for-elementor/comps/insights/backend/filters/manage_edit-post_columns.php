<?php

$columns['product_insight'] = Lang_clfe::__('Product insights', 'clfe');

