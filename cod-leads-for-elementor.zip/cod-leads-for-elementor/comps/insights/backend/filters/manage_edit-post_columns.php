<?php

$columns['product_insight'] = Lang_cl::__('Product insights', 'cl');

