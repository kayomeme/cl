<?php
    switch ( $column ) {
        case 'product_insight' : // This has to match to the defined column in function above
            $startDate = date('Y-m-d 00:00:01');
            $endDate = date('Y-m-d 23:59:00');
            $insightLink = get_site_url()."/wp-admin/admin.php?page=cl_insights&product_id=".$post_id.'&start_date='.$startDate.'&end_date='.$endDate;
            echo "<a target='_blank' href='".$insightLink."'>".Lang_cl::__('Insight page', 'cl')."</a>";
            break;
    }
