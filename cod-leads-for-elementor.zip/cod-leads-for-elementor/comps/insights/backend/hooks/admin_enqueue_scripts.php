<?php
if( isset($_REQUEST['page']) && $_REQUEST['page'] == 'clfe_insights' ) {
    wp_enqueue_style(MainApp_clfe::$assetsPrefix.$hook['compName'], MainApp_clfe::$compsUrl.$hook['compName']. '/backend/assets/css/insights_bk.css', [], $assetsVersion );
    wp_enqueue_script(MainApp_clfe::$assetsPrefix.$hook['compName'], MainApp_clfe::$compsUrl.$hook['compName']. '/backend/assets/js/insights_bk.js', array( 'jquery'), $assetsVersion );
}

if( isset($_REQUEST['page']) && $_REQUEST['page'] == 'clfe_global_settings' && isset($_REQUEST['compo']) && $_REQUEST['compo'] == 'insights' ) {
    wp_enqueue_script('insights_settings_bk_js', MainApp_clfe::$compsUrl.$hook['compName']. '/backend/assets/js/insights_settings_bk.js', [], $assetsVersion );
    wp_enqueue_style('insights_settings_bk_css', MainApp_clfe::$compsUrl.$hook['compName']. '/backend/assets/css/insights_settings_bk.css', [], $assetsVersion );
}
