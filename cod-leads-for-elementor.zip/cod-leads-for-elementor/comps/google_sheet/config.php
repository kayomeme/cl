<?php

/**
 * general
 */
return array(
    'setting' => [
        'sheet_active' => 'yes',
        'sheet_deployment_id' => '',
        'sheet_web_app_url' => '',
        'sheet_columns' => '{"elements":{"0":{"col_name":"Order status","col_value":"status"},"1":{"col_name":"Order date","col_value":"created_at"},"2":{"col_name":"Full name","col_value":"full_name"},"3":{"col_name":"Phone","col_value":"phone"},"4":{"col_name":"Quantity","col_value":"product_qty"},"5":{"col_name":"City","col_value":"city"},"6":{"col_name":"address_1","col_value":"address_1"},"7":{"col_name":"Product","col_value":"product_title_with_options"},"8":{"col_name":"Note","col_value":"customer_note"},"9":{"col_name":"Total","col_value":"total"},"10":{"col_name":"Product url","col_value":"product_url"},"11":{"col_name":"Prodcut sku","col_value":"sku"},"12":{"col_name":"Order ID","col_value":"order_id"}}}',
        'sheet_head_bg_color' => '#ffffff',
        'sheet_head_font_color' => '#000000',
        'sheet_row_bg_color' => '#ffffff',
        'sheet_row_font_color' => '#000000',
        'insert_new_row_at' => 'add_row_to_top',
        'sheet_name' => 'first_sheet',
    ],
    'lang' => [
    ],
    'style' => [
    ]
);
