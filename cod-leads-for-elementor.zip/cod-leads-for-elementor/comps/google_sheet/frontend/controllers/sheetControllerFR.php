<?php
/**
 */
class SheetControllerFR_cl {

    public static function submitOrderDatas($args) {
        $orderData = self::validateOrderData($args);
        
        $orderData['total_with_currency'] = $orderData['total'].' '.$orderData['currency_code'];
        $orderData['product_price_with_currency'] = $orderData['product_price'].' '.$orderData['currency_code'];
        
        $product_title_with_options = $orderData['product_title'];
        if( isset( $orderData['variations_text'] ) ) {
            $product_title_with_options = $orderData['product_title'].' - '.$orderData['variations_text'];
        }
        if( isset( $orderData['qtyoffer_title'] ) ) {
            $product_title_with_options = $product_title_with_options.' - '.$orderData['qtyoffer_title'];
        }
        $orderData['product_title_with_options'] = $product_title_with_options;

        $sheetSettings  = PublicCompo_cl::getSettingsForProduct('google_sheet', $orderData['product_id'], $orderData['settings_model_id']);
        
        if( empty( $sheetSettings['sheet_web_app_url'] ) ) {
            return response_cl(0, Lang_cl::__('Google sheet model setting url is empty', 'cl'), null);
        }
        
        $url                = $sheetSettings['sheet_web_app_url'];
        $registredColumns   = jsonDecode_cl($sheetSettings['sheet_columns']);
        $sheetColValues     = self::setColumnValue($registredColumns, $orderData);

        // action => modify_header / add_row_to_top / add_row_to_bottom
        //$data = [  ];
        $data [] = [
            'action' => $sheetSettings['insert_new_row_at'],
            'sheet_name' => $sheetSettings['sheet_name'],
            'sheet_row_bg_color' => $sheetSettings['sheet_head_bg_color'],
            'sheet_row_font_color' => $sheetSettings['sheet_head_font_color'],
            'site_url' => get_site_url(),
        ];

        $data [] = array_values($sheetColValues);
        $response = SheetUtils_cl::sendCurlPost($url, $data);  
               
        return $response;
    }
    /*
     * return array
     */
    private static function validateOrderData(array $args) {
        $orderData = isset($args['order_data']) ? json_decode(stripslashes($args['order_data']), true) : '';

        if( !isset($orderData['total']) ) {
            return response_cl(0, Lang_cl::__('Google sheet datas not exist', 'cl'), null);
        }
        
        return $orderData;
    }
    /*
     * 
     */
    private static function setColumnValue($registredColumns, $orderData) {

        $sheetColValues = [];
        
        if( isset( $registredColumns['elements'] ) && !empty($registredColumns['elements']) ) {
            foreach ($registredColumns['elements'] as $value) {
                if( isset( $value['col_name'] ) && isset( $value['col_value'] ) ) {
                    $sheetColValues[] = isset( $orderData[$value['col_value']] ) ? $orderData[$value['col_value']] : ""; 
                }
            }
        }
        
        return $sheetColValues;
    }
    
}
