(function( $ ) {
    //'use strict';

    googleSheet_clfe = {
        send: function (jsArgs, orderData, cartProducts) {
            orderData['product_slug'] = jsProduct.slug;
            orderData['product_url'] = jsProduct.short_url;
            orderData['insight_order_source_infos'] = $("input[name=insight_order_source_infos]").val();
            orderData['insight_user_location'] = $("input[name=insight_user_location]").val();



            var formData = [];
            formData.push({ "name": "action", "value": jsArgs.ajax_public_action });
            formData.push({ "name": "clfe_action_name", "value": 'send_to_googlesheet' });
            formData.push({ "name": "order_data", "value": JSON.stringify(orderData) });

            // Add cart products to form data
            formData.push({ "name": "cart_products", "value": JSON.stringify(cartProducts) });

            jQuery.ajax({
                url: jsArgs.ajax_url, // Here goes our WordPress AJAX endpoint.
                type: 'post',
                data: formData,
                success: function (data) {
                    // You can craft something here to handle the message return
                    if (data === '') { var data = '{"code":0,"msg":"Undefined error try again","res":null}'; }

                    var extract_data = data.match(/{"code"(.*)}/).pop();
                    extract_data = '{"code"' + extract_data + '}';
                    var response = jQuery.parseJSON(extract_data);

                    if (response.code === '1') {
                    } else {
                    }
                },
                fail: function (err) {
                    // You can craft something here to handle an error if something goes wrong when doing the AJAX request.
                    console.log(" Error undefined try again " + err);
                }
            });
        }
    };
})( jQuery );