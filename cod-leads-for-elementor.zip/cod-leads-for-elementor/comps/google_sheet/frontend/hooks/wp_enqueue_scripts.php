<?php
//$hook['compName']
wp_enqueue_script( 'cl_google_sheet_public_js', MainApp_cl::$compsUrl. 'google_sheet/frontend/assets/js/google_sheet.js', array( 'jquery' ), MainApp_cl::$assetsVersion );
