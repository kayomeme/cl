<?php
//$hook['compName']
wp_enqueue_script( 'clfe_google_sheet_public_js', MainApp_clfe::$compsUrl. 'google_sheet/frontend/assets/js/google_sheet.js', array( 'jquery' ), MainApp_clfe::$assetsVersion );
