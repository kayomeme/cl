<?php
/**
 * Description of GoogleSheet_clfe
 *
 * @author GIGABYTE
 */
class SheetUtils_clfe {
    
    public static function orderVars() {
        return [ 
            'order_id'                    => Lang_clfe::__('Order ID', 'clfe'), 
            'currency_code'         => Lang_clfe::__('currency code', 'clfe'),
            'currency_label'        => Lang_clfe::__('currency label', 'clfe'), 
            'total'                 => Lang_clfe::__('Order total', 'clfe'),
            'total_with_currency'   => Lang_clfe::__('Order total with currency', 'clfe'),
            'shipping_fees'         => Lang_clfe::__('shipping fees', 'clfe'),
            'status'          => Lang_clfe::__('Order status', 'clfe'),
            'created_at'            => Lang_clfe::__('Order date', 'clfe'),
            'insight_type'          => Lang_clfe::__('Order source', 'clfe'),
            'product_id'            => Lang_clfe::__('Product ID', 'clfe'), 
            'product_title'         => Lang_clfe::__('Product title', 'clfe'),
            'product_title_with_options'         => Lang_clfe::__('Product title & order Options', 'clfe'),
            'product_slug'          => Lang_clfe::__('Product slug', 'clfe'),
            'product_qty'           => Lang_clfe::__('Product quantity', 'clfe'),
            'product_url'           => Lang_clfe::__('Product url', 'clfe'),
            'product_price'         => Lang_clfe::__('Product price', 'clfe'),
            'product_price_with_currency'         => Lang_clfe::__('Product price with currency', 'clfe'),
            'regular_price'         => Lang_clfe::__('Product regular price', 'clfe'),
            'sale_price'            => Lang_clfe::__('Product sale price', 'clfe'),
            'sku'                   => Lang_clfe::__('Product SKU', 'clfe'),
            'full_name'             => Lang_clfe::__('Customer full name', 'clfe'),
            'first_name'            => Lang_clfe::__('Customer first name', 'clfe'),
            'last_name'             => Lang_clfe::__('Customer last name', 'clfe'),
            'city'                  => Lang_clfe::__('Customer city', 'clfe'),
            'address_1'                => Lang_clfe::__('Customer address 1', 'clfe'),
            'phone'                 => Lang_clfe::__('Customer phone', 'clfe'),
            'email'                 => Lang_clfe::__('Customer email', 'clfe'),
            'customer_note'                 => Lang_clfe::__('Customer note', 'clfe'),
            'variations_text'       => Lang_clfe::__('Product variations', 'clfe'),
            'variations_total_fees'       => Lang_clfe::__('Variations Total fees', 'clfe'),
            'offer_title'               => Lang_clfe::__('Quantity offer title', 'clfe'),
            'offer_value'               => Lang_clfe::__('Quantity offer value', 'clfe'),
            'qty_total_offer_value'         => Lang_clfe::__('Quantity total offer value', 'clfe'),
            'insight_order_source_infos' => Lang_clfe::__('Order source infos', 'clfe'),
            'insight_user_location' => Lang_clfe::__('Customer detected location', 'clfe'),
            'ip_address'            => Lang_clfe::__('Customer ip address', 'clfe'),
            'user_agent'            => Lang_clfe::__('Customer user_agent', 'clfe'),
            'none'            => Lang_clfe::__('Empty value', 'clfe'),
        ];
        
        //`phone`, `city`, `full_name`, `product_id`, `currency`, `regular_price`, `sale_price`, `sku`, `shipping_fees`, `shipping_label`, `shipping_title`
    }
    /*
     * 
     */
    public static function sendCurlPost($url, $data) {
        $response = response_clfe(0, '', null);
        
        $payload = json_encode($data);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // follow redirects response
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        $curlResponse = json_decode($result);
        
        if ( isset($curlResponse->status) && 'success' == $curlResponse->status) {
            $response->code   = 1;
            $response->msg    = Lang_clfe::__('Settings updated successfully', 'clfe');
        } else {
            $response->code   = 0;
            $response->msg    = Lang_clfe::__('Something went wrong with Google Sheets. Please verify the sheet name, try again later, or reset the Google Sheet setup configuration.', 'clfe');
        }
        
        return $response;
    }
    /*
     * 
     */
    public static function getCurlSheetData($url, $params) {
        $response = response_clfe(0, '', null);
        
        $queryString = '?'.http_build_query($params);
        
        $ch = curl_init($url.$queryString);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // follow redirects response
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        $jsonResult = json_decode($result);
        
        if ( isset($jsonResult->data) ) {
            $response->code   = 1;
            $response->msg    = Lang_clfe::__('Executed successfully', 'clfe');
            $response->result = $jsonResult->data;
        } else {
            $response->code   = 0;
            $response->msg    = Lang_clfe::__('Something went wrong with Google Sheets. Please verify the sheet name, try again later, or reset the Google Sheet setup configuration.', 'clfe');
        }
        
        return $response;
    }
    
    /*
     * 
     */
    public static function getStatusColumnPosition($columns) {
        $statusColumnPosition = -1;
        
        if( !isset( $columns['elements'] ) ) {
            return $statusColumnPosition;
        }
        
        foreach ($columns['elements'] as $index => $column) {
            if( $column['col_value'] == 'status' ) {
                return $index;
            }
        }
        
        return $statusColumnPosition;
    }
}
