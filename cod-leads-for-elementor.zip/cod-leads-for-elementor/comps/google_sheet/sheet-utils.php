<?php
/**
 * Description of GoogleSheet_cl
 *
 * @author GIGABYTE
 */
class SheetUtils_cl {
    
    public static function orderVars() {
        return [ 
            'order_id'                    => Lang_cl::__('Order ID', 'cl'), 
            'currency_code'         => Lang_cl::__('currency code', 'cl'),
            'currency_label'        => Lang_cl::__('currency label', 'cl'), 
            'total'                 => Lang_cl::__('Order total', 'cl'),
            'total_with_currency'   => Lang_cl::__('Order total with currency', 'cl'),
            'shipping_fees'         => Lang_cl::__('shipping fees', 'cl'),
            'status'          => Lang_cl::__('Order status', 'cl'),
            'created_at'            => Lang_cl::__('Order date', 'cl'),
            'insight_type'          => Lang_cl::__('Order source', 'cl'),
            'product_id'            => Lang_cl::__('Product ID', 'cl'), 
            'product_title'         => Lang_cl::__('Product title', 'cl'),
            'product_title_with_options'         => Lang_cl::__('Product title & order Options', 'cl'),
            'product_slug'          => Lang_cl::__('Product slug', 'cl'),
            'product_qty'           => Lang_cl::__('Product quantity', 'cl'),
            'product_url'           => Lang_cl::__('Product url', 'cl'),
            'product_price'         => Lang_cl::__('Product price', 'cl'),
            'product_price_with_currency'         => Lang_cl::__('Product price with currency', 'cl'),
            'regular_price'         => Lang_cl::__('Product regular price', 'cl'),
            'sale_price'            => Lang_cl::__('Product sale price', 'cl'),
            'sku'                   => Lang_cl::__('Product SKU', 'cl'),
            'full_name'             => Lang_cl::__('Customer full name', 'cl'),
            'first_name'            => Lang_cl::__('Customer first name', 'cl'),
            'last_name'             => Lang_cl::__('Customer last name', 'cl'),
            'city'                  => Lang_cl::__('Customer city', 'cl'),
            'address_1'                => Lang_cl::__('Customer address 1', 'cl'),
            'phone'                 => Lang_cl::__('Customer phone', 'cl'),
            'email'                 => Lang_cl::__('Customer email', 'cl'),
            'customer_note'                 => Lang_cl::__('Customer note', 'cl'),
            'variations_text'       => Lang_cl::__('Product variations', 'cl'),
            'variations_total_fees'       => Lang_cl::__('Variations Total fees', 'cl'),
            'offer_title'               => Lang_cl::__('Quantity offer title', 'cl'),
            'offer_value'               => Lang_cl::__('Quantity offer value', 'cl'),
            'qty_total_offer_value'         => Lang_cl::__('Quantity total offer value', 'cl'),
            'insight_order_source_infos' => Lang_cl::__('Order source infos', 'cl'),
            'insight_user_location' => Lang_cl::__('Customer detected location', 'cl'),
            'ip_address'            => Lang_cl::__('Customer ip address', 'cl'),
            'user_agent'            => Lang_cl::__('Customer user_agent', 'cl'),
            'none'            => Lang_cl::__('Empty value', 'cl'),
        ];
        
        //`phone`, `city`, `full_name`, `product_id`, `currency`, `regular_price`, `sale_price`, `sku`, `shipping_fees`, `shipping_label`, `shipping_title`
    }
    /*
     * 
     */
    public static function sendCurlPost($url, $data) {
        $response = response_cl(0, '', null);
        
        $payload = json_encode($data);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // follow redirects response
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        $curlResponse = json_decode($result);
        
        if ( isset($curlResponse->status) && 'success' == $curlResponse->status) {
            $response->code   = 1;
            $response->msg    = Lang_cl::__('Settings updated successfully', 'cl');
        } else {
            $response->code   = 0;
            $response->msg    = Lang_cl::__('Something went wrong with Google Sheets. Please verify the sheet name, try again later, or reset the Google Sheet setup configuration.', 'cl');
        }
        
        return $response;
    }
    /*
     * 
     */
    public static function getCurlSheetData($url, $params) {
        $response = response_cl(0, '', null);
        
        $queryString = '?'.http_build_query($params);
        
        $ch = curl_init($url.$queryString);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // follow redirects response
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        $jsonResult = json_decode($result);
        
        if ( isset($jsonResult->data) ) {
            $response->code   = 1;
            $response->msg    = Lang_cl::__('Executed successfully', 'cl');
            $response->result = $jsonResult->data;
        } else {
            $response->code   = 0;
            $response->msg    = Lang_cl::__('Something went wrong with Google Sheets. Please verify the sheet name, try again later, or reset the Google Sheet setup configuration.', 'cl');
        }
        
        return $response;
    }
    
    /*
     * 
     */
    public static function getStatusColumnPosition($columns) {
        $statusColumnPosition = -1;
        
        if( !isset( $columns['elements'] ) ) {
            return $statusColumnPosition;
        }
        
        foreach ($columns['elements'] as $index => $column) {
            if( $column['col_value'] == 'status' ) {
                return $index;
            }
        }
        
        return $statusColumnPosition;
    }
}
