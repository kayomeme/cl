<?php
$dirPath = plugin_dir_path( __FILE__ );

//For all
require_once $dirPath  . 'sheet-utils.php';

// backend
if($isAdminAria) {
    require_once $dirPath  . 'backend/controllers/sheetSettingsControllerBk.php';
    require_once $dirPath  . 'backend/controllers/sheetControllerBk.php';
}

// frontend
if($isPublicAria) {
    require_once $dirPath  . 'frontend/controllers/sheetControllerFR.php';
}

