<?php
/**
 * Description of GoogleSheet_clfe
 *
 * @author GIGABYTE
 */
class SheetControllerBk_clfe {

    /*
     * 
     */
    public static function getOrdersFromSheetToSyncr($sheetSettings, $startRow, $endRow) {
        if( empty( $sheetSettings['sheet_web_app_url'] ) ) {
            return response_clfe(0, Lang_clfe::__('Google sheet model setting url is empty', 'clfe'), null);
        }
        
        $sheet_name         = $sheetSettings['sheet_name'];
        $registredColumns   = jsonDecode_clfe($sheetSettings['sheet_columns']);
        
        if( !isset( $registredColumns['elements'] ) ) {
            return response_clfe(0, Lang_clfe::__('Invalid or empty sheet columns', 'clfe'), null);
        }
        
        $sheetColumns = [];
        foreach ($registredColumns['elements'] as $posi => $col) {
            $sheetColumns[$col['col_value']] = $posi;
        }
        
        if( !isset( $sheetColumns['order_id'] ) || !isset( $sheetColumns['status'] ) ) {
            return response_clfe(0, Lang_clfe::__('Synchronization requires Order ID and Order Status columns. Please add them to your sheet and try again.', 'clfe'), null);
        }
        
        $params = [
            'action_todo' => 'sync_orders',
            //'sheet_name' => 'first_sheet',
            'sheet_name' => $sheet_name,
            'col_positions' => implode(',', array_values($sheetColumns)),
            'col_names' => implode(',', array_keys($sheetColumns)),
            'start_row' => $startRow,
            'end_row' => $endRow
        ];

        return SheetUtils_clfe::getCurlSheetData($sheetSettings['sheet_web_app_url'], $params);
    }

    /*
     * 
     */
    public static function synchronizeOrderStatusesWithGoogleSheets($settingsModelId, $statusColumnPosition = null, $url = null) {
        
            if( !$statusColumnPosition || !$url ) {
                $sheetSettings = AdminCompo_clfe::getSettings('google_sheet', $settingsModelId);
                $url = $sheetSettings['sheet_web_app_url'];

                if( !adminUtils_clfe::textExistsIn('script.google.com/macros/s', $url) ) {
                    $errorMsg = Lang_clfe::__('To synchronize order order_status with Google Sheets, some initial configuration is required. Please go to the Google Sheet settings page and set up the integration.', 'clfe');
                    return response_clfe(0, $errorMsg , null);   
                }

                $sheetColumns = (array)jsonDecode_clfe($sheetSettings['sheet_columns']);
                $statusColumnPosition = SheetUtils_clfe::getStatusColumnPosition($sheetColumns); 
            }


            return self::updateOrderStatuses($url, $statusColumnPosition);
    }
    
    /*
     * 
     */
    private static function updateOrderStatuses($webAppUrl, $statusColumnPosition) {
        // First, create the header configuration
        $data = [
            [
                'action' => 'modify_order_status',
                'sheet_name' => 'order_status',
                'site_url' => '',
                'sheet_row_bg_color' => '',
                'sheet_row_font_color' => '',
                'status_column_position' => $statusColumnPosition
            ],
            // Column headers
            ['id', 'status slug', 'status title', 'row_bg_color', 'row_text_color', 'status cost'],
        ];

        // Get the order statuses
        $orderStatuses = OrderStatusesModelBK_clfe::getStatusesForSheet($limit=30, $settingsModelId=0);
        if( !is_array($orderStatuses) ) {
            //$linkOrderStatuses = '<a href="'.admin_url('admin.php?page=clfe_order_statuses').'"></a>';
            $errorMsg = Lang_clfe::__('Order statuses required: Please add at least one status in the Order Statuses page to proceed.', 'clfe');
            return response_clfe(0, $errorMsg , null);
        }

        // Transform and add each status row
        $data = array_merge($data,
            array_map(fn($status) => array_values($status), $orderStatuses)
        );

        // Send the data
        $response = SheetUtils_clfe::sendCurlPost($webAppUrl, $data);
        
        return $response;
    }
    
}
