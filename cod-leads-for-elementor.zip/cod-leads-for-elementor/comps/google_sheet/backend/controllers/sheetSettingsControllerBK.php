<?php

class SheetSettingsControllerBK_clfe
{
    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'google_sheet';
        $tabName = isset($urlArgs['tab']) ? $urlArgs['tab'] : 'google-sheet-integration';

        $orderVars = SheetUtils_clfe::orderVars();
        $sheetColumns = jsonDecode_clfe($settings['sheet_columns']);

        if( !isset($sheetColumns['elements']) || empty( $sheetColumns['elements'] ) ) {  
            $sheetColumns['elements'][] = [
                'col_name' => '',
                'col_value' => ''
            ];
        }

        include AdminApp_clfe::$viewsPath . 'global_settings/index.php';
    }
    public static function save_settings($compoName, $settingsModelId, $args)
    {
        $sharedSettings = [];

        AdminCompo_clfe::saveSettings($compoName, $settingsModelId, $args);

        $url = $args['sheet_web_app_url'];
            
        if( !adminUtils_clfe::textExistsIn('script.google.com/macros/s', $url) ) {
            $errorMsg = Lang_clfe::__('There seems to be an issue with the Web App URL. Please double-check that you\'ve copied the URL correctly from your Google Apps Script project. Be sure to copy the entire URL and avoid any typos.', 'clfe');
            return response_clfe(0, $errorMsg , null);
        }
        
        $sheetColumns = jsonDecode_clfe($args['sheet_columns']);

        if( !isset( $sheetColumns['elements'] ) || empty($sheetColumns['elements']) ) {
            $errorMsg = Lang_clfe::__('Please consider adding at least one additional column, and ensure that column names do not include any special characters.', 'clfe');
            return response_clfe(0, $errorMsg , null);
        }
        
        $sheetColNames = [];
        foreach ($sheetColumns['elements'] as $value) {
            if( isset( $value['col_name'] ) && isset( $value['col_value'] ) ) {
                $sheetColNames[] = $value['col_name'];
            }
        }
        
        $statusColumnPosition = SheetUtils_clfe::getStatusColumnPosition($sheetColumns);
        // action => modify_header / add_row_to_top / add_row_to_bottom
        $data [] = [
            'action' => 'modify_header',
            'sheet_name' => $args['sheet_name'],
            'sheet_row_bg_color' => $args['sheet_head_bg_color'],
            'sheet_row_font_color' => $args['sheet_head_font_color'],
            'site_url' => get_site_url(),
            'status_column_position' => $statusColumnPosition
        ];
        $data [] = array_values($sheetColNames);
        
        $response = SheetUtils_clfe::sendCurlPost($url, $data);
        
        if( $response->code == 1 ) {
            $response = SheetControllerBk_clfe::synchronizeOrderStatusesWithGoogleSheets($settingsModelId, $url, $statusColumnPosition);
        }
        
        return $response;
    }

    private static function getSharedSettings($args)
    {
        $sharedSettings = [];

        return $sharedSettings;
    }
}
