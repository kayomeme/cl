<?php
/**
 * Description of GoogleSheet_cl
 *
 * @author GIGABYTE
 */
class SheetControllerBk_cl {

    /*
     * 
     */
    public static function getOrdersFromSheetToSyncr($sheetSettings, $startRow, $endRow) {
        if( empty( $sheetSettings['sheet_web_app_url'] ) ) {
            return response_cl(0, Lang_cl::__('Google sheet model setting url is empty', 'cl'), null);
        }
        
        $sheet_name         = $sheetSettings['sheet_name'];
        $registredColumns   = jsonDecode_cl($sheetSettings['sheet_columns']);
        
        if( !isset( $registredColumns['elements'] ) ) {
            return response_cl(0, Lang_cl::__('Invalid or empty sheet columns', 'cl'), null);
        }
        
        $sheetColumns = [];
        foreach ($registredColumns['elements'] as $posi => $col) {
            $sheetColumns[$col['col_value']] = $posi;
        }
        
        if( !isset( $sheetColumns['order_id'] ) || !isset( $sheetColumns['status'] ) ) {
            return response_cl(0, Lang_cl::__('Synchronization requires Order ID and Order Status columns. Please add them to your sheet and try again.', 'cl'), null);
        }
        
        $params = [
            'action_todo' => 'sync_orders',
            //'sheet_name' => 'first_sheet',
            'sheet_name' => $sheet_name,
            'col_positions' => implode(',', array_values($sheetColumns)),
            'col_names' => implode(',', array_keys($sheetColumns)),
            'start_row' => $startRow,
            'end_row' => $endRow
        ];

        return SheetUtils_cl::getCurlSheetData($sheetSettings['sheet_web_app_url'], $params);
    }

    /*
     * 
     */
    public static function synchronizeOrderStatusesWithGoogleSheets($settingsModelId, $statusColumnPosition = null, $url = null) {
        
            if( !$statusColumnPosition || !$url ) {
                $sheetSettings = AdminCompo_cl::getSettings('google_sheet', $settingsModelId);
                $url = $sheetSettings['sheet_web_app_url'];

                if( !adminUtils_cl::textExistsIn('script.google.com/macros/s', $url) ) {
                    $errorMsg = Lang_cl::__('To synchronize order order_status with Google Sheets, some initial configuration is required. Please go to the Google Sheet settings page and set up the integration.', 'cl');
                    return response_cl(0, $errorMsg , null);   
                }

                $sheetColumns = (array)jsonDecode_cl($sheetSettings['sheet_columns']);
                $statusColumnPosition = SheetUtils_cl::getStatusColumnPosition($sheetColumns); 
            }


            return self::updateOrderStatuses($url, $statusColumnPosition);
    }
    
    /*
     * 
     */
    private static function updateOrderStatuses($webAppUrl, $statusColumnPosition) {
        // First, create the header configuration
        $data = [
            [
                'action' => 'modify_order_status',
                'sheet_name' => 'order_status',
                'site_url' => '',
                'sheet_row_bg_color' => '',
                'sheet_row_font_color' => '',
                'status_column_position' => $statusColumnPosition
            ],
            // Column headers
            ['id', 'status slug', 'status title', 'row_bg_color', 'row_text_color', 'status cost'],
        ];

        // Get the order statuses
        $orderStatuses = OrderStatusesModelBK_cl::getStatusesForSheet($limit=30, $settingsModelId=0);
        if( !is_array($orderStatuses) ) {
            //$linkOrderStatuses = '<a href="'.admin_url('admin.php?page=cl_order_statuses').'"></a>';
            $errorMsg = Lang_cl::__('Order statuses required: Please add at least one status in the Order Statuses page to proceed.', 'cl');
            return response_cl(0, $errorMsg , null);
        }

        // Transform and add each status row
        $data = array_merge($data,
            array_map(fn($status) => array_values($status), $orderStatuses)
        );

        // Send the data
        $response = SheetUtils_cl::sendCurlPost($webAppUrl, $data);
        
        return $response;
    }
    
}
