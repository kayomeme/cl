<?php

if( isset($_REQUEST['page']) && $_REQUEST['page'] == 'clfe_global_settings' && isset($_REQUEST['compo']) && $_REQUEST['compo'] == 'google_sheet' ) {
    wp_enqueue_style('google_sheet_settings_bk', MainApp_clfe::$compsUrl.$hook['compName']. '/backend/assets/css/google_sheet_settings_bk.css', [], $assetsVersion );
}
