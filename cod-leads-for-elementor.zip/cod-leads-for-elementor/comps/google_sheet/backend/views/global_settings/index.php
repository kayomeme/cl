<div id="cl_google_sheet_integration_tab" class="cl-single-tab">
    <?php include 'partails/google_sheet_integration.php'; ?>
</div>
<div id="cl_settings_tab" class="cl-single-tab">
    <?php include 'partails/sheet_mapping.php'; ?>
</div>
<div id="cl_columns_tab" class="cl-single-tab">
    <?php include 'partails/columns_mapping.php'; ?>
</div>        
