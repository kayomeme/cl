<div id="clfe_google_sheet_integration_tab" class="clfe-single-tab">
    <?php include 'partails/google_sheet_integration.php'; ?>
</div>
<div id="clfe_settings_tab" class="clfe-single-tab">
    <?php include 'partails/sheet_mapping.php'; ?>
</div>
<div id="clfe_columns_tab" class="clfe-single-tab">
    <?php include 'partails/columns_mapping.php'; ?>
</div>        
