<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Active sheet integration', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <label class="clfe-switch">
          <input type="checkbox" <?= $settings['sheet_active'] == 'yes' ? 'checked="checked"' : '' ?> >
          <span class="clfe-slider clfe-round"></span>
          <input type="hidden" name="sheet_active" value="<?= $settings['sheet_active'] ?>">
        </label>
        
    </div>
</div>

<!--<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Deployment ID', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <input type="text"  name="sheet_deployment_id" value="<?= $settings['sheet_deployment_id'] ?>">
        
    </div>
</div>-->

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Web app url', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <input type="text"  name="sheet_web_app_url" value="<?= $settings['sheet_web_app_url'] ?>" clfe_ischanged="yes">
        
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th-full">
        <label>
            <?= Lang_clfe::_e('Script to copy and paste in google sheet app', 'clfe') ?>
        </label>

        <button class="button button-primary clfe-copy-textarea-text" attachedTextarea="tx-google-sheet-script">
            <?= Lang_clfe::_e('Click here to copy the script', 'clfe') ?>
        </button>
    </div>
    <div class="clfe-td-full">
        <textarea name="tx-google-sheet-script" style="width: 100%">
const doPost = (request = {}) => {
    const { parameter, postData: { contents, type } = {} } = request;
    //const type1 = 'application/json'
    if (type === 'application/json') {
        
        /*const jsonData = JSON.parse('[{"action":"add_row_to_bottom","sheet_name":"current", "sheet_row_bg_color":"#000000", "sheet_head_font_color":"#ffffff","site_url":"http:\/\/codleads.test"},["c6","c2222","c3","c4","c5"]]');*/
        
        const jsonData = JSON.parse(contents);
        
        const actionToDo    = jsonData[0]['action'];
        const sheetName     = jsonData[0]['sheet_name'];
        const siteURL       = jsonData[0]['site_url'];
        const rowBgColor    = jsonData[0]['sheet_row_bg_color'];
        const rowFontColor  = jsonData[0]['sheet_row_font_color'];
        
        if( actionToDo == 'modify_header' ) {
          const statusColumnPosition = jsonData[0]['status_column_position'];
            modifySheetHeader(jsonData[1], sheetName, rowBgColor, rowFontColor, statusColumnPosition);
        }

        if( actionToDo == 'add_row_to_top' ) {
            addNewRowToTheTop(jsonData[1], sheetName, rowBgColor, rowFontColor);
        }
        
        if( actionToDo == 'add_row_to_bottom' ) {
            addNewRowToTheBottom(jsonData[1], sheetName, rowBgColor, rowFontColor);
        }

        if( actionToDo == 'modify_order_status' ) {
            const statusColumnPosition = jsonData[0]['status_column_position'];
            modifySheetOrderStatues(jsonData, sheetName, statusColumnPosition);
        }

        result = {
            status: 'success',
            message: 'Rows are added.'
        };

        return ContentService.createTextOutput(JSON.stringify(result));
    }
};

/**
 * Inserts a row at the first row in the sheet. 
 * @param {array<string>} data - format [[date, email, name]]
 * @param {string} sheetName - the name of the selected sheet.
 */
function modifySheetHeader(data, sheetName, rowBgColor, rowFontColor, statusColumnPosition) {
    // the row to insert the data in.
    const targetRow = 1;

    sheetName = getValideSheetName(sheetName);

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(sheetName);
    sheet.getRange(targetRow, 1, 1, data.length).setValues([data]).setBackground(rowBgColor).setFontColor(rowFontColor);

      // change the header for all other sheets
      const sheetNames = getAllSheetNames();
      for (let i = 0; i < sheetNames.length; i++) {
        var currentSheet = ss.getSheetByName(sheetNames[i]);
        currentSheet.getRange(targetRow, 1, 1, data.length).setValues([data]).setBackground(rowBgColor).setFontColor(rowFontColor);
      }

      // modify order status colums position
      const orderStatusSheetName = getValideSheetName('order_status');
      const orderStatusSheet = ss.getSheetByName(orderStatusSheetName);

      orderStatusSheet.getRange('E1').setValue('Order status column position');
      orderStatusSheet.getRange('E2').setValue(statusColumnPosition);

      // set the status validation for the current sheet
      const statusData = orderStatusSheet.getDataRange().getValues();
      statusData.shift(); // remove the header
      createDataValidationForStatusColumn(statusData, sheetName,statusColumnPosition);

    SpreadsheetApp.flush();
}

function createDataValidationForStatusColumn(statusData, sheetName, statusColumnPosition) {
    if( statusColumnPosition < 0) {
      return;
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const orderSheet = ss.getSheetByName(sheetName);

    var statusNames = statusData.map(row => row[0]);
    var backgroundColors = statusData.map(row => row[1]); // Get an array of background colors
    var textColors = statusData.map(row => row[2]); // Get an array of text colors

    // get the order status range column like 'E:E'
    const statusColumnRangeText = getColumnRangeTextByPosition(statusColumnPosition);

    // Create data validation rule to the order status column
    var rule = SpreadsheetApp.newDataValidation().requireValueInList(statusNames).build();
    orderSheet.getRange(statusColumnRangeText).setDataValidation(rule);

    var rules = [];
    var range = orderSheet.getRange(statusColumnRangeText);

    // Apply conditional formatting for backgroundColors
    backgroundColors.forEach(function(color, index) {
      var rule = SpreadsheetApp.newConditionalFormatRule().whenTextContains(statusNames[index]).setBackground(color).setFontColor(textColors[index]).setRanges([range]).build();

      rules.push(rule);
    });

    orderSheet.setConditionalFormatRules(rules);
}
/**
 * Inserts a row at the first row in the sheet. 
 * @param {array<string>} data - format [[date, email, name]]
 * @param {string} sheetName - the name of the selected sheet.
 */
function modifySheetOrderStatues(data, sheetName, statusColumnPosition) {
  //data, sheetName
    //var sheetName = 'order_status';
    sheetName = getValideSheetName(sheetName);
    
    // Remove the first element from the array that contain => action, sheet_name ....
    data.shift();

    /*const data = [
      ['a111', 'b1', 'c1', 'd1'],
      ['a2', 'b2', 'c2', 'd2'],
      ];*/

      const ss = SpreadsheetApp.getActiveSpreadsheet();
      const sheet = ss.getSheetByName(sheetName);

      // Get the dimensions of the data array
      var numRows = data.length;
      var numColumns = data[0].length;

      // Define the range starting from A1 and dynamically adjust based on data dimensions
      var rangeToReplace = sheet.getRange(1, 1, numRows, numColumns);

      // Set the existing array as the new values for the identified range
      rangeToReplace.setValues(data);
      SpreadsheetApp.flush();

      // Remove the second row (index 1) from the array that contain the columns names
      data.shift();

      const sheetNames = getAllSheetNames();
      for (let i = 0; i < sheetNames.length; i++) {
        createDataValidationForStatusColumn(data, sheetNames[i], statusColumnPosition);
      }
     

}

/**
 * retunr ana array of all existing sheet names
 * and exclude the sheets that not contrains orders datas like order_status
 */
function getAllSheetNames() {
  var excludedSheetNames = ['order_status'];

  var spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  var sheets = spreadsheet.getSheets();

  var sheetNames = sheets
    .filter(function(sheet) {
      return !excludedSheetNames.includes(sheet.getName());
    })
    .map(function(sheet) {
      return sheet.getName();
    });

  return sheetNames;
}

/**
 * this function return the range letter by a giving index
 * for example this return A:A for index 0, B:B for index 1
 */
function getColumnRangeTextByPosition(columnPosition) {
  var columnLetter = String.fromCharCode('A'.charCodeAt(0) + columnPosition);
  // 2 to skip the first header column
  return columnLetter+"2" + ":" + columnLetter;
}

/**
 * Inserts a row at the second row in the sheet. 
 * @param {array<string>} data - format [[date, email, name]]
 * @param {string} sheetName - the name of the selected sheet.
 */
function addNewRowToTheTop(data, sheetName, rowBgColor, rowFontColor) {
    // the row to insert the data in.
    const targetRow = 2;

    sheetName = getValideSheetName(sheetName);

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(sheetName);
  
    sheet.insertRowBefore(targetRow);
    sheet.getRange(targetRow, 1, 1, data.length).setValues([data]).setBackground(rowBgColor).setFontColor(rowFontColor);

    SpreadsheetApp.flush();
}
/**
 * Inserts a row at the end in the sheet. 
 * @param {array<string>} data - format [date, email, name]
 * @param {string} sheetName - the name of the selected sheet.
 */
function addNewRowToTheBottom(data, sheetName, rowBgColor, rowFontColor) {

    sheetName = getValideSheetName(sheetName);

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(sheetName);
  
    sheet.appendRow(data);
    sheet.getRange(sheet.getLastRow(), 1, 1, sheet.getLastColumn()).setBackground(rowBgColor).setFontColor(rowFontColor);

    SpreadsheetApp.flush();
}

function getValideSheetName(sheetName) {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();

  sheetName = sanitizeSheetName(sheetName);
  if (sheetName === "" || sheetName === "first_sheet") {
    sheetName = "cod_lead_orders";
    var sheet = spreadsheet.getSheetByName(sheetName);
    if (!sheet) {
      spreadsheet.insertSheet(sheetName, 0);
    }
  } else {
    var sheet = spreadsheet.getSheetByName(sheetName);
    if (!sheet) {
      spreadsheet.insertSheet(sheetName);
    }
  }

  return sheetName;
}

function sanitizeSheetName(name) {
  // Replace invalid characters with underscores
  const sanitizedName = name.replace(/[^a-zA-Z0-9_ ]/g, "_");

  // Trim leading and trailing spaces
  return sanitizedName.trim();
}

function doGet(e) {

    const actionToDo    = e.parameter.action_todo;
    //actionToDo = 'sync_orders';
    if( actionToDo === 'sync_orders' ) {
      return sync_orders(e);
    }
}

function sync_orders(e) {
    sheetName = e.parameter.sheet_name;
    startRow = e.parameter.start_row;
    endRow = e.parameter.end_row;
    colPositionsString = e.parameter.col_positions;
    colNames = e.parameter.col_names;
  

    /*sheetName = 'Sheet1';
    startRow  = 20;
    endRow    = 30;
    colPositionsString = '0,1,2';
    colNames = 'order_id,total,status';*/

    sheetName = getValideSheetName(sheetName);
      
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(sheetName);

    const dataRange = sheet.getRange(startRow, 1, endRow - startRow + 1, sheet.getLastColumn());
    const values = dataRange.getValues();

    // Filter out empty rows
    var nonEmptyRows = values.filter(function(row) {
      return row.join('').trim() !== '';
    });

  const newDatas = [];
  const colPositions = colPositionsString.split(",").map(col => parseInt(col, 10));

  newDatas.push(colNames.split(","));
  for (let i = 0; i < nonEmptyRows.length; i++) {
    const newRow = [];
    colPositions.forEach(position => {
       // Access using adjusted position
      if( nonEmptyRows[i][position] != undefined ) {
        newRow.push(nonEmptyRows[i][position]);
      }
    });
    newDatas.push(newRow);
  }


    // Include sheet name in the response
    var responseData = {
      sheetName: sheetName,
      sheetId: ss.getId(),
      data: newDatas
    };

    return ContentService.createTextOutput(JSON.stringify(responseData));
}

/*
* this function is triggered when the content of a cell is changed
* this will autmatically change the row bg color when the status is changed
*/
function onEdit(e) {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const orderStatusSheet = ss.getSheetByName('order_status');

    const statusColumnPosition =  orderStatusSheet.getRange('E2').getValue();
    const statusData = orderStatusSheet.getDataRange().getValues();

    // remove the order_status sheet header
    statusData.shift();

    var statusNames = statusData.map(row => row[0]); // Get an array of status names
    var backgroundColors = statusData.map(row => row[1]); // Get an array of background colors
    var textColors = statusData.map(row => row[2]); // Get an array of text colors

  // Check if column 2 is edited
  const currentColumnPosition = e.range.getColumn() - 1;
  const currentColumnText = e.range.getValue();
  const statusNameArrayIndex = textIndexInArray(currentColumnText, statusNames);

  if ( currentColumnPosition === statusColumnPosition && statusNameArrayIndex !== -1 ) {
    const sheet = e.range.getSheet();
    const editedRow = e.range.getRow();

    const bgColor = backgroundColors[statusNameArrayIndex];
    const TextColor = textColors[statusNameArrayIndex];

    // Apply the header color to the entire edited row
    sheet.getRange(editedRow, 1, 1, sheet.getLastColumn()).setBackground(bgColor).setFontColor(TextColor);
  }
}

/*
* return the index of text in array or return -1 when not found
*/
function textIndexInArray(text, textArray) {
  for (let i = 0; i < textArray.length; i++) {
    if (textArray[i] === text) {
      return i;
    }
  }
  return -1; // Text not found

  //return textArray.findIndex(element => element === text);
}




function doget_test() {
  var e = '{"action":"add_row_to_bottom","sheet_name":"Sheet1__", "sheet_row_bg_color":"#000000", "sheet_head_font_color":"#ffffff","site_url":"http:\/\/codleads.test"}';
  doGet(e);
}        
        
        </textarea>
        
    </div>
</div>