<div class="c-element c-element-flex">
    <div>
        <input type="text" elementName="col_name" isRequired="yes" value="<?= $value['col_name'] ?>" />    
    </div>
    <div>
    <select elementName="col_value">
                        <?php foreach ( $orderVars as $varKey => $varValue) { ?>
                        <option value="<?= $varKey ?>" <?= $value['col_value'] == $varKey ? 'selected' : '' ?>>
                                <?= $varValue ?>
                        </option>
                        <?php  } ?>
                    </select>    
    </div>
    <div class="cl-element-buttons">
        <button type="button" class="deleteElement" title="<?= Lang_cl::_e('Remove this sheet column', 'cl') ?>">
            <span class="dashicons dashicons-trash"></span>
        </button>

        <div class="cl-move-element" title="<?= Lang_cl::_e('Move this sheet column', 'cl') ?>">
                <span class="dashicons dashicons-move"></span>
         </div>
    </div>

</div>