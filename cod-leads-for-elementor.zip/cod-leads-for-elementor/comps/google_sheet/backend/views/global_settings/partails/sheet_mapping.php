<div class="cl-row ">
    <div class="cl-th">
        <label>
            <?= Lang_cl::_e('Sheet Header', 'cl') ?>
        </label>
    </div>
    <div class="cl-td">
        <table>
            <tr>
                <td>
                    <?= Lang_cl::_e('Background color', 'cl') ?>
                    <input type="text" class="cl_color"  name="sheet_head_bg_color" value="<?= $settings['sheet_head_bg_color'] ?>" cl-ischanged="yes">
                </td>
                <td>
                    <?= Lang_cl::_e('Font color', 'cl') ?>
                    <input type="text" class="cl_color"  name="sheet_head_font_color" value="<?= $settings['sheet_head_font_color'] ?>" cl-ischanged="yes">
                </td>
            </tr>
        </table>
        
    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <label>
            <?= Lang_cl::_e('Sheet new Row', 'cl') ?>
        </label>
    </div>
    <div class="cl-td">
        <table>
            <tr>
                <td>
                    <?= Lang_cl::_e('Background color', 'cl') ?>
                    <input type="text" class="cl_color"  name="sheet_row_bg_color" value="<?= $settings['sheet_row_bg_color'] ?>" cl-ischanged="yes">
                </td>
                <td>
                    <?= Lang_cl::_e('Font color', 'cl') ?>
                    <input type="text" class="cl_color"  name="sheet_row_font_color" value="<?= $settings['sheet_row_font_color'] ?>" cl-ischanged="yes">
                </td>
            </tr>
        </table>
        
    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <label>
            <?= Lang_cl::_e('Insert new row at the', 'cl') ?>
        </label>
    </div>
    <div class="cl-td">
        <select name="insert_new_row_at" class="cl-style-element" value="<?= $settings['insert_new_row_at'] ?>" cl-ischanged="yes">
            <option value="add_row_to_top"><?= Lang_cl::_e('Top of the sheet', 'cl') ?></option>
            <option value="add_row_to_bottom"><?= Lang_cl::_e('Bottom of the sheet', 'cl') ?></option>
        </select> 
        
    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <label>
            <?= Lang_cl::_e('Sheet name', 'cl') ?>
        </label>
    </div>
    <div class="cl-td">
        <input type="text"  name="sheet_name" value="<?= $settings['sheet_name'] ?>" cl-ischanged="yes">
        <div class="cl-alert cl-alert-info">
            <?= Lang_cl::_e('Don\'t change this only if you know what are you doing', 'cl') ?>
        </div>
    </div>
</div>