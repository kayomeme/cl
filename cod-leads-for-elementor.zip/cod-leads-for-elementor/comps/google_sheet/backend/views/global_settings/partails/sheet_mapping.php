<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Sheet Header', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <table>
            <tr>
                <td>
                    <?= Lang_clfe::_e('Background color', 'clfe') ?>
                    <input type="color"  name="sheet_head_bg_color" value="<?= $settings['sheet_head_bg_color'] ?>" clfe_ischanged="yes">
                </td>
                <td>
                    <?= Lang_clfe::_e('Font color', 'clfe') ?>
                    <input type="color"  name="sheet_head_font_color" value="<?= $settings['sheet_head_font_color'] ?>" clfe_ischanged="yes">
                </td>
            </tr>
        </table>
        
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Sheet new Row', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <table>
            <tr>
                <td>
                    <?= Lang_clfe::_e('Background color', 'clfe') ?>
                    <input type="color"  name="sheet_row_bg_color" value="<?= $settings['sheet_row_bg_color'] ?>" clfe_ischanged="yes">
                </td>
                <td>
                    <?= Lang_clfe::_e('Font color', 'clfe') ?>
                    <input type="color"  name="sheet_row_font_color" value="<?= $settings['sheet_row_font_color'] ?>" clfe_ischanged="yes">
                </td>
            </tr>
        </table>
        
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Insert new row at the', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <select name="insert_new_row_at" class="clfe-style-element" value="<?= $settings['insert_new_row_at'] ?>" clfe_ischanged="yes">
            <option value="add_row_to_top"><?= Lang_clfe::_e('Top of the sheet', 'clfe') ?></option>
            <option value="add_row_to_bottom"><?= Lang_clfe::_e('Bottom of the sheet', 'clfe') ?></option>
        </select> 
        
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Sheet name', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <input type="text"  name="sheet_name" value="<?= $settings['sheet_name'] ?>" clfe_ischanged="yes">
        <div class="clfe-alert clfe-alert-info">
            <?= Lang_clfe::_e('Don\'t change this only if you know what are you doing', 'clfe') ?>
        </div>
    </div>
</div>