<div class="google-sheet-columns">
    <div class="clfe-row">
        <div class="clfe-th">
            <label>
                <?= Lang_clfe::_e('Google sheet columns :  Name /  Value', 'clfe') ?>
            </label>
        </div>
        <div class="clfe-td">
            <div class="dynamic-elements" attachedSettingName="sheet_columns">
                <?php
                foreach ($sheetColumns['elements'] as $value) {
                    if (isset($value['col_name'])) {
                        include 'c_element_column.php';
                    }
                }
                ?>
            </div>
            <button type="button" class="clfe-add-dynamic-element" dynamic-elements-container="google-sheet-columns">
                <span class="dashicons dashicons-plus"></span>
                <?= Lang_clfe::_e('Add new sheet column', 'clfe') ?>
            </button>
            <input type="hidden"  name="sheet_columns" value="<?= adminUtils_clfe::cleanInput($settings['sheet_columns']) ?>">


            <div class="clfe-empty-elements" style="display: none !important">
                <?php
                $value = [
                    'col_name'  => '',
                    'col_value' => ''
                ];
                include 'c_element_column.php';
                ?>
            </div>
        </div>
    </div>
</div>