<div class="google-sheet-columns">
    <div class="cl-row">
        <div class="cl-th">
            <label>
                <?= Lang_cl::_e('Google sheet columns :  Name /  Value', 'cl') ?>
            </label>
        </div>
        <div class="cl-td">
            <div class="dynamic-elements" attachedSettingName="sheet_columns">
                <?php
                foreach ($sheetColumns['elements'] as $value) {
                    if (isset($value['col_name'])) {
                        include 'c_element_column.php';
                    }
                }
                ?>
            </div>
            <button type="button" class="cl-add-dynamic-element" dynamic-elements-container="google-sheet-columns">
                <span class="dashicons dashicons-plus"></span>
                <?= Lang_cl::_e('Add new sheet column', 'cl') ?>
            </button>
            <input type="hidden"  name="sheet_columns" value="<?= adminUtils_cl::cleanInput($settings['sheet_columns']) ?>">


            <div class="cl-empty-elements" style="display: none !important">
                <?php
                $value = [
                    'col_name'  => '',
                    'col_value' => ''
                ];
                include 'c_element_column.php';
                ?>
            </div>
        </div>
    </div>
</div>