<button tab="clfe_google_sheet_integration_tab">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_clfe::_e('Google sheet integration', 'clfe') ?>
</button>

<button tab="clfe_settings_tab">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_clfe::_e('Sheet Mapping', 'clfe') ?>
</button>

<button tab="clfe_columns_tab">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_clfe::_e('Columns Mapping', 'clfe') ?>
</button>