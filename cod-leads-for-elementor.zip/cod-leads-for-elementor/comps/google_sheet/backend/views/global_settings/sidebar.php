<button tab="cl_google_sheet_integration_tab">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_cl::_e('Google sheet integration', 'cl') ?>
</button>

<button tab="cl_settings_tab">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_cl::_e('Sheet Mapping', 'cl') ?>
</button>

<button tab="cl_columns_tab">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_cl::_e('Columns Mapping', 'cl') ?>
</button>