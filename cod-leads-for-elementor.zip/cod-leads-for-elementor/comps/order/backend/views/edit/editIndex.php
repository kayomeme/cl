<div id="clfe_update_order" class="order-edit">
    <div class="order-edit__body">
        <div class="order-edit__header">
            <?php include_once 'order_details.php'; ?>
        </div>
        <div class="order-edit__content">
            <!-- Customer Information -->
            <div class="order-edit__customer">
                <?php include_once 'customer_details.php'; ?>
            </div>
            <!-- Cart Items Section -->
            <div class="order-edit__cart">
                <?php include_once 'cart.php'; ?>
            </div>
        </div>
    </div>

    <div class="order-edit__sidebar">
        <div class="sidebar-actions">
            <button class="clfe-button">
                <?= Lang_clfe::__('Block customer IP', 'clfe') ?>
            </button>
            <button class="clfe-button">
                <?= Lang_clfe::__('Remove the order', 'clfe') ?>
            </button>
            <button class="clfe-button">
                <?= Lang_clfe::__('Print the order', 'clfe') ?>
            </button>
            <button class="clfe-button">
                <?= Lang_clfe::__('Send Review Request', 'clfe') ?>
            </button>
        </div>
    <?php include_once MainApp_clfe::$compsPath . 'order/backend/views/edit/status_history.php'; ?>
    </div>
    
    
    <div id="clfe-sticky-bottom-bar">
        <div class="clfe-container">
            <div class="order-edit__actions">
                <input type="hidden" name="order_id" value="<?= $order->id ?>" clfe_ischanged="yes">
            </div>

            <div class="clfe-user-fedback"></div>
        </div>
    </div>
    
</div>