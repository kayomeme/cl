<div class="history__item" data-id="<?= $history->id ?>">
    <div class="history__item-header">
        <div class="history__meta">
            <div class="history__status-change">
                <?php if ($history->from_status): ?>
                    <div class="history__status history__status--from" style="<?=
                    isset($orderStatuses[$history->from_status]) ?
                            'background-color:' . $orderStatuses[$history->from_status]['bg_color'] .
                            ';color:' . $orderStatuses[$history->from_status]['text_color'] : ''
                    ?>">
                             <?=
                             isset($orderStatuses[$history->from_status]) ?
                                     $orderStatuses[$history->from_status]['title'] :
                                     Lang_clfe::__($history->from_status, 'clfe')
                             ?>
                    </div>
                    <span class="history__arrow">→</span>
                <?php endif; ?>
                <div class="history__status history__status--to" style="<?=
                isset($orderStatuses[$history->to_status]) ?
                        'background-color:' . $orderStatuses[$history->to_status]['bg_color'] .
                        ';color:' . $orderStatuses[$history->to_status]['text_color'] : ''
                ?>">
                         <?=
                         isset($orderStatuses[$history->to_status]) ?
                                 $orderStatuses[$history->to_status]['title'] :
                                 Lang_clfe::__($history->to_status, 'clfe')
                         ?>
                </div>
            </div>
            <div>
                <div class="history__time">
                    <?= date(Lang_clfe::__('M d, Y, g:i A', 'clfe'), strtotime($history->date_created_gmt)) ?>
                </div>
                <?php if ($history->changed_by): ?>
                    <div class="history__user">
                        <?= Lang_clfe::__('by', 'clfe') ?> 
                        <span class="history__user-name">
                            <?= get_user_by('id', $history->changed_by)->display_name ?>
                        </span>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>

    <div class="history__note" data-id="<?= $history->id ?>">
        <?php if (!empty($history->note)): ?>
            <div class="history__note-content">
                <?= $history->note ?>
            </div>
        <?php else: ?>
            <div class="history__note-placeholder">
                <?= Lang_clfe::__('Click to add a note...', 'clfe') ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="history__note-edit" style="display: none;">
        <textarea class="history__note-textarea"><?= $history->note ?></textarea>
        <div class="history__note-actions">
            <button class="history__note-cancel clfe-button">
                <?= Lang_clfe::__('Cancel', 'clfe') ?>
            </button>
            <button class="history__note-save clfe-button clfe-button-primary">
                <?= Lang_clfe::__('Save Note', 'clfe') ?>
            </button>
        </div>
    </div>
</div>