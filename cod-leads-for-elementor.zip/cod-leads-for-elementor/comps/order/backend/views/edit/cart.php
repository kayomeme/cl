<div class="cart">
    <div class="cart__items">
        <?php
        $regularTotalCart = 0;
        $saleTotalCart = 0;
        $totalDiscountOffers = 0;
        foreach ($cartProducts as $cartProduct) {
            //var_dump($cartProduct);
            $qty = (int) $cartProduct['qty'];
            $regularPrice = (float) $cartProduct['regular_price'];
            $discountPerProduct = (float) $cartProduct['discount_per_product'];
            $salePrice = $regularPrice - $discountPerProduct;

            $regularTotalCart += $regularPrice * $qty;
            $saleTotalCart += $salePrice * $qty;
            $totalDiscountOffers += $discountPerProduct * $qty;
            
            include 'cart_item.php';
        }
        ?>
    </div>

    <div class="cart__summary">
        <div class="cart__summary-item cart__summary-item--total">
            <span class="cart__summary-label">
                <?= Lang_clfe::__('Total cart', 'clfe') ?>
            </span>

            <div>
                <span>
                    <span class="clfe_total_cart"><?= number_format($regularTotalCart - $totalDiscountOffers, 0) ?></span><?= ' ' . $currencyCode ?>

                </span>
                <span class="price-struck">
                    <span class="clfe_total_cart_regular"><?= number_format($regularTotalCart, 0) ?></span><?= ' ' . $currencyCode ?>

                </span>
            </div>

        </div>
        <?php if ($totalDiscountOffers > 0): ?>
            <div class="cart__summary-item">
                <span class="cart__summary-label">
                    <?= Lang_clfe::__('Total discount', 'clfe') ?>
                </span>
                <span class="cart__summary-item--discount">
                    <span class="clfe_total_discount">-<?= $totalDiscountOffers ?></span> <?= ' ' . $currencyCode ?>

                </span>
            </div>
        <?php endif; ?>

        <?php if (isset($shippingInfos)): ?>
            <div class="cart__summary-item">
                <span class="cart__summary-label">
                    <?=
                    isset($shippingInfos['fees']) && $shippingInfos['fees'] > 0 ? $shippingInfos['title'] : Lang_clfe::__('Shipping', 'clfe')
                    ?>
                </span>
                <span class="">
                    <?php if (isset($shippingInfos['fees']) && $shippingInfos['fees'] > 0): ?>
                        +<span id="clfe_total_shipping"><?= $shippingInfos['fees'] ?></span> <?= $currencyCode ?>
                    <?php elseif (isset($shippingInfos['title'])): ?>
                        <?= $shippingInfos['title'] ?>
                    <?php endif; ?>
                </span>
            </div>
        <?php endif; ?>


        <div class="cart__summary-item cart__summary-item--total">
            <span class="cart__summary-label">
                <?= Lang_clfe::__('Total to pay', 'clfe') ?>
            </span>
            <span class=" cart__price--sale">
                <span class="clfe_total_amount"><?= number_format($order->total, 0) ?></span>
                <span class="cart__currency"><?= $currencyCode ?></span>
            </span>
        </div>
    </div>
</div>