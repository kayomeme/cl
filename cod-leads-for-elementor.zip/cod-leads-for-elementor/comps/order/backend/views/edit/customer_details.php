<div id="clfe_update_order_customer_info" class="customer__form">
        <div class="order__field">
            <label class="order__label"><?= Lang_clfe::__('Customer', 'clfe') ?></label>
            <select class="order__select" name="order_customer">
                <option>
                    <?= Lang_clfe::__('Guest', 'clfe') ?>
                </option>
            </select>
        </div>
    <div class="clfe-grid-2cols">
        <div class="customer__field">
            <label class="customer__label"><?= Lang_clfe::__('First Name', 'clfe') ?></label>
             <input type="text" class="customer__input" name="first_name" value="<?= $order->first_name ?>">
        </div>
        <div class="customer__field">
            <label class="customer__label"><?= Lang_clfe::__('Last Name', 'clfe') ?></label>
            <input type="text" class="customer__input" name="last_name" value="<?= $order->last_name ?>">
        </div>
    </div>
    <div class="customer__field">
        <label class="customer__label">
            <?= Lang_clfe::__('Phone', 'clfe') ?>
            
            <a href="tel:<?= $order->phone ?>">
                <?= Lang_clfe::__('Call ', 'clfe') . $order->phone ?>
                <i class="dashicons dashicons-phone"></i>
            </a>
        </label>
        <input type="tel" class="customer__input" name="phone" value="<?= $order->phone ?>">
    </div>
    <div class="clfe-grid-2cols">
        <div class="customer__field">
            <label class="customer__label"><?= Lang_clfe::__('City', 'clfe') ?></label>
            <input type="text" class="customer__input" name="city" value="<?= $order->city ?>">
        </div>
        <div class="customer__field">
            <label class="customer__label"><?= Lang_clfe::__('Email', 'clfe') ?></label>
            <input type="email" class="customer__input" name="email" value="<?= $order->email ?>">
        </div>
    </div>
        <div class="customer__field">
            <label class="customer__label"><?= Lang_clfe::__('Address', 'clfe') ?></label>
            <input type="text" class="customer__input" name="address_1" value="<?= $order->address ?>">
        </div>
    
    <div class="clfe-grid-3cols">
        <div class="customer__field">
            <label class="customer__label"><?= Lang_clfe::__('State', 'clfe') ?></label>
            <input type="text" class="customer__input" name="state" value="<?= $order->state ?>">
        </div>
        <div class="customer__field">
            <label class="customer__label"><?= Lang_clfe::__('Postal Code', 'clfe') ?></label>
            <input type="text" class="customer__input" name="postcode" value="<?= $order->postcode ?>">
        </div>
        <div class="customer__field">
            <label class="customer__label"><?= Lang_clfe::__('Country', 'clfe') ?></label>
            <input type="text" class="customer__input" name="country" value="<?= $order->country ?>">
        </div>
    </div>
    
    <div class="customer__field">
        <label class="customer__label"><?= Lang_clfe::__('Customer note', 'clfe') ?></label>
        <input type="text" class="customer__input" name="customer_note" value="<?= $order->customer_note ?>">
    </div>

    <button id="save-update-order-customer-info" class="button button-primary">
        <?= Lang_clfe::__('Save change', 'clfe') ?>
    </button>
</div>



    <!--<div class="customer__form">
        <div class="customer__field">
            <label class="customer__label"><?= Lang_clfe::__('Full Name', 'clfe') ?></label>
            <input type="text" class="customer__input" name="customer_name" value="<?= $order->full_name ?>">
        </div>
        <div class="customer__field">
            <label class="customer__label"><?= Lang_clfe::__('Email', 'clfe') ?></label>
            <input type="email" class="customer__input" name="customer_email" value="<?= $order->email ?>">
        </div>
        <div class="customer__field">
            <label class="customer__label">
                <?= Lang_clfe::__('Phone', 'clfe') ?>
                
                <a href="tel:<?= $order->phone ?>">
                    <?= Lang_clfe::__('Call ', 'clfe') . $order->phone ?>
                    <i class="dashicons dashicons-phone"></i>
                </a>
            </label>
            <input type="tel" class="customer__input" name="customer_phone" value="<?= $order->phone ?>">
        </div>
        <div class="customer__field">
            <label class="customer__label"><?= Lang_clfe::__('City', 'clfe') ?></label>
            <input type="text" class="customer__input" name="customer_city" value="<?= $order->city ?>">
        </div>
        <div class="customer__field">
            <label class="customer__label"><?= Lang_clfe::__('Address', 'clfe') ?></label>
            <textarea class="customer__input customer__input--textarea" name="customer_address"><?= $order->address ?></textarea>
        </div>
    </div> -->