<div class="order-container">
    <div class="header-actions">
        <button class="btn btn-primary" id="save-order">
            <i class="icon icon-save"></i>
            <?= Lang_clfe::__('Save', 'clfe') ?>
        </button>
    </div>
    <!-- Header -->
    <div class="order-header">
        <div class="header-content">
            <div class="header-left">
                <div class="order-info">
                    <div class="order-amount"><?= $order['totals']['formatted'] ?></div>
                    <div class="order-meta">
                        <a href="#" class="order-number">#<?= $order['id'] ?></a>
                        <span class="order-date"><?= $order['dates']['formatted'] ?></span>
                    </div>
                </div>
                <div class="order-status <?= $order['status']['code'] ?>">
                    <?= $order['status']['label'] ?>
                </div>
            </div>
        </div>
        <div class="header-contact">
            <?php if (!empty($order['customer']['phone'])): ?>
            <a href="tel:<?= $order['customer']['phone'] ?>" class="contact-item">
                <i class="icon icon-phone"></i>
                <?= $order['customer']['phone'] ?>
            </a>
            <?php endif; ?>
            
            <?php if (!empty($order['customer']['city'])): ?>
            <span class="contact-item">
                <i class="icon icon-location"></i>
                <?= $order['customer']['city'] ?>
            </span>
            <?php endif; ?>
            
            <?php if (!empty($order['customer']['address'])): ?>
            <span class="contact-item">
                <i class="icon icon-address"></i>
                <?= $order['customer']['address'] ?>
            </span>
            <?php endif; ?>
        </div>
        <!-- Order Modification -->
        <div class="order-quick-update">
            <div class="form-group">
                <label><?= Lang_clfe::__('Order Status', 'clfe') ?></label>
                <select class="form-select" name="order_status">
                    <?php foreach (OrderModelBK_clfe::getOrderStatuses() as $status_key => $status_label): ?>
                        <option value="<?= $status_key ?>" 
                                <?= $order['status']['code'] === $status_key ? 'selected' : '' ?>>
                            <?= $status_label ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label><?= Lang_clfe::__('Order Date', 'clfe') ?></label>
                <input type="datetime-local" class="form-input" name="order_date" 
                       value="<?= date('Y-m-d\TH:i', strtotime($order['dates']['created'])) ?>">
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="section details-section">
            <div class="section-header">
                <h2><?= Lang_clfe::__('Customer & Order Details', 'clfe') ?></h2>
            </div>
            <div class="section-content two-columns">
                <!-- Customer Information -->
                <div class="customer-details">
                    <h3><?= Lang_clfe::__('Customer Information', 'clfe') ?></h3>
                    <div class="form-group">
                        <label><?= Lang_clfe::__('Full Name', 'clfe') ?></label>
                        <input type="text" class="form-input" name="customer_name" 
                               value="<?= $order['customer']['full_name'] ?>">
                    </div>
                    <div class="form-group">
                        <label><?= Lang_clfe::__('Email', 'clfe') ?></label>
                        <input type="email" class="form-input" name="customer_email" 
                               value="<?= $order['customer']['email'] ?>">
                    </div>
                    <div class="form-group">
                        <label><?= Lang_clfe::__('Phone', 'clfe') ?></label>
                        <input type="tel" class="form-input" name="customer_phone" 
                               value="<?= $order['customer']['phone'] ?>">
                    </div>
                    <div class="form-group">
                        <label><?= Lang_clfe::__('City', 'clfe') ?></label>
                        <input type="text" class="form-input" name="customer_city" 
                               value="<?= $order['customer']['city'] ?>">
                    </div>
                    <div class="form-group">
                        <label><?= Lang_clfe::__('Address', 'clfe') ?></label>
                        <textarea class="form-input" name="customer_address"><?= $order['customer']['address'] ?></textarea>
                    </div>
                </div>

                <!-- Cart Items Section -->
                <div class="section cart-section">
                    <div class="section-header">
                        <h2><?= Lang_clfe::__('Order Items', 'clfe') ?></h2>
                    </div>
                    <div class="section-content">
                        <?php foreach ($order['items'] as $item): ?>
                        <div class="product-card">
                            <div class="product-info">
                                <div class="product-details">
                                    <h4><?= $item['name'] ?></h4>
                                    <?php if (!empty($item['variations'])): ?>
                                        <p class="variant"><?= $item['variations'] ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="product-price">
                                    <span class="price-final"><?= $item['formatted_price'] ?></span>
                                    <span class="quantity">x<?= $item['quantity'] ?></span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>

                        <div class="order-summary">
                            <div class="summary-row total">
                                <span><?= Lang_clfe::__('Total', 'clfe') ?></span>
                                <span><?= $order['totals']['formatted'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar Sections -->
        <div class="sidebar-sections">
            <!-- Order Notes -->
            <div class="section">
                <div class="section-header">
                    <h2><?= Lang_clfe::__('Order Notes', 'clfe') ?></h2>
                </div>
                <div class="section-content">
                    <textarea class="form-input" name="order_note" 
                              placeholder="<?= Lang_clfe::__('Add a note...', 'clfe') ?>"></textarea>
                    <button class="btn btn-primary full-width" id="add-note">
                        <?= Lang_clfe::__('Add Note', 'clfe') ?>
                    </button>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="section">
                <div class="section-header">
                    <h2><?= Lang_clfe::__('Quick Actions', 'clfe') ?></h2>
                </div>
                <div class="section-content">
                    <div class="quick-actions">
                        <button class="action-btn" data-action="email">
                            <i class="icon icon-mail"></i>
                            <?= Lang_clfe::__('Email', 'clfe') ?>
                        </button>
                        <button class="action-btn" data-action="sms">
                            <i class="icon icon-message"></i>
                            <?= Lang_clfe::__('SMS', 'clfe') ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>