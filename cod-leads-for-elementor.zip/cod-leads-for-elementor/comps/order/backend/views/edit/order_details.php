<div id="clfe_update_order_info">
    <div class="order__info">
        <div class="order__amount">
            <span class="clfe_total_amount"><?= number_format($order->total, 0) ?></span>
            <?= ' ' . $currencyCode ?>
        </div>
        <div class="order__number">
            <?= Lang_clfe::__('Edit Order', 'clfe') ?>
            #<?= $order->id ?>
        </div>
        <div class="order__source">
            <?= Lang_clfe::__('TikTok', 'clfe') ?>
        </div>
    </div>


    <div class="order__status_container">
        <div>
            <label class="order__label order-status-label">
                <?= Lang_clfe::__('Order Status', 'clfe') ?>
            </label>
            <select class="order__select" name="status">
                <?php foreach ($orderStatuses as $status): ?>
                    <option value="<?= $status['slug'] ?>" bg_color="<?= $status['bg_color'] ?>" text_color="<?= $status['text_color'] ?>"
                            <?= $order->status === $status['slug'] ? 'selected' : '' ?>>
                                <?= $status['title'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div>
            <?php
            $statusStyle = '';
            $status = $order->status;
            if (isset($orderStatuses[$order->status])) {
                $statusStyle = 'background-color:' . $orderStatuses[$order->status]['bg_color'] . ';color:' . $orderStatuses[$order->status]['text_color'];
                $status = $orderStatuses[$order->status]['title'];
            }
            ?>
            <div class="order__status" style="<?= $statusStyle ?>">
                <?= $status ?>
            </div>
            <div>
                <label class="order__label">
                    <?= Lang_clfe::__('Created', 'clfe') ?>
                    <strong> <?= date('Y-m-d\TH:i', strtotime($order->created_at)) ?></strong>
                </label> 

            </div>
        </div>
    </div>
</div>
