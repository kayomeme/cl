<div id="clfe_cart_save_updated_product" class="cart-update-product-<?= $productId ?>">
    <?php
    $qty = (int) $cartProduct['qty'];
    $regularPrice = (float) $cartProduct['regular_price'];
    $discountPerProduct = (float) $cartProduct['discount_per_product'];
    $salePrice = $regularPrice - $discountPerProduct;

    $discountTotal = $discountPerProduct * $qty;
    $regularPriceTotal = $regularPrice * $qty;
    $salePriceTotal = $regularPriceTotal - $discountTotal;
    
    ?>
    <div class="cart-edit-offer">
        <div class="cart__image">
            <img src="<?= $cartProduct['short_image_url'] ?>" alt="<?= $cartProduct['title'] ?>"/>
        </div>
        <div>
            <?php if (isset($cartProduct['added_via'])) { ?>
                <div class="cart__added_via">
                    <?= Lang_clfe::__('Added via :', 'clfe') ?>
                    <strong><?= $cartProduct['added_via'] ?></strong>
                </div>
            <?php } ?>
            <div class="cart__title">
                <?= $cartProduct['title'] ?>
            </div>

            <div class="cart__pricing">
                <div class="cart__price-row">
                    <?php if ($salePrice < $regularPrice): ?>
                        <span class="cart__price--sale">
                            <?= $salePrice ?> <?= $currencyCode ?>
                        </span>
                        <span class="cart__price price-struck">
                            <?= $regularPrice ?> <?= $currencyCode ?>
                        </span>
                    <?php else: ?>
                        <span class="cart__price">
                            <?= $regularPrice ?> <?= $currencyCode ?>
                        </span>
                    <?php endif; ?>

                    <span class="cart__badge"><?= $qty ?></span>
                </div>
                <?php if ($qty > 1) { ?>
                    <div class="cart__price-row">
                        <span class="cart__price cart__price--total">
                            <?= $salePriceTotal ?> <?= $currencyCode ?>
                        </span>
                        <?php if ($salePrice < $regularPriceTotal): ?>
                            <span class="cart__price price-struck">
                                <?= $regularPriceTotal ?> <?= $currencyCode ?>
                            </span>
                        <?php endif; ?>
                    </div>
                <?php } ?>

                <?php if (!empty($cartProduct['offer'])) { ?>
                    <div class="cart__offer">
                        <?= $cartProduct['offer']['title'] ?> 
                        -<?= $discountTotal ?> <?= $currencyCode ?>
                    </div>
                    <?php } else { echo $discountTotal.' '.$currencyCode; }
                ?>
            </div>

            </div>
    </div>


    <?php if ($cartProduct['added_via'] === 'thankyou_upsell'): ?><?php endif; ?>
    <div class="product-edit-section-title">
        <!--<?= Lang_clfe::__('Offer Details', 'clfe') ?> -->
    </div>
    <div class="cart-edit-offer">
        <div>
            <span><?= Lang_clfe::__('Offer Title', 'clfe') ?></span> <br/>
            <input type="text" name="offer_title" value="<?= $cartProduct['offer']['title'] ?>">
        </div>
        <div class="cart-edit-qty">
            <span><?= Lang_clfe::__('Quantity', 'clfe') ?></span> <br/>
            <input type="number" name="qty" value="<?= $cartProduct['qty'] ?>" duplicate_variations="<?= $isActiveVariationDuplicate ?>">
        </div>
        <div>
            <span><?= Lang_clfe::__('Discount per Product', 'clfe') ?></span> <br/>
            <input type="number" name="discount_per_product" value="<?= $cartProduct['discount_per_product'] ?>" >
        </div>
    </div>


    <div class="cart-edit-variations">
        <div class="product-edit-section-title">
            <?= Lang_clfe::__('Variations', 'clfe') ?>
        </div>
        <?php
        //For each quantity in cart (say 2 items), user should be able to select different variations (e.g. first item: red/L, second: blue/M).
        $existIndex = 0;
        $maxDuplicate = $isActiveVariationDuplicate == 'yes' ? $cartProduct['qty'] : 1;
        for ($index = 0; $index < $maxDuplicate; $index++) {
            if( isset( $cartProduct['variations'][$index] ) ) {
                $existIndex = $index;
            }
            $cartProductVariation = !isset($cartProduct['variations'][$index]) ? $cartProduct['variations'][$existIndex] : $cartProduct['variations'][$index];
            ?>

            <div class="qty_choise_variation">
                <?php if( $isActiveVariationDuplicate == 'yes' ) { ?>
                <span class="qty-choose-index"> 
                    <?= Lang_clfe::__('Choose', 'clfe') . ' : ' ?> 
                    <span> <?= $index + 1 ?> </span>
                </span>
                <?php } ?>
                <?php foreach ($variations['elements'] as $variation) { ?>
                    <div>
                        <span><?= $variation['title'] ?></span> <br/>
                        <select slug="<?= $variation['slug'] ?>" v_type="<?= $variation['type'] ?>">
                            <option></option>
                            <?php
                            foreach ($variation['options'] as $option) {
                                $isSelected = '';

                                foreach ($cartProductVariation as $selectedOption) {
                                    if ($variation['slug'] == $selectedOption['slug'] && $option['title'] == $selectedOption['value']) {
                                        $isSelected = 'selected="selected"';
                                        break;
                                    }
                                }
                                ?>
                                <option value="<?= $option['title'] ?>" extra_fees="<?= $option['extra_fees'] ?>" <?= $isSelected ?>> 
                                        <?= $option['title'] ?> 
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                <?php } ?>
            </div>
            <?php
        }
        ?>
    </div>

</div>
