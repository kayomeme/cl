<div id="cart-item-<?= $cartProduct['product_id'] ?>" class="cart__item">
    <div class="cart__image">
        <img src="<?= $cartProduct['short_image_url'] ?>" alt="<?= $cartProduct['title'] ?>"/>
    </div>

    <div class="cart__content">
        <?php if (isset($cartProduct['added_via'])) { ?>
            <div class="cart__added_via">
                <?= Lang_clfe::__('Added via :', 'clfe') ?>
                <strong><?= $cartProduct['added_via'] ?></strong>
            </div>
        <?php } ?>
        <div class="cart__header">
            <div class="cart__title">
                <?= $cartProduct['title'] ?>
            </div>
            <?php if (!empty($cartProduct['variations'])): ?>
                <div class="cart__variations">
                    <?php foreach ($cartProduct['variations'] as $qtyVariations): ?>
                        <div class="cart__variant">
                            <?php foreach ($qtyVariations as $qtyVariation): ?>
                                <span class="cart__variant-detail">
                                    <?= $qtyVariation['slug'] ?>: <?= $qtyVariation['value'] ?>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>


        </div>


        <div class="cart__pricing">
            <div class="cart__price-row">
                <?php if ($salePrice < $regularPrice): ?>
                    <span class="cart__price--sale">
                        <?= $salePrice ?> <?= $currencyCode ?>
                    </span>
                    <span class="cart__price price-struck">
                        <?= $regularPrice ?> <?= $currencyCode ?>
                    </span>
                <?php else: ?>
                    <span class="cart__price">
                        <?= $regularPrice ?> <?= $currencyCode ?>
                    </span>
                <?php endif; ?>

                <span class="cart__badge"><?= $qty ?></span>
            </div>
            <?php if ($qty > 1) { ?>
                <div class="cart__price-row">
                    <span class="cart__price cart__price--total">
                        <?= $salePrice * $qty ?> <?= $currencyCode ?>
                    </span>
                    <?php if ($salePrice < $regularPrice): ?>
                        <span class="cart__price price-struck">
                            <?= $regularPrice * $qty ?> <?= $currencyCode ?>
                        </span>
                    <?php endif; ?>
                </div>
            <?php } ?>

            <?php if (!empty($cartProduct['offer'])): ?>
                <div class="cart__offer">
                    <?= $cartProduct['offer']['title'] ?> 
                    -<?= $discountPerProduct * $qty ?> <?= $currencyCode ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="cart__actions">
            <button class="cart-load-update-product clfe-button clfe-button-update" product_id="<?= $cartProduct['product_id'] ?>">
                <?= Lang_clfe::__('Update', 'clfe') ?>
                <span class="dashicons dashicons-edit"></span>
            </button>
            <button class="cart-delete-product clfe-button clfe-button-delete" product_id="<?= $cartProduct['product_id'] ?>" title="<?= Lang_clfe::__('Remove this product from the cart', 'clfe') ?>">
                <span class="dashicons dashicons-trash"></span>
                
            </button>
        </div>
    </div>

</div>