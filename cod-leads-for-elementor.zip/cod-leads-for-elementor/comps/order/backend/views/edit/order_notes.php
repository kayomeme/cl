<?php
// order_notes.php
?>
<div class="sidebar-notes">
    <div class="notes__header">
        <h3 class="notes__title"><?= Lang_clfe::__('Order Notes', 'clfe') ?></h3>
        <button class="notes__add-button clfe-button">
            <?= Lang_clfe::__('Add Note', 'clfe') ?>
            <span class="dashicons dashicons-plus-alt2"></span>
        </button>
    </div>

    <div class="notes__form" style="display: none;">
        <div class="notes__field">
            <textarea class="notes__input notes__input--textarea" 
                      name="order_note" 
                      placeholder="<?= Lang_clfe::__('Enter note here...', 'clfe') ?>"></textarea>
        </div>
        <div class="notes__actions">
            <button class="notes__cancel-button clfe-button">
                <?= Lang_clfe::__('Cancel', 'clfe') ?>
            </button>
            <button class="notes__save-button clfe-button clfe-button-primary">
                <?= Lang_clfe::__('Save Note', 'clfe') ?>
            </button>
        </div>
    </div>

    <div class="notes__list">
        <?php if (!empty($order->notes)): ?>
            <?php foreach ($order->notes as $note): ?>
                <div class="notes__item">
                    <div class="notes__item-header">
                        <span class="notes__author"><?= $note->author ?></span>
                        <span class="notes__date"><?= date('Y-m-d H:i', strtotime($note->created_at)) ?></span>
                    </div>
                    <div class="notes__content">
                        <?= $note->content ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="notes__empty">
                <?= Lang_clfe::__('No notes added yet', 'clfe') ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
/* Order Notes Styles */
.notes__header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.notes__title {
    font-size: 16px;
    color: #333;
    font-weight: bold;
}

.notes__form {
    margin-bottom: 15px;
}

.notes__field {
    display: flex;
    flex-direction: column;
    gap: 5px;
    margin-bottom: 10px;
}

.notes__input--textarea {
    min-height: 80px;
    padding: 8px;
    border: 1px solid #eee;
    border-radius: 4px;
    resize: vertical;
}

.notes__actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

.notes__list {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.notes__item {
    padding: 10px;
    background: #f8f9fa;
    border: 1px solid #eee;
    border-radius: 4px;
}

.notes__item-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 5px;
}

.notes__author {
    font-weight: bold;
    font-size: 14px;
    color: #333;
}

.notes__date {
    font-size: 12px;
    color: #666;
}

.notes__content {
    font-size: 14px;
    color: #444;
    line-height: 1.4;
}

.notes__empty {
    text-align: center;
    padding: 20px;
    color: #666;
    font-size: 14px;
    border: 1px dashed #eee;
    border-radius: 4px;
}
    
</style>