<div class="c-element">
    <div class="clfe-accordion">
        <?= $value['name'] ?>
        <div class="clfe-draggable-icons-container">
            <span class="dashicons dashicons-sort"></span>
            <span class="dashicons dashicons-move"></span>
        </div>
    </div> 
    
    <div class="clfe-accordion-panel c-element-panel" style="display: none">

            <div>
                <label><?= Lang_clfe::_e('Name', 'clfe') ?></label><br/>
                <input type="text" elementName="name" value="<?= $value['name'] ?>" />
            </div>
            <div>
                <label><?= Lang_clfe::_e('Title', 'clfe') ?></label><br/>
                <input type="text" elementName="title" value="<?= $value['title'] ?>" />
            </div>
            <div>
                <label><?= Lang_clfe::_e('Cost', 'clfe') ?></label><br/>
                <input type="number" elementName="cost" isRequired="yes" value="<?= $value['cost'] ?>" placeholder="<?= Lang_clfe::_e('Status cost', 'clfe') ?>" />
            </div>
            <div>
                <label><?= Lang_clfe::_e('BG color', 'clfe') ?></label><br/>
                <input type="color" elementName="row_bg_color" isRequired="yes" value="<?= $value['row_bg_color'] ?>" />
            </div>
            <div>
                <label><?= Lang_clfe::_e('Text Color', 'clfe') ?></label><br/>
                <input type="color" elementName="row_text_color" isRequired="yes" value="<?= $value['row_text_color'] ?>" />
            </div>

            <div>
                <button type="button" class="clfe-image-selector">
                    <span>
                        <i class="dashicons dashicons-cloud-upload"></i>
                        <?= Lang_clfe::_e('Upload the thumbnail image', 'clfe') ?>
                    </span> <br/>
                    <img src="<?= isset($value['thumbnail_url']) ? $value['thumbnail_url'] : "" ?>" alt="" title="<?= Lang_clfe::_e('Select offer image', 'clfe') ?>" /> <br/>
                    <input type="hidden" class="clfe_img_id" elementName="thumbnail_id" value="<?= isset($value['thumbnail_id']) ? $value['thumbnail_id'] : "" ?>" />
                    <input type="hidden" class="clfe_img_url" elementName="thumbnail_url" value="<?= isset($value['thumbnail_url']) ? $value['thumbnail_url'] : "" ?>" />
                </button>
            </div>
        
            <div class="clfe-element-buttons">
                <button type="button" class="deleteElement" title="<?= Lang_clfe::_e('Remove this status', 'clfe') ?>">
                    <?= Lang_clfe::_e('Remove', 'clfe') ?>
                    <span class="dashicons dashicons-trash"></span>
                </button>
            </div>
    </div>
</div>