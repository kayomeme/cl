<div class="c-element clfe-flex-center">
    <div>
        <table>
            <tr>
                <td>
                    <span><?= Lang_clfe::_e('Name', 'clfe') ?></span> <input type="text" elementName="name" isRequired="yes" value="<?= $value['name'] ?>" placeholder="<?= Lang_clfe::_e('Status name', 'clfe') ?>" />
                </td>
                <td>
                    <span><?= Lang_clfe::_e('BG color', 'clfe') ?></span> 
                    <input type="color" elementName="row_bg_color" isRequired="yes" value="<?= $value['row_bg_color'] ?>" />
                </td>
                <td>
                    <span><?= Lang_clfe::_e('Text Color', 'clfe') ?></span> 
                    <input type="color" elementName="row_text_color" isRequired="yes" value="<?= $value['row_text_color'] ?>" />
                </td>
                <td>
                    <span><?= Lang_clfe::_e('Cost', 'clfe') ?></span> 
                    <input type="number" elementName="cost" isRequired="yes" value="<?= $value['cost'] ?>" placeholder="<?= Lang_clfe::_e('Status cost', 'clfe') ?>" />
                </td>
            </tr>
        </table>        
    </div>
    <div class="clfe-element-buttons">
        <button type="button" class="deleteElement" title="<?= Lang_clfe::_e('Remove this status', 'clfe') ?>">
            <span class="dashicons dashicons-trash"></span>
        </button>
    </div>

</div>