<div class="order-status">
    <h2 class="c-header" style="text-align: center">
        <strong><?= Lang_clfe::_e('Order Status name / BG color / text color / status cost', 'clfe') ?></strong>
    </h2>
    <div class="dynamic-elements order-status-dynamic-elements" attachedSettingName="order_status">
        <?php 
        foreach ($orderStatus['elements'] as $value) { 
            if( isset( $value['name'] ) ) {
                include 'c_element_status.php';
            }
        }
        ?> 
    </div>
    <button type="button" class="clfe-add-dynamic-element" dynamic-elements-container="order-status">
        <span class="dashicons dashicons-plus"></span>
        <?= Lang_clfe::_e('Add new status', 'clfe') ?>
    </button>
    <input type="text"  name="order_status" value="<?= adminUtils_clfe::cleanInput($settings['order_status']) ?>">
    

    <div class="clfe-empty-elements" style="display: none !important">
        <?php 
            $value = [
                'name' => '',
                'title' => '',
                'cost' => '0',
                'row_bg_color' => '#ffffff',
                'row_text_color' => '#000000',
                'thumbnail_id' => '',
                'thumbnail_url' => '',
            ];
            include 'c_element_status.php';
        ?>
    </div>
</div>