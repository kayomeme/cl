<div class="clfe-flex-center">
    <div>
        <strong> User Submitted City </strong> : <?= $insightDatas['city'] ?>
    </div>
    <div>
        <strong> Automatic City Detection </strong> : <?= $insightDatas['city_detection'] ?>
    </div>
</div>

<div class="clfe-flex-center">
    <div>
        <strong> country </strong> : <?= $insightDatas['country'] ?>
    </div>
    <div>
        <strong> state </strong> : <?= $insightDatas['state'] ?>
    </div>
    <div>
        <strong> address </strong> : 
        <a target="_blank" href="https://www.google.com/maps?q=<?= $insightDatas['latitude'].','.$insightDatas['longitude'] ?>">
            View on google map
        </a>
            
    </div>
</div>

<div class="clfe-flex-center">
    <div>
        <strong> referer </strong> : <?= $insightDatas['referer'] ?>
    </div>
    <div>
        <strong> Source </strong> : <?= $insightDatas['utm_source'] ?>
    </div>
    <div>
        <strong> Campaign </strong> : <?= $insightDatas['campaign_name'] ?>
    </div>
    <div>
        <strong> Adset </strong> : <?= $insightDatas['adset_name'] ?>
    </div>
    <div>
        <strong> ad_name </strong> : <?= $insightDatas['adset_name'] ?>
    </div>
</div>

<div class="clfe-flex-center">
    <div>
        <strong> user_browser </strong> : <?= $insightDatas['user_browser'] ?>
    </div>
    
    <div>
        <strong> user_ip </strong> : <?= $insightDatas['user_ip'] ?>
    </div>
    
    <div>
        <strong> user_os </strong> : <?= $insightDatas['user_os'] ?>
    </div>
</div>

<div class="clfe-flex-center">
    <div>
        <strong> user_agent </strong> : <?= $insightDatas['user_agent'] ?>
    </div> 
</div>
    
    
