<?php
include 'header.php';
?>

<div>
    <span class="clfe-text-white"><?= Lang_clfe::_e('Change To', 'clfe') ?></span>
    <select onchange="if(this.value) {window.location = this.value}">
        <option><?= Lang_clfe::_e('Select page limit', 'clfe') ?></option>
        <option value="<?= $_SERVER['REQUEST_URI'].'&limit=10' ?>">10</option>
        <option value="<?= $_SERVER['REQUEST_URI'].'&limit=30' ?>">30</option>
        <option value="<?= $_SERVER['REQUEST_URI'].'&limit=50' ?>">50</option>
        <option value="<?= $_SERVER['REQUEST_URI'].'&limit=100' ?>">100</option>
        <option value="<?= $_SERVER['REQUEST_URI'].'&limit=150' ?>">150</option>
    </select>
</div>
<table class="wp-list-table widefat fixed striped table-view-list posts">
    <thead>
        <th><?= Lang_clfe::_e('date', 'clfe') ?></th>
        <th><?= Lang_clfe::_e('Status', 'clfe') ?></th>
        <th><?= Lang_clfe::_e('full_name', 'clfe') ?></th>
        <th><?= Lang_clfe::_e('phone', 'clfe') ?></th>
        <th><?= Lang_clfe::_e('city', 'clfe') ?></th>
        <th><?= Lang_clfe::_e('adress', 'clfe') ?></th>
        <th><?= Lang_clfe::_e('product_title', 'clfe') ?></th>
        <th><?= Lang_clfe::_e('product_price', 'clfe') ?></th>
        <th><?= Lang_clfe::_e('quantity', 'clfe') ?></th>
        <th><?= Lang_clfe::_e('total', 'clfe') ?></th>
        <th><?= Lang_clfe::_e('Variations', 'clfe') ?></th>
        <th><?= Lang_clfe::_e('Insight', 'clfe') ?></th>
        <th><?= Lang_clfe::_e('Remove', 'clfe') ?></th>
    </thead>
    <tbody>
        <?php 
            $detailPopups = "";
            foreach ($orders as $order) { 
                $popupTitle = $order->full_name.' : '.$order->phone;
                $detailPopups = $detailPopups.'<div id="popup-'.$order->id.'" popuptitle="'.$popupTitle.'"> </div>';
            ?>
            <tr id="row-order-id-<?= $order->id ?>">
                <td><?= $order->created_at ?></td>
                <td><?= $order->status ?></td>
                <td><?= $order->full_name ?></td>
                <td><?= $order->phone ?></td>
                <td><?= $order->city ?></td>
                <td><?= $order->address ?></td>
                <td><?= $order->product_title ?></td>
                <td><?= $order->product_price ?></td>
                <td><?= $order->product_qty ?></td>
                <td><?= $order->total ?></td>
                <td><?= $order->variations_text ?></td>
                <td>
                    <button type="button" class="clfe-getinsight-bt" order_id="<?= $order->id ?>">
                        <span class="dashicons dashicons-analytics"></span> <?= Lang_clfe::_e('Insight', 'clfe') ?>
                    </button>
                </td>
                <td>
                    <button type="button" class="clfe-remove-bt" order_id="<?= $order->id ?>">
                        <span class="dashicons dashicons-trash"></span> <?= Lang_clfe::_e('Remove', 'clfe') ?>
                    </button>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>


<div id="clfe_delete_order">
    <input type="text" name="order_id" />
    <div class="clfe-user-fedback">
        <div class="clfe-msg_box">
            <div class="clfe-wait_msg"></div>
            <div class="alert"></div>
        </div>
    </div>
</div>

<div id="clfe_get_order_insight">
    <input type="text" name="order_id" />
    <div class="clfe-user-fedback">
        <div class="clfe-msg_box">
            <div class="clfe-wait_msg"></div>
            <div class="alert"></div>
        </div>
    </div>
</div>

<div style="display: none">
<?= $detailPopups ?>
</div>