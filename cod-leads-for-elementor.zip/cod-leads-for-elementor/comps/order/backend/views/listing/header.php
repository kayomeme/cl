<?php
// Add this to your helpers/functions.php or similar
function clfe_format_price($price, $currency = '') {
    $currency = empty($currency) ? get_option('clfe_currency', '$') : $currency;
    return $currency . number_format((float)$price, 2, '.', ',');
}