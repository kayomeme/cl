<?php
if (!defined('ABSPATH')) {
    exit;
}

include 'header.php';
?>

<div class="clfe-orders-container">
    <!-- Header -->
    <div class="clfe-page-header">
        <div class="clfe-header-main">
            <h1 class="clfe-title"><?= Lang_clfe::__('Orders', 'clfe') ?></h1>
            <span class="clfe-count"><?php printf('%d %s', count($orders), Lang_clfe::__('orders', 'clfe')); ?></span>
        </div>
    </div>

    <!-- Toolbar -->
    <div class="clfe-toolbar">
        <div class="clfe-toolbar-left">
            <select class="clfe-select" onchange="if (this.value) {
                        window.location = this.value
                    }">
                <option value=""><?= Lang_clfe::__('Bulk actions', 'clfe') ?></option>
                <?php
                $limits = [10, 30, 50, 100, 150];
                foreach ($limits as $option) {
                    printf(
                            '<option value="%s">%d %s</option>',
                            esc_url(add_query_arg('limit', $option, $_SERVER['REQUEST_URI'])),
                            $option,
                            Lang_clfe::__('orders per page', 'clfe')
                    );
                }
                ?>
            </select>
            <select class="clfe-select order__select" name="order_status">
                <?php foreach ($orderStatuses as $status): ?>
                    <option value="<?= $status['slug'] ?>" 
                        <?= $status['slug'] ?>>
                        <?= $status['title'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>

    <!-- Orders Table div -->
    <div class="clfe-table-container">
        <div class="clfe-table-header">
            <div class="table-row">
                <div class="cell cell-order-recup">
                    <?= Lang_clfe::__('Order', 'clfe') ?>
                </div>
                <div class="cell"><?= Lang_clfe::__('Customer info', 'clfe') ?></div>
                <div class="cell"><?= Lang_clfe::__('Cart info', 'clfe') ?></div>
                <div class="cell td-actions-buttons">
                    <?= Lang_clfe::__('Actions', 'clfe') ?>
                </div>
            </div>
        </div>

        <div class="clfe-table-body">
            <?php if (!empty($orders)) : ?>
                <?php
                foreach ($orders as $order) :
                    $order_id = absint($order->id);
                    $status_class = sanitize_html_class('status-' . $order->status);
                    $orderData = OrderModelBK_clfe::getOrderData($order_id);
                    //$cartProducts = isset($orderData['cart']) ? $orderData['cart'] : [];
                    $cartProducts = OrderModelBK_clfe::getCartItems($order_id);
                    $currency = isset($orderData['currency_code']) ? $orderData['currency_code'] : '';
                    ?>
                    <div class="table-row" id="row-order-id-<?= $order_id ?>">

                        <div class="cell cell-order-recup">
                            <div>
                                <span class="order-total">
                                    <?= number_format($order->total, 2) . ' ' . $currency ?>
                                </span>
                                <?php 
                                $statusStyle = '';
                                $status = $order->status;
                                if( isset( $orderStatuses[$order->status] ) ) {
                                   $statusStyle = 'background-color:'.$orderStatuses[$order->status]['bg_color'].';color:'.$orderStatuses[$order->status]['text_color']; 
                                
                                   $status = $orderStatuses[$order->status]['title'];
                                }
                                ?>
                                <span class="status-pill <?= $status_class ?>" style="<?= $statusStyle ?>">
                                    <?= $status ?>
                                </span>
                            </div>
                            <div>
                                <a href="<?= admin_url('admin.php?page=clfe_orders&action=edit&order_id=' . $order_id) ?>" class="order-link">
                                    #<?= $order_id ?>
                                </a>
                                <span class="clfe-date">
                                    <?= date('M j, Y, g:i A', strtotime($order->created_at)) ?>
                                </span>
                            </div>

                        </div>
                        <div class="cell td-customer-info">
                            <div class="customer-info">
                                <?php if (!empty($order->full_name)) : ?>
                                    <span class="customer-name">
                                        <span class="dashicons dashicons-admin-users"></span>
                                        <?= $order->full_name ?>
                                    </span>
                                <?php endif; ?>
                                <?php if (!empty($order->phone)) : ?>
                                    <span class="customer-phone">
                                        <span class="dashicons dashicons-phone"></span>
                                        <a href="tel:<?= esc_attr(str_replace(' ', '', $order->phone)) ?>" class="phone-link">
                                            <?= $order->phone ?>
                                        </a>
                                    </span>
                                <?php endif; ?>
                                <?php if (!empty($order->email)) : ?>
                                    <span class="customer-email">
                                        <span class="dashicons dashicons-email"></span>
                                        <?= $order->email ?>
                                    </span>
                                <?php endif; ?>
                                <?php if (!empty($order->city)) : ?>
                                    <span class="customer-city">
                                        <span class="dashicons dashicons-location"></span>
                                        <?= $order->city ?>
                                    </span>
                                <?php endif; ?>
                                <?php if (!empty($order->address_1)) : ?>
                                    <span class="customer-adress">
                                        <span class="dashicons dashicons-location-alt"></span>
                                        <?= $order->address_1 ?> khh  jhkjgjkgk  jjhj jhjk
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="cell td-cart">
                            <div class="cart-display">
                                <?php foreach ($cartProducts as $cartProduct) : ?>
                                    <div class="cart-product">
                                        <div class="cart-product-img">
                                            <img src="<?= $cartProduct['short_image_url'] ?>" />
                                        </div>
                                        <div class="cart-product-meta">
                                            <div class="cart-product-header">
                                                <?= $cartProduct['title'] . ' * ' . $cartProduct['qty'] ?>

                                            </div>
                                            <!--<div class="clfe-cart-product-variations">
                                            <?php foreach ($cartProduct['variations'] as $qtyVariations) : ?>
                                                        <div class="qty_choise_variation">
                                                <?php foreach ($qtyVariations as $qtyVariation) : ?>
                                                                    <span> <?= $qtyVariation['slug'] ?> : <?= $qtyVariation['value'] ?> </span>
                                                <?php endforeach; ?>
                                                        </div>
                                            <?php endforeach; ?>
                                            </div> -->
                                        </div>

                                        <!--<div class="cart-product-prices">
                                                <span class="regular-price"><?= $cartProduct['regular_price'] . ' ' . $currency ?></span>
                                                <span class="sale-price"><?= $cartProduct['sale_price'] . ' ' . $currency ?></span>
                                        </div> -->

                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="cell td-actions-buttons">
                            <div class="action-buttons">
                                <a href="<?= admin_url('admin.php?page=clfe_orders&action=edit&order_id=' . $order_id) ?>" class="clfe-action-btn button button-primary">
                                    <span class="dashicons dashicons-edit"></span>
                                    <?= Lang_clfe::__('Edit', 'clfe') ?> 
                                </a>
                                <button type="button" class="clfe-action-btn clfe-getinsight-bt" order_id="<?= $order_id ?>">
                                    <span class="dashicons dashicons-analytics"></span>
                                </button>
                                <button type="button" class="clfe-action-btn clfe-remove-bt" order_id="<?= $order_id ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <div class="table-row no-items">
                    <div class="cell" style="width: 100%">
                        <div class="clfe-empty-state">
                            <span class="dashicons dashicons-clipboard"></span>
                            <h2><?= Lang_clfe::__('No orders found', 'clfe') ?></h2>
                            <p><?= Lang_clfe::__('Orders will appear here when you receive them.', 'clfe') ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="clfe-sticky-bottom-bar">
    <div class="clfe-user-fedback">

    </div>
</div>