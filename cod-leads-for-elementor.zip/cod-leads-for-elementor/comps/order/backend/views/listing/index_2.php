<?php
if (!defined('ABSPATH')) {
    exit;
}

include 'header.php';
?>

<div class="clfe-orders-container">
    <!-- Header -->
    <div class="clfe-page-header">
        <div class="clfe-header-main">
            <h1 class="clfe-title"><?= Lang_clfe::__('Orders', 'clfe') ?></h1>
            <span class="clfe-count"><?php printf('%d %s', count($orders), Lang_clfe::__('orders', 'clfe')); ?></span>
        </div>
    </div>

    <!-- Toolbar -->
    <div class="clfe-toolbar">
        <div class="clfe-toolbar-left">
            <select class="clfe-select" onchange="if(this.value) {window.location = this.value}">
                <option value=""><?= Lang_clfe::__('Bulk actions', 'clfe') ?></option>
                <?php 
                $limits = [10, 30, 50, 100, 150];
                foreach($limits as $option) {
                    printf(
                        '<option value="%s">%d %s</option>',
                        esc_url(add_query_arg('limit', $option, $_SERVER['REQUEST_URI'])),
                        $option,
                        Lang_clfe::__('orders per page', 'clfe')
                    );
                }
                ?>
            </select>
        </div>
    </div>

    <!-- Orders Table -->
    <div class="clfe-table-container">
        <table class="clfe-table">
            <thead>
                <tr>
                    <th class="checkbox-column">
                        <input type="checkbox" class="clfe-select-all">
                    </th>
                    <th><?= Lang_clfe::__('Order', 'clfe') ?></th>
                    <th><?= Lang_clfe::__('Customer info', 'clfe') ?></th>
                    <th><?= Lang_clfe::__('cart info', 'clfe') ?></th>
                    <th><?= Lang_clfe::__('Actions', 'clfe') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($orders)) : ?>
                    <?php foreach ($orders as $order) : 
                        $order_id = absint($order->id);
                        $status_class = sanitize_html_class('status-' . $order->status);
                        $orderData = OrderModelBK_clfe::getOrderData($order_id);
                        $cartProducts = isset( $orderData['cart'] ) ? $orderData['cart']  : [];
                        //var_dump($orderData);
                    ?>
                        <tr id="row-order-id-<?= $order_id ?>">
                            <td>
                                <input type="checkbox" class="clfe-select-order" value="<?= $order_id ?>">
                            </td>
                            <td>
                                <a href="<?= admin_url('admin.php?page=clfe_orders&action=edit&order_id=' . $order_id) ?>" class="order-link">
                                    #<?= $order_id ?>
                                </a> 
                                <span class="order-total">
                                    <?= clfe_format_price($order->total) ?>
                                </span>
                                <span class="status-pill <?= $status_class ?>">
                                    <span class="status-dot"></span>
                                    <?= $order->status ?>
                                </span>
                                <br/>
                                <span class="clfe-date">
                                    <?= date('M j, Y, g:i A', strtotime($order->created_at)) ?>
                                </span>
                            </td>
                            <td class="td-customer-info">
                                <div class="customer-info">
                                    <?php if(!empty($order->full_name)) { ?>
                                    <span class="customer-name"><?= $order->full_name ?></span>
                                    <?php } ?>
                                    <?php if(!empty($order->phone)) { ?>
                                    <span class="customer-phone"><?= $order->phone ?></span>
                                    <?php } ?>
                                    <?php if(!empty($order->email)) { ?>
                                    <span class="customer-email"><?= $order->email ?></span>
                                    <?php } ?>
                                    <?php if(!empty($order->city)) { ?>
                                    <span class="customer-city"><?= $order->city ?></span>
                                    <?php } ?>
                                    <?php if(!empty($order->address_1)) { ?>
                                    <span class="customer-adress"><?= $order->address_1 ?></span>
                                    <?php } ?>
                                </div>
                            </td>
                            <td class="td-cart">
                                <div class="cart-display">
                                    <?php foreach ($cartProducts as $cartProduct) { ?>
                                    <div class="cart-product">
                                        <div class="cart-product-img">
                                            <img src="<?= $cartProduct['short_image_url'] ?>" />
                                        </div>
                                        <div class="cart-product-meta">
                                            <div class="clfe-cart-product-title">
                                                <?= $cartProduct['title'] ?>
                                            </div>
                                            <div class="clfe-cart-product-variations">
                                                <?php foreach ($cartProduct['variations'] as $qtyVariations) { ?>
                                                <div class="qty_choise_variation">
                                                    <?php foreach ($qtyVariations as $qtyVariation) { ?>
                                                    <span> <?= $qtyVariation['slug'] ?> :  <?= $qtyVariation['value'] ?>  </span>
                                                    <?php } ?>
                                                </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="cart-product-price-box">
                                            <div class="cart-product-price">
                                                <div class="clfe-cart-product-sale-price">
                                                    <span class="sale_price"><?= $cartProduct['sale_price'] ?></span>
                                                    <span class="clfe-currency"><?= $orderData['currency_label'] ?></span>
                                                </div>
                                                <div class="clfe-cart-product-regular-price">
                                                    <span class="regular_price"><?= $cartProduct['regular_price'] ?></span>
                                                    <span class="clfe-currency"><?= $orderData['currency_label'] ?></span>
                                                </div>
                                            </div>
                                            <div class="cart-product-price-offer">
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <button type="button" class="clfe-action-btn clfe-getinsight-bt" order_id="<?= $order_id ?>">
                                        <span class="dashicons dashicons-analytics"></span>
                                    </button>
                                    <button type="button" class="clfe-action-btn clfe-remove-bt" order_id="<?= $order_id ?>">
                                        <span class="dashicons dashicons-trash"></span>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr class="no-items">
                        <td colspan="7">
                            <div class="clfe-empty-state">
                                <span class="dashicons dashicons-clipboard"></span>
                                <h2><?= Lang_clfe::__('No orders found', 'clfe') ?></h2>
                                <p><?= Lang_clfe::__('Orders will appear here when you receive them.', 'clfe') ?></p>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Hidden Forms -->
<div id="clfe_delete_order" style="display: none;">
    <input type="text" name="order_id" />
    <div class="clfe-user-fedback">
        <div class="clfe-msg_box">
            <div class="clfe-wait_msg"></div>
            <div class="alert"></div>
        </div>
    </div>
</div>

<div id="clfe_get_order_insight" style="display: none;">
    <input type="text" name="order_id" />
    <div class="clfe-user-fedback">
        <div class="clfe-msg_box">
            <div class="clfe-wait_msg"></div>
            <div class="alert"></div>
        </div>
    </div>
</div>