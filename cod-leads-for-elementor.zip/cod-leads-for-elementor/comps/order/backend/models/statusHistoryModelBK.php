<?php

class StatusHistoryModelBK_clfe {
    private static $tableName = 'order_status_history';
    
    private static function getTableName() {
        global $wpdb;
        return $wpdb->prefix . self::$tableName;
    }
    
    public static function getOrderHistory($orderId) {
        if (!$orderId) {
            return [];
        }

        global $wpdb;
        $tableName = self::getTableName();
        
        $query = $wpdb->prepare(
            "SELECT * FROM {$tableName} 
            WHERE order_id = %d 
            ORDER BY date_created_gmt DESC",
            $orderId
        );
        
        $results = $wpdb->get_results($query);
        return $wpdb->last_error ? array() : $results;
    }

    public static function getHistoryItem($historyId) {
        if (!$historyId) {
            return null;
        }

        global $wpdb;
        $tableName = self::getTableName();
        
        $query = $wpdb->prepare(
            "SELECT * FROM {$tableName} WHERE id = %d",
            $historyId
        );
        
        return $wpdb->get_row($query);
    }

    public static function addHistoryEntry($data) {
        if (!isset($data['order_id']) || !isset($data['to_status'])) {
            return response_clfe(0, Lang_clfe::__('Missing required fields', 'clfe'), null);
        }

        $defaultData = [
            'date_created_gmt' => current_time('mysql', true),
            'changed_by' => get_current_user_id(),
            'note' => '',
            'customer_notified' => 0
        ];

        $insertData = array_merge($defaultData, $data);
        
        $response = adminDB_clfe::insert(self::$tableName, $insertData);
        
        return $response;
    }

    public static function updateNote($historyId, $note) {
        if (!$historyId) {
            return response_clfe(0, Lang_clfe::__('Invalid history ID', 'clfe'), null);
        }

        $data = ['note' => $note];
        $where = ['id' => $historyId];

        return adminDB_clfe::update(self::$tableName, $data, $where);
    }

    public static function verifyTable() {
        global $wpdb;
        $tableName = self::getTableName();
        
        return $wpdb->get_var("SHOW TABLES LIKE '{$tableName}'") === $tableName;
    }
}