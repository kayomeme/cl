<?php

class CartModelBK_clfe {
    public static function getVariations($productId) {
        $variations = get_post_meta($productId, 'clfe_variations', true);
        
        $variations = jsonDecode_clfe($variations);
        if( is_null($variations) || empty( $variations ) ) {  
            $variations['elements'][] = self::$default_variations;
        }  
        
        return $variations;
    }
}
