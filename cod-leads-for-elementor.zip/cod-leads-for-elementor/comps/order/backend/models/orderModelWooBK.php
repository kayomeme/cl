<?php
class OrderModelWooBK_clfe {
    private static $orderTable = 'wc_orders';
    private static $orderMetaTable = 'wc_orders_meta';
    private static $orderAddressesTable = 'wc_order_addresses';
    private static $orderItemsTable = 'wc_order_items';
    private static $orderItemMetaTable = 'wc_order_item_meta';
    private static $orderStatsTable = 'wc_order_stats';
    
    // old woocommerce system
    private static $woocommerceOrderItemsTable = 'woocommerce_order_items';
    private static $woocommerceOrderItemMetaTable = 'woocommerce_order_itemmeta';
    
    private static function getTableName($table) {
        global $wpdb;
        return $wpdb->prefix . $table;
    }
    
    public static function getOrderData($order_id) {
        if( !$order_id ) {
            return [];
        }
        $jsonOrderData = adminDB_clfe::getOrderMetaValue(self::$orderMetaTable, 'clfe_order_data', $order_id);
        return (array) jsonDecode_clfe($jsonOrderData);
    }

    /*
     * HPOS system
     */
    public static function getCartItemsFromWcItems($order_id) {
        global $wpdb;
            $itemsTable = self::getTableName(self::$orderItemsTable);
            $itemMetaTable = self::getTableName(self::$orderItemMetaTable);

            // Get items with their meta
            $query = $wpdb->prepare("
                SELECT 
                    i.id as item_id,
                    i.product_id,
                    i.name as title,
                    i.quantity as qty,
                    i.total as sale_price,
                    i.subtotal as regular_price,
                    GROUP_CONCAT(
                        CONCAT(
                            im.meta_key,
                            '::',
                            im.meta_value
                        )
                        SEPARATOR '||'
                    ) as meta_data
                FROM {$itemsTable} i
                LEFT JOIN {$itemMetaTable} im ON i.id = im.order_item_id
                WHERE i.order_id = %d
                GROUP BY i.id",
                $order_id
            );

            $items = $wpdb->get_results($query);

            $processed_items = [];
            foreach ($items as $item) {
                $variations = [];
                $custom_fields = [];
                $qtyOffer = [];
                $short_image_url = '';
                $discount_per_product = 0;

                if ($item->meta_data) {
                    $meta_array = explode('||', $item->meta_data);
                    $variation_set = [];

                    foreach ($meta_array as $meta) {
                        list($key, $value) = explode('::', $meta);

                        if (strpos($key, 'pa_') === 0) {
                            $variation_set[] = [
                                'slug' => str_replace('pa_', '', $key),
                                'value' => $value,
                                'v_index' => 1,
                                'fees' => 0,
                                'v_type' => 'buttons'
                            ];
                        } elseif ($key === 'image_url') {
                            $short_image_url = $value;
                        } elseif ($key === 'qty_offer') {
                            $qtyOffer = jsonDecode_clfe($value);
                        } elseif ($key === 'discount_per_product') {
                            $discount_per_product = floatval($value);
                        } else {
                            $custom_fields[$key] = $value;
                        }
                    }

                    if (!empty($variation_set)) {
                        $variations[] = $variation_set;
                    }
                }

                $processed_items[] = [
                    'product_id' => $item->product_id,
                    'title' => $item->title,
                    'regular_price' => floatval($item->regular_price),
                    'sale_price' => floatval($item->sale_price),
                    'discount_per_product' => $discount_per_product,
                    'qty' => $item->qty,
                    'short_image_url' => $short_image_url,
                    'custom_fields' => $custom_fields,
                    'variations' => $variations,
                    'qty_offer' => $qtyOffer
                ];
            }

            return $processed_items;   
    }
    /*
     * old Woocommerce system
     */    
    public static function getCartItemsFromWoocommerceItems($order_id) {
       global $wpdb;
       $itemsTable = self::getTableName(self::$woocommerceOrderItemsTable);
       $itemMetaTable = self::getTableName(self::$woocommerceOrderItemMetaTable);

       $query = $wpdb->prepare("
           SELECT 
               oi.order_item_id as item_id,
               MAX(CASE WHEN oim.meta_key = '_product_id' THEN oim.meta_value END) as product_id,
               oi.order_item_name as title,
               MAX(CASE WHEN oim.meta_key = '_qty' THEN oim.meta_value END) as qty,
               MAX(CASE WHEN oim.meta_key = '_line_total' THEN oim.meta_value END) as sale_price,
               MAX(CASE WHEN oim.meta_key = '_line_subtotal' THEN oim.meta_value END) as regular_price,
               GROUP_CONCAT(
                   CONCAT(
                       oim.meta_key,
                       '::',
                       oim.meta_value
                   )
                   SEPARATOR '||'
               ) as meta_data
           FROM {$itemsTable} oi
           LEFT JOIN {$itemMetaTable} oim ON oi.order_item_id = oim.order_item_id
           WHERE oi.order_id = %d
           GROUP BY oi.order_item_id",
           $order_id
       );

       $items = $wpdb->get_results($query);
       $processed_items = [];

       foreach ($items as $item) {
           $variations = [];
           $custom_fields = [];
           $qtyOffer = [];
           $short_image_url = '';
           $discount_per_product = 0;

           if ($item->meta_data) {
               $meta_array = explode('||', $item->meta_data);
               $variation_set = [];
               foreach ($meta_array as $meta) {
                   list($key, $value) = explode('::', $meta);
                   if (strpos($key, 'pa_') === 0) {
                       $variation_set[] = [
                           'slug' => str_replace('pa_', '', $key),
                           'value' => $value,
                           'v_index' => 1,
                           'fees' => 0,
                           'v_type' => 'buttons'
                       ];
                   } elseif ($key === 'image_url') {
                       $short_image_url = $value;
                   } elseif ($key === 'qty_offer') {
                       $qtyOffer = jsonDecode_clfe($value);
                   } elseif ($key === 'discount_per_product') {
                       $discount_per_product = floatval($value);
                   } else {
                       $custom_fields[$key] = $value;
                   }
               }
               if (!empty($variation_set)) {
                   $variations[] = $variation_set;
               }
           }

           $processed_items[] = [
               'product_id' => $item->product_id,
               'title' => $item->title,
               'regular_price' => floatval($item->regular_price),
               'sale_price' => floatval($item->sale_price),
               'discount_per_product' => $discount_per_product,
               'qty' => $item->qty,
               'short_image_url' => $short_image_url,
               'custom_fields' => $custom_fields,
               'variations' => $variations,
               'qty_offer' => $qtyOffer
           ];
       }
       return $processed_items;   
    }
    
}