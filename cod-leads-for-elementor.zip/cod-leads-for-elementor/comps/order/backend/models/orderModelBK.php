<?php
class OrderModelBK_clfe {
    private static $orderTable = 'wc_orders';
    private static $orderMetaTable = 'wc_orders_meta';
    private static $orderAddressesTable = 'wc_order_addresses';
    private static $orderItemsTable = 'wc_order_items';
    private static $orderItemMetaTable = 'wc_order_item_meta';
    private static $orderStatsTable = 'wc_order_stats';
    
    private static $orderTableColumns = [
        'status', 'currency', 'total_amount', 'customer_note', 'insight_id'
    ];
    private static $orderAddressesTableColumns = [
        'first_name', 'last_name', 'address_1', 'city', 'state', 'postcode', 'country', 'email', 'phone'
    ];
    
    private static function getTableName($table) {
        global $wpdb;
        return $wpdb->prefix . $table;
    }
    
    public static function getCartItems($order_id) {
        /*
         * this is the format for cart items
         * [{\"product_id\":36725,\"title\":\"Sweatshirt - Born Race\",\"regular_price\":249,\"sale_price\":169,\"discount_per_product\":100,\"qty\":2,\"short_image_url\":\"https:\\/\\/silvereagle.test\\/wp-content\\/uploads\\/2022\\/03\\/free-image-resizer-cropper-51-150x150.png\",\"custom_fields\":[],\"variations\":[[{\"slug\":\"couleur\",\"value\":\"bleuciel\",\"v_index\":1,\"fees\":0,\"v_type\":\"buttons\"}],[{\"slug\":\"couleur\",\"value\":\"bleuciel\",\"v_index\":1,\"fees\":0,\"v_type\":\"buttons\"}]],\"offers\":[{\"type\":\"qty_offers\",\"qty\":2,\"discount_per_product\":100,\"title\":\"Buy 2 \",\"total_discount\":498}]}]
         */

        if (!$order_id) {
            return [];
        }

        $jsonOrderData = adminDB_clfe::getOrderMetaValue(self::$orderMetaTable, 'clfe_cart_items', $order_id);
        $cartItems = (array) jsonDecode_clfe($jsonOrderData);
        $cartItems = array_column($cartItems, null, 'product_id');

        if (!empty($cartItems)) {
            return $cartItems;
        }

        $cartItems = OrderModelWooBK_clfe::getCartItemsFromWcItems($order_id);
        $cartItems = array_column($cartItems, null, 'product_id');
        
        if( !empty( $cartItems ) ) {
            return $cartItems;
        }
        
        $cartItems = OrderModelWooBK_clfe::getCartItemsFromWoocommerceItems($order_id);
        $cartItems = array_column($cartItems, null, 'product_id');

        return $cartItems;
    }
    
    public static function getOrderData($order_id) {
        if( !$order_id ) {
            return [];
        }
        $jsonOrderData = adminDB_clfe::getOrderMetaValue(self::$orderMetaTable, 'clfe_order_data', $order_id);
        return (array) jsonDecode_clfe($jsonOrderData);
    }
    
    public static function addNewMeta($order_id, $meta_key, $meta_value) {
        
        if( is_array($meta_value) || is_object($meta_value) ) {
            $meta_value = jsonEncode_clfe($meta_value);
        }
        
        $data = [
            'order_id' => $order_id,
            'meta_key' => $meta_key,
            'meta_value' => $meta_value
        ];
        
        $response = adminDB_clfe::insert('wc_orders_meta', $data);

        return $response;
    }
    
    public static function updateMeta($order_id, $meta_key, $meta_value) {
        
        if( is_array($meta_value) || is_object($meta_value) ) {
            $meta_value = jsonEncode_clfe($meta_value);
        }
        
        $data = [
            'meta_value' => $meta_value
        ];
        
        $where = [
            'order_id' => $order_id,
            'meta_key' => $meta_key,
        ];

        $response = adminDB_clfe::update('wc_orders_meta', $data, $where);

        return $response;
    }
    
    public static function GetLastPostId() {
        global $wpdb;
        $orderTable = self::getTableName(self::$orderTable);
        $query = "SELECT id FROM {$orderTable} ORDER BY id DESC LIMIT 0,1";
        $result = $wpdb->get_results($query);
        return !empty($result) ? $result[0]->id : 0;
    }
    
    public static function GetLastOrders($limit) {
        global $wpdb;
        $orderTable = self::getTableName(self::$orderTable);
        $addressTable = self::getTableName(self::$orderAddressesTable);
        $itemsTable = self::getTableName(self::$orderItemsTable);
        $itemMetaTable = self::getTableName(self::$orderItemMetaTable);
        
        $query = $wpdb->prepare("
            SELECT 
                o.id,
                o.status,
                o.date_created_gmt as created_at,
                o.total_amount as total,
                a.first_name,
                a.last_name,
                CONCAT(a.first_name, ' ', a.last_name) as full_name,
                a.phone,
                a.email,
                a.city,
                a.address_1,
                i.product_id,
                i.name as product_title,
                i.quantity as product_qty,
                i.total as product_price,
                GROUP_CONCAT(DISTINCT CONCAT(im.meta_key, ': ', im.meta_value) SEPARATOR ', ') as variations_text
            FROM {$orderTable} o
            LEFT JOIN {$addressTable} a ON o.id = a.order_id AND a.address_type = 'billing'
            LEFT JOIN {$itemsTable} i ON o.id = i.order_id
            LEFT JOIN {$itemMetaTable} im ON i.id = im.order_item_id AND im.meta_key LIKE 'pa_%'
            GROUP BY o.id
            ORDER BY o.id DESC 
            LIMIT %d",
            $limit
        );
        
        $results = $wpdb->get_results($query);
        return $wpdb->last_error ? array() : $results;
    }
    
    public static function getOrderDetails($orderId) {
        if (!$orderId) {
            return response_clfe(0, Lang_clfe::__('Invalid order ID', 'clfe'), null);
        }

        global $wpdb;
        $orderTable = self::getTableName(self::$orderTable);
        $addressTable = self::getTableName(self::$orderAddressesTable);

        // First get order and billing info
        $query = $wpdb->prepare("
            SELECT 
                o.id,
                o.status,
                o.date_created_gmt as created_at,
                o.total_amount as total,
                o.customer_note,
                a.first_name,
                a.last_name,
                CONCAT(a.first_name, ' ', a.last_name) as full_name,
                a.phone,
                a.email,
                a.city,
                a.state,
                a.postcode,
                a.country,
                a.address_1 as address
            FROM {$orderTable} o LEFT JOIN {$addressTable} a ON o.id = a.order_id AND a.address_type = 'billing'
            WHERE o.id = %d", $orderId );

        $order = $wpdb->get_row($query);

        if (!$order) {
            return response_clfe(0, Lang_clfe::__('Order not found ', 'clfe').$wpdb->last_error, null);
        }

        // Build response data
        /*$order_data = [
            'id' => $order->id,
            'status' => [
                'code' => $order->status,
                'label' => Lang_clfe::__($order->status, 'clfe')
            ],
            'dates' => [
                'created' => $order->created_at,
                'formatted' => date(Lang_clfe::__('M d, Y, g:i A', 'clfe'), strtotime($order->created_at))
            ],
            'totals' => [
                'amount' => $order->total,
                'formatted' => sprintf(
                    '%s %s', 
                    number_format((float)$order->total, 2), 
                    Lang_clfe::__('USD', 'clfe')
                )
            ],
            'customer' => [
                'first_name' => $order->first_name,
                'last_name' => $order->last_name,
                'full_name' => $order->full_name,
                'phone' => $order->phone,
                'email' => $order->email,
                'city' => $order->city,
                'address' => $order->address_1
            ],
            //'items' => $processed_items
        ];*/

        return response_clfe(1, Lang_clfe::__('Order details retrieved successfully', 'clfe'), $order);
    }
    
    public static function update($orderId, $args) {
        
        $response = self::updateAddresesTable($orderId, $args);
        $response = self::updateOrderTable($orderId, $args);
        
        return $response;
    }
    
    public static function updateOrderTable($orderId, $args) {
        $dataToUpdate = [];
        
        foreach (self::$orderTableColumns as $fieldName) {
            if (isset($args[$fieldName])) {
                $dataToUpdate[$fieldName] = $args[$fieldName];
            }
        }
        
        $where = [
            'id' => (int)$orderId,
        ];
        

        $response = adminDB_clfe::update(self::$orderTable, $dataToUpdate, $where);

        return $response;
    }

    public static function updateAddresesTable($orderId, $args) {
        $dataToUpdate = [];
        
        foreach (self::$orderAddressesTableColumns as $fieldName) {
            if (isset($args[$fieldName])) {
                $dataToUpdate[$fieldName] = $args[$fieldName];
            }
        }
        
        $where = [
            'order_id' => (int)$orderId,
        ];
        

        $response = adminDB_clfe::update(self::$orderAddressesTable, $dataToUpdate, $where);

        return $response;
    }
    
    
    
    
    public static function deleteOrder($orderId) {
        global $wpdb;
        $orderId = (int)$orderId;
        
        $wpdb->query('START TRANSACTION');
        
        try {
            $tables = [
                self::$orderTable => ['id', $orderId],
                self::$orderAddressesTable => ['order_id', $orderId],
                self::$orderItemsTable => ['order_id', $orderId],
                self::$orderMetaTable => ['order_id', $orderId],
               // self::$orderStatsTable => ['order_id', $orderId]
            ];
            
            foreach ($tables as $table => $condition) {
                $wpdb->delete(
                    self::getTableName($table),
                    [$condition[0] => $condition[1]],
                    ['%d']
                );
            }
            
            $wpdb->query('COMMIT');
            return response_clfe(1, Lang_clfe::__('order deleted', 'clfe'), null);
            
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            error_log('Error deleting order: ' . $e->getMessage());
            return response_clfe(0, Lang_clfe::__('error when deleting order', 'clfe'), null);
        }
    }
    
    public static function getAttachedInsightInfo($orderId) {
        global $wpdb;
        $insightsTableName = $wpdb->prefix . 'insights';
        
        $query = $wpdb->prepare(
            "SELECT * FROM {$insightsTableName} WHERE order_id = %d",
            $orderId
        );
        
        $result = $wpdb->get_results($query, ARRAY_A);
        return $wpdb->last_error ? array() : $result;
    }
    
    public static function updateOrdersList($orders) {
        global $wpdb;
        
        if (empty($orders) || !is_array($orders) || empty($orders[0])) {
            return response_clfe(0, Lang_clfe::__('No orders to update', 'clfe'), null);
        }
        
        $dbFieldsNames = array_flip($orders[0]);
        
        if (!isset($dbFieldsNames['order_id']) || !isset($dbFieldsNames['status'])) {
            return response_clfe(0, 'Invalid order data format', null);
        }
        
        $countUpdated = 0;
        $wpdb->query('START TRANSACTION');
        
        try {
            foreach ($orders as $order) {
                $order_id = (int)$order[$dbFieldsNames['order_id']];
                if ($order_id > 0) {
                    $status = sanitize_text_field($order[$dbFieldsNames['status']]);
                    
                    $updated = $wpdb->update(
                        self::getTableName(self::$orderTable),
                        ['status' => $status],
                        ['id' => $order_id],
                        ['%s'],
                        ['%d']
                    );
                    
                    if ($updated !== false) {
                        $countUpdated++;
                    }
                }
            }
            
            $wpdb->query('COMMIT');
            
            return response_clfe(1, 
                Lang_clfe::__('Synchronization done for', 'clfe') . ' ' . 
                $countUpdated . ' ' . 
                Lang_clfe::__('orders', 'clfe'), 
                null
            );
            
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            error_log('Error updating orders: ' . $e->getMessage());
            return response_clfe(0, 'Error updating orders', null);
        }
    }
    
    public static function verifyTables() {
        global $wpdb;
        
        $tables = [
            self::getTableName(self::$orderTable),
            self::getTableName(self::$orderMetaTable),
            self::getTableName(self::$orderAddressesTable),
            self::getTableName(self::$orderItemsTable),
            self::getTableName(self::$orderItemMetaTable),
            self::getTableName(self::$orderStatsTable)
        ];
        
        foreach ($tables as $table) {
            if (!$wpdb->get_var("SHOW TABLES LIKE '{$table}'")) {
                return false;
            }
        }
        
        return true;
    }
}