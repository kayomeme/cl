<?php
// status_history.php
?>
<div class="order-edit__history">
    <div class="history__header">
        <div class="history__title">
            <?= Lang_clfe::__('Status History', 'clfe') ?>
        </div>
    </div>

    <div class="history__content">
        <div class="history__meta">
            <div>
               <label class="order__label"><?= Lang_clfe::__('Created', 'clfe') ?></label> 
               <strong><?= date('Y-m-d\TH:i', strtotime($order->created_at)) ?></strong>
            </div>
        </div>
        <?php if (!empty($statusHistory)): ?>
            <?php foreach ($statusHistory as $history) {
                include 'status_history_item.php';  
            } ?>
        <?php else: ?>
            <div class="history__empty">
                <?= Lang_clfe::__('No status history available', 'clfe') ?>
            </div>
        <?php endif; ?>
    </div>
</div>