<div id="clfe_update_order" class="order-edit">
    <div class="order-edit__body">
        <div class="order-edit__header">
            <?php include_once 'order_details.php'; ?>
        </div>
        <div class="order-edit__content">
            <!-- Customer Information -->
            <div class="order-edit__customer">
                <?php include_once 'customer_details.php'; ?>
            </div>
            <!-- Cart Items Section -->
            <div class="order-edit__cart">
                <?php include_once 'cart.php'; ?>
            </div>
        </div>
    </div>

    <div class="order-edit__sidebar">
    <?php include_once MainApp_clfe::$compsPath . 'order/backend/views/edit/status_history.php'; ?>
        <div class="sidebar-actions">
            
        </div>
    </div>
    
    
    <div id="clfe-sticky-bottom-bar">
        <div class="clfe-container">
            <div class="order-edit__actions">
                <input type="hidden" name="order_id" value="<?= $order->id ?>" clfe_ischanged="yes">
            </div>

            <div class="clfe-user-fedback"></div>
        </div>
    </div>
    
</div>