(function( $ ) {
	'use strict';

        $(document).ready( function () {
            
            /*
             * Remove single order
             */
            $('.clfe-remove-bt').on('click', function(ev) {
                ev.preventDefault();
                
                if( confirm(jsLang.delete_confirm_msg) == true ) {  
                    const currentOrderID = $(this).attr('order_id');
                    const clfe_controller     = 'clfe_order';
                    const clfe_action  = 'clfe_delete_order';

                    const formData = AdminFn_clfe.getFormDatas('clfe_delete_order');
                    formData['order_id'] = currentOrderID;

                    AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
                    AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);

                    const handleResponse = function() {
                        if(jsArgs.lastResponse.code === 1) {
                            const row = $("#row-order-id-" + currentOrderID);
                            row.animate({opacity: 0, marginLeft: '-100%'}, 300, function() {
                                $(this).slideUp(200, function() {
                                    $(this).remove();
                                });
                            });
                        }
                        document.removeEventListener(clfe_action+'lastResponse', handleResponse);
                    };
                    document.addEventListener(clfe_action+'lastResponse', handleResponse);
                }
  
            }); 
            
            $('.table-row').on('click', function(ev) {
                $('.table-row').removeClass('table-row-active');
                $(this).addClass('table-row-active');
            });
            
        $('.clfe-getinsight-bt').on('click', function(ev) {
            ev.preventDefault();
            
            $("input[name=order_id]").val( $(this).attr('order_id') );
            
            const clfe_controller     = 'clfe_order';
            const clfe_action  = 'clfe_get_order_insight';
            
            var formData = AdminFn_clfe.getFormDatas('clfe_get_order_insight');

            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);

            // Wait for the custom event before accessing the modified variable
            document.addEventListener(clfe_action+'lastResponse', function (event) {

                if( jsArgs.lastResponse.code === 1 ) {
                    const currentOrderID = $("input[name=order_id]").val();
                    $("#popup-"+currentOrderID).html(jsArgs.lastResponse.res);

                    $("#row-order-id-"+currentOrderID).addClass('clfe-row-with-border');
                    $("#popup-"+currentOrderID).dialog({
                        title: $("#popup-"+currentOrderID).attr('popuptitle'),
                        resizable: true,
                        height: "auto",
                        width: "auto",
                        modal: true,
                        buttons: {
                            "Cancel": function() {
                                $( this ).dialog( "close" );
                                $("#row-order-id-"+currentOrderID).removeClass('clfe-row-with-border');
                            }
                        },
                        close: function() { 
                            $( this ).dialog( "destroy" );
                            $("#row-order-id-"+currentOrderID).removeClass('clfe-row-with-border');
                        }
                    });
                    
                    
                }
            });

        }); 
            
        } );

})( jQuery );