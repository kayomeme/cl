(function ($) {
    //'use strict';
    orderEditBk_clfe = {
        order_id: 0,
        total_amount: 0,
        total_discount: 0,
        total_shipping: 0,
        old_status: '',

        init: function () {
            this.order_id = parseInt($("input[name=order_id]").val()) || 0;
            this.total_shipping = parseFloat($('#clfe_total_shipping').text()) || 0;
            this.total_amount = parseFloat($('.clfe_total_amount:first').text()) || 0;
            this.old_status = this.getSelectedStatus().value;
            console.log(this.old_status);
        },
        cartRemoveProduct: function (productID) {
            const clfe_controller = 'clfe_order';
            const clfe_action = 'clfe_cart_delete_product';
            const formData = AdminFn_clfe.getFormDatas(clfe_action);
            formData['product_id'] = productID;
            formData['order_id'] = this.order_id;
            formData['total_shipping'] = this.total_shipping;

            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);

            const handleResponse = function (event) {
                orderEditBk_clfe.updateDomElementsValues(jsArgs.lastResponse.res);

                AdminFn_clfe.removeDomElementWithAnimation("#cart-item-" + productID);
                document.removeEventListener(clfe_action + 'lastResponse', handleResponse);
            };
            document.addEventListener(clfe_action + 'lastResponse', handleResponse); 
        },
        cartLoadUpdateProduct: function (productID) {
            const clfe_controller = 'clfe_order';
            const clfe_action = 'clfe_cart_load_update_product';
            const formData = AdminFn_clfe.getFormDatas(clfe_action);
            formData['product_id'] = productID;
            formData['order_id'] = this.order_id;
            formData['currency_code'] = jsArgs.currency_code;

            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);

            const handleResponse = function (event) {
                $('.cart__item').removeClass('cart__item-active');
                
                const cartProductHtmlCodeUpdate = jsArgs.lastResponse.res;
                if( cartProductHtmlCodeUpdate ) {
                    const celement = $('<div id="cart-update-product-modal"></div>');
                    celement.html(cartProductHtmlCodeUpdate);
                    
                   // AdminFn_clfe.closeActiveModals();

                    celement.dialog({
                        create: function (event, ui) {
                            // Set maxWidth
                            $(this).css("maxWidth", "660px");
                        },
                        classes: {
                            "ui-dialog": "highlight"
                        },
                        title: jsLang.edit_cart_product,
                        resizable: false,
                        height: "auto",
                        width: $(window).width() > 800 ? 660 : 'auto',
                        modal: true,
                        buttons: {
                            "Cancel": function () {
                                $(this).dialog("close");
                            },
                            "Save": function () {
                                //$(this).dialog("close");
                                const modalElement = $(this);
                                orderEditBk_clfe.cartSaveUpdatedProduct(productID, modalElement);
                            }
                        },
                        close: function () {
                            $(this).dialog("destroy");
                        }
                    });
                    
                    
                }

                document.removeEventListener(clfe_action + 'lastResponse', handleResponse);
            };
            document.addEventListener(clfe_action + 'lastResponse', handleResponse); 
        },
        cartSaveUpdatedProduct: function (productID, modalElement) {
            const clfe_controller = 'clfe_order';
            const clfe_action = 'clfe_cart_save_updated_product';
            const formData = AdminFn_clfe.getFormDatas(clfe_action);
            formData['product_id'] = productID;
            formData['order_id'] = this.order_id;
            formData['total_shipping'] = this.total_shipping;
            formData['currency_code'] = jsArgs.currency_code;
            formData['variations'] = JSON.stringify(this.getSelectedVariations());

            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);
            
            const handleResponse = function (event) {
                if (jsArgs.lastResponse.code === 1) {
                    modalElement.dialog("close");
                    
                    orderEditBk_clfe.updateDomElementsValues(jsArgs.lastResponse.res);
                    AdminFn_clfe.removeDomElementWithAnimation("#cart-item-" + productID);
                    
                    const newCartProduct = $(jsArgs.lastResponse.res['car_product_html_code']).addClass('cart__item-active');

                    $('.cart__items').append(newCartProduct);
                }
                
                document.removeEventListener(clfe_action + 'lastResponse', handleResponse);
            };
            document.addEventListener(clfe_action + 'lastResponse', handleResponse); 
        },
        updateDomElementsValues: function (responseResult) {
            ['total_amount', 'total_discount', 'total_cart', 'total_cart_regular'].forEach(key => {
                if (key in responseResult) {
                    $(`.clfe_${key}`).text(responseResult[key]);
                }
            });
        },
        getSelectedVariations: function () {
            var qtyVariations = [];
            $(".qty_choise_variation").each(function (qtyIndex) {
                var variations = [];
                $(this).find("select").each(function (index) {
                    var selectedOption = $(this).find("option:selected");
                    if (selectedOption.val()) {
                        variations.push({
                            slug: $(this).attr("slug") || '',
                            value: selectedOption.val(),
                            v_index: index,
                            fees: parseFloat(selectedOption.attr("extra_fees") || 0),
                            v_type: $(this).attr("v_type") || 'buttons'
                        });
                    }
                });
                qtyVariations[qtyIndex] = variations;
            });
            return qtyVariations;
        },
        duplicateVariationsOnQtyChange: function (qty, variation_is_duplicated_per_qty) {
           if (variation_is_duplicated_per_qty === 'yes' && qty > 0) {
               const currentVariations = $('.qty_choise_variation').length;

               if (currentVariations < qty) {
                   // Need to add more variations
                   for (var i = currentVariations; i < qty; i++) {
                       var vItemsClone = $(".qty_choise_variation:first").clone(true);
                       $(vItemsClone).addClass("clfe-variation-clone").find('.qty-choose-index span').text(i+1);
                       $(".cart-edit-variations").append(vItemsClone);
                   }
               } else if (currentVariations > qty) {
                   // Need to remove excess variations
                   for (var i = currentVariations; i > qty; i--) {
                       $(".qty_choise_variation:last").remove();
                   }
               }
           }
        },
        changeStatusBadgeColorsBasedOnCurrentStatus: function() {
            // Update status display
            const option = $('select[name="status"]').find(':selected');
            $('.order__status').css({
                'background-color': option.attr('bg_color'),
                'color': option.attr('text_color')
            }).text(option.text());  
        },
        updateOrderInfo: function () {
            const clfe_controller = 'clfe_order';
            const clfe_action = 'clfe_update_order_info';
            const formData = AdminFn_clfe.getFormDatas(clfe_action);
            formData['order_id'] = this.order_id;
            formData['old_status'] = this.old_status;
            
            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData); 
            

            const handleResponse = function(event) {
                if (jsArgs.lastResponse.code === 1) {
                    // Add new history item if provided
                    if ( jsArgs.lastResponse.res.history_html ) {
                        $('.status-history-items').prepend(jsArgs.lastResponse.res.history_html);
                        orderEditBk_clfe.old_status = orderEditBk_clfe.getSelectedStatus().value;
                    }
                }
                document.removeEventListener(clfe_action + 'lastResponse', handleResponse);
            };

            document.addEventListener(clfe_action + 'lastResponse', handleResponse);
        },
        updateCustomerInfo: function() {
            const clfe_controller = 'clfe_order';
            const clfe_action = 'clfe_update_order_customer_info';
            const formData = AdminFn_clfe.getFormDatas(clfe_action);
            formData['order_id'] = this.order_id;
            
            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);
        }
    };

    $(document).ready(function () {
        orderEditBk_clfe.init();

        $('#clfe_update_order_info select').on('change', function () {
            $(this).attr('clfe_ischanged', 'yes');
            orderEditBk_clfe.updateOrderInfo();
        });
        
        
        $('#save-update-order-customer-info').on('click', function (ev) {
            ev.preventDefault();

            orderEditBk_clfe.updateCustomerInfo();
        });

        $('select[name="status"]').on('change', function () {
            orderEditBk_clfe.changeStatusBadgeColorsBasedOnCurrentStatus();
        });
        
        // only use $(document) for element that reload via ajax
        $(document).on('click', '.cart-delete-product', function(ev) {
            ev.preventDefault();
            if (!confirm(jsLang.delete_confirm_msg)) { return; }
            
            const productID = $(this).attr('product_id');
            orderEditBk_clfe.cartRemoveProduct(productID);
        });
        
        $(document).on('click', '.cart-load-update-product', function(ev) {
            ev.preventDefault();
            
            const productID = $(this).attr('product_id');
            orderEditBk_clfe.cartLoadUpdateProduct(productID);
        });
        
        $(document).on('change', '.cart-edit-offer input[name=qty]', function(ev) {
        //$('.cart-edit-offer input[name=qty]').on('change', function () {

            const duplicate_variations = $(this).attr('duplicate_variations');
            const qty = $(this).val();

            orderEditBk_clfe.duplicateVariationsOnQtyChange(qty, duplicate_variations);
        });
        
    });

})(jQuery);

(function ($) {
    'use strict';
    
    // Extend existing orderEditBk_clfe object
    $.extend(orderEditBk_clfe, {
        getSelectedStatus: function() {
            const statusSelect = $('#clfe_update_order_info select[name="status"]');
            return {
                value: statusSelect.val(),
                text: statusSelect.find('option:selected').text(),
                bgColor: statusSelect.find('option:selected').attr('bg_color'),
                textColor: statusSelect.find('option:selected').attr('text_color')
            };
        },
        initStatusHandlers: function() {
            const self = this;
            
            // Store initial status
            const statusSelect = $('#clfe_update_order_info select[name="status"]');
            const initialStatus = statusSelect.val();
            statusSelect.attr('data-previous', initialStatus);

            // Handle note editing
            $(document).on('click', '.history__note', function() {
                const historyItem = $(this).closest('.history__item');
                const noteContent = $(this).find('.history__note-content').text() || '';
                
                // Show edit form
                $(this).hide();
                historyItem.find('.history__note-edit').show()
                    .find('textarea').val(noteContent).focus();
            });

            // Handle note cancellation
            $(document).on('click', '.history__note-cancel', function() {
                const historyItem = $(this).closest('.history__item');
                historyItem.find('.history__note-edit').hide();
                historyItem.find('.history__note').show();
            });

            // Handle note saving
            $(document).on('click', '.history__note-save', function() {
                const historyItem = $(this).closest('.history__item');
                const historyId = historyItem.data('id');
                const noteContent = historyItem.find('.history__note-textarea').val();
                
                self.updateStatusNote(historyId, noteContent, historyItem);
            });
        },
        updateStatusNote: function(historyId, noteContent, historyItem) {
            const clfe_controller = 'clfe_order_status_history';
            const clfe_action = 'clfe_update_status_note';
            const formData = AdminFn_clfe.getFormDatas(clfe_action);
            
            formData['history_id'] = historyId;
            formData['note'] = noteContent;

            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);

            const handleResponse = function(event) {
                if (jsArgs.lastResponse.code === 1) {
                    const historyEntry = jsArgs.lastResponse.res;
                    
                    // Update note display
                    historyItem.find('.history__note-edit').hide();
                    const noteElement = historyItem.find('.history__note').show();
                    
                    if (noteContent) {
                        noteElement.html(`<div class="history__note-content">${noteContent}</div>`);
                    }
                }
                document.removeEventListener(clfe_action + 'lastResponse', handleResponse);
            };

            document.addEventListener(clfe_action + 'lastResponse', handleResponse);
        }
    });

    // Initialize in document ready
    $(document).ready(function() {
        orderEditBk_clfe.initStatusHandlers();
    });

})(jQuery);