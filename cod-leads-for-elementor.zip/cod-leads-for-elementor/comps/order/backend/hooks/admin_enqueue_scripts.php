<?php
//MainApp_clfe::$compsUrl.$hook['compName']

if( !isset( $_REQUEST['page'] ) || $_REQUEST['page'] != 'clfe_orders' ) {
    return;
}
if(  !isset( $_REQUEST['action'] ) ) {
    wp_enqueue_style( 'orders_list_bk', MainApp_clfe::$compsUrl.'order/backend/assets/css/orders_list_bk.css', [], $assetsVersion );
    wp_enqueue_script( 'orders_list_bk', MainApp_clfe::$compsUrl.'order/backend/assets/js/orders_list_bk.js', [], $assetsVersion );
}

if(  isset( $_REQUEST['action'] ) && $_REQUEST['action'] == 'edit' ) {
    wp_enqueue_style( 'order_edit_bk', MainApp_clfe::$compsUrl.'order/backend/assets/css/order_edit_bk.css', [], $assetsVersion );
    wp_enqueue_script( 'orders_edit_bk', MainApp_clfe::$compsUrl.'order/backend/assets/js/order_edit_bk.js', [], $assetsVersion );
    
    wp_enqueue_style( 'order_edit_history_bk', MainApp_clfe::$compsUrl.'order/backend/assets/css/order_edit_history_bk.css', [], $assetsVersion );
    
}