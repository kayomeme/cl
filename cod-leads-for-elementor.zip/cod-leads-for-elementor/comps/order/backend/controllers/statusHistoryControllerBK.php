<?php

class StatusHistoryControllerBK_clfe {

    public static function routes($action, $args) {
        $result = false;
        switch ($action) {
            case 'clfe_update_status_note':
                $result = self::updateStatusNote($args);
                break;
        }
        return $result;
    }


    public static function AddNewEntry($args) {
        $orderId = isset($args['order_id']) && $args['order_id'] > 0 ? $args['order_id'] : false;
        $oldStatus = isset($args['old_status']) ? $args['old_status'] : false;

        if (!$orderId) {
            return response_clfe(0, Lang_clfe::__('Invalid Order ID', 'clfe'), null);
        }
        
        // If status was changed, add history entry and get updated history HTML
        if (isset($args['status']) && $args['status'] !== $oldStatus) {
            // Add history entry
            $historyData = [
                'order_id' => $orderId,
                'from_status' => $oldStatus,
                'to_status' => $args['status'],
                'changed_by' => get_current_user_id(),
                'date_created_gmt' => current_time('mysql', true)
            ];

            $response = StatusHistoryModelBK_clfe::addHistoryEntry($historyData);
            
            if( $response->code == 1 && isset( $response->res['insert_id'] ) ) {
                $historyId = $response->res['insert_id'];
                // Get updated history HTML
                $history = StatusHistoryModelBK_clfe::getHistoryItem($historyId);
                $orderStatuses = OrderStatusesModelBK_clfe::getStatusesForOrder($limit = 50, $settingsModelId = 0);
                $orderStatuses = array_column($orderStatuses, null, 'slug');

                ob_start();
                include MainApp_clfe::$compsPath . 'order/backend/views/edit/status_history_item.php';
                $historyHtml = ob_get_clean();

                $response->res['history_html'] = $historyHtml;
                return $response; 
            }

        }
        
        return response_clfe(1, Lang_clfe::__('No history change', 'clfe'), null);
    }
    public static function updateStatusNote($args) {
        if (!isset($args['history_id'])) {
            return response_clfe(0, Lang_clfe::__('No history item selected', 'clfe'), null);
        }

        $historyId = $args['history_id'];
        $note = isset($args['note']) ? $args['note'] : '';

        $response = StatusHistoryModelBK_clfe::updateNote($historyId, $note);

        return $response;
    }
}