<?php

/**
 */
class OrderControllerBK_clfe {

    /*private static $tableName = 'orders';
    
    private static $formFields =  [
        'phone', 'city', 'address_1', 'full_name', 'email', 'product_id', 'product_title', 'product_qty', 'product_cat',
        'qty_offer_title', 'qty_offer_value', 'qty_total_offer_value'
    ];
    private static $serverFields =  [
        'status', 'total', 'currency_code', 'currency_label', 'regular_price', 'sale_price', 'sku', 
        'shipping_fees', 'shipping_label', 'shipping_title'
    ];*/
    
    public static function routes($action, $args) {
        $result = false;
        switch ($action) {
            case 'clfe_delete_order':
                $result = self::deleteOrder($args);
                break;
            case 'clfe_get_order_insight':
                $result = self::getOrderAttachedInsight($args);
                break;
        }

        return $result;
    }

    /*
     * The main function
     */
    public function index($args) {
        $currentUrl = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);

        $limit = isset( $_REQUEST['limit'] ) ? $_REQUEST['limit'] : 50;
        $orders = OrderModelBK_clfe::GetLastOrders($limit);
        include MainApp_clfe::$compsPath.'order/backend/views/listing/index.php';
    }
    
    public static function deleteOrder($args) {
        
        $result = OrderModelBK_clfe::deleteOrder($args['order_id']);
        
        //$result = response_clfe(1, Lang_clfe::__('ddddSettings updated successfully', 'clfe'), null);
        return $result;
    }
    
    /*
     * 
     */
    public static function getOrderAttachedInsight($args) {
        $response = response_clfe(0, Lang_clfe::__('No order selected', 'clfe'), null);
        if( !isset( $args['order_id'] ) ) {
            return $response;
        }
        
        $insightDatas = OrderModelBK_clfe::getAttachedInsightInfo($args['order_id']);
        
        if( empty($insightDatas) || !isset( $insightDatas[0] )  ) {
            $msgContent = Lang_clfe::__('No insight exist attached to this order', 'clfe');
            return response_clfe(1, $msgContent, $msgContent);
        }
        
        $insightDatas = $insightDatas[0];
        $compoName = 'order';
        ob_start();
        include MainApp_clfe::$compsPath.$compoName.'/backend/views/listing/ajax_call/order_insight_data.php';
        $content = ob_get_contents();
        ob_get_clean();
        
        return response_clfe(1, Lang_clfe::__('Insight data loader loaded successfully.', 'clfe'), $content);
    }
    
    /*
     * 
     */
    public static function syncOrders($orders) {
        $response = response_clfe(0, Lang_clfe::__('No orders to syncronize', 'clfe'), null);
        if( empty( $orders ) ) {
            return $response;
        }
        
        $response = OrderModelBK_clfe::updateOrdersList($orders);
        
        return $response;
    }
}
