<?php

class OrderControllerBK_clfe {

    public static function routes($action, $args) {
        $result = false;
        switch ($action) {
            case 'clfe_update_order_info':
                $result = self::updateOrderInfo($args);
                break;
            case 'clfe_update_order_customer_info':
                $result = self::updateCustomerInfo($args);
                break;
            case 'clfe_delete_order':
                $result = self::deleteOrder($args);
                break;
            case 'clfe_cart_delete_product':
                $result = CartControllerBK_clfe::deleteProduct($args);
                break;
            case 'clfe_cart_load_update_product':
                $result = CartControllerBK_clfe::loadUpdateProduct($args);
                break;
            case 'clfe_cart_save_updated_product':
                $result = CartControllerBK_clfe::saveUpdatedProduct($args);
                break;
            case 'clfe_get_order_insight':
                $result = self::getOrderAttachedInsight($args);
                break;
        }
        return $result;
    }

    public function index() {
        $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 'list';
        switch ($action) {
            case 'edit':
                self::editIndex();
                break;
            case 'list':
                self::listIndex();
                break;
        }
    }

    public static function editIndex() {
        $orderId = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
        if (!$orderId) {
            wp_die(Lang_clfe::__('Invalid order ID', 'clfe'));
        }

        // Get order details for display
        $response = OrderModelBK_clfe::getOrderDetails($orderId);
        if ($response->code === 0) {
            wp_die($response->msg);
        }

        $order = $response->res;
        $orderData = OrderModelBK_clfe::getOrderData($orderId);

        $shippingInfos = isset($orderData['shipping']) ? $orderData['shipping'] : [];

        $orderStatuses = OrderStatusesModelBK_clfe::getStatusesForOrder($limit = 50, $settingsModelId = 0);
        $orderStatuses = array_column($orderStatuses, null, 'slug');

        $cartProducts = OrderModelBK_clfe::getCartItems($orderId);
        
        //var_dump($cartProducts[39079]['variations']);
        
        $statusHistory = StatusHistoryModelBK_clfe::getOrderHistory($orderId);


        $sharedSettings = AdminCompo_clfe::getSharedSettings($settingsModelId = 0);
        $currencyCode = $sharedSettings['currency_code'];

        include MainApp_clfe::$compsPath . 'order/backend/views/edit/editIndex.php';
    }

    public static function updateOrderInfo($args) {
        $orderId = isset($args['order_id']) && $args['order_id'] > 0 ? $args['order_id'] : false;

        if (!$orderId) {
            return response_clfe(0, Lang_clfe::__('Invalid Order ID', 'clfe'), null);
        }

        $response = OrderModelBK_clfe::updateOrderTable($orderId, $args);

        if ($response->code == 1 && isset($response->res['count_updated']) && $response->res['count_updated'] > 0) {
            //SheetControllerBk_clfe::synchronizeOrderStatusesWithGoogleSheets($settingsModelId = 0);

            $response = StatusHistoryControllerBK_clfe::AddNewEntry($args); 
        }

        return $response;
    }
    
    public static function updateCustomerInfo($args) {
        $orderId = isset($args['order_id']) && $args['order_id'] > 0 ? $args['order_id'] : false;

        if (!$orderId) {
            return response_clfe(0, Lang_clfe::__('Invalid Order ID', 'clfe'), null);
        }

        $response = OrderModelBK_clfe::updateAddresesTable($orderId, $args);

        if ($response->code == 1 && isset($response->res['count_updated']) && $response->res['count_updated'] > 0) {
            //SheetControllerBk_clfe::synchronizeOrderStatusesWithGoogleSheets($settingsModelId = 0);
        }

        return $response;
    }

    public static function listIndex() {
        $currentUrl = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
        $limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 50;

        $orders = OrderModelBK_clfe::GetLastOrders($limit);

        $orderStatuses = OrderStatusesModelBK_clfe::getStatusesForOrder($limit = 50, $settingsModelId = 0);
        $orderStatuses = array_column($orderStatuses, null, 'slug');

        include MainApp_clfe::$compsPath . 'order/backend/views/listing/index.php';
    }

    public static function deleteOrder($args) {
        $result = OrderModelBK_clfe::deleteOrder($args['order_id']);
        return $result;
    }


    public static function getOrderAttachedInsight($args) {
        $response = response_clfe(0, Lang_clfe::__('No order selected', 'clfe'), null);
        if (!isset($args['order_id'])) {
            return $response;
        }

        $insightDatas = OrderModelBK_clfe::getAttachedInsightInfo($args['order_id']);

        if (empty($insightDatas) || !isset($insightDatas[0])) {
            $msgContent = Lang_clfe::__('No insight exist attached to this order', 'clfe');
            return response_clfe(1, $msgContent, $msgContent);
        }

        $insightDatas = $insightDatas[0];
        $compoName = 'order';
        ob_start();
        include MainApp_clfe::$compsPath . $compoName . '/backend/views/listing/ajax_call/order_insight_data.php';
        $content = ob_get_contents();
        ob_get_clean();

        return response_clfe(1, Lang_clfe::__('Insight data loaded successfully.', 'clfe'), $content);
    }

    public static function syncOrders($orders) {
        $response = response_clfe(0, Lang_clfe::__('No orders to syncronize', 'clfe'), null);
        if (empty($orders)) {
            return $response;
        }

        $response = OrderModelBK_clfe::updateOrdersList($orders);
        return $response;
    }
}
