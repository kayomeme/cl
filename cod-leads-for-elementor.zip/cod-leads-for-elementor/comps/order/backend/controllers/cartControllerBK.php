<?php

class CartControllerBK_clfe {

    public static function deleteProduct($args) {
        if (!isset($args['order_id']) || !isset($args['product_id'])) {
            $response = response_clfe(0, Lang_clfe::__('No cart product selected', 'clfe'), null);
        }

        $orderId = $args['order_id'];
        $productId = $args['product_id'];

        $cartProducts = OrderModelBK_clfe::getCartItems($orderId);
        $cartProductsCopy = $cartProducts;

        if (!isset($cartProducts[$productId])) {
            return response_clfe(0, Lang_clfe::__('Selected product not exist the cart product', 'clfe'), null);
        }

        unset($cartProducts[$productId]);
        $response = OrderModelBK_clfe::updateMeta($orderId, 'clfe_cart_items', $cartProducts);
        
        if ($response->code == 1) {
            $response = self::updateOrderAndGetTotals($orderId, $cartProducts, $cartProductsCopy, $args);
        }

        return $response;
    }

    
    public static function loadUpdateProduct($args) {
        if (!isset($args['order_id']) || !isset($args['product_id'])) {
            return response_clfe(0, Lang_clfe::__('No cart product selected', 'clfe'), null);
        }

        $orderId = $args['order_id'];
        $productId = $args['product_id'];

        $cartProducts = OrderModelBK_clfe::getCartItems($orderId);

        if (!isset($cartProducts[$productId])) {
            return response_clfe(0, Lang_clfe::__('Selected product not exist the cart product', 'clfe'), null);
        }

        $currencyCode = $args['currency_code'];
        $cartProduct = $cartProducts[$productId]; 
        $variations = CartModelBK_clfe::getVariations($productId);
        
        $productGeneralSettings = ProductUtils_clfe::getGeneralSettings($productId);
        $isActiveVariationDuplicate = $productGeneralSettings['variation_is_duplicated_per_qty'];
        
        
        ob_start();
        include MainApp_clfe::$compsPath . 'order/backend/views/edit/cart_product_update_modal.php';
        $generatedCartproductHtmlCode = ob_get_clean();


        return response_clfe(1, Lang_clfe::__('Loaded', 'clfe'), $generatedCartproductHtmlCode);
    }
    public static function saveUpdatedProduct($args) {
        if (!isset($args['order_id']) || !isset($args['product_id'])) {
            return response_clfe(0, Lang_clfe::__('No cart product selected', 'clfe'), null);
        }
        
        $cartProducts = OrderModelBK_clfe::getCartItems($args['order_id']);
        $cartProductsCopy = $cartProducts;

        if (!isset($cartProducts[$args['product_id']])) {
            return response_clfe(0, Lang_clfe::__('Selected product not exist the cart product', 'clfe'), null);
        }

        $cartProduct = $cartProducts[$args['product_id']]; 
        
        $response = self::setUpNewCartItemData($cartProduct, $args);
        if( $response->code == 0 || !is_array($response->res)) {
            return $response;
        }
        
        $cartProductNew = $response->res;
        
        $cartProducts[$args['product_id']] = $cartProductNew;
        $response = OrderModelBK_clfe::updateMeta($args['order_id'], 'clfe_cart_items', $cartProducts);
       
        if ($response->code == 1) {
            $response = self::updateOrderAndGetTotals($args['order_id'], $cartProducts, $cartProductsCopy, $args);
            if ($response->code == 1) {
                $response->res['car_product_html_code'] = self::getCartProductHtmlCode($cartProductNew, $args);
            }
        }
        
        return $response;
    }
    
    private static function setUpNewCartItemData($cartProduct, $args) { 
        if (isset($args['qty'])) {
            $cartProduct['qty'] = $args['qty'];
        }

        if (isset($args['discount_per_product'])) {
            if ($args['discount_per_product'] > $cartProduct['regular_price']) {
                return response_clfe(0, Lang_clfe::__('The discount cannot be greater than the product price', 'clfe'), null);
            }

            $cartProduct['discount_per_product'] = $args['discount_per_product'];
            $cartProduct['sale_price'] = $cartProduct['regular_price'] - $args['discount_per_product'];
        }

        if (isset($args['offer_title'])) {
            $cartProduct['offer']['title'] = $args['offer_title'];
        }

        if (isset($args['variations'])) {
            $newVariations = jsonDecode_clfe($args['variations']);
            if (is_array($newVariations)) {
                $cartProduct['variations'] = $newVariations;
            }
        }

        return response_clfe(1, Lang_clfe::__('Cart item array updated', 'clfe'), $cartProduct);
    }

    private static function updateOrderAndGetTotals($orderId, $cartProducts, $cartProductsCopy, $args) {
        $newOrderTotals = self::getTotals($cartProducts, $args['total_shipping']);

        $response = OrderModelBK_clfe::updateOrderTable($orderId, ['total_amount' => $newOrderTotals['total_amount'] ]);

        if ($response->code == 1) {
            $response->res  = $newOrderTotals;
        } else {
            // rollback
            OrderModelBK_clfe::updateMeta($orderId, 'clfe_cart_items', $cartProductsCopy);
        }
        
        return $response;
    }
    
    private static function getCartProductHtmlCode($cartProduct, $args) {
        $qty = (int) $cartProduct['qty'];
        $regularPrice = (float) $cartProduct['regular_price'];
        $discountPerProduct = (float) $cartProduct['discount_per_product'];
        $salePrice = $regularPrice - $discountPerProduct;
        
        $currencyCode = $args['currency_code'];
        
        ob_start();
        include MainApp_clfe::$compsPath . 'order/backend/views/edit/cart_item.php';
        $generatedCartproductHtmlCode = ob_get_clean();
        
        return $generatedCartproductHtmlCode;
    }
    
    
    private static function getTotals($cartProducts, $totalShipping) {
        $regularTotalCart = 0;
        $saleTotalCart = 0;
        $totalDiscountOffers = 0;

        foreach ($cartProducts as $cartProduct) {
            $qty = (int) $cartProduct['qty'];
            $regularPrice = (float) $cartProduct['regular_price'];
            $discountPerProduct = (float) $cartProduct['discount_per_product'];
            $salePrice = $regularPrice - $discountPerProduct;
            
            $regularTotalCart = $regularTotalCart + ($regularPrice * $qty);
            $saleTotalCart = $saleTotalCart + ($salePrice * $qty);

            $totalDiscountOffers = $totalDiscountOffers + ($discountPerProduct * $qty);

            
        }

        return [
            'total_amount' => $saleTotalCart + (float) $totalShipping,
            'total_discount' => $totalDiscountOffers,
            'total_cart' => $saleTotalCart,
            'total_cart_regular' => $saleTotalCart + $totalDiscountOffers
        ];
    }
}
