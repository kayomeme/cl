<?php

class CartControllerBK_clfe {

    public static function deleteProduct($args) {
        if (!isset($args['order_id']) || !isset($args['product_id'])) {
            $response = response_clfe(0, Lang_clfe::__('No cart product selected', 'clfe'), null);
        }

        $orderId = $args['order_id'];
        $productId = $args['product_id'];

        $cartProducts = OrderModelBK_clfe::getCartItems($orderId);
        $cartProductsCopy = $cartProducts;

        if (!isset($cartProducts[$productId])) {
            return response_clfe(0, Lang_clfe::__('Selected product not exist the cart product', 'clfe'), null);
        }

        $qty = $cartProducts[$productId]['qty'];

        unset($cartProducts[$productId]);
        $response = OrderModelBK_clfe::updateMeta($orderId, 'clfe_cart_items', $cartProducts);

        if ($response->code == 1) {
            $newOrderTotals = self::getOrderTotals($cartProducts);
            $total_amount = $newOrderTotals['total_amount'] + (float) $args['total_shipping'];

            $response = OrderModelBK_clfe::updateOrderTable($orderId, [
                'total_amount' => $total_amount
            ]);

            if ($response->code == 1) {
                $response->res['total_amount'] = number_format($total_amount, 2);
                $response->res['total_discount'] = number_format($newOrderTotals['total_discount'], 2);
                $response->res['total_cart'] = number_format($newOrderTotals['total_amount'], 2);
                $response->res['total_cart_regular'] = $response->res['total_cart'] + $response->res['total_discount']; 
            } else {
                // rollback
                OrderModelBK_clfe::updateMeta($orderId, 'clfe_cart_items', $cartProductsCopy);
            }
        }

        return $response;
    }

    
    public static function loadUpdateProduct($args) {
        if (!isset($args['order_id']) || !isset($args['product_id'])) {
            $response = response_clfe(0, Lang_clfe::__('No cart product selected', 'clfe'), null);
        }

        $orderId = $args['order_id'];
        $productId = $args['product_id'];

        $cartProducts = OrderModelBK_clfe::getCartItems($orderId);

        if (!isset($cartProducts[$productId])) {
            return response_clfe(0, Lang_clfe::__('Selected product not exist the cart product', 'clfe'), null);
        }

        $currencyCode = $args['currency_code'];
        $cartProduct = $cartProducts[$productId]; 
        $variations = CartModelBK_clfe::getVariations($productId);
        
        $productGeneralSettings = ProductUtils_clfe::getGeneralSettings($productId);
        $isActiveVariationDuplicate = $productGeneralSettings['variation_is_duplicated_per_qty'];
        
        
        ob_start();
        include MainApp_clfe::$compsPath . 'order/backend/views/edit/ajax/cart_product_update.php';
        $generatedCartproductHtmlCode = ob_get_clean();


        return response_clfe(1, Lang_clfe::__('Loaded', 'clfe'), $generatedCartproductHtmlCode);
    }
    public static function saveUpdatedProduct($args) {
        if (!isset($args['order_id']) || !isset($args['product_id'])) {
            $response = response_clfe(0, Lang_clfe::__('No cart product selected', 'clfe'), null);
        }

        $orderId = $args['order_id'];
        $productId = $args['product_id'];

        $cartProducts = OrderModelBK_clfe::getCartItems($orderId);
        $cartProductsCopy = $cartProducts;

        if (!isset($cartProducts[$productId])) {
            return response_clfe(0, Lang_clfe::__('Selected product not exist the cart product', 'clfe'), null);
        }

        $cartProduct = $cartProducts[$productId]; 
        
        if( isset( $args['qty'] ) ) {
            $cartProduct['qty'] = $args['qty'];
        }
        
        if( isset( $args['discount_per_product'] ) ) {
            
            if ($args['discount_per_product'] > $cartProduct['regular_price']) {
               return response_clfe(0, Lang_clfe::__('The discount cannot be greater than the product price', 'clfe'), null);
            }
            
            $cartProduct['discount_per_product'] = $args['discount_per_product'];
            $cartProduct['sale_price'] = $cartProduct['regular_price'] - $args['discount_per_product'];
        }
        
        if( isset( $args['offer_title'] ) ) {
            $cartProduct['offer']['title'] = $args['offer_title'];
        }
        
        if( isset( $args['variations'] ) ) {
            $newVariations = jsonDecode_clfe($args['variations']);
            if( is_array($newVariations) ) {
                $cartProduct['variations'] = $newVariations; 
            }
        }
        
        $cartProducts[$productId] = $cartProduct;
        $response = OrderModelBK_clfe::updateMeta($orderId, 'clfe_cart_items', $cartProducts);
        
        if ($response->code == 1) {
            $newOrderTotals = self::getOrderTotals($cartProducts);
            $total_amount = $newOrderTotals['total_amount'] + (float) $args['total_shipping'];

            $response = OrderModelBK_clfe::updateOrderTable($orderId, [
                'total_amount' => $total_amount
            ]);

            if ($response->code == 1) {
                $response->res['total_amount'] = number_format($total_amount, 2);
                $response->res['total_discount'] = number_format($newOrderTotals['total_discount'], 2);
                $response->res['total_cart'] = number_format($newOrderTotals['total_amount'], 2);
                $response->res['total_cart_regular'] = $response->res['total_cart'] + $response->res['total_discount']; 
            } else {
                // rollback
                OrderModelBK_clfe::updateMeta($orderId, 'clfe_cart_items', $cartProductsCopy);
            }
        }

        
        $response->res['car_product_html_code'] = self::getCartProductHtmlCode($cartProduct, $args);

        return $response;
    }
    
    private static function getCartProductHtmlCode($cartProduct, $args) {
        $qty = (int) $cartProduct['qty'];
        $regularPrice = (float) $cartProduct['regular_price'];
        $discountPerProduct = (float) $cartProduct['discount_per_product'];
        $salePrice = $regularPrice - $discountPerProduct;
        
        $currencyCode = $args['currency_code'];
        
        ob_start();
        include MainApp_clfe::$compsPath . 'order/backend/views/edit/cart_item.php';
        $generatedCartproductHtmlCode = ob_get_clean();
        
        return $generatedCartproductHtmlCode;
    }
    
    
    public static function getOrderTotals($cartProducts) {
        $regularTotalCart = 0;
        $saleTotalCart = 0;
        $totalDiscountOffers = 0;

        foreach ($cartProducts as $cartProduct) {
            $qty = (int) $cartProduct['qty'];
            $regularPrice = (float) $cartProduct['regular_price'];
            $salePrice = isset($cartProduct['sale_price']) ? (float) $cartProduct['sale_price'] : $regularPrice;

            $saleTotalCart = $saleTotalCart + ($salePrice * $qty);

            $discountOffers = $regularPrice - $salePrice;
            $totalDiscountOffers = $totalDiscountOffers + $discountOffers;

            $regularTotalCart = $regularTotalCart + ($regularPrice * $qty);
        }

        return [
            'total_amount' => $saleTotalCart,
            'total_discount' => $totalDiscountOffers
        ];
    }
}
