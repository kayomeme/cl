<?php

/*
 * for security reason you should add a function that recalculate the total in the server part
 * you should add this as an option in the admin so the client can active that or not
 */

class OrderControllerFR_clfe {

    private static $orderTableColumns = [
        'status', 'currency', 'total_amount', 'customer_note', 'insight_id'
    ];
    private static $orderAddressesTableColumns = [
        'first_name', 'last_name', 'address_1', 'city', 'state', 'postcode', 'country', 'email', 'phone'
    ];
    private static $formFields = [
        'full_name', 'settings_model_id', 'status', 'total', 'currency_code', 'currency_label',
    ];
    private static $shippingFields = [
        'id', 'fees', 'label', 'title'
    ];
    /*private static $orderSummaryInfos = [
        'order_id', 'thankyou_url'
    ];*/

    private static $cartProducts = [
        'product_id', 'sku', 'regular_price', 'sale_price', 'product_title', 'product_qty', 'product_cat', 'custom_fields', 'variations', 'qty_offer', 'shipping'
    ];

    // 'qty_offer_title', 'qty_offer_value', 'qty_total_offer_value'
    // 'shipping_fees', 'shipping_label', 'shipping_title'

    /*
     * The main function
     */
    public static function addNewOrder($args) {
        $cartProducts = self::getcartProducts($args['cart_products']);
        if (!$cartProducts) { return response_clfe(0, Lang_clfe::__('Please select a product, your cart items is empty', 'clfe'), null); }

        $orderColumnsValues = self::getOrderColumnsValues($args);
        $response = OrderModelFR_clfe::add($orderColumnsValues);
        $orderID = isset($response->res['order_id']) ? $response->res['order_id'] : false;

        if ($orderID) {
            $orderKey           = publicUtils_clfe::generate_order_key($orderID);
            
            $thankyouPageUrl    = self::getThankyouPageUrl($args['thankyou_page_id'], $orderID, $orderKey);
            if ( $thankyouPageUrl ) { $response->res['thankyou_page_url'] = $thankyouPageUrl; }
            
            $orderData = array_merge($orderColumnsValues, [
                'key' => $orderKey, // only for woo 
                'id' => $orderID,
                'date' => date('Y-m-d H:i:s'),
                'sales_funnel_mode' => $args['sales_funnel_mode'],
                'thankyou_url' => $thankyouPageUrl,
                'shipping' => self::getShippingInfos($args),
                'customer' => self::getCustomerInfos($args),
                'total_discount' => isset($args['total_discount']) ? $args['total_discount'] : 0
            ]);

            OrderModelFR_clfe::addNewMeta($orderID, 'clfe_order_data', $orderData);
            OrderModelFR_clfe::addNewMeta($orderID, 'clfe_cart_items', $cartProducts);

            self::saveOrderAddresses($orderID, $args);
            //InsightsControllerFR_clfe::updateAfterSubmitOrder($args['insight_id'], $orderInfos);
        }

        return $response;
    }
    private static function getThankyouPageUrl($thankyouPageID, $orderID, $orderKey) {
        if (!$thankyouPageID) {
            return false;
        }

        // Get the permalink for the given post ID
        $permalink = get_permalink($thankyouPageID);
        if (!$permalink) {
            $permalink = get_site_url() . '/?page_id=' . $thankyouPageID;
        }

        // Check if URL already contains query parameters
        $separator = (strpos($permalink, '?') !== false) ? '&' : '?';

        // Append order parameters
        return $permalink . $separator . 'id=' . $orderID . '&key=' . $orderKey;
    }

    private static function getOrderColumnsValues($args) {
        $data = [
            'payment_method' => 'cod',
            'payment_method_title' => 'cod',
            'date_created_gmt' => date('Y-m-d H:i:s'),
            'parent_order_id' => 0,
            'customer_id' => 0,
            'type' => 'shop_order'
        ];

        foreach (self::$orderTableColumns as $fieldName) {
            if (isset($args[$fieldName])) {
                $data[$fieldName] = $args[$fieldName];
            }
        }

        return $data;
    }

    /*private static function getOrderSummary($args) {
        $orderSummary = [];

        foreach (self::$orderTableColumns as $fieldName) {
            if (isset($args[$fieldName])) {
                $orderSummary[$fieldName] = $args[$fieldName];
            }
        }

        $orderSummary['total_discount'] = isset($args['total_discount']) ? $args['total_discount'] : 0;

        return $orderSummary;
    }*/
    
    private static function getShippingInfos($args) {
        $shippingInfos = [];

        foreach (self::$shippingFields as $fieldName) {
            if (isset($args['shipping_'.$fieldName])) {
                $shippingInfos[$fieldName] = $args['shipping_'.$fieldName];
            }
        }

        return $shippingInfos;
    }

    private static function getCustomerInfos($args) {
        $customerInfos = [];

        // you should also add the custom fields
        $fields = [
            'full_name','first_name', 'last_name', 'city', 'address_1', 'state', 'postcode', 'country', 'email', 'phone'
        ];
        foreach ($fields as $fieldName) {
            if (isset($args[$fieldName])) {
                $customerInfos[$fieldName] = $args[$fieldName];
            }
        }

        return $customerInfos;
    }

    /*
     * skip all other infos
     */

    private static function saveOrderAddresses($orderID, $args) {
        $data = [
            'address_type' => 'billing',
        ];

        foreach (self::$orderAddressesTableColumns as $fieldName) {
            if (isset($args[$fieldName])) {
                $data[$fieldName] = $args[$fieldName];
            }
        }

        $data['order_id'] = $orderID;
        $response = OrderModelFR_clfe::addNewAddresses($data);

        return $response;
    }

    /*
     * return array of items OR false
     */

    private static function getcartProducts($cartProductsJson) {
        $cartProducts = jsonDecode_clfe($cartProductsJson);
        if (!isset($cartProducts[0]['product_id'])) {
            return false;
        }

        return $cartProducts;
    }

    /*
     * skip all other infos
     */

    private static function getFormFields($args) {
        $data = [];

        foreach (self::$formFields as $fieldName) {
            if (isset($args[$fieldName])) {
                $data[$fieldName] = $args[$fieldName];
            }
        }

        return $data;
    }

    private static function getDatasToInsert($args) {
        $data = self::getFormFields($args);
        $data['created_at'] = date('Y-m-d H:i:s');

        /* $data['product_price'] = $productDetails['sale_price'] > 0 && $productDetails['sale_price'] < $productDetails['regular_price'] ? $productDetails['sale_price'] : $productDetails['regular_price'];
          $data['total'] = $data['product_qty'] * $data['product_price']; */

        // Quantity offer 
        if (isset($data['qty_offer_value'])) {
            if ($productDetails['regular_price'] * $data['product_qty'] > (int) $data['qty_offer_value']) {
                $data['qty_total_offer_value'] = (int) $data['qty_offer_value'] * (int) $data['product_qty'];

                $data['total'] = $productDetails['regular_price'] * $data['product_qty'];
                $data['total'] = $data['total'] - $data['qty_total_offer_value'];
            }
        }

        // variations
        if (isset($args['variations']) && strlen($args['variations']) > 5) {
            $variationFields = self::getVariationsFields($args['variations'], $data['product_qty']);

            $data['total'] = $data['total'] + $variationFields['variations_total_fees'];
            $data = array_merge($data, $variationFields);
        }

        return $data;
    }

    private static function getVariationsFields($variations, $quantity) {

        $variationsTotalFees = 0;
        $textVar = [];
        $variationElements = jsonDecode_clfe($variations);

        if (is_array($variationElements)) {
            foreach ($variationElements as $variation) {
                $variationsTotalFees = $variationsTotalFees + $variation['fees'];
                unset($variation['fees']);
                $textVar[] = implode(":", $variation);
            }
        }

        if ($variationsTotalFees < 0) {
            $variationsTotalFees = 0;
        }

        return [
            'variations_total_fees' => $variationsTotalFees * $quantity,
            'variations_text' => implode("|", $textVar),
            'variations_json' => stripslashes($variations),
        ];
    }
}
