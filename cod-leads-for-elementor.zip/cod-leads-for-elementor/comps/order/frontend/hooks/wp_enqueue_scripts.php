<?php
/*if( is_singular('product') ) {}
wp_enqueue_script( $compoName, plugin_dir_url( __FILE__ ) . '../assets/js/index.js', array( 'jquery' ), 12, false );
wp_enqueue_style( $compoName, plugin_dir_url( __FILE__ ) . '../assets/css/index.css', 12, false );*/

wp_enqueue_style( 'clfe_'.$hook['compName'], MainApp_clfe::$compsUrl.$hook['compName']. '/frontend/assets/css/index.css', [], MainApp_clfe::$assetsVersion );
wp_enqueue_script( 'clfe_'.$hook['compName'], MainApp_clfe::$compsUrl.$hook['compName']. '/frontend/assets/js/index.js', array( 'jquery' ), MainApp_clfe::$assetsVersion );