<?php

class OrderModelFR_clfe {
    
    public static function add($orderInfos) {
        $newOrderId = self::getNextOrderID();
        $orderInfos['id'] = $newOrderId;
        $response = publicDB_clfe::insert('wc_orders', $orderInfos);

        if( $response->code ) {
            $response->res['order_id'] = $newOrderId;
        }
        
        return $response;
    }
    
    /*
     * insert a new row in the wc_order_addresses table
     */
    public static function addNewAddresses($orderAddressesFields) {
        $response = publicDB_clfe::insert('wc_order_addresses', $orderAddressesFields);
        
        return $response;
    }
    
    
    public static function addNewMeta($order_id, $meta_key, $meta_value) {
        
        if( is_array($meta_value) || is_object($meta_value) ) {
            $meta_value = jsonEncode_clfe($meta_value);
        }
        
        $data = [
            'order_id' => $order_id,
            'meta_key' => $meta_key,
            'meta_value' => $meta_value
        ];
        
        $response = publicDB_clfe::insert('wc_orders_meta', $data);

        return $response;
    }
    
    public static function updateMeta($order_id, $meta_key, $meta_value) {
        
        if( is_array($meta_value) || is_object($meta_value) ) {
            $meta_value = jsonEncode_clfe($meta_value);
        }
        
        $data = [
            'meta_value' => $meta_value
        ];
        
        $where = [
            'order_id' => $order_id,
            'meta_key' => $meta_key,
        ];

        $response = publicDB_clfe::update('wc_orders_meta', $data, $where);

        return $response;
    }
    
    public static function updateOrderTable($order_id, $data) {
        
        $where = [
            'id' => $order_id,
        ];

        $response = publicDB_clfe::update('wc_orders', $data, $where);

        return $response;
    }
    
    private static function getNextOrderID() {
        $lastOrderID = (int)publicDB_clfe::getVar('wc_orders', 'max(id)');
        
        $lastOrderID++;
        
        return $lastOrderID;
    }
}
