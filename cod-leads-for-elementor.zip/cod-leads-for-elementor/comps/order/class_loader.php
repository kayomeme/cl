<?php
$dirPath = plugin_dir_path( __FILE__ );

// backend
if($isAdminAria) {
    require_once $dirPath  . 'backend/models/orderModelBK.php';
    require_once $dirPath  . 'backend/controllers/orderControllerBK.php';
    
    require_once $dirPath  . 'backend/models/cartModelBK.php';
    require_once $dirPath  . 'backend/controllers/cartControllerBK.php';
    
        require_once $dirPath  . 'backend/models/statusHistoryModelBK.php';
    require_once $dirPath  . 'backend/controllers/statusHistoryControllerBK.php';
    
    require_once $dirPath  . 'backend/models/orderModelWooBK.php';
}

if($isPublicAria) {
    // frontend
    require_once $dirPath  . 'frontend/models/orderModelFR.php';
    require_once $dirPath  . 'frontend/controllers/orderControllerFR.php';
}

