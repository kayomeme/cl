<?php

/**
 * general
 */
return array(
    'setting' => [
        'site_title' => '',
        'site_slogon' => '',
        'site_icon_id' => '',
        'site_icon_url' => '',
        'langue_code' => 'fr',
        'langue_direction' => 'ltr',
        'langue_direction_effect' => 'entire_landing_page',
        'reset_lang_confirm' => 'yes',
        'font_name' => 'Roboto',
        'font_sublink' => '',
        'font_weight' => '400;500;700',
        'font_embed_code' => '',
        'font_effect' => 'entire_landing_page',
        'clarity_is_active' => 'no',
        'clarity_code' => '',
    ],
    'lang' => [
        'currency_code' => 'USD',
        'currency_label' => 'DH',
    ],
    'style' => [
        
    ]
    );
