<?php return array (
  'setting' => 
  array (
    'contact_info_version' => 'v1',
    'contact_info' => '{}',
  ),
  'lang' => 
  array (
  ),
  'style' => 
  array (
  ),
);