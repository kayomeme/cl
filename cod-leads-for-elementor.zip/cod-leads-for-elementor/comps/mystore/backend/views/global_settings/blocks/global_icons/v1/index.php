<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Collapse header icons', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Collapse Open icon', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    IconsSelectorBK_cl::getButton([
                        'name' => 'collapse_open_icon_id',
                        'value' => $settings['collapse_open_icon_id']
                    ]);
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Collapse Close icon', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    IconsSelectorBK_cl::getButton([
                        'name' => 'collapse_close_icon_id',
                        'value' => $settings['collapse_close_icon_id']
                    ]);
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>