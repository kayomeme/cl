<?php return array (
  'setting' => 
  array (
    'language_version' => 'v1',
    'langue_code' => 'fr',
    'langue_direction' => 'ltr',
    'langue_direction_effect' => 'entire_landing_page',
    'reset_lang_confirm' => 'yes',
  ),
  'lang' => 
  array (
  ),
  'style' => 
  array (
  ),
);