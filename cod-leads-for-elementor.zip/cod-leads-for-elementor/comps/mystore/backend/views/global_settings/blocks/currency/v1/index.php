<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Currency options', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Currency code', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select name="currency_code" class="cl-style-element" value="<?= esc_attr($settings['currency_code']) ?>">
                        <?php foreach ($currencies as $code => $value) {  ?>
                            <option value="<?= esc_attr($code) ?>" <?= selected($settings['currency_code'], $code, false) ?>>
                                <?= esc_html(Lang_cl::_e($value['label'], 'cl')) ?>
                            </option>
                        <?php } ?>
                    </select> 
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Currency label', 'cl') ?>
                </div>
                <div class="cl-td">
                    <input type="text"  name="currency_label" value="<?= esc_attr($settings['currency_label']) ?>">
                </div>
            </div>
        </div>
    </div>
</div>