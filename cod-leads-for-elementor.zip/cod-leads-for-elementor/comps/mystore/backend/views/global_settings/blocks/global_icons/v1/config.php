<?php return array (
  'setting' => 
  array (
    'global_icons_version' => 'v1',
    'collapse_open_icon_id' => '5',
    'collapse_close_icon_id' => '41',
  ),
  'lang' => 
  array (
  ),
  'style' => 
  array (
  ),
);