<?php
// We only generate CSS if a font name is actually set.
if (isset($settings['font_name']) && strlen($settings['font_name']) > 2) {
    
    $font_family_css = 'font-family: "' . esc_attr($settings['font_name']) . '";';
    $selector = '';

    switch ($settings['font_effect']) {
        case 'order_form_only':
            $selector = '.cl-product-container *, #cl-modal-form *';
            break;
        case 'entire_landing_page':
            $selector = '.single *:not(.wp-admin *), .cl-product-container *, #cl-modal-form *';
            break;
        case 'entire_shop':
            $selector = 'body *:not(.wp-admin *), .cl-product-container *, #cl-modal-form *';
            break;
    }

    if (!empty($selector)) {
        echo '<style>';
        echo esc_html($selector) . ' { ' . esc_html($font_family_css) . ' }';
        echo '</style>';
    }
}
?>