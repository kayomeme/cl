<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Global Contact Info', 'cl') ?>
        <div class="cl-alert cl-alert-info">
            <?= Lang_cl::_e('Configure the contact details that can be displayed across your site. Only enabled items will be saved.', 'cl') ?>
        </div>
    </div>
    <div id="cl-contact-info-container" class="cl-td">
        <?php 
        // Loop through the master list of contact types defined in the controller.
        foreach ($contact_types as $key => $label) {
            // Check if this item exists in the saved data to determine its state.
            $current_item = isset($saved_contact_items[$key]) ? $saved_contact_items[$key] : array();
            $is_active = !empty($current_item);
            $text = isset($current_item['text']) ? $current_item['text'] : '';
            $link = isset($current_item['link']) ? $current_item['link'] : '';
            $icon_id = isset($current_item['icon_id']) ? $current_item['icon_id'] : '';
        ?>
            <div class="admin_toggle_block" is_open="no">
                <div class="admin_toggle_header"><?= esc_html($label) ?></div>
                <div class="admin_toggle_body" show_in_open>
                    <div class="cl-sub-section" data-contact-key="<?= esc_attr($key) ?>">
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Enable Item', 'cl') ?></div>
                            <div class="cl-td">
                                <label class="cl-switch">
                                  <input type="checkbox" class="state-on-off" data-type="is_active" <?= checked($is_active, true, false) ?>>
                                  <span class="cl-slider cl-round"></span>
                                </label>
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Icon', 'cl') ?></div>
                            <div class="cl-td">
                                <?php
                                IconsSelectorBK_cl::getButton([
                                    'name' => '', // JS will handle value retrieval
                                    'value' => $icon_id
                                ]);
                                ?>
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th"><?= Lang_cl::_e('Text', 'cl') ?></div>
                            <div class="cl-td">
                                <input type="text" data-type="text" value="<?= esc_attr($text) ?>" placeholder="...">
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th">
                                <?= Lang_cl::_e('Link (Optional)', 'cl') ?>
                                <div class="cl-alert cl-alert-info">
                                    <?= Lang_cl::_e('Use for tel: or mailto: links.', 'cl') ?>
                                </div>
                            </div>
                            <div class="cl-td">
                                <input type="text" data-type="link" value="<?= esc_attr($link) ?>" placeholder="#">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
        <input type="hidden" name="contact_info" value="<?= esc_attr($settings['contact_info']) ?>">
    </div>
</div>