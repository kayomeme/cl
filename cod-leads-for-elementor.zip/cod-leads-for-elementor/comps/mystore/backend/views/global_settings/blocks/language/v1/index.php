<div id="cl_reset_comps_lang" class="cl-row">
    <div class="cl-td-full">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Select the language', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select name="langue_code" class="cl-style-element" value="<?= esc_attr($settings['langue_code']) ?>" cl-ischanged='yes'>
                        <option value="0"><?= Lang_cl::_e('Select the new language', 'cl') ?></option>
                        <?php foreach ($langs_cl as $langCode => $lang) { ?>
                            <option value="<?= esc_attr($langCode) ?>" langdir="<?= esc_attr($lang['dir']) ?>" <?= selected($settings['langue_code'], $langCode, false) ?>>
                                <?= esc_html($lang['name']) ?>
                            </option>
                        <?php }  ?>
                    </select> 
                    
                    <select name="reset_lang_confirm" value="no" class="cl-hide">
                        <option value="no" selected><?= Lang_cl::_e('No', 'cl') ?></option>
                        <option value="yes"><?= Lang_cl::_e('Yes, I confirm that I want to reset the language.', 'cl') ?></option>
                    </select> 
                    <button type="button" id="mystore_reset_lang" class="cl-bt cl-bt-danger cl-float-inline-end">
                        <?= Lang_cl::_e('Click here to reset to the selected language.', 'cl') ?>
                    </button>
                    <div class="cl-alert cl-alert-info" modal_title="<?= esc_attr(Lang_cl::__('Confirm the language reset', 'cl')) ?>">
                        <?= Lang_cl::_e('Note: By choosing to reset to the selected language, all your existing language-related changes in all settings will be erased, and the chosen language will be applied.', 'cl') ?>
                    </div>
                </div>
                
            </div>

            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('language Direction', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select name="langue_direction" class="cl-style-element" value="<?= esc_attr($settings['langue_direction']) ?>" cl-ischanged='yes'>
                        <option value="0"><?= Lang_cl::_e('Select the new language direction', 'cl') ?></option>
                        <option value="rtl" <?= selected($settings['langue_direction'], 'rtl', false) ?>><?= Lang_cl::_e('Right To left', 'cl') ?></option>
                        <option value="ltr" <?= selected($settings['langue_direction'], 'ltr', false) ?>><?= Lang_cl::_e('Left to right', 'cl') ?></option>
                    </select> 

                </div>
            </div>

            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Apply the language direction forcefully to', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select name="langue_direction_effect" class="cl-style-element" value="<?= esc_attr($settings['langue_direction_effect']) ?>" cl-ischanged='yes'>
                        <option value="order_form_only" <?= selected($settings['langue_direction_effect'], 'order_form_only', false) ?>><?= Lang_cl::_e('the order form only.', 'cl') ?></option>
                        <option value="entire_landing_page" <?= selected($settings['langue_direction_effect'], 'entire_landing_page', false) ?>><?= Lang_cl::_e('the entire landing page', 'cl') ?></option>
                    </select> 

                </div>
            </div>
            
        </div>
    </div>
    
    <input type="hidden" name="settings_model_id" value="<?= esc_attr($settingsModelId) ?>" cl-ischanged='yes' />
    <div class="cl-user-fedback">
        <div class="cl-msg_box">
            <div class="cl-wait_msg"></div>
            <div class="alert"></div>
        </div>
    </div>
    
</div>