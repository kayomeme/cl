<?php return array (
  'setting' => 
  array (
    'font_settings_version' => 'v1',
    'font_name' => 'Roboto',
    'font_sublink' => '',
    'font_weight' => '400;500;700',
    'font_embed_code' => '',
    'font_effect' => 'entire_landing_page',
  ),
  'lang' => 
  array (
  ),
  'style' => 
  array (
  ),
);