<?php return array (
  'setting' => 
  array (
    'currency_version' => 'v1',
  ),
  'lang' => 
  array (
    'currency_code' => 'USD',
    'currency_label' => 'DH',
  ),
  'style' => 
  array (
  ),
);