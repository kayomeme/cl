<?php 
$floatLeft  = $settings['langue_direction'] == 'rtl' ? 'right' : 'left';
$floatRight = $settings['langue_direction'] == 'rtl' ? 'left' : 'right';

$leftOrRight0 = $settings['langue_direction'] == 'rtl' ? 'right: 0;' : 'left: 0;';
?>

<style>
   <?php if( $settings['langue_direction_effect'] == 'order_form_only' ) { ?>
    .cl-product-container *, #cl-modal-form * {
       direction: <?= esc_attr($settings['langue_direction']) ?>;
   }
   <?php } else { ?>
    .single *:not(.wp-admin *), .cl-product-container *, #cl-modal-form * {
       direction: <?= esc_attr($settings['langue_direction']) ?>;
    }
    
    /*
    * elementor fix
    */
    .elementor-accordion { text-align: <?= esc_attr($floatLeft) ?> !important;}
    
   <?php } ?>
</style>