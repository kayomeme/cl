<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Select Google font', 'cl') ?>
    </div>
    <div class="cl-td">

        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Font category', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select class="cl_font_categories">
                        <option value="all_fonts"><?= Lang_cl::_e('All Font categories', 'cl') ?></option>
                        <?php foreach ($font_categories as $fontCategory) {  ?>
                        <option value="<?= esc_attr($fontCategory) ?>">
                            <?= esc_html($fontCategory) ?>
                        </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Font name', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select class="select_font_name">
                        <option value=""><?= Lang_cl::_e('Select a font', 'cl') ?></option>
                        <?php 
                        foreach ($googleFonts as $fontCategory => $fonts) { 
                            foreach ($fonts as $key => $font) { ?>
                            <option value='<?= esc_attr(json_encode($font)) ?>' class="<?= esc_attr($fontCategory) ?> all_fonts">
                                <?= esc_html($font['name']) ?>
                            </option>
                        <?php   }     
                        } ?>
                        <option value='{"name": "google_custom_font","sublink": "","weight": ""}'>
                            <?= Lang_cl::_e('Use Another google custom font', 'cl') ?>
                        </option>
                    </select> 
                    <span>
                        <strong><?= Lang_cl::_e('Selected font', 'cl') ?> : </strong> 
                        <span class="cl_selected_font_name"><?= esc_html($settings['font_name']) ?></span>
                    </span>
                </div>
            </div>
            
            <div class="cl-row cl-hide google_custom_font">
                
                <div class="cl-th-full">
                    <?= Lang_cl::_e('Google font name', 'cl') ?>
                </div>
                <div class="cl-th-full cl_font_options">
                    <input type="text" name="font_name" value="<?= esc_attr($settings['font_name']) ?>" />
                    <input type="hidden" name="font_weight" value="<?= esc_attr($settings['font_weight']) ?>" />
                    <input type="hidden" name="font_sublink" value="<?= esc_attr($settings['font_sublink']) ?>" />
                </div>
                
                
                <div class="cl-th-full">
                    <?= Lang_cl::_e('Google font embed code', 'cl') ?>
                </div>
                <div class="cl-td-full">
                    <textarea name="font_embed_code" rows="6"><?= esc_textarea($settings['font_embed_code']) ?></textarea>
                    <div class="cl-alert cl-alert-info">
                        <a href="https://fonts.google.com/selection/embed" target="_blank">
                            <?= Lang_cl::_e('Click here to visit Google Fonts, select the desired font-family, and obtain the embed code.', 'cl') ?>
                        </a> 
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Apply the font to', 'cl') ?>
    </div>
    <div class="cl-td">
        <select name="font_effect" class="cl-style-element" value="<?= esc_attr($settings['font_effect']) ?>">
            <option value="order_form_only" <?= selected($settings['font_effect'], 'order_form_only', false) ?>><?= Lang_cl::_e('The order form only', 'cl') ?></option>
            <option value="entire_landing_page" <?= selected($settings['font_effect'], 'entire_landing_page', false) ?>><?= Lang_cl::_e('The entire landing page', 'cl') ?></option>
            <option value="entire_shop" <?= selected($settings['font_effect'], 'entire_shop', false) ?>><?= Lang_cl::_e('The entire shop', 'cl') ?></option>
        </select> 
        
    </div>
</div>