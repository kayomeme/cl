<?php 
$floatLeft  = $settings['langue_direction'] == 'rtl' ? 'right' : 'left';
$floatRight = $settings['langue_direction'] == 'rtl' ? 'left' : 'right';

$leftOrRight0 = $settings['langue_direction'] == 'rtl' ? 'right: 0;' : 'left: 0;';
?>

<style>
   <?php if( $settings['langue_direction_effect'] == 'order_form_only' ) { ?>
    .clfe-product-container *, #clfe-modal-form * {
       direction: <?= $settings['langue_direction'] ?>;
   }
   <?php } else { ?>
    .single *:not(.wp-admin *), .clfe-product-container *, #clfe-modal-form * {
       direction: <?= $settings['langue_direction'] ?>;
    }
    
    /*
    * elementor fix
    */
    .elementor-accordion { text-align: <?= $floatLeft ?> !important;}
    body {padding-bottom: 60px;}
    
   <?php } ?>
    
    <?php 
    if( strlen($settings['font_name']) > 2 ) {
        switch ($settings['font_effect']) {
            case 'order_form_only':
                echo '.clfe-product-container *, #clfe-modal-form * { font-family: "'.$settings['font_name'].'"; }';
                break;
            case 'entire_landing_page':
                echo '.single *:not(.wp-admin *), .clfe-product-container *, #clfe-modal-form * { font-family: "'.$settings['font_name'].'"; }';
                break;
            case 'entire_shop':
                echo 'body *:not(.wp-admin *), .clfe-product-container *, #clfe-modal-form * { font-family: "'.$settings['font_name'].'"; }';
                break;

            default:
                break;
        }
    }
    ?>
   
#clfe_order_summary .detail-row .key-name {
    float: <?= $floatLeft ?>;
}
#clfe_order_summary .detail-row .key-price {
    float: <?= $floatRight ?>;
}
/*-----quantity offer----*/
.clfe-qty-offer, .clfe-offer-radio-bt {
    float: <?= $floatLeft ?>;
}
.clfe-qty-offer .offer-center {
    justify-content: <?= $floatLeft ?>;
}
.clfe-qty-offer .offer-end {
    margin-<?= $floatLeft ?>: auto;
}
</style>