<button tab="clfe_general_tab">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_clfe::_e('General', 'clfe') ?>
</button>

<button tab="clfe_currency_tab">
    <span class="dashicons dashicons-money-alt"></span>

    <?= Lang_clfe::_e('Currency', 'clfe') ?>
</button>

<button tab="clfe_reset_langue_tab">
    <span class="dashicons dashicons-translation"></span>
    <?= Lang_clfe::_e('Langue', 'clfe') ?>
</button>

<button tab="clfe_googlefont_settings_tab">
    <span class="dashicons dashicons-editor-textcolor"></span>
    <?= Lang_clfe::_e('Google font settings', 'clfe') ?>
</button>