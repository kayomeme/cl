<div id="clfe_general_tab" class="clfe-single-tab">
    <?php include 'partails/general.php'; ?>
</div>     
<div id="clfe_currency_tab" class="clfe-single-tab">
    <?php include 'partails/currency.php'; ?>
</div>     
<div id="clfe_reset_langue_tab" class="clfe-single-tab">
    <?php include 'partails/reset_langue.php'; ?>
</div>     
<div id="clfe_googlefont_settings_tab" class="clfe-single-tab">
    <?php include 'partails/font_settings.php'; ?>
</div>    