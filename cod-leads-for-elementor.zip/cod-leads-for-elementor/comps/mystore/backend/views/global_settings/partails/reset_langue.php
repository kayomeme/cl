<div id="clfe_reset_comps_lang" class="clfe-row">
    <!--<div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Language options', 'clfe') ?>
        </label>
    </div>-->
    <div class="clfe-td-full">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Select the language', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <select name="langue_code" class="clfe-style-element" value="<?= $settings['langue_code'] ?>" clfe_ischanged='yes'>
                        <option value="0"><?= Lang_clfe::_e('Select the new language', 'clfe') ?></option>
                        <?php foreach ($langs_clfe as $langCode => $lang) { ?>
                            <option value="<?= $langCode ?>" langdir="<?= $lang['dir'] ?>">
                                <?= $lang['name'] ?>
                            </option>
                        <?php }  ?>
                    </select> 
                    
                    <select name="reset_lang_confirm" value="no" class="clfe-hide">
                        <option value="no" selected><?= Lang_clfe::_e('No', 'clfe') ?></option>
                        <option value="yes"><?= Lang_clfe::_e('Yes, I confirm that I want to reset the language.', 'clfe') ?></option>
                    </select> 
                    <button type="button" id="mystore_reset_lang" class="clfe-bt clfe-bt-danger clfe-float-inline-end">
                        <?= Lang_clfe::_e('Click here to reset to the selected language.', 'clfe') ?>
                    </button>
                    <div class="clfe-alert clfe-alert-info" modalTitle="<?= Lang_clfe::__('Confirm the language reset', 'clfe') ?>">
                        <?= Lang_clfe::_e('Note: By choosing to reset to the selected language, all your existing language-related changes in all settings will be erased, and the chosen language will be applied.', 'clfe') ?>
                    </div>
                </div>
                
            </div>

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('language Direction', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <select name="langue_direction" class="clfe-style-element" value="<?= $settings['langue_direction'] ?>" clfe_ischanged='yes'>
                        <option value="0"><?= Lang_clfe::_e('Select the new language direction', 'clfe') ?></option>
                        <option value="rtl"><?= Lang_clfe::_e('Right To left', 'clfe') ?></option>
                        <option value="ltr"><?= Lang_clfe::_e('Left to right', 'clfe') ?></option>
                    </select> 

                </div>
            </div>

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Apply the language direction forcefully to', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <select name="langue_direction_effect" class="clfe-style-element" value="<?= $settings['langue_direction_effect'] ?>" clfe_ischanged='yes'>
                        <option value="order_form_only"><?= Lang_clfe::_e('the order form only.', 'clfe') ?></option>
                        <option value="entire_landing_page"><?= Lang_clfe::_e('the entire landing page', 'clfe') ?></option>
                    </select> 

                </div>
            </div>
            
        </div>
    </div>
    
    <input type="hidden" name="settings_model_id" value="<?= $settingsModelId ?>" clfe_ischanged='yes' />
    <div class="clfe-user-fedback">
        <div class="clfe-msg_box">
            <div class="clfe-wait_msg"></div>
            <div class="alert"></div>
        </div>
    </div>
    
</div>
