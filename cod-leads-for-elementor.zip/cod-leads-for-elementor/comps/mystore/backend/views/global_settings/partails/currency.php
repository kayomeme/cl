<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Currency options', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Currency code', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <select name="currency_code" class="clfe-style-element" value="<?= $settings['currency_code'] ?>">
                        <?php foreach ($currencies as $code => $value) {  ?>
                            <option value="<?= $code ?>">
                                <?= Lang_clfe::_e($value['label'], 'clfe') ?>
                            </option>
                        <?php } ?>
                    </select> 
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Currency label', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="currency_label" value="<?= $settings['currency_label'] ?>">
                </div>
            </div>
        </div>
    </div>
</div>