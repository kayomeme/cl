<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Select Google font', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">

        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Font category', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <select class="clfe_font_categories">
                        <?php foreach ($font_categories as $fontCategory) {  ?>
                        <option value="all_fonts"><?= Lang_clfe::_e('All Font categories', 'clfe') ?></option>
                        <option value="<?= $fontCategory ?>">
                            <?= $fontCategory ?>
                        </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Font name', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <select class="select_font_name">
                        <option value=""><?= Lang_clfe::_e('Select a font', 'clfe') ?></option>
                        <?php 
                        foreach ($googleFonts as $fontCategory => $fonts) { 
                            foreach ($fonts as $key => $font) { ?>
                            <option value='<?= json_encode($font) ?>' class="<?= $fontCategory ?> all_fonts">
                                <?= $font['name'] ?>
                            </option>
                        <?php   }     
                        } ?>
                        <option value='{"name": "google_custom_font","sublink": "","weight": ""}'>
                            <?= Lang_clfe::_e('Use Another google custom font', 'clfe') ?>
                        </option>
                    </select> 
                    <span>
                        <strong><?= Lang_clfe::_e('Selected font', 'clfe') ?> : </strong> 
                        <span class="clfe_selected_font_name"><?= $settings['font_name'] ?></span>
                    </span>
                </div>
            </div>
            
            <div class="clfe-row clfe-hide google_custom_font">
                
                <div class="clfe-th-full">
                    <label>
                        <?= Lang_clfe::_e('Google font name', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-th-full clfe_font_options">
                    <input type="text" name="font_name" value="<?= $settings['font_name'] ?>" />
                    <input type="hidden" name="font_weight" value="<?= $settings['font_weight'] ?>" />
                    <input type="hidden" name="font_sublink" value="<?= $settings['font_sublink'] ?>" />
                </div>
                
                
                <div class="clfe-th-full">
                    <label>
                        <?= Lang_clfe::_e('Google font embed code', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td-full">
                    <textarea name="font_embed_code" rows="6"><?= $settings['font_embed_code'] ?></textarea>
                    <div class="clfe-alert clfe-alert-info">
                        <a href="https://fonts.google.com/selection/embed" target="_blank">
                            <?= Lang_clfe::_e('Click here to visit Google Fonts, select the desired font-family, and obtain the embed code.', 'clfe') ?>
                        </a> 
                    </div>
                </div>
            </div>
            
        </div>
        


        
    </div>
</div>

<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Apply the font to', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <select name="font_effect" class="clfe-style-element" value="<?= $settings['font_effect'] ?>">
            <option value="order_form_only"><?= Lang_clfe::_e('The order form only', 'clfe') ?></option>
            <option value="entire_landing_page"><?= Lang_clfe::_e('The entire landing page', 'clfe') ?></option>
            <option value="entire_shop"><?= Lang_clfe::_e('The entire shop', 'clfe') ?></option>
        </select> 
        
    </div>
</div>
