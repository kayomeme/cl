<div class="clfe-row">
    <div class="clfe-td-full">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Site Title', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="site_title" value="<?= $settings['site_title'] ?>">
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Site slogon', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="site_slogon" value="<?= $settings['site_slogon'] ?>">
                    <div class="clfe-alert clfe-alert-info">
                        <?= Lang_clfe::_e('In a few words, explain what this site is about', 'clfe') ?>
                    </div>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Site favicon', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <button type="button" class="clfe-image-selector">
                        <img src="<?= $settings['site_icon_url'] ?>" alt="<?= Lang_clfe::_e('Select image', 'clfe') ?>" /> <br/>
                        <input type="hidden" class="clfe_img_id" name="site_icon_id" value="<?= $settings['site_icon_id'] ?>" />
                        <input type="hidden" class="clfe_img_url" name="site_icon_url" value="<?= $settings['site_icon_url'] ?>" />
                    </button>
                    <div class="clfe-alert clfe-alert-info">
                        <?= Lang_clfe::_e('The site icon is what you see in browser tabs, bookmark bars. It should be square and at least 512 × 512 pixels.', 'clfe') ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>