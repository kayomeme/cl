(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */  
        $(document).ready( function () {
            
            $('select[name=currency_code]').on('change', function(){
                $("input[name=currency_label]").val( $(this).val() );
            });
            
            $('select[name=langue_code]').on('change', function() {
                const langDir = $(this).find(':selected').attr('langdir');
                $('select[name=langue_direction]').val( langDir );
            });
            
            $('#mystore_reset_lang').on('click', function(ev){
                ev.preventDefault();
                
                console.log('dddddddddddddd');

                const celement      = $(this).closest(".clfe-td").find(".clfe-alert-info");
                const modalTitle    = $(celement).attr('modalTitle');
                
                celement.dialog({
                    create: function( event, ui ) {
                      // Set maxWidth
                      $(this).css("maxWidth", "660px");
                    },
                    title: modalTitle,
                    resizable: false,
                    height: "auto",
                    width: $(window).width() > 800 ? 500 : 'auto',
                    modal: true,
                    buttons: {
                        "Cancel": function() {
                            $( this ).dialog( "close" ); 
                        },
                        "Save": function() {
                            $( this ).dialog( "close" );
                            
                            const clfe_controller   = 'clfe_tools';
                            const clfe_action       = 'clfe_reset_comps_lang';

                            const formData = AdminFn_clfe.getFormDatas(clfe_action);
                            
                            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
                            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);

                            // Wait for the custom event before accessing the modified variable
                            document.addEventListener(clfe_action+'lastResponse', function (event) {
                                if( jsArgs.lastResponse.code == 1 ) {
                                    AdminFn_clfe.autoSaveSettings();
                                }
                            });
                            
                        }
                    },
                    close: function() { 
                        $( this ).dialog( "destroy" );
                    }
                });
                
            }); 
            /*----------------------------------------*/
            $('.clfe_font_categories').on('change', function(){
                const fontCategory = $(this).val();
                
                $("select.select_font_name").val("");
                $("select.select_font_name option").hide();
                $("select.select_font_name option."+fontCategory).show();
                $("select.select_font_name option:last").show();
            });
            
            $('select.select_font_name').on('change', function(){
                var selectedFont = JSON.parse($(this).val());
                
                $("span.clfe_selected_font_name").text(selectedFont.name);
                
                if( selectedFont.name == 'google_custom_font' ) {
                    $("div.google_custom_font").removeClass("clfe-hide");
                    $('.clfe_font_options input').val("");
                } else {
                    $("div.google_custom_font").addClass("clfe-hide");
                    
                    $("div.google_custom_font textarea").val("");
                    $('input[name=font_name]').val(selectedFont.name);
                    $('input[name=font_weight]').val(selectedFont.weight);
                    $('input[name=font_sublink]').val(selectedFont.sublink);
                    
                }
            });
            

        } );

})( jQuery );