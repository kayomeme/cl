(function ($) {
    'use strict';

    $(document).ready(function () {
        
        /* --- Logic for Contact Info block --- */
        function updateContactInfoJson() {
            var contactInfo = {};

            $('#cl-contact-info-container .cl-sub-section').each(function() {
                var $section = $(this);
                var key = $section.data('contact-key');
                var isActive = $section.find('[data-type="is_active"]').is(':checked');

                if (isActive) {
                    var text = $section.find('[data-type="text"]').val();
                    var link = $section.find('[data-type="link"]').val();
                    var iconId = $section.find('input.cl-icon-input').val();

                    contactInfo[key] = {
                        'text': text,
                        'link': link,
                        'icon_id': iconId
                    };
                }
            });
            
            $('input[name="contact_info"]').val(JSON.stringify(contactInfo)).attr('cl-ischanged', 'yes');
        }

        $(document).on('change', '#cl-contact-info-container input, #cl-contact-info-container select, #cl-contact-info-container textarea', function() { 
            updateContactInfoJson(); 
        });


        /* --- Logic for Social Links block --- */
        function updateSocialLinksJson() {
            var socialLinks = {};

            $('#cl-social-links-container .cl-sub-section').each(function() {
                var $section = $(this);
                var key = $section.data('social-key');
                var isActive = $section.find('[data-type="is_active"]').is(':checked');

                if (isActive) {
                    var url = $section.find('[data-type="url"]').val();
                    var iconId = $section.find('input.cl-icon-input').val();

                    socialLinks[key] = {
                        'url': url,
                        'icon_id': iconId
                    };
                }
            });
            
            $('input[name="social_links"]').val(JSON.stringify(socialLinks)).attr('cl-ischanged', 'yes');
        }

        $(document).on('change', '#cl-social-links-container input, #cl-social-links-container select, #cl-social-links-container textarea', function() { 
            updateSocialLinksJson(); 
        });

        /* --- Existing MyStore JS --- */
        $('select[name=currency_code]').on('change', function () {
            $("input[name=currency_label]").val($(this).val());
        });

        $('select[name=langue_code]').on('change', function () {
            const langDir = $(this).find(':selected').attr('langdir');
            $('select[name=langue_direction]').val(langDir);
        });

        $('#mystore_reset_lang').on('click', function (ev) {
            ev.preventDefault();

            const celement = $(this).closest(".cl-td").find(".cl-alert-info");
            const modal_title = $(celement).attr('modal_title');

            celement.dialog({
                create: function (event, ui) {
                    $(this).css("maxWidth", "660px");
                },
                title: modal_title,
                resizable: false,
                height: "auto",
                width: $(window).width() > 800 ? 500 : 'auto',
                modal: true,
                buttons: {
                    "Cancel": function () {
                        $(this).dialog("close");
                    },
                    "Save": function () {
                        $(this).dialog("close");

                        const cl_controller = 'cl_tools';
                        const cl_action = 'cl_reset_comps_lang';

                        const formData = AdminFn_cl.getFormDatas(cl_action);

                        AdminFn_cl.beforeSendAjaxRequest(cl_action);
                        AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formData);

                        document.addEventListener(cl_action + 'lastResponse', function (event) {
                            if (jsArgs.lastResponse.code == 1) {
                                AdminFn_cl.autoSaveSettings();
                            }
                        });

                    }
                },
                close: function () {
                    $(this).dialog("destroy");
                }
            });

        });
        
        $('.cl_font_categories').on('change', function () {
            const fontCategory = $(this).val();

            $("select.select_font_name").val("");
            $("select.select_font_name option").hide();
            $("select.select_font_name option." + fontCategory).show();
            $("select.select_font_name option:last").show();
        });

        $('select.select_font_name').on('change', function () {
            var selectedFont = JSON.parse($(this).val());

            $("span.cl_selected_font_name").text(selectedFont.name);

            if (selectedFont.name == 'google_custom_font') {
                $("div.google_custom_font").removeClass("cl-hide");
                $('.cl_font_options input').val("");
            } else {
                $("div.google_custom_font").addClass("cl-hide");

                $("div.google_custom_font textarea").val("");
                $('input[name=font_name]').val(selectedFont.name);
                $('input[name=font_weight]').val(selectedFont.weight);
                $('input[name=font_sublink]').val(selectedFont.sublink);

            }
        });

    });

})(jQuery);