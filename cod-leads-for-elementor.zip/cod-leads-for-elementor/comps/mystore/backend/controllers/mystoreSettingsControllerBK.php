<?php

class MystoreSettingsControllerBK_cl
{

    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'mystore';
        
        // If we arrived here from the activation redirect
        if( isset( $_REQUEST['flush_rules'] ) ) {
            // Update permalinks to /%postname%/ format and flush rules
            adminUtils_cl::setPermalinkStructureToPostnameAndFlushRules();
        }

        // Get default settings to ensure all keys are present for all blocks.
        $defaultSettings = AdminCompo_cl::getDefaultSettings($compoName, $settings);

        // --- Prepare data for blocks ---
        $siteInfos = [
            'site_title' => get_bloginfo('name'),
            'site_slogon' => get_bloginfo('description')
        ];
        $settings = array_merge($settings, $siteInfos);
        
        $langs_cl = require MainApp_cl::$pluginPath.'languages/comps/langs_cl.php'; 

        ob_start();
        include(AdminApp_cl::$assetsPath . 'currencies.json');
        $currencies = jsonDecode_cl(ob_get_clean());

        ob_start();
        include(AdminApp_cl::$assetsPath . 'google_fonts.json');
        $googleFonts = jsonDecode_cl(ob_get_clean());
        $font_categories = array_keys($googleFonts);

        // --- Data for social_links block ---
        $social_networks = array(
            'facebook'  => Lang_cl::__('Facebook', 'cl'),
            'twitter'   => Lang_cl::__('Twitter (X)', 'cl'),
            'instagram' => Lang_cl::__('Instagram', 'cl'),
            'linkedin'  => Lang_cl::__('LinkedIn', 'cl'),
            'youtube'   => Lang_cl::__('YouTube', 'cl'),
            'tiktok'    => Lang_cl::__('TikTok', 'cl'),
            'pinterest' => Lang_cl::__('Pinterest', 'cl'),
        );
        //$saved_social_links = json_decode($settings['social_links'], true);
        $saved_social_links = jsonDecode_cl($settings['social_links']);
        if (!is_array($saved_social_links)) {
            $saved_social_links = array();
        }

        // --- Data for contact_info block ---
        $contact_types = array(
            'address'       => Lang_cl::__('Address', 'cl'),
            'email'         => Lang_cl::__('Email', 'cl'),
            'phone'         => Lang_cl::__('Phone', 'cl'),
            'whatsapp'      => Lang_cl::__('WhatsApp', 'cl'),
            'working_hours' => Lang_cl::__('Working Hours', 'cl'),
        );
        $saved_contact_items = jsonDecode_cl($settings['contact_info']);
        if (!is_array($saved_contact_items)) {
            $saved_contact_items = array();
        }
        
        include AdminApp_cl::$viewsPath . 'global_settings/index.php';
    }


    public static function save_settings($compoName, $settingsModelId, $args)
    {
        $response = AdminCompo_cl::saveSettings($compoName, $settingsModelId, $args);
        
        var_dump($response);

        $mystoreSharedSettings = self::getSharedSettings($args);
        AdminCompo_cl::saveSharedSettings($settingsModelId, $mystoreSharedSettings);

        self::setWebsiteInfoFromMystoreCompo($args);
        
        if( $response ) {
            return $response;
        }
    }

    private static function getSharedSettings($args)
    {
        $sharedSettings = [];

        if (isset($args['langue_direction'])) {
            $sharedSettings['lang_dir'] = $args['langue_direction'];
        }

        if (isset($args['currency_code'])) {
            $sharedSettings['currency_code'] = $args['currency_code'];
        }

        if (isset($args['currency_label'])) {
            $sharedSettings['currency_label'] = $args['currency_label'];
        }
        
        if (isset($args['collapse_open_icon_id'])) {
            $sharedSettings['collapse_open_icon_id'] = $args['collapse_open_icon_id'];
        }
        
        if (isset($args['collapse_close_icon_id'])) {
            $sharedSettings['collapse_close_icon_id'] = $args['collapse_close_icon_id'];
        }

        return $sharedSettings;
    }

    private static function setWebsiteInfoFromMystoreCompo($infos)
    {
        if (isset($infos['site_title']) && !empty($infos['site_title'])) {
            update_option('blogname', $infos['site_title']);
        }

        if (isset($infos['site_slogon']) && !empty($infos['site_slogon'])) {
            update_option('blogdescription', $infos['site_slogon']);
        }

        if (isset($infos['site_icon_id']) && !empty($infos['site_icon_id'])) {
            update_option('site_icon', $infos['site_icon_id']);
        }
    }
}