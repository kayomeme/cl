<?php

class MystoreSettingsControllerBK_clfe
{

    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'mystore';
        $tabName = isset($urlArgs['tab']) ? $urlArgs['tab'] : 'general';
        
        // If we arrived here from the activation redirect
        if( isset( $_REQUEST['flush_rules'] ) ) {
            // Update permalinks to /%postname%/ format and flush rules
            adminUtils_clfe::setPermalinkStructureToPostnameAndFlushRules();
        }

        $siteInfos = [
            'site_title' => get_bloginfo('name'),
            'site_slogon' => get_bloginfo('description')
        ];
        $settings = array_merge($settings, $siteInfos);
        
        $langs_clfe = require MainApp_clfe::$pluginPath.'languages/comps/langs_clfe.php'; 

        ob_start();
        include(AdminApp_clfe::$assetsPath . 'currencies.json');
        $currencies = jsonDecode_clfe(ob_get_clean());

        ob_start();
        include(AdminApp_clfe::$assetsPath . 'google_fonts.json');
        $googleFonts = jsonDecode_clfe(ob_get_clean());
        $font_categories = array_keys($googleFonts);

        include AdminApp_clfe::$viewsPath . 'global_settings/index.php';
    }


    public static function save_settings($compoName, $settingsModelId, $args)
    {
        $response = AdminCompo_clfe::saveSettings($compoName, $settingsModelId, $args);

        $mystoreSharedSettings = self::getSharedSettings($args);
        AdminCompo_clfe::saveSharedSettings($settingsModelId, $mystoreSharedSettings);

        self::setWebsiteInfoFromMystoreCompo($args);

        // you should attach this to an option so it can be enabled or disabled
        adminUtils_clfe::setPermalinkStructureToPostnameAndFlushRules();
        
        if( $response ) {
            return $response;
        }
    }

    private static function getSharedSettings($args)
    {
        $sharedSettings = [];

        if (isset($args['langue_direction'])) {
            $sharedSettings['lang_dir'] = $args['langue_direction'];
        }

        if (isset($args['currency_code'])) {
            $sharedSettings['currency_code'] = $args['currency_code'];
        }

        if (isset($args['currency_label'])) {
            $sharedSettings['currency_label'] = $args['currency_label'];
        }

        return $sharedSettings;
    }

    /*
        * This will change the site title, desc, favicon in the wp system
        */
    private static function setWebsiteInfoFromMystoreCompo($infos)
    {
        if (isset($infos['site_title']) && !empty($infos['site_title'])) {
            update_option('blogname', $infos['site_title']);
        }

        if (isset($infos['site_slogon']) && !empty($infos['site_slogon'])) {
            update_option('blogdescription', $infos['site_slogon']);
        }

        if (isset($infos['site_icon_id']) && !empty($infos['site_icon_id'])) {
            update_option('site_icon', $infos['site_icon_id']);
        }
    }
}
