<?php

if( isset($_REQUEST['page']) && $_REQUEST['page'] == 'cl_global_settings' && isset($_REQUEST['compo']) && $_REQUEST['compo'] == 'mystore' ) {
    
    // Enqueue the backend CSS for the mystore component
    wp_enqueue_style( 
        MainApp_cl::$assetsPrefix . 'mystore', 
        MainApp_cl::$compsUrl . 'mystore/backend/assets/css/mystore_bk.css', 
        [], 
        $assetsVersion 
    );
    
    // Enqueue the backend JavaScript for the mystore component
    wp_enqueue_script( 
        MainApp_cl::$assetsPrefix . 'mystore', 
        MainApp_cl::$compsUrl . 'mystore/backend/assets/js/mystore_bk.js', 
        ['jquery'], 
        $assetsVersion 
    );
}