<?php
if( !$mystore_clfe ) {
    return;
}
    //$hook['compName']
    echo $mystore_clfe->getFontImportLinks();
    ?>
<script>
let jsMystore = JSON.parse('<?= $mystore_clfe->getJsMystore() ?>');
</script>
