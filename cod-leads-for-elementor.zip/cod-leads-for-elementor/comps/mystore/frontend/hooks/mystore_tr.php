<?php
global $mystore_clfe;
$mystore_clfe = new MystoreFrontendController_clfe($settingsModelId);
