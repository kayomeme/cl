<?php

/**
 */
class MystoreFrontendController_clfe {
    
    public $settings;


    public function __construct($settingsModelId) {
        
        $compoName = 'mystore';
        $settings = PublicCompo_clfe::getSettings($compoName, $settingsModelId);
        
        $this->settings = $settings;
    }
    
    /*
     * the code returned by this should be include in the head 
     */
    public function getFontImportLinks() {
        return MainUtils_clfe::getGoogleFontEmbed($this->settings['font_name'], $this->settings['font_embed_code']);
    }
    
    public function getCurrencyInfos() {
        $currency = [];
        
        $currency['currency_code']        = $this->settings['currency_code'];
        $currency['currency_label']       = $this->settings['currency_label'];
        
        return $currency;
    }
    
    public function getJsMystore() {
        $jsMystore = [];
        
        $jsMystore['currency_code']        = $this->settings['currency_code'];
        $jsMystore['currency_label']       = $this->settings['currency_label'];
        
        return jsonEncodeForJs_clfe($jsMystore);
    }
    
}
