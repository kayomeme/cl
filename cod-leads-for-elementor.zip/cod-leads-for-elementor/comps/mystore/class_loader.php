<?php
$dirPath = plugin_dir_path( __FILE__ );

// backend
if($isAdminAria) {
    //require_once $dirPath  . 'backend/controllers/sheetControllerBk.php';
    require_once $dirPath.'backend/controllers/mystoreSettingsControllerBK.php';
}

if($isPublicAria) {
    require_once $dirPath  . 'frontend/controllers/mystoreControllerFR.php';
}

