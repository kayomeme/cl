    <div class="clfe_cart_empty-element" style="display: none !important">
        <div class="cart-product">
            <div class="img-and-title">
                <?php if ($settings['cart_products_image_is_active'] == 'yes') { ?>
                    <div class="clfe-cart-product-img">
                        <img src="" />
                    </div>
                <?php } ?>

                <div class="clfe-cart-body">

                    <div class="cart-product-meta">
                        <?php if ($settings['cart_products_title_is_active'] == 'yes') { ?>
                            <div class="clfe-cart-product-title"></div>
                        <?php } ?>
                        <?php if ($settings['cart_products_variations_is_active'] == 'yes') { ?>
                            <div class="clfe-cart-product-variations"></div>
                        <?php } ?>    
                    </div>


                    <div class="cart-product-price-box">
                        <div class="cart-product-price">
                            <?php if ($settings['cart_products_sale_price_is_active'] == 'yes') { ?>
                                <div class="clfe-cart-product-sale-price">
                                    <span class="sale_price"></span>
                                    <span class="clfe-currency"><?= $sharedSettings['currency_label'] ?></span>
                                </div>
                            <?php } ?>
                            <?php if ($settings['cart_products_regular_price_is_active'] == 'yes') { ?>
                                <div class="clfe-cart-product-regular-price">
                                    <span class="regular_price"></span>
                                    <span class="clfe-currency"><?= $sharedSettings['currency_label'] ?></span>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="cart-product-offer">
                            <span class="clfe-title"></span>
                            <span class="clfe-value"></span>
                        </div>
                    </div>
                </div>

            </div>
            <div class="cart-product-actions">
                <a class="clfe-button clfe-button-update" href=""
                   title="<?= Lang_clfe::__('Update this product.', 'clfe') ?>">
                       
                    <i class="clfe-icon icon-edit" title="<?= Lang_clfe::__('Update', 'clfe') ?>"></i>
                </a>
                <button class="cart-remove-product clfe-button clfe-button-delete" title="<?= Lang_clfe::__('Remove this item from your shopping cart.', 'clfe') ?>">
                    <i class="clfe-icon icon-trash-2" title="<?= Lang_clfe::__('Remove', 'clfe') ?>"></i>
                </button>
            </div>
        </div>
    </div>