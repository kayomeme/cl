<style>
    
    .clfe_cart_products {
        <?= $settings['cart_products_container_style'] ?>
    }

    .cart-header-title {
        <?= $settings['cart_products_header_title_style'] ?>
    }

    .cart-header-count-container {
        <?= $settings['cart_products_header_count_text_style'] ?>
    }
    .clfe_cart_products_display {
        display: flex;
        flex-wrap: wrap;
        column-gap: 10px;
    }

    .cart-product {
        display: flex;
        min-width: fit-content; /*---to check each time for evry layout display------*/
        flex-wrap: wrap;
        row-gap: 5px;
        flex:1;
        align-items: center;
        column-gap: 10px;
        margin-bottom: 3px;
        <?= $settings['cart_product_container_style'] ?>
    }
    .cart-product .img-and-title{
        display: flex;
        column-gap: 10px;
        width: fit-content;
        flex: 1;
    }

    .clfe-cart-product-title {
        <?= $settings['cart_products_title_style'] ?>
    }

    .clfe-cart-product-img {
        display: flex;
        align-items: center;
    }

    .clfe-cart-product-img img {
        /*max-width: 40px;
        border-radius: 50%;*/
        <?= $settings['cart_products_img_style'] ?>
    }
    .clfe-cart-body {
    display: flex;
    flex-direction: column;
    justify-content: center;
    row-gap: 5px;
    }
    .clfe-cart-product-variations {
        display: flex;
        flex-wrap: wrap;
        column-gap: 6px;
    }

    .clfe-cart-product-variations .qty_choise_variation {
        margin-bottom: 4px;
        <?= $settings['cart_products_variations_style'] ?>
    }

    .clfe-cart-product-variations span::after {
        content: " / ";
    }

    .clfe-cart-product-variations span:last-child::after {
        content: "";
    }

    .cart-variation-extra-fees {
        border-radius: 3px;
        border: solid;
        border-bottom: 0;
        padding: 0px 2px;
    }

    .cart-variation-extra-fees-plus {
        color: #aa6020;
    }

    .cart-variation-extra-fees-minus {
        color: #7ebf4b;
    }

    .cart-product-meta {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }

    .cart-product-price-box {
        display: flex;
        flex-wrap: wrap;
        column-gap: 15px;
        align-items: center;
    }

    .cart-product-price {
        display: flex;
        column-gap: 7px;
    }

    .clfe-cart-product-regular-price {
        text-decoration: line-through;
        <?= $settings['cart_products_regular_price_style'] ?>
    }

    .clfe-cart-product-sale-price {
        <?= $settings['cart_products_sale_price_style'] ?>
    }
    
    .cart-product-offer {
        display: flex;
        align-items: center;
        column-gap: 6px;
    }
    .cart-product-offer .clfe-value {
        color: #2ecc71;  /* Bright green color */
        font-weight: bold;
        background-color: #f8fff9; /* Light green background */
        border-radius: 4px;
    }
    .cart-product-actions {
        display: flex;
        justify-content: space-between;
        gap: 5px;
        flex-direction: column;
        padding: 5px;
    }

    @media screen and (max-width: 475px) {
        .cart-product {
            width: 100%;
        }
        .clfe-cart-body, .cart-product-price-box {
            flex-grow: 1;
            justify-content: space-between;
        }
        .cart-product-actions {
            justify-content: space-between;
            width: 100%;
            flex-grow: 1;
            flex-direction: row;
        }
    }
</style>