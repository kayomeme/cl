<?php
return [
    /*-----------My Store component--------*/
    'mystore' => [
        'name'      => 'mystore',
        'is_active' => 'yes',  
        'admin_hooks' => [
            18 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            28 => 'template_redirect',
            30 => 'wp_head',
        ],
        'public_filters' => []
    ],
    /*-----------Sales Funnel component--------*/
    'sales_funnel' => [
        'name'      => 'sales_funnel',
        'is_active' => 'yes',
        'admin_hooks' => [
            1 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [
            1 => 'template_redirect',
            2 => 'wp_head',
            3 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Product component--------*/
    'product' => [
        'name'      => 'product',
        'is_active' => 'yes',
        'admin_hooks' => [
            2 => 'admin_head',
            3 => 'admin_footer',
            4 => 'manage_post_posts_custom_column',
            5 => 'admin_enqueue_scripts',
            6 => 'add_meta_boxes',
            7 => 'save_post_product',
        ],
        'admin_filters' => [
            1 => 'manage_edit-post_columns',
        ],
        'public_hooks' => [
            4 => 'template_redirect',
            5 => 'wp_head',
            6 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Cart component--------*/
    'cart' => [
        'name'      => 'cart',
        'is_active' => 'yes',
        'admin_hooks' => [
            8 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            7 => 'template_redirect',
            8 => 'wp_head',
            9 => 'wp_enqueue_scripts',
        ],
        'public_filters' => [
            1 => 'the_content',
        ]
    ],
    /*-----------Checkout component--------*/
    'checkout' => [
        'name'      => 'checkout',
        'is_active' => 'yes',
        'admin_hooks' => [
            9 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            10 => 'template_redirect',
            11 => 'wp_head',
            12 => 'wp_enqueue_scripts',
        ],
        'public_filters' => [
            2 => 'the_content',
        ]
    ],
    /*-----------Thank You component--------*/
    'thankyou' => [
        'name'      => 'thankyou',
        'is_active' => 'yes',
        'admin_hooks' => [
            10 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            13 => 'template_redirect',
            14 => 'wp_head',
            15 => 'wp_enqueue_scripts',
        ],
        'public_filters' => [
            3 => 'the_content',
        ]
    ],
    /*-----------Google Sheet component--------*/
    'google_sheet' => [
        'name'      => 'google_sheet',
        'is_active' => 'yes',  
        'admin_hooks' => [
            11 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [
            16 => 'template_redirect',
            17 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Top Bar component--------*/
    'top_bar' => [
        'name'      => 'top_bar',
        'is_active' => 'yes',
        'admin_hooks' => [],
        'admin_filters' => [],
        'public_hooks' => [
            18 => 'template_redirect',
            19 => 'wp_body_open',
            29 => 'wp_head',
        ],
        'public_filters' => []
    ],
    /*-----------WhatsApp component--------*/
    'whatsapp' => [
        'name'      => 'whatsapp',
        'is_active' => 'yes',
        'admin_hooks' => [],
        'admin_filters' => [],
        'public_hooks' => [
            20 => 'template_redirect',
            21 => 'wp_footer',
        ],
        'public_filters' => []
    ],
    /*-----------Tracking component--------*/
    'tracking' => [
        'name'      => 'tracking',
        'is_active' => 'yes',
        'admin_hooks' => [],
        'admin_filters' => [],
        'public_hooks' => [
            22 => 'template_redirect',
            23 => 'wp_head',
            24 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Order component--------*/
    'order' => [
        'name'      => 'order',
        'is_active' => 'yes',
        'admin_menus' => [],
        'admin_hooks' => [
            12 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Order Status component--------*/
    'order_status' => [
        'name'      => 'order_status',
        'is_active' => 'yes',
        'admin_menus' => [],
        'admin_hooks' => [
            13 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Products Listing component--------*/
    'plist1' => [
        'name'      => 'plist1',
        'is_active' => 'yes',
        'admin_hooks' => [
            14 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Categories Listing component--------*/
    'categories_listing' => [
        'name'      => 'categories_listing',
        'is_active' => 'yes',
        'admin_hooks' => [
            15 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Insights component--------*/
    'insights' => [
        'name'      => 'insights',
        'is_active' => 'yes',
        'admin_hooks' => [
            16 => 'admin_enqueue_scripts',
            17 => 'manage_post_posts_custom_column',
        ],
        'admin_filters' => [
            2 => 'manage_edit-post_columns',
        ],
        'public_hooks' => [
            25 => 'template_redirect',
            26 => 'wp_head',
            27 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
];
