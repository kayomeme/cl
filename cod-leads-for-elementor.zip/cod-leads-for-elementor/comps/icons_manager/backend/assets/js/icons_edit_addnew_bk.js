(function ($) {
    'use strict';
    $(document).ready(function () {
        
        // Show/hide fields based on icon type
        $('#icon-type-select').on('change', function() {
            const selectedType = $(this).val();
            
            if (selectedType === 'svg') {
                $('.svg-code-container, .svg-preview-container').removeClass('cl-hide');
            } else {
                $('.svg-code-container, .svg-preview-container').addClass('cl-hide');
            }
        });
        
        // Trigger change on load to set initial visibility
        $('#icon-type-select').trigger('change');
        
        // Live SVG preview
        $('textarea[name="code"]').on('input', function() {
            const svgCode = $(this).val();
            const cleanedCode = svgCode.replace(/\\"/g, '"');

            // --- START: Logic to extract viewBox and determine fill ---
            let viewBox = '0 0 24 24'; // Default viewBox
            const viewBoxMatch = cleanedCode.match(/viewBox\s*=\s*["']([^"']*)["']/);
            if (viewBoxMatch && viewBoxMatch[1]) {
                viewBox = viewBoxMatch[1];
            }

            let fill = 'currentColor'; // Default fill
            const fillMatch = cleanedCode.match(/fill\s*=\s*["']([^"']*)["']/);
            if (fillMatch && fillMatch[1] && fillMatch[1].toLowerCase() === 'none') {
                fill = 'none';
            }
            // --- END: Logic ---

            // Now, we must extract only the inner content for the wrapper
            const innerContentMatch = cleanedCode.match(/<svg[^>]*>(.*?)<\/svg>/s);
            const innerContent = innerContentMatch ? innerContentMatch[1] : cleanedCode;

            // Use the extracted viewBox in the wrapper. Removed hardcoded stroke attributes.
            const svgWrapper = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${viewBox}" fill="${fill}">${innerContent}</svg>`;

            $('#icon-preview').html(svgWrapper);
        });
        
        
        // Initialize preview settings and trigger initial render
        if($('textarea[name="code"]').val() !== '') {
            $('textarea[name="code"]').trigger('input');
        }

        // Form submission for updating icons
        $('#save-update-icon').on('click', function (ev) {
            ev.preventDefault();
            
            const cl_controller = 'cl_icons';
            const cl_action = 'cl_update_icon';
            const formData = AdminFn_cl.getFormDatas(cl_action);
            AdminFn_cl.beforeSendAjaxRequest(cl_action);
            AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formData);
            
            // Wait for the custom event before accessing the modified variable
            document.addEventListener(cl_action + 'lastResponse', function (event) {
                console.log(jsArgs.lastResponse);
                if (jsArgs.lastResponse.code == 1) {
                    // Handle successful update if needed
                }
            });
        });
        
        // Form submission for adding new icons
        $('#save-new-icon').on('click', function (ev) {
            ev.preventDefault();
            
            const cl_controller = 'cl_icons';
            const cl_action = 'cl_addnew_icon';
            const formData = AdminFn_cl.getFormDatas(cl_action);
            AdminFn_cl.beforeSendAjaxRequest(cl_action);
            AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formData);
            
            // Wait for the custom event before accessing the modified variable
            document.addEventListener(cl_action + 'lastResponse', function (event) {
                console.log(jsArgs.lastResponse);
                if (jsArgs.lastResponse.code == 1) {
                    // Handle successful addition if needed
                    if (jsArgs.lastResponse.res.redirect_to) {
                        window.location.href = jsArgs.lastResponse.res.redirect_to;
                    }
                }
            });
        });
    });
})(jQuery);