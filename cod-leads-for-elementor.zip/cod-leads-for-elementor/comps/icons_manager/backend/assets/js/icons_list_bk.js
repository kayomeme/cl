(function ($) {
    'use strict';
    $(document).ready(function () {
        
        $('.save-delete-icon').on('click', function (ev) {
            ev.preventDefault();
            if (confirm(jsLang.delete_confirm_msg) == true) {   
                $("input[name=icon_id]").val($(this).attr('icon_id'));
                const cl_controller = 'cl_icons';
                const cl_action = 'cl_delete_icon';
                const formData = AdminFn_cl.getFormDatas(cl_action);
                AdminFn_cl.beforeSendAjaxRequest(cl_action);
                AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formData);
                
                // Wait for the custom event before accessing the modified variable
                document.addEventListener(cl_action + 'lastResponse', function (event) {
                    if (jsArgs.lastResponse.code == 1) {
                        const iconId = $("input[name=icon_id]").val();
                        const iconElement = $('#icon-' + iconId);
                        iconElement.css('background-color', '#ffebee').animate({opacity: 0}, 600, function() {
                            $(this).slideUp(200, function() {
                                $(this).remove();
                                
                                // Show empty state if no icons remain
                                if ($('.icon-item').length === 0) {
                                    $('.icon-items').html('<div class="icon-empty-state"><p>' + 
                                        Lang_cl.__('No icons found. Click "Add New Icon" to create one.', 'cl') + 
                                        '</p></div>');
                                }
                            });
                        });
                    }
                });
            }
        });
        
    });
})(jQuery);