(function ($) {

    IconsSelector_cl = {
        closeActiveModals: function () {
            $(".ui-dialog .ui-dialog-buttonset .ui-button:first-child").click();
        },
        openModal: function (clickedEl, ev) {
            IconsSelector_cl.closeActiveModals();

            ev.preventDefault();
            const iconId = clickedEl.attr('icon_id');
            const celement = $('#cl_icons_select_modal');
            
            celement.dialog({
                title: jsLang.icons_select_modal_title,
                /*resizable: false,
                height: "auto",
                
                modal: false,*/
                width: $(window).width() > 800 ? 800 : 'auto',
                buttons: {
                    "Cancel": function () {
                        $(this).dialog("close");
                    },
                    "Save": function () {
                        $(this).dialog("close");
                        
                        // for system id
                        const currentSelectedIconId = $('.icon_item_selected').attr('icon_id');

                        clickedEl.attr('icon_id', currentSelectedIconId);
                        
                        // for the viewer
                        const matchingIconItem = $('.icon-item[icon_id="' + currentSelectedIconId + '"] .icon-svg svg').clone(false);
                        clickedEl.find('.cl_icon_viewer').html(matchingIconItem);
                        clickedEl.find('.cl_icon_viewer').attr('icon_id', currentSelectedIconId);
                        
                        // for hidden input
                        clickedEl.closest('.cl-icon-container').find('input.cl-icon-input').val(currentSelectedIconId).change();
                    }
                },
                close: function () {
                    $(this).dialog("destroy");
                }
            });
        }
    };

    $(function () {
        //IconsSelector_cl.init();
    });

    $(document).ready(function () {
        
        $('.cl_select_icon_bt').on('click', function (ev) {
            IconsSelector_cl.openModal($(this), ev);
        });
         $('#cl_icons_select_modal .icon-item').on('click', function (ev) {
            $('#cl_icons_select_modal .icon-item').removeClass('icon_item_selected'); 
            $(this).addClass('icon_item_selected');
        });
        
        // Loop through all elements with class 'cl_icon_viewer'
        $('.cl_select_icon_bt').each(function() {
            const iconViewer = $(this);
            const iconId = iconViewer.attr('icon_id');
            
            if( parseInt(iconId) > 0 ) {
                const matchingIconItem = $('.icon-item[icon_id="' + iconId + '"] .icon-svg svg').clone(false);
                iconViewer.find('.cl_icon_viewer').html(matchingIconItem);
            }
        });
        

    });

})(jQuery);