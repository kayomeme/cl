<?php
$loadIcons = false;


if( IsClfePages() ) {
    $loadIcons = true;
}

if( $loadIcons ) {
    IconsSelectorBK_cl::getModal($args = []);
}

