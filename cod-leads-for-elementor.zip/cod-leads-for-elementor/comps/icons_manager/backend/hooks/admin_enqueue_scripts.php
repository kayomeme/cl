<?php
if( !IsInCurrentPages(['cl_icons']) ) {
    wp_enqueue_style('icons_selector_css', MainApp_cl::$compsUrl.'icons_manager/backend/assets/css/icons_selector_bk.css', [], $assetsVersion);
    wp_enqueue_script('icons_selector_js', MainApp_cl::$compsUrl.'icons_manager/backend/assets/js/icons_selector_bk.js', [], $assetsVersion);
    
    return;
}

if ( !isset($_REQUEST['action'])) {
    wp_enqueue_style('icons_list_css', MainApp_cl::$compsUrl.'icons_manager/backend/assets/css/icons_list_bk.css', [], $assetsVersion);
    wp_enqueue_script('icons_list_js', MainApp_cl::$compsUrl.'icons_manager/backend/assets/js/icons_list_bk.js', [], $assetsVersion);
}

if (isset($_REQUEST['action']) && ($_REQUEST['action'] == 'edit' || $_REQUEST['action'] == 'addnew')) {
    wp_enqueue_style('icons_edit_css', MainApp_cl::$compsUrl.'icons_manager/backend/assets/css/icons_edit_addnew_bk.css', [], $assetsVersion);
    wp_enqueue_script('icons_edit_js', MainApp_cl::$compsUrl.'icons_manager/backend/assets/js/icons_edit_addnew_bk.js', [], $assetsVersion);
}