<div class="cl-hide">
    <div id="cl_icons_select_modal">

        <?php if (!$icons) { ?>
            <div class="cl-alert cl-alert-infos">
                No icons are currently available. <a href=''>Go to Icons Manager</a> 
                to add or activate icons so they'll appear in this selection menu.
            </div>
        <?php } else { ?>

            <div class="icon-selector-container">
                <?php foreach ($icons as $id => $icon) : ?>
                    <div class="icon-item" icon_id="<?= $id ?>">
<div class="icon-svg">
    <?= IconsUtilBK_cl::getCompleteSvg($icon['code'], $icon['view_box'], $icon['fill']) ?>
</div>
                        <div class="icon-name">
                            <?= $icon['name'] ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        
        <?php } ?>
    </div>
</div>