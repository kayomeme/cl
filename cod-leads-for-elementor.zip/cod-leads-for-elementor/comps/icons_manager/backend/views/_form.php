<?php
/**
 * Reusable Icon Form PARTIAL (_form.php)
 * Contains only the <form> element and its contents.
 *
 * It expects two variables to be available before being included:
 * @var bool   $isEditing  - True if in 'edit' mode, false if in 'add' mode.
 * @var object $iconData   - The icon data object.
 */
?>
<form class="edit-icon-form" method="POST" action="">
    <!-- Main Content -->
    <div class="edit-icon__main">
        <div class="edit-icon__section">
            <div class="cl-group">
                <label><?= Lang_cl::__('Icon Name', 'cl') ?></label>
                <input type="text" name="name" value="<?= esc_attr($iconData->name) ?>" required <?= ($isEditing && $iconData->is_system == 'yes') ? 'readonly' : '' ?>>
                <?php if ($isEditing && $iconData->is_system == 'yes'): ?>
                    <div class="cl-alert cl-alert-warning"><?= Lang_cl::__('System icon names cannot be changed.', 'cl') ?></div>
                <?php endif; ?>
            </div>

            <div class="form-row-flex">
                <div class="cl-group cl-group--flex">
                    <label><?= Lang_cl::__('Icon Type', 'cl') ?></label>
                    <select name="type" class="cl-select" id="icon-type-select">
                        <option value="svg" <?= selected($iconData->type, 'svg', false) ?>><?= Lang_cl::__('SVG', 'cl') ?></option>
                    </select>
                </div>

                <div class="cl-group cl-group--flex">
                    <label><?= Lang_cl::__('Is Active', 'cl') ?></label>
                    <select name="is_active" class="cl-select">
                        <option value="yes" <?= selected($iconData->is_active, 'yes', false) ?>><?= Lang_cl::__('Yes', 'cl') ?></option>
                        <option value="no" <?= selected($iconData->is_active, 'no', false) ?>><?= Lang_cl::__('No', 'cl') ?></option>
                    </select>
                </div>

                <?php if (!$isEditing || ($isEditing && $iconData->is_system !== 'yes')): ?>
                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Is System', 'cl') ?></label>
                        <select name="is_system" class="cl-select">
                            <option value="no" <?= selected($iconData->is_system, 'no', false) ?>><?= Lang_cl::__('No', 'cl') ?></option>
                            <option value="yes" <?= selected($iconData->is_system, 'yes', false) ?>><?= Lang_cl::__('Yes', 'cl') ?></option>
                        </select>
                    </div>
                <?php else: ?>
                    <input type="hidden" name="is_system" value="yes">
                <?php endif; ?>
            </div>

            <div class="cl-group svg-code-container">
                <label><?= Lang_cl::__('SVG Code', 'cl') ?></label>
                <textarea name="code" rows="10" required><?= $isEditing ? esc_textarea(IconsUtilBK_cl::getCompleteSvg($iconData->code, $iconData->view_box, $iconData->fill)) : '' ?></textarea>
                

            </div>


        </div>
        <div class="edit-icon_help-preview">
            <div class="cl-group svg-preview-container">
                <label><?= Lang_cl::__('Preview', 'cl') ?></label>
                <div id="icon-preview" class="icon-preview">
                    <?php if ($isEditing && $iconData->type === 'svg'): ?>
                        <?= IconsUtilBK_cl::getCompleteSvg($iconData->code, $iconData->view_box, $iconData->fill) ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="cl-alert cl-alert-info">
                <?= Lang_cl::__('You can paste the full &lt;svg&gt; code here. The system will automatically extract the necessary parts.', 'cl') ?>
                <div style="margin-top: 8px;">
                    <strong><?= Lang_cl::__('Free SVG Icon Resources:', 'cl') ?></strong>
                    <div style="margin-top: 5px; line-height: 1.6;">
                        <a href="https://fontawesome.com/icons?d=gallery&p=2&s=brands,solid&m=free" target="_blank" style="display: block; margin-bottom: 3px;">
                            <?= Lang_cl::__('• Font Awesome - Popular free icon library', 'cl') ?>
                        </a>
                        <a href="https://fonts.google.com/icons" target="_blank" style="display: block; margin-bottom: 3px;">
                            <?= Lang_cl::__('• Google Icons - Material Design icons collection', 'cl') ?>
                        </a>
                        <a href="https://lucide.dev/icons/" target="_blank" style="display: block; margin-bottom: 3px;">
                            <?= Lang_cl::__('• Lucide Icons - Beautiful customizable SVG icons', 'cl') ?>
                        </a>
                        <a href="https://tabler-icons.io/" target="_blank" style="display: block; margin-bottom: 3px;">
                            <?= Lang_cl::__('• Tabler Icons - 4000+ free SVG icons', 'cl') ?>
                        </a>
                    </div>
                    <small style="display: block; margin-top: 8px; opacity: 0.8;">
                        <?= Lang_cl::__('All resources above offer completely free SVG icons with permissive licenses.', 'cl') ?>
                    </small>
                </div>
            </div>
                <div class="cl-alert cl-alert-info">
                    <strong>📌 <?= Lang_cl::__('Important Tips for Best Results:', 'cl') ?></strong>
                    <ul style="margin: 5px 0 0 20px; padding: 0; list-style-type: disc;">
                        <li><?= Lang_cl::__('Ensure the SVG uses a `viewBox` (e.g., `viewBox="0 0 24 24"`).', 'cl') ?></li>
                        <li><?= Lang_cl::__('Avoid SVGs with fixed `width` and `height` attributes for better scaling.', 'cl') ?></li>
                    </ul>
                </div>
        </div>
    </div>

    <!-- Actions -->
    <div id="cl-sticky-bottom-bar">
        <div class="cl-container">
            <div class="edit-icon__actions">
                <?php if ($isEditing): ?>
                    <input type="hidden" name="id" value="<?= $iconData->id ?>" cl-ischanged="yes">
                <?php endif; ?>
                <button id="<?= $isEditing ? 'save-update-icon' : 'save-new-icon' ?>" type="submit" class="cl-button button button-primary">
                    <?= $isEditing ? Lang_cl::__('Update Icon', 'cl') : Lang_cl::__('Add Icon', 'cl') ?>
                </button>
                <a href="<?= admin_url('admin.php?page=cl_icons') ?>" class="button button-secondary">
                    <?= Lang_cl::__('Cancel', 'cl') ?>
                </a>
            </div>
            <div class="cl-user-fedback">
                <div class="cl-msg_box"><div class="cl-wait_msg"></div><div class="alert"></div></div>
            </div>
        </div>
    </div>
</form>