<div id="cl_addnew_icon" class="edit-icon__wrapper">
    <div class="edit-icon__header">
        <h2><?= Lang_cl::__('Add New Icon', 'cl') ?></h2>
    </div>

    <?php
    // Set up variables for the reusable form in "Add New" mode
    $isEditing = false;
    $iconData = (object) [
        'name'      => '',
        'type'      => 'svg',
        'is_active' => 'yes',
        'is_system' => 'no',
        'code'      => '',
        'view_box'  => '0 0 24 24',
        'fill'      => 'currentColor'
    ];

    // Include the reusable form partial
    include '_form.php';
    ?>
</div>