<div id="cl_update_icon" class="edit-icon__wrapper">
    <div class="edit-icon__header">
        <h2><?= Lang_cl::__('Edit Icon:', 'cl') . ' ' . esc_html($iconData->name) ?></h2>
    </div>
    
    <?php
    // Set up the mode for the reusable form.
    $isEditing = true;
    // The `$iconData` variable is already provided by the controller.

    // Include the reusable form partial
    include '_form.php';
    ?>
</div>