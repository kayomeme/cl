<div class="icons-manager-wrapper">
    <div class="cl-header-tab">
        <div class="cl-title-tab">
            <?= Lang_cl::_e('Icons Manager', 'cl') ?>
        </div>
        <a href="<?= admin_url('admin.php?page=cl_icons&action=addnew') ?>" class="cl-button cl-addnew">
            <span class="dashicons dashicons-plus"></span>
            <?= Lang_cl::_e('Add New Icon', 'cl') ?>
        </a>
    </div>
    
    <!-- Listing section -->
    <div id="icon-list-container">
        <?php if (empty($iconItems)): ?>
            <div class="icon-empty-state">
                <p><?= Lang_cl::__('No icons found. Click "Add New Icon" to create one.', 'cl') ?></p>
            </div>
        <?php else: ?>
            <div class="icon-items">
                <?php foreach ($iconItems as $icon): ?>
                    <div id="icon-<?= $icon->id ?>" class="icon-item <?= $icon->is_active == 'yes' ? 'icon-active' : 'icon-inactive' ?> <?= $icon->is_system == 'yes' ? 'icon-system' : '' ?>">
                        <div class="icon-item__header">
                            <h3 class="icon-item__title">
                                <?= $icon->name ?>
                                <?php if ($icon->is_system === 'yes'): ?>
                                    <span class="icon-system-badge"><?= Lang_cl::__('System', 'cl') ?></span>
                                <?php endif; ?>
                            </h3>
                            
                            <div class="icon-item__type-id">
                                <span class="icon-type-badge"><?= strtoupper($icon->type) ?></span>
                            </div>
                        </div>
                        
                        <div class="icon-item__preview">
                            <?php if ($icon->type === 'svg'): ?>
                                <?= IconsUtilBK_cl::getCompleteSvg($icon->code, $icon->view_box, $icon->fill) ?>
                            <?php endif; ?>
                        </div>
                        
                        <div class="icon-item__footer">
                           <div class="icon-item__status">
                                <span class="<?= $icon->is_active == 'yes' ? 'status-active' : 'status-inactive' ?>">
                                    <?= $icon->is_active == 'yes' ? Lang_cl::__('Active', 'cl') : Lang_cl::__('Inactive', 'cl') ?>
                                </span>
                            </div>
                            <div>
                                <a href="<?= admin_url('admin.php?page=cl_icons&action=edit&icon_id=' . $icon->id) ?>" class="button button-small">
                                    <span class="dashicons dashicons-edit"></span>
                                    <?= Lang_cl::__('Edit', 'cl') ?>
                                </a>
                                <?php if ($icon->is_system !== 'yes'): ?>
                            <button class="button button-small button-link-delete save-delete-icon" icon_id="<?= $icon->id ?>" title=" <?= Lang_cl::__('Delete', 'cl') ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Delete confirmation hidden form -->
    <div id="cl_delete_icon">
        <div id="cl-sticky-bottom-bar">
            <div class="cl-container">
                <input type="hidden" name="icon_id" cl-ischanged="yes">
                <div class="cl-user-fedback">
                    <div class="cl-msg_box">
                        <div class="cl-wait_msg"></div>
                        <div class="alert"></div>
                    </div>
                </div>
            </div>        
        </div>
    </div>
</div>