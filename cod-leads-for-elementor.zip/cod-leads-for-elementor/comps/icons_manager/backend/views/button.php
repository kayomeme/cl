<div class="cl-icon-container">
    <input type="hidden" class="cl-icon-input" name="<?= isset($args['name']) ? $args['name'] : '' ?>" value="<?= isset($args['value']) ? $args['value'] : '' ?>">
    <button class="cl_select_icon_bt"  <?= $iconIdAttr ?> >
        <span><?= $buttonText ?></span>
        <span class="cl_icon_viewer" <?= $iconIdAttr ?>></span>
    </button>
</div>
