<?php

/**
 * Controller for managing icons
 */
class IconsControllerBK_cl {

    /*
     * Ajax Routes
     */
    public static function routes($action, $args) {
        $response = false;
        switch ($action) {
            case 'cl_update_icon':
                $response = self::saveUpdate($args);
                break;
            case 'cl_addnew_icon':
                $response = self::saveAddNew($args);
                break;
            case 'cl_delete_icon':
                $response = self::deleteItem($args);
                break;
        }

        return $response;
    }

    /*
     * HTTP Routes
     */
    public function index() {
        $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 'list';
        switch ($action) {
            case 'edit':
                self::editIndex();
                break;
            case 'addnew':
                self::addNewIndex();
                break;
            case 'list':
                self::listIndex();
                break;
        }
    }
    
    /**
     * Display the add new icon form
     */
    public static function addNewIndex() {
        include MainApp_cl::$compsPath.'icons_manager/backend/views/addNewIndex.php';
    }
    
    /**
     * Handle adding a new icon
     */
    public static function saveAddNew($args) {
        $response = IconsModelBK_cl::addNew($args);
        
        if ($response->code == 1 && isset($response->res['insert_id'])) {
            $response->res['redirect_to'] = admin_url('admin.php?page=cl_icons&action=edit&icon_id='.$response->res['insert_id']);
        }
        
        return $response;
    }
    
    /**
     * Display the edit icon form
     */
    public static function editIndex() {
        $iconId = isset($_GET['icon_id']) ? intval($_GET['icon_id']) : 0;
        if (!$iconId) {
            wp_die(Lang_cl::__('Invalid icon ID', 'cl'));
        }

        // Get icon for edit
        $response = IconsModelBK_cl::getSingle($iconId);
        if ($response->code === 0) {
            wp_die($response->msg);
        }

        $iconData = $response->res;
        
        include MainApp_cl::$compsPath.'icons_manager/backend/views/editIndex.php';
    }
    
    /**
     * Handle updating an existing icon
     */
    public static function saveUpdate($args) {
        $iconId = isset($args['id']) && $args['id'] > 0 ? $args['id'] : false;
        
        if (!$iconId) {
            return response_cl(0, Lang_cl::__('Invalid icon ID', 'cl'), null);
        }
        
        if( $args['type'] == 'svg' && !IconsUtilBK_cl::isValidSvgCode($args['code']) ) {
            return response_cl(0, Lang_cl::__('Invalid svg code', 'cl'), null);
        }
        
        $response = IconsModelBK_cl::update($iconId, $args);
        return $response;
    }
    
    /**
     * Display the icons listing
     */
    public static function listIndex() {
        $currentUrl = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
        $limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 50;
        $iconItems = IconsModelBK_cl::getAll($limit);
        
        include MainApp_cl::$compsPath.'icons_manager/backend/views/listIndex.php';
    }
    
    /**
     * Handle deleting an icon
     */
    public static function deleteItem($args) {
        $response = IconsModelBK_cl::delete($args['icon_id']);
        return $response;
    }
}