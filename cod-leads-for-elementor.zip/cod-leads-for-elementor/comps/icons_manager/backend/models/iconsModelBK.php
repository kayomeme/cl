<?php
class IconsModelBK_cl {
    private static $tableName = 'icons';
    private static $optionName = 'cl_icons_svg'; // Option to store active icons
        
    private static $tableColumns = [
        'id', 'is_active', 'is_system', 'name', 'type', 'code', 'view_box', 'fill',
        'date_created_gmt', 'date_updated_gmt'
    ];
    
    private static $requiredColumns = [
        'name', 'code'
    ];
    
    /**
     * Get all icons from the database
     */
    public static function getAll($limit = null) {
        if (!$limit) {
            $limit = 100;  
        }
        $query = "SELECT * FROM table_name ORDER BY date_updated_gmt desc LIMIT {$limit}";
        $result = adminDB_cl::getResultsAsObjects(self::$tableName, $query);
        return $result;
    }

    /**
     * Add a new icon to the database
     */
    public static function addNew($args) {
        foreach (self::$requiredColumns as $fieldName) {
            if (!isset($args[$fieldName]) || empty($args[$fieldName])) {
                return response_cl(0, Lang_cl::__($fieldName, 'cl').Lang_cl::__(' is required', 'cl'), null);
            }
        }
        
        // Extract path data from full SVG code if SVG type
        if ($args['type'] === 'svg') {
            $svgAttrs = IconsUtilBK_cl::getSvgAttributes($args['code']);
            
            $pathData = IconsUtilBK_cl::extractPathData($args['code']);
            if (!$pathData) {
                return response_cl(0, Lang_cl::__('Invalid SVG code. Please ensure it contains valid SVG markup.', 'cl'), null);
            }
            
            // Store only the path data
            $args['code'] = $pathData;
            
            $args = array_merge($args, $svgAttrs);
        }
        
        $dataToAdd = [];
        foreach (self::$tableColumns as $fieldName) {
            if (isset($args[$fieldName])) {
                $dataToAdd[$fieldName] = $args[$fieldName];
            }
        }
       
        
        if (!isset($dataToAdd['date_created_gmt'])) {
            $dataToAdd['date_created_gmt'] = current_time('mysql', true);
        }
        
        $response = adminDB_cl::insert(self::$tableName, $dataToAdd);
        
        // Update the WordPress option for active icons
        if ($response->code == 1) {
            self::updateActiveIconsOption();
        }
        
        return $response;
    }
    
    /**
     * Get a single icon by ID
     */
    public static function getSingle($id) {
        $response = adminDB_cl::getSingleById(self::$tableName, $id);
        return $response;
    }
    
    /**
     * Update an existing icon
     */
    public static function update($iconId, $args) {
        // Check if this is a system icon
        $iconData = adminDB_cl::getSingleById(self::$tableName, $iconId);
        if ($iconData->code !== 1) {
            return response_cl(0, Lang_cl::__('Icon not found', 'cl'), null);
        }
        
        // If it's a system icon, prevent changing certain fields
        if ($iconData->res->is_system === 'yes') {
            // Can't change the name or system status
            if (isset($args['name']) && $args['name'] !== $iconData->res->name) {
                return response_cl(0, Lang_cl::__('Cannot change the name of a system icon', 'cl'), null);
            }
            
            if (isset($args['is_system']) && $args['is_system'] !== 'yes') {
                return response_cl(0, Lang_cl::__('Cannot change system status of a system icon', 'cl'), null);
            }
            
            // Ensure is_system remains yes
            $args['is_system'] = 'yes';
        }

        // Extract path data if SVG code is provided for SVG type
        if (isset($args['code']) && !empty($args['code']) && (($args['type'] ?? $iconData->res->type) === 'svg')) {

            $pathData = IconsUtilBK_cl::extractPathData($args['code']);
            if (!$pathData) {
                return response_cl(0, Lang_cl::__('Invalid SVG code. Please ensure it contains valid SVG markup.', 'cl'), null);
            }
            
            $svgAttrs = IconsUtilBK_cl::getSvgAttributes($args['code']);
            
            $args['code'] = $pathData;
            $args = array_merge($args, $svgAttrs);
        }
        
        $dataToUpdate = [];
        foreach (self::$tableColumns as $columnName) {
            if (isset($args[$columnName])) {
                $dataToUpdate[$columnName] = $args[$columnName];
            }
        }
        
        // Always update the modified timestamp
        $dataToUpdate['date_updated_gmt'] = current_time('mysql', true);
        
        $where = [
            'id' => $iconId,
        ];
        
        $response = adminDB_cl::update(self::$tableName, $dataToUpdate, $where);
        
        // Update the WordPress option for active icons
        if ($response->code == 1) {
            self::updateActiveIconsOption();
        }
        
        return $response;
    }
    
    /**
     * Delete an icon by ID
     */
    public static function delete($iconId) {
        // Check if this is a system icon
        $iconData = adminDB_cl::getSingleById(self::$tableName, $iconId);
        if ($iconData->code !== 1) {
            return response_cl(0, Lang_cl::__('Icon not found', 'cl'), null);
        }
        
        // Prevent deletion of system icons
        if ($iconData->res->is_system === 'yes') {
            return response_cl(0, Lang_cl::__('System icons cannot be deleted', 'cl'), null);
        }
        
        $where = [
            'id' => $iconId
        ];
        $response = adminDB_cl::delete(self::$tableName, $where);
        
        // Update the WordPress option for active icons
        if ($response->code == 1) {
            self::updateActiveIconsOption();
        }
        
        return $response;
    }

    /**
     * Update WordPress option with all active icons
     */
    public static function updateActiveIconsOption() {
        // Get all active icons
        $query = "SELECT id, name, type, code, view_box, fill FROM table_name WHERE is_active = 'yes'";
        $activeIcons = adminDB_cl::getResultsAsObjects(self::$tableName, $query);
        
        // Create an array with ID as key and icon data as value
        $iconCollection = [];
        foreach ($activeIcons as $icon) {
            $iconCollection[$icon->id] = [
                'name' => $icon->name,
                'type' => $icon->type,
                'view_box' => $icon->view_box,
                'fill' => $icon->fill,
                'code' => $icon->code,
            ];
        }
        
        // Update the WordPress option
        update_option(self::$optionName, $iconCollection, 'no');
        
        return true;
    }
}