<?php

/**
 * this will be used across the plugin settings
 */
class IconsSelectorBK_cl {
    
    /**
     * Display the add new icon form
     */
    public static function getButton($args) {
        $iconIdAttr = isset($args['value']) ? 'icon_id="'.$args['value'].'"' : "";
        //$attachedSelectorAttr = isset($args['attached_selector']) ? 'attached_selector="'.$args['attached_selector'].'"' : 'attached_selector="input[name=\''.$args['name'].'\']"';
        $buttonText = isset($args['bt_text']) ? $args['bt_text'] : Lang_cl::__('Select an icon', 'cl');

        include MainApp_cl::$compsPath.'icons_manager/backend/views/button.php';
    }
    
    /*
     * will be used in icons_manager\backend\hooks\admin_footer.php
     */
    public static function getModal($args) {
        $icons = get_option('cl_icons_svg', []);
        include MainApp_cl::$compsPath.'icons_manager/backend/views/icons_modal.php';
    }
}