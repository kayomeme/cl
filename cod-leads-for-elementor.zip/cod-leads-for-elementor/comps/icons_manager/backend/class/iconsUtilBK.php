<?php

class IconsUtilBK_cl {

    // Default SVG wrapper with fewer hardcoded attributes for more flexibility
    private static $svgWrapper = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="%s" fill="%s">%s</svg>';

    /**
     * Get a complete SVG with wrapper
     * @param string $pathData The SVG path data
     * @param string $viewBox The viewBox attribute
     * @param string $fill The fill attribute
     * @return string Complete SVG code
     */
    public static function getCompleteSvg($pathData, $viewBox, $fill) {
        $cleanedPath = self::cleanSvgPath($pathData);
        return sprintf(self::$svgWrapper, $viewBox, $fill, $cleanedPath);
    }

    /**
     * Extracts viewBox and fill attributes from the main <svg> tag.
     * @param string $svgCode The SVG markup to parse
     * @return array An array with 'view_box' and 'fill' attributes
     */
    public static function getSvgAttributes($svgCode) {
        $attributes = [
            'view_box' => '0 0 24 24',
            'fill' => 'currentColor' // Default for solid icons
        ];
        $svgCode = stripslashes($svgCode);

        // Extract viewBox value
        if (preg_match('/viewBox\s*=\s*["\']([^"\']*)["\']/i', $svgCode, $viewBoxMatches)) {
            $attributes['view_box'] = $viewBoxMatches[1];
        }

        // Extract fill value from the main <svg> tag
        if (preg_match('/<svg[^>]+fill\s*=\s*["\']([^"\']*)["\']/i', $svgCode, $fillMatches)) {
            if (strtolower($fillMatches[1]) === 'none') {
                $attributes['fill'] = 'none'; // Set to none if explicitly defined on the SVG tag
            }
        }
        
        return $attributes;
    }

    /**
     * Extracts the raw inner content from an SVG string.
     * This version is non-destructive to the inner paths and their attributes.
     *
     * @param string $svgCode The SVG code.
     * @return string|false The inner content, or false on failure.
     */
    public static function extractPathData($svgCode) {
        // If it's already just path data (no svg tag), return it as is.
        if (strpos($svgCode, '<svg') === false) {
            return $svgCode;
        }

        // Use a non-greedy regex to capture everything between the first > and the last </svg>
        if (preg_match('/<svg[^>]*>(.*?)<\/svg>/is', $svgCode, $matches)) {
            // Remove comments from the inner content for cleanliness
            $innerContent = preg_replace('/<!--.*?-->/s', '', $matches[1]);
            return trim($innerContent);
        }

        return false;
    }

    /**
     * Validates if the input is proper SVG code
     * @param string $svgCode The code to validate
     * @return bool True if valid SVG, false otherwise
     */
    public static function isValidSvgCode($svgCode) {
        if (!preg_match('/<svg[^>]*>.*<\/svg>/is', $svgCode)) {
            return false;
        }
        return true;
    }

    /**
     * Clean SVG path data by removing escaped quotes
     */
    public static function cleanSvgPath($pathData) {
        $cleanedPath = str_replace('\"', '"', $pathData);
        $cleanedPath = str_replace('\\', '', $cleanedPath);
        return $cleanedPath;
    }
}