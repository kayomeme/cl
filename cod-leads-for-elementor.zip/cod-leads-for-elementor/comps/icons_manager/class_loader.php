<?php
$dirPath = plugin_dir_path( __FILE__ );
if( $isAdminAria ) {    
    require_once $dirPath  . 'backend/class/iconsSelectorBK.php';
    require_once $dirPath  . 'backend/class/iconsUtilBK.php';
    
    require_once $dirPath  . 'backend/controllers/iconsControllerBK.php';
    
    if( IsInCurrentPages(['cl_icons']) ) {
        require_once $dirPath  . 'backend/models/iconsModelBK.php';
    }
}
if($isPublicAria) {
    require_once $dirPath  . 'frontend/controllers/iconsSelectorFR.php';
    require_once $dirPath  . 'frontend/models/iconsModelFR.php';
}