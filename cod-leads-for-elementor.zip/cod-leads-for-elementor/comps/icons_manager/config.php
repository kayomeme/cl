<?php

/**
 * general
 */
return array(
    'setting' => [

    ],
    'lang' => [

    ],
    'style' => [
        
    ]
    );
