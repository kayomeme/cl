<?php
class IconsModelFR_cl {
    private static $tableName = 'Icons';
   
    
}