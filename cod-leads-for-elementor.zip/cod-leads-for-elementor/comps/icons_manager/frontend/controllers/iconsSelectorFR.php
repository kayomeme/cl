<?php
/**
 * IconsSelectorFR_cl Class
 * 
 * Manages SVG icons with support for custom viewBox and fill attributes
 */
class IconsSelectorFR_cl {
    /**
     * @var array $icons Storage for icon data
     */
    public $icons = [];
    
    /**
     * @var string $svgWrapper SVG template for rendering icons
     */
    private $svgWrapper = '<span class="cl-icon %s"><svg xmlns="http://www.w3.org/2000/svg" viewBox="%s" fill="%s">%s</svg></span>';
    
    /**
     * Constructor - loads icons from options
     */
    public function __construct() {
        $icons = get_option('cl_icons_svg');
        
        if ($icons) {
            $this->icons = $icons;
        }
    }
    
    /**
     * Get the complete SVG code for an icon by ID
     * 
     * @param string $iconID The icon identifier
     * @param array|null $args Optional arguments like 'class'
     * @return string|null Complete SVG code or null if icon not found
     */
    public function getIconCode($iconID, $args = null) {
        if (isset($this->icons[$iconID])) {
            $icon = $this->icons[$iconID];
            $className = isset( $args['class'] ) ? $args['class'] : '';
            return $this->getCompleteSvg($className, $icon['code'], $icon['view_box'], $icon['fill']);
        }
        return null;
    }
    
    /**
     * Generate complete SVG with the specified path data, viewBox and fill
     * 
     * @param string $className Custom CSS class for the wrapper span
     * @param string $pathData The SVG path data
     * @param string $viewBox The viewBox attribute
     * @param string $fill The fill attribute
     * @return string Complete SVG code
     */
    private function getCompleteSvg($className, $pathData, $viewBox, $fill) {
        // Clean the path data first
        $cleanedPath = $this->cleanSvgPath($pathData);
        
        // Format the SVG with the provided parameters
        return sprintf($this->svgWrapper, $className, $viewBox, $fill, $cleanedPath);
    }
    
    /**
     * Clean SVG path data by removing escaped quotes and backslashes
     * 
     * @param string $pathData The SVG path data to clean
     * @return string Cleaned path data
     */
    private function cleanSvgPath($pathData) {
        // Remove escaped quotes
        $cleanedPath = str_replace('\"', '"', $pathData);
        $cleanedPath = str_replace('\\', '', $cleanedPath);
        
        return $cleanedPath;
    }

}