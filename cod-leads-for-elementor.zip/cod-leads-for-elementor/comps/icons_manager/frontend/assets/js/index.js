(function( $ ) {
	'use strict'; 
})( jQuery );