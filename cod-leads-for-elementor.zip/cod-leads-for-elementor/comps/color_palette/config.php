<?php
/**
 * Configuration for the Color Palette component's settings model.
 */

// Default colors extracted from the seed data.
$default_palette_json = '[
    {"name":"txt-color1","code":"#111827","title":"Primary Text Color","category":"txt-color"},
    {"name":"txt-color2","code":"#4B5563","title":"Secondary Text Color","category":"txt-color"},
    {"name":"txt-color3","code":"#9CA3AF","title":"Muted Text Color","category":"txt-color"},
    {"name":"txt-color4","code":"#2563EB","title":"Link Text Color","category":"txt-color"},
    {"name":"bg-color1","code":"#FFFFFF","title":"Main Background","category":"bg-color"},
    {"name":"bg-color2","code":"#F9FAFB","title":"Section Background","category":"bg-color"},
    {"name":"bg-color3","code":"#F3F4F6","title":"Card Background","category":"bg-color"},
    {"name":"bg-color4","code":"#E5E7EB","title":"Accent Background","category":"bg-color"},
    {"name":"border-color1","code":"#E5E7EB","title":"Light Border","category":"border-color"},
    {"name":"border-color2","code":"#D1D5DB","title":"Medium Border","category":"border-color"},
    {"name":"border-color3","code":"#9CA3AF","title":"Dark Border","category":"border-color"},
    {"name":"border-color4","code":"#2563EB","title":"Accent Border","category":"border-color"},
    {"name":"shadow-color1","code":"#000000","title":"Deep Shadow","category":"shadow-color"},
    {"name":"shadow-color2","code":"#374151","title":"Medium Shadow","category":"shadow-color"},
    {"name":"shadow-color3","code":"#6B7280","title":"Light Shadow","category":"shadow-color"},
    {"name":"shadow-color4","code":"#9CA3AF","title":"Subtle Shadow","category":"shadow-color"}
]';

return array(
    'setting' => [
        // This setting stores the master JSON configuration for the palette.
        // It is managed separately from the live CRUD table.
        'palette_config_json' => $default_palette_json,
    ],
    'lang' => [],
    'style' => []
);