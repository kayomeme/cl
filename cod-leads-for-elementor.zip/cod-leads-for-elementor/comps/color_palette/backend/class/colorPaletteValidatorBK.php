<?php

/**
 * Validator class for Color Palette operations
 */
class ColorPaletteValidatorBK_cl {
    
    private static $validCategories = ['txt-color', 'bg-color', 'border-color', 'shadow-color'];
    private static $requiredFields = ['title', 'code', 'category'];
    
    /**
     * Validate data for adding new color
     */
    public static function validateAddNew($args) {
        // Validate required fields
        $requiredValidation = self::validateRequiredFields($args);
        if ($requiredValidation->code != 1) {
            return $requiredValidation;
        }
        
        // Validate and sanitize inputs
        $sanitizedArgs = self::sanitizeInputs($args);
        
        // Validate color code format
        $colorCodeValidation = self::validateColorCode($sanitizedArgs['code']);
        if ($colorCodeValidation->code != 1) {
            return $colorCodeValidation;
        }
        
        // Validate category
        $categoryValidation = self::validateCategory($sanitizedArgs['category']);
        if ($categoryValidation->code != 1) {
            return $categoryValidation;
        }
        
        // Check for duplicate color
        $duplicateValidation = self::validateDuplicate($sanitizedArgs['code'], $sanitizedArgs['category'], $sanitizedArgs['settings_model_id'] ?? 0);
        if ($duplicateValidation->code != 1) {
            return $duplicateValidation;
        }
        
        return response_cl(1, Lang_cl::__('Validation passed', 'cl'), $sanitizedArgs);
    }
    
    /**
     * Validate data for updating color
     */
    public static function validateUpdate($args) {
        // Validate color ID
        $idValidation = self::validateColorId($args);
        if ($idValidation->code != 1) {
            return $idValidation;
        }
        
        // Validate required fields
        $requiredValidation = self::validateRequiredFields($args);
        if ($requiredValidation->code != 1) {
            return $requiredValidation;
        }
        
        // Validate and sanitize inputs
        $sanitizedArgs = self::sanitizeInputs($args);
        
        // Validate color code format
        $colorCodeValidation = self::validateColorCode($sanitizedArgs['code']);
        if ($colorCodeValidation->code != 1) {
            return $colorCodeValidation;
        }
        
        // Validate category
        $categoryValidation = self::validateCategory($sanitizedArgs['category']);
        if ($categoryValidation->code != 1) {
            return $categoryValidation;
        }
        
        // Check for duplicate color (excluding current color)
        $duplicateValidation = self::validateDuplicateForUpdate($sanitizedArgs['code'], $sanitizedArgs['category'], $sanitizedArgs['id'], $sanitizedArgs['settings_model_id'] ?? 0);
        if ($duplicateValidation->code != 1) {
            return $duplicateValidation;
        }
        
        return response_cl(1, Lang_cl::__('Validation passed', 'cl'), $sanitizedArgs);
    }
    
    /**
     * Validate data for deleting color
     */
    public static function validateDelete($args) {
        // Validate color ID from color_id field
        if (!isset($args['color_id']) || empty($args['color_id'])) {
            return response_cl(0, Lang_cl::__('Color ID is required for deletion', 'cl'), null);
        }

        $colorId = intval($args['color_id']);
        if ($colorId <= 0) {
            return response_cl(0, Lang_cl::__('Invalid color ID provided', 'cl'), null);
        }

        // Check if color exists using model
        $existingColor = ColorPaletteModelBK_cl::getSingle($colorId);
        if (!$existingColor || $existingColor->code != 1) {
            return response_cl(0, Lang_cl::__('Color not found', 'cl'), null);
        }

        // Check if it's a system color
        if (isset($existingColor->res->is_system) && $existingColor->res->is_system === 'yes') {
            return response_cl(0, Lang_cl::__('System colors cannot be deleted', 'cl'), null);
        }
        
        return response_cl(1, Lang_cl::__('Validation passed', 'cl'), ['color_id' => $colorId]);
    }
    
    /**
     * Validate data for getting category colors
     */
    public static function validateGetCategoryColors($args) {
        if (!isset($args['category']) || empty($args['category'])) {
            return response_cl(0, Lang_cl::__('Category is required', 'cl'), null);
        }
        
        // Validate category
        $categoryValidation = self::validateCategory($args['category']);
        if ($categoryValidation->code != 1) {
            return $categoryValidation;
        }
        
        $sanitizedArgs = [
            'category' => sanitize_text_field($args['category']),
            'settings_model_id' => isset($args['settings_model_id']) ? intval($args['settings_model_id']) : 0
        ];
        
        return response_cl(1, Lang_cl::__('Validation passed', 'cl'), $sanitizedArgs);
    }
    
    /**
     * Validate required fields
     */
    private static function validateRequiredFields($args) {
        foreach (self::$requiredFields as $field) {
            if (!isset($args[$field]) || empty(trim($args[$field]))) {
                return response_cl(0, Lang_cl::__('Please fill all required fields', 'cl'), null);
            }
        }
        return response_cl(1, Lang_cl::__('Required fields validated', 'cl'), null);
    }
    
    /**
     * Validate color ID
     */
    private static function validateColorId($args) {
        $colorId = isset($args['id']) && $args['id'] > 0 ? $args['id'] : false;
        if (!$colorId) {
            return response_cl(0, Lang_cl::__('Invalid color ID provided', 'cl'), null);
        }
        return response_cl(1, Lang_cl::__('Color ID validated', 'cl'), null);
    }
    
    /**
     * Validate color code format
     */
    private static function validateColorCode($code) {
        if (!preg_match('/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/', $code)) {
            return response_cl(0, Lang_cl::__('Please enter a valid color code (e.g., #FF0000)', 'cl'), null);
        }
        return response_cl(1, Lang_cl::__('Color code validated', 'cl'), null);
    }
    
    /**
     * Validate category
     */
    private static function validateCategory($category) {
        if (!in_array($category, self::$validCategories)) {
            return response_cl(0, Lang_cl::__('Please select a valid category', 'cl'), null);
        }
        return response_cl(1, Lang_cl::__('Category validated', 'cl'), null);
    }
    
    /**
     * Check for duplicate color (for add new)
     */
    private static function validateDuplicate($code, $category, $settingsModelId) {
        $existingColor = ColorPaletteModelBK_cl::checkExisting($code, $category, $settingsModelId);
        if ($existingColor) {
            return response_cl(0, Lang_cl::__('This color already exists in this category', 'cl'), null);
        }
        return response_cl(1, Lang_cl::__('No duplicate found', 'cl'), null);
    }
    
    /**
     * Check for duplicate color (for update - excluding current color)
     */
    private static function validateDuplicateForUpdate($code, $category, $colorId, $settingsModelId) {
        $existingColor = ColorPaletteModelBK_cl::checkExisting($code, $category, $settingsModelId);
        if ($existingColor && $existingColor->id != $colorId) {
            return response_cl(0, Lang_cl::__('This color already exists in this category', 'cl'), null);
        }
        return response_cl(1, Lang_cl::__('No duplicate found', 'cl'), null);
    }
    
    /**
     * Sanitize input data
     */
    private static function sanitizeInputs($args) {
        $sanitized = [];
        
        // Sanitize text fields
        $textFields = ['title', 'code', 'category'];
        foreach ($textFields as $field) {
            if (isset($args[$field])) {
                $sanitized[$field] = sanitize_text_field($args[$field]);
            }
        }
        
        // Sanitize numeric fields
        if (isset($args['id'])) {
            $sanitized['id'] = intval($args['id']);
        }
        
        if (isset($args['settings_model_id'])) {
            $sanitized['settings_model_id'] = intval($args['settings_model_id']);
        }
        
        // Ensure color code is uppercase
        if (isset($sanitized['code'])) {
            $sanitized['code'] = strtoupper($sanitized['code']);
        }
        
        return $sanitized;
    }
}