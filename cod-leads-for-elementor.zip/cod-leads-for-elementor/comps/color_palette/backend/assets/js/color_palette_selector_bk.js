(function ($) {

    class ColorSelector_cl {
        constructor() {
            this.init();
        }

        init() {
            this.bindEvents();
            
            // automatically create the color selector for all single css properties after the page is loaded
            this.attachColorSelectorToInputsColors('.cl-single-css-property');
        }

        attachColorSelectorToInputsColors(inContainer = '.cl-single-css-property') {
            $(inContainer).find('.cl_color').each(function(index) {
                const $wrapper = $(this).closest('div');

                // only add if not alredy exit
                if( $wrapper.find('.color-select-wrapper').length === 0 ) {
                    const newColorSelector = $('#color_selector_palette').clone(true);
                    newColorSelector.removeAttr('id');
                    $wrapper.append(newColorSelector);
                }
                
                const cssvarname = $(this).val().match(/^var\(--cl-(.+)\)$/)?.[1] || null;
                if(cssvarname) {
                    $wrapper.find(`.cl-color-option[data-colorname="${cssvarname}"]`).click();
                }
                
            });  
        }

        bindEvents() {
            // automatically create the color selector after the style modal is opening
            $(document).on('click', '.cl-bt-style', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                this.attachColorSelectorToInputsColors('#style_generator_modal');
            });
            
            
            // Color select dropdown events
            $(document).on('click', '.color-select-custom', (e) => {
                e.preventDefault();
                e.stopPropagation();

                const $wrapper = $(e.target).closest('.color-select-wrapper');
                const $menu = $wrapper.find('.color-dropdown-menu');
                const $select = $wrapper.find('.color-select-custom');

                $('.color-dropdown-menu').removeClass('show dropup');

                const selectRect = $select[0].getBoundingClientRect();
                const viewportHeight = window.innerHeight;
                const spaceBelow = viewportHeight - selectRect.bottom;
                const spaceAbove = selectRect.top;
                const dropdownHeight = 200;

                if (spaceBelow < dropdownHeight && spaceAbove > spaceBelow) {
                    $menu.addClass('dropup');
                }

                $menu.toggleClass('show');
            });

            $(document).on('click', '.cl-color-option', (e) => {
                e.stopPropagation();
                
                const $currentOption = $(e.target).closest('.cl-color-option');
                const $wrapper = $currentOption.closest('.color-select-wrapper');
                const $menu = $wrapper.find('.color-dropdown-menu');
                
                $wrapper.find('.cl-color-option').removeClass('selected');
                
                const colorId = $currentOption.data('value');
                
                $currentOption.addClass('selected');
                
                const $select = $wrapper.find('.color-select-custom');
                $select.find('.color-select-text').text(`${$currentOption.data('colorname')} (${$currentOption.data('colorcode')})`);
                $select.find('.color-select-preview').css('background-color', $currentOption.data('colorcode'));
                $select.attr('data-value', $currentOption.data('colorid'));
                
                // set the css var color in the hideen input and trigger the change event to see the chnages in the simulatot
                $wrapper.prev('input.cl_color').val(`var(--cl-${$currentOption.data('colorname')})`).change();
                
                $menu.removeClass('show dropup');
            });

            $(document).on('click', (e) => {
                if (!$(e.target).closest('.color-select-wrapper').length) {
                    $('.color-dropdown-menu').removeClass('show dropup');
                }
            });
        }
    }

    $(document).ready(function () {
        const ColorSelectorClass = new ColorSelector_cl();
    });

})(jQuery);