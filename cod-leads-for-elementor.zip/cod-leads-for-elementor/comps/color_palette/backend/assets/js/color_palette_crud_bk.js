(function ($) {

    class ColorTemplateManager {
        constructor() {
            this.init();
        }

        init() {
            this.bindEvents();
            this.syncColorPicker();
        }

        bindEvents() {
            // Modal events
            $('.btn-add-new[data-category]').on('click', (e) => {
                const category = $(e.target).data('category');
                this.openModal('add', { category: category });
            });

            $('.modal-close, .modal-overlay').on('click', (e) => {
                if (e.target === e.currentTarget) {
                    this.closeModal();
                }
            });

            // Form events
            $('#colorForm').on('submit', (e) => {
                e.preventDefault();
                this.saveColor();
            });

            $('#modalCancelBtn').on('click', () => {
                this.closeModal();
            });

            $('#colorPicker').on('change', () => {
                $('#colorCode').val($('#colorPicker').val().toUpperCase());
            });

            $('#colorCode').on('input', () => {
                const color = $('#colorCode').val();
                if (this.isValidColor(color)) {
                    $('#colorPicker').val(color);
                }
            });
        }

        // Extract color data from DOM element
        extractColorData(buttonElement) {
            const colorItem = $(buttonElement).closest('.color-item');
            return {
                id: colorItem.data('color-id'),
                category: colorItem.data('color-category'),
                code: colorItem.data('color-code'),
                title: colorItem.data('color-title')
            };
        }

        // Extract modal form data
        extractFormData() {
            return {
                id: $('#editingId').val(),
                title: $('#colorTitle').val().trim(),
                code: $('#colorCode').val().trim(),
                category: $('#colorCategory').val()
            };
        }

        loadCategoryColors(category) {
            const cl_action = 'cl_get_category_colors';
            const formData = AdminFn_cl.getFormDatas(cl_action);
            
            if (formData === false) {
                this.showNotification('Required form data missing', 'error');
                return;
            }
            
            // Add category to formData
            formData['category'] = category;
            
            AdminFn_cl.beforeSendAjaxRequest(cl_action);
            AdminFn_cl.sendAjaxRequest('cl_color_palette', cl_action, formData);
            
            document.addEventListener(cl_action + 'lastResponse', (event) => {
                if (jsArgs.lastResponse.code == 1 && jsArgs.lastResponse.res && jsArgs.lastResponse.res.items_htmlcode) {
                    $('#colorList-' + category).html(jsArgs.lastResponse.res.items_htmlcode);
                } else if (jsArgs.lastResponse.msg) {
                    this.showNotification(jsArgs.lastResponse.msg, 'error');
                }
            }, { once: true });
        }

        openModal(mode, data = {}) {
            const modal = $('#colorModal');
            const modalTitle = $('#modalTitle');
            const submitBtn = $('#modalSubmitBtn');

            this.resetForm();

            if (mode === 'add') {
                $('#colorCategory').val(data.category);
                modalTitle.text(`Add New ${this.getCategoryDisplayName(data.category)}`);
                submitBtn.text(`Add ${this.getCategoryDisplayName(data.category)}`);
                $('#editingId').val('');
            } else if (mode === 'edit') {
                modalTitle.text('Edit Color');
                submitBtn.text('Update Color');
                
                // Populate form with extracted data
                $('#editingId').val(data.id);
                $('#colorTitle').val(data.title || data.name);
                $('#colorCode').val(data.code);
                $('#colorPicker').val(data.code);
                $('#colorCategory').val(data.category);
            }

            modal.addClass('show');
            setTimeout(() => {
                $('#colorTitle').focus();
            }, 300);
        }

        closeModal() {
            $('#colorModal').removeClass('show');
            this.resetForm();
        }

        editColor(buttonElement) {
            const colorData = this.extractColorData(buttonElement);
            this.openModal('edit', colorData);
        }

        deleteColor(buttonElement) {
            const colorData = this.extractColorData(buttonElement);
            
            if (confirm(jsLang.delete_confirm_msg)) {
                const cl_action = 'cl_delete_color_palette';
                const formData = AdminFn_cl.getFormDatas(cl_action);
                
                // Add extracted data to formData
                formData['color_id'] = colorData.id;
                
                AdminFn_cl.beforeSendAjaxRequest(cl_action);
                AdminFn_cl.sendAjaxRequest('cl_color_palette', cl_action, formData);

                document.addEventListener(cl_action + 'lastResponse', (event) => {
                    if (jsArgs.lastResponse.code == 1) {
                        this.showNotification(jsArgs.lastResponse.msg, 'success');
                        this.loadCategoryColors(colorData.category);
                    } else {
                        this.showNotification(jsArgs.lastResponse.msg, 'error');
                    }
                }, { once: true });
            }
        }

        saveColor() {
            const modalData = this.extractFormData();

            const isEdit = modalData.id && modalData.id.length > 0;
            const cl_action = isEdit ? 'cl_update_color_palette' : 'cl_addnew_color_palette';
            
            // Use existing AdminFn_cl system
            const formData = AdminFn_cl.getFormDatas(cl_action);

            // Add extracted data to formData
            formData['title'] = modalData.title;
            formData['code'] = modalData.code.toUpperCase();
            formData['category'] = modalData.category;
            formData['settings_model_id'] = '0';
            
            if (isEdit) {
                formData['id'] = modalData.id;
            }

            AdminFn_cl.beforeSendAjaxRequest(cl_action);
            AdminFn_cl.sendAjaxRequest('cl_color_palette', cl_action, formData);

            document.addEventListener(cl_action + 'lastResponse', (event) => {
                if (jsArgs.lastResponse.code == 1) {
                    this.showNotification(jsArgs.lastResponse.msg, 'success');
                    this.loadCategoryColors(modalData.category);
                    this.closeModal();
                } else {
                    this.showNotification(jsArgs.lastResponse.msg, 'error');
                }
            }, { once: true });
        }

        resetForm() {
            $('#colorForm')[0].reset();
            $('#editingId').val('');
            $('#colorCategory').val('');
            $('#colorPicker').val('#0073aa');
            $('#colorCode').val('#0073aa');
        }

        syncColorPicker() {
            if ($('#colorPicker').length > 0) {
                $('#colorCode').val($('#colorPicker').val().toUpperCase());
            }
        }

        // Keep basic client-side color validation for immediate visual feedback
        isValidColor(color) {
            return /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(color);
        }

        // Simple category display helper
        getCategoryDisplayName(category) {
            const categoryNames = {
                'txt-color': 'Text Color',
                'bg-color': 'Background Color',
                'border-color': 'Border Color',
                'shadow-color': 'Shadow Color'
            };
            return categoryNames[category] || 'Color';
        }

        showNotification(message, type = 'success') {
            const notification = $('#notification');
            notification.removeClass('success error').addClass(type);
            notification.text(message).addClass('show');

            setTimeout(() => {
                notification.removeClass('show');
            }, 6000);
        }
    }

    $(document).ready(function () {
        const colorManager = new ColorTemplateManager();
        window.colorManager = colorManager;
    });

})(jQuery);