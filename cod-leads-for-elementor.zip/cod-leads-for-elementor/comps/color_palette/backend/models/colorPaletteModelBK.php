<?php
class ColorPaletteModelBK_cl {
    private static $tableName = 'color_palette';
    
    private static $tableColumns = [
        'id', 'is_active', 'name', 'code', 'title', 'category', 'is_system', 'is_used', 
        'used_count', 'settings_model_id', 'date_created_gmt', 'date_updated_gmt'
    ];

    /**
     * Synchronizes the custom color palette table from a JSON source.
     * Deletes all existing colors for the given settings model and inserts the new ones.
     *
     * @param array $colors_from_json The array of colors decoded from the JSON setting.
     * @param int $settingsModelId The ID of the settings model to sync.
     * @return bool True on success, false on failure.
     */
    public static function syncFromJson($colors_from_json, $settingsModelId) {
        global $wpdb;
        $tableName = $wpdb->prefix . self::$tableName;

        // Step 1: Delete ALL existing colors for this settings model.
        $wpdb->delete($tableName, ['settings_model_id' => $settingsModelId], ['%d']);
        
        // Step 2: Insert the new colors from the JSON array.
        foreach ($colors_from_json as $color) {
            $dataToInsert = [];
            // Ensure we only insert columns that exist in the table.
            foreach (self::$tableColumns as $column) {
                if (isset($color[$column])) {
                    $dataToInsert[$column] = $color[$column];
                }
            }
            // Ensure the settings_model_id is set correctly for this batch.
            $dataToInsert['settings_model_id'] = $settingsModelId;

            // The 'id' should not be specified during insert to allow auto-increment.
            unset($dataToInsert['id']);

            // Insert if we have data to insert.
            if (!empty($dataToInsert) && isset($dataToInsert['name'])) {
                $wpdb->insert($tableName, $dataToInsert);
            }
        }

        return true;
    }
    
    public static function getAll($settingsModelId, $limit = null) {
        if (!$limit) {
            $limit = 100;  
        }
        $query = "SELECT * FROM table_name WHERE settings_model_id = {$settingsModelId} ORDER BY category, id ASC LIMIT {$limit}";
        $result = adminDB_cl::getResultsAsObjects(self::$tableName, $query);
        return $result;
    }
    
    public static function getAllByCategory($category, $settingsModelId = 0) {
        $limit = 50;  
        $query = "SELECT * FROM table_name WHERE category = '{$category}' and settings_model_id = {$settingsModelId} ORDER BY category, id ASC LIMIT {$limit}";
        $result = adminDB_cl::getResultsAsObjects(self::$tableName, $query);
        
        return $result;
    }

    public static function addNew($args) {
        // Auto-generate name based on category
        $args['name'] = self::generateNextColorName($args['category'], $args['settings_model_id']);
        
        $dataToAdd = [];
        foreach (self::$tableColumns as $fieldName) {
            if (isset($args[$fieldName])) {
                $dataToAdd[$fieldName] = $args[$fieldName];
            }
        }
        
        $response = adminDB_cl::insert(self::$tableName, $dataToAdd);
        return $response;
    }
    
    public static function getSingle($id) {
        $response = adminDB_cl::getSingleById(self::$tableName, $id);
        return $response;
    }
    
    public static function checkExisting($code, $category, $settingsModelId = 0) {
        global $wpdb;
        $tableName = $wpdb->prefix . self::$tableName;
        
        $query = $wpdb->prepare(
            "SELECT * FROM {$tableName} WHERE code = %s AND category = %s AND settings_model_id = %d LIMIT 1",
            $code,
            $category,
            $settingsModelId
        );
        
        return $wpdb->get_row($query);
    }
    
    public static function update($colorId, $args) {
        // Note: Validation is handled by ColorPaletteValidatorBK_cl before calling this method
        
        // Don't allow manual name changes - name is auto-generated
        if (isset($args['name'])) {
            unset($args['name']);
        }
        
        $dataToUpdate = [];
        
        foreach (self::$tableColumns as $fieldName) {
            if (isset($args[$fieldName])) {
                $dataToUpdate[$fieldName] = $args[$fieldName];
            }
        }
        
        $where = [
            'id' => $colorId,
        ];
        
        $response = adminDB_cl::update(self::$tableName, $dataToUpdate, $where);
        return $response;
    }
    
    public static function delete($colorId) {
        $where = [
            'id' => $colorId
        ];
        return adminDB_cl::delete(self::$tableName, $where);
    }
    
    /**
     * Generate next color name based on category
     */
    private static function generateNextColorName($category, $settingsModelId = 0) {
        global $wpdb;
        $tableName = $wpdb->prefix . self::$tableName;
        
        // Get all colors for this category to find the highest number
        $query = $wpdb->prepare(
            "SELECT name FROM {$tableName} WHERE category = %s AND settings_model_id = %d",
            $category,
            $settingsModelId
        );
        
        $results = $wpdb->get_col($query);
        
        $maxNumber = 0;
        $categoryPrefix = $category;
        
        // Extract numbers from existing names
        foreach ($results as $name) {
            if (preg_match("/^{$categoryPrefix}(\d+)$/", $name, $matches)) {
                $number = intval($matches[1]);
                if ($number > $maxNumber) {
                    $maxNumber = $number;
                }
            }
        }
        
        // Return next number
        return $categoryPrefix . ($maxNumber + 1);
    }
    
    /**
     * Update the used_count for all colors based on their usage in component CSS options
     * 
     * @param int $settingsModelId The settings model ID to check (default: 0)
     * @return array Summary of updated counts
     */
    public static function updateUsedCounts($settingsModelId = 0) {
        // Get all colors for this settings model
        $colors = self::getAll($settingsModelId);
        
        if (empty($colors)) {
            return ['message' => 'No colors found', 'updated' => 0];
        }
        
        // Get component names from MainApp_cl
        $componentNames = MainApp_cl::$compsNames;
        $updatedCount = 0;
        
        // Loop through each color
        foreach ($colors as $color) {
            $totalUsage = 0;
            
            // Count usage across all components for this color
            foreach ($componentNames as $componentName) {
                $optionName = "cl_{$componentName}_generated_css_{$settingsModelId}";
                $cssContent = get_option($optionName, '');
                
                if (!empty($cssContent)) {
                    $searchPattern = "--cl-{$color->name}";
                    $count = substr_count($cssContent, $searchPattern);
                    $totalUsage += $count;
                }
            }
            
            // Update the count for this color using its ID
            $updateData = [
                'used_count' => $totalUsage,
                'date_updated_gmt' => current_time('mysql', true)
            ];
            
            $where = ['id' => $color->id];
            $updateResult = adminDB_cl::update(self::$tableName, $updateData, $where);
            
            if ($updateResult && $updateResult->code == 1) {
                $updatedCount++;
            }
        }
        
        return [
            'message' => "Updated usage counts for {$updatedCount} colors",
            'updated' => $updatedCount,
            'total_colors' => count($colors)
        ];
    }
    
}