<?php

include MainApp_cl::$compsPath.'color_palette/backend/views/crud/color_selector_box_to_clone.php';
