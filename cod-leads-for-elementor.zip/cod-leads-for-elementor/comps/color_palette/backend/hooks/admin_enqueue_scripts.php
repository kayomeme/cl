<?php

wp_enqueue_style('color_palette_selector_bk_css', MainApp_cl::$compsUrl.'color_palette/backend/assets/css/color_palette_selector_bk.css', [], $assetsVersion);
wp_enqueue_script('color_palette_selector_bk_js', MainApp_cl::$compsUrl.'color_palette/backend/assets/js/color_palette_selector_bk.js', [], $assetsVersion);

if( IsInCurrentPages(['cl_color_palette']) ) {
    wp_enqueue_style('color_palette_crud_bk_css', MainApp_cl::$compsUrl.'color_palette/backend/assets/css/color_palette_crud_bk.css', [], $assetsVersion);
    wp_enqueue_script('color_palette_crud_bk_js', MainApp_cl::$compsUrl.'color_palette/backend/assets/js/color_palette_crud_bk.js', [], $assetsVersion);
}
