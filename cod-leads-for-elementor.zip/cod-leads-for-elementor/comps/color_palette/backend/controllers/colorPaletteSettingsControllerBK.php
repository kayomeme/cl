<?php

class ColorPaletteSettingsControllerBK_cl
{
    /**
     * Renders the color palette component's settings page in the admin area.
     * This method prepares data for display ONLY, sourcing it from the settings array.
     *
     * @param int $settingsModelId The ID of the settings model.
     * @param array $settings The current settings for the component.
     * @param array $urlArgs URL arguments.
     */
    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'color_palette';

        // Include the main view file for the settings page.
        include AdminApp_cl::$viewsPath . 'global_settings/index.php';
    }

    /**
     * Saves the color palette settings AND synchronizes the JSON data with the custom table.
     *
     * @param string $compoName The name of the component.
     * @param int $settingsModelId The ID of the settings model.
     * @param array $args The settings data to save.
     * @return mixed The response from the save operation.
     */
    public static function save_settings($compoName, $settingsModelId, $args)
    {
        // Step 1: Save the raw JSON data to the cl_settings table (standard procedure).
        $response = AdminCompo_cl::saveSettings($compoName, $settingsModelId, $args);

        // Step 2: If the save was successful, synchronize the custom table.
        if (isset($args['palette_config_json'])) {
            $json_data = stripslashes($args['palette_config_json']);
            $colors_from_json = json_decode($json_data, true);

            if (is_array($colors_from_json)) {
                // This new method in the model will handle the delete-then-insert logic.
                ColorPaletteModelBK_cl::syncFromJson($colors_from_json, $settingsModelId);
            }
        }
        
        if ($response) {
            return $response;
        }
    }
}