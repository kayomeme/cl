<?php

/**
 * Controller for managing color palette
 */
class ColorPaletteControllerBK_cl {

    /*
     * Ajax Routes
     */
    public static function routes($action, $args) {
        $response = false;
        switch ($action) {
            case 'cl_update_color_palette':
                $response = self::saveUpdate($args);
                break;
            case 'cl_addnew_color_palette':
                $response = self::saveAddNew($args);
                break;
            case 'cl_delete_color_palette':
                $response = self::deleteColor($args);
                break;
            case 'cl_get_category_colors':
                $response = self::getCategoryColors($args);
                break;
            case 'cl_save_product_settings':
                $response = self::save_settings($args);
                break;
        }

        return $response;
    }

    /*
     * http Routes
     */
    public function index() {
        
        // todo : Optimize this code to run only when required
        ColorPaletteModelBK_cl::updateUsedCounts($settingsModelId = 0);
        
        $colors = ColorPaletteModelBK_cl::getAll($settingsModelId = 0);
        $compsPath = MainApp_cl::$compsPath;
        
        $textColors = array_filter($colors, function($color) { return $color->category === 'txt-color'; });
        $backgroundColors = array_filter($colors, function($color) { return $color->category === 'bg-color'; });
        $borderColors = array_filter($colors, function($color) { return $color->category === 'border-color'; });
        $shadowColors = array_filter($colors, function($color) { return $color->category === 'shadow-color'; });

        include $compsPath.'color_palette/backend/views/crud/index.php';
    }

    public static function getCategoryColors($args) {
        // Validate using validator
        $validation = ColorPaletteValidatorBK_cl::validateGetCategoryColors($args);
        if ($validation->code != 1) {
            return $validation;
        }
        
        $validatedArgs = $validation->res;
        $compsPath = MainApp_cl::$compsPath;
        
        $categoryColors = ColorPaletteModelBK_cl::getAllByCategory($validatedArgs['category'], $validatedArgs['settings_model_id']);

        ob_start();
        foreach ($categoryColors as $color) {
            include $compsPath.'color_palette/backend/views/crud/single_color_list.php';
        }
        wp_reset_postdata();
        $colorsCategoryHtmlCode = ob_get_clean();

        $response = response_cl(1, Lang_cl::__('Colors retrieved successfully', 'cl'), null);
        $response->res['items_htmlcode'] = $colorsCategoryHtmlCode;
        
        return $response;
    }

    public static function saveAddNew($args) {
        // Validate using validator
        $validation = ColorPaletteValidatorBK_cl::validateAddNew($args);
        if ($validation->code != 1) {
            return $validation;
        }
        
        $validatedArgs = $validation->res;
        $response = ColorPaletteModelBK_cl::addNew($validatedArgs);
        
        if ($response->code == 1) {
            self::generatedCssVars($validatedArgs);
            $response->msg = Lang_cl::__('Color added successfully', 'cl');
        }
        
        return $response;
    }

    public static function saveUpdate($args) {
        // Validate using validator
        $validation = ColorPaletteValidatorBK_cl::validateUpdate($args);
        if ($validation->code != 1) {
            return $validation;
        }
        
        $validatedArgs = $validation->res;
        $colorId = $validatedArgs['id'];
        
        $response = ColorPaletteModelBK_cl::update($colorId, $validatedArgs);
        
        if ($response->code == 1) {
            self::generatedCssVars($validatedArgs);
            $response->msg = Lang_cl::__('Color updated successfully', 'cl');
        }
        
        return $response;
    }

    public static function deleteColor($args) {
        // Validate using validator
        $validation = ColorPaletteValidatorBK_cl::validateDelete($args);
        if ($validation->code != 1) {
            return $validation;
        }
        
        $validatedArgs = $validation->res;
        $response = ColorPaletteModelBK_cl::delete($validatedArgs['color_id']);
        
        if ($response->code == 1) {
            self::generatedCssVars($args);
            $response->msg = Lang_cl::__('Color deleted successfully', 'cl');
        }
        
        return $response;
    }

    private static function generatedCssVars($args) {
        $settingsModelId = isset($args['settings_model_id']) ? $args['settings_model_id'] : 0;

        $colors = ColorPaletteModelBK_cl::getAll($settingsModelId);

        if (empty($colors)) {
            return;
        }

        ob_start();
        echo '<style>:root {';
        foreach ($colors as $color) {
            echo '--cl-' . $color->name . ': ' . $color->code . ';';
        }
        echo '}</style>';

        $generatedCss = ob_get_clean();

        if (adminUtils_cl::isValideGeneratedCss($generatedCss)) {
            $generatedCss = adminUtils_cl::minify_css($generatedCss);
            $optionName = 'cl_color_palette_css_vars_' . (int) $settingsModelId;
            update_option($optionName, $generatedCss, 'no');
        }
    }
}