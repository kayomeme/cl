
    <div class="cl-row">
        <div class="cl-th-full">
            <?= Lang_cl::_e('Palette JSON Configuration', 'cl') ?>
            <div class="cl-alert cl-alert-info">
                <?= Lang_cl::_e('Manage your global color palette using the JSON format below. When you save, this data will be used to generate the CSS variables and populate the color pickers across the plugin.', 'cl') ?>
            </div>
        </div>
        <div class="cl-td-full">
            <textarea name="palette_config_json" rows="25" style="width: 100%; font-family: monospace;"><?= esc_textarea(json_encode(json_decode($settings['palette_config_json']), JSON_PRETTY_PRINT)) ?></textarea>
        </div>
    </div>
