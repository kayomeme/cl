<div class="header">
        <h1><?= Lang_cl::__('Global Color Template System', 'cl') ?></h1>
        <p><?= Lang_cl::__('Manage your plugin\'s color scheme with ease', 'cl') ?></p>
    </div>
<div class="color-list-container">

    <!-- Text Colors Section -->
    <div class="section">
        <div class="color-list-header">
            <h3 class="add-section">
                <?= Lang_cl::__('Text Colors', 'cl') ?>
            </h3>
            <button type="button" class="btn btn-add-new" data-category="txt-color">
                <?= Lang_cl::__('Add Text Color', 'cl') ?>
            </button>
        </div>

        <div class="color-list" id="colorList-txt-color">
            <?php if (!empty($textColors) && count($textColors) > 0): ?>
                <?php foreach ($textColors as $color):
                    include 'single_color_list.php';
                endforeach; ?>
            <?php else: ?>
                <div class="empty-state"><?= Lang_cl::__('No text colors added yet. Create your first text color!', 'cl') ?></div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Background Colors Section -->
    <div class="section">
        <div class="color-list-header">
            <h3 class="add-section">
                <?= Lang_cl::__('Background Colors', 'cl') ?>
            </h3>
            <button type="button" class="btn btn-add-new" data-category="bg-color">
                <?= Lang_cl::__('Add Background Color', 'cl') ?>
            </button>
        </div>

        <div class="color-list" id="colorList-bg-color">
            <?php if (!empty($backgroundColors) && count($backgroundColors) > 0): ?>
                <?php foreach ($backgroundColors as $color):
                    include 'single_color_list.php';
                endforeach; ?>
            <?php else: ?>
                <div class="empty-state"><?= Lang_cl::__('No background colors added yet. Create your first background color!', 'cl') ?></div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Border Colors Section -->
    <div class="section">
        <div class="color-list-header">
            <h3 class="add-section">
                <?= Lang_cl::__('Border Colors', 'cl') ?>
            </h3>
            <button type="button" class="btn btn-add-new" data-category="border-color">
                <?= Lang_cl::__('Add Border Color', 'cl') ?>
            </button>
        </div>

        <div class="color-list" id="colorList-border-color">
            <?php if (!empty($borderColors) && count($borderColors) > 0): ?>
                <?php foreach ($borderColors as $color):
                    include 'single_color_list.php';
                endforeach; ?>
            <?php else: ?>
                <div class="empty-state"><?= Lang_cl::__('No border colors added yet. Create your first border color!', 'cl') ?></div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Shadow Colors Section -->
    <div class="section">
        <div class="color-list-header">
            <h3 class="add-section">
                <?= Lang_cl::__('Shadow Colors', 'cl') ?>
            </h3>
            <button type="button" class="btn btn-add-new" data-category="shadow-color">
                <?= Lang_cl::__('Add Shadow Color', 'cl') ?>
            </button>
        </div>

        <div class="color-list" id="colorList-shadow-color">
            <?php if (!empty($shadowColors) && count($shadowColors) > 0): ?>
                <?php foreach ($shadowColors as $color):
                    include 'single_color_list.php';
                endforeach; ?>
            <?php else: ?>
                <div class="empty-state"><?= Lang_cl::__('No shadow colors added yet. Create your first shadow color!', 'cl') ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Color Modal for edit or add a new color -->
<div class="modal-overlay" id="colorModal">
    <div class="modal">
        <div class="modal-header">
            <h2 id="modalTitle"><?= Lang_cl::__('Add New Color', 'cl') ?></h2>
            <button type="button" class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
            <form id="colorForm">
                <input type="hidden" id="editingId" value="">
                <input type="hidden" id="colorCategory" value="">

                <div class="form-group">
                    <label for="colorTitle"><?= Lang_cl::__('Color Title', 'cl') ?></label>
                    <input type="text" id="colorTitle" placeholder="<?= Lang_cl::__('e.g., Primary Text Color, Button Background', 'cl') ?>" required>
                </div>

                <div class="form-group">
                    <label for="colorCode"><?= Lang_cl::__('Color Code', 'cl') ?></label>
                    <div class="color-input-wrapper">
                        <input type="color" id="colorPicker" class="color-picker" value="#0073aa">
                        <input type="text" id="colorCode" placeholder="#0073aa" required>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" id="modalCancelBtn">
                <?= Lang_cl::__('Cancel', 'cl') ?>
            </button>
            <button type="submit" form="colorForm" class="btn btn-save" id="modalSubmitBtn">
                <?= Lang_cl::__('Add Color', 'cl') ?>
            </button>
        </div>
    </div>
</div>

<!-- Hidden form containers for AJAX data collection -->
<div style="display: none;">
    <!-- Container for get colors operations -->
    <div id="cl_get_category_colors">
        <input type="hidden" name="category" cl-ischanged="yes">
        <input type="hidden" name="settings_model_id" value="0" cl-ischanged="yes">
    </div>

    <!-- Container for add operations -->
    <div id="cl_addnew_color_palette">
        <input type="hidden" name="title" cl-ischanged="yes">
        <input type="hidden" name="code" cl-ischanged="yes">
        <input type="hidden" name="category" cl-ischanged="yes">
        <input type="hidden" name="settings_model_id" value="0" cl-ischanged="yes">
    </div>

    <!-- Container for update operations -->
    <div id="cl_update_color_palette">
        <input type="hidden" name="id" cl-ischanged="yes">
        <input type="hidden" name="title" cl-ischanged="yes">
        <input type="hidden" name="code" cl-ischanged="yes">
        <input type="hidden" name="category" cl-ischanged="yes">
        <input type="hidden" name="settings_model_id" value="0" cl-ischanged="yes">
    </div>

    <!-- Container for delete operations -->
    <div id="cl_delete_color_palette">
        <input type="hidden" name="color_id" cl-ischanged="yes">
        <input type="hidden" name="settings_model_id" value="0" cl-ischanged="yes">
    </div>
</div>

<!-- Notification -->
<div id="notification" class="notification"></div>