<?php 
// this will be called via the index.php and via the controller for ajax requests
?>
<div class="color-item" 
     data-color-id="<?= $color->id ?>" 
     data-color-category="<?= $color->category ?>"
     data-color-code="<?= $color->code ?>"
     data-color-title="<?= $color->title ?>">
    
    <div class="color-info">
        <div class="color-preview" style="background-color: <?= $color->code ?>;"></div>
        <div class="color-details">
            <span class="color-name"><?= $color->title ? $color->title : $color->name ?></span>
            <div class="color-metas">
                <span class="color-code"><?= $color->code ?></span>
                <span class="color-usage"><?= Lang_cl::__('Used', 'cl') ?> <?= isset($color->used_count) ? $color->used_count : 0 ?> <?= Lang_cl::__('times', 'cl') ?></span>
            </div>
        </div>
    </div>
    <div class="color-actions">
        <button class="btn btn-edit btn-small" onclick="colorManager.editColor(this)">
            <?= Lang_cl::__('Edit', 'cl') ?>
        </button>
        <?php if ($color->is_system !== 'yes'): ?>
            <button class="btn btn-danger btn-small" onclick="colorManager.deleteColor(this)">
                <?= Lang_cl::__('Delete', 'cl') ?>
            </button>
        <?php endif; ?>
    </div>
</div>