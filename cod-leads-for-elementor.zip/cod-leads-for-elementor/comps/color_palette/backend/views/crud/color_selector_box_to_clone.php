<?php 
$colors = ColorPaletteModelBK_cl::getAll($settingsModelId = 0);
?>
<div style="display: none">
    <div id="color_selector_palette" class="color-select-wrapper">
        <div class="color-select-custom">
            <div class="color-select-preview"></div>
            <span class="color-select-text"><?= Lang_cl::__('Select Color Template', 'cl') ?></span>
            <i class="color-select-arrow"></i>
        </div>
        <div class="color-dropdown-menu">
            <!-- Default option -->
            <div class="cl-color-option selected" data-value="">
                <div class="cl-color-option-preview" style="background: #f0f0f0; border: 2px dashed #ccc;"></div>
                <div class="cl-color-option-text">
                    <div><?= Lang_cl::__('Select Color Template', 'cl') ?></div>
                    <div class="cl-color-option-code"><?= Lang_cl::__('No color selected', 'cl') ?></div>
                </div>
            </div>
            
            <!-- Text Colors Group -->
            <?php 
            $textColors = array_filter($colors, function($color) { 
                return $color->category === 'txt-color'; 
            });
            ?>
            <?php if (!empty($textColors)): ?>
                <div class="cl-color-group-header"><?= Lang_cl::__('Text Colors', 'cl') ?></div>
                <?php foreach ($textColors as $color): ?>
                    <div class="cl-color-option" data-colorid="<?= $color->id ?>" data-colorname="<?= $color->name ?>" data-colorcode="<?= $color->code ?>" data-category="<?= $color->category ?>">
                        <div class="cl-color-option-preview" style="background-color: <?= $color->code ?>;"></div>
                        <div class="cl-color-option-text">
                            <div><?= $color->title ?></div>
                            <div class="cl-color-option-code"><?= $color->name ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
            
            <!-- Background Colors Group -->
            <?php 
            $backgroundColors = array_filter($colors, function($color) { 
                return $color->category === 'bg-color'; 
            });
            ?>
            <?php if (!empty($backgroundColors)): ?>
                <div class="cl-color-group-header"><?= Lang_cl::__('Background Colors', 'cl') ?></div>
                <?php foreach ($backgroundColors as $color): ?>
                    <div class="cl-color-option" data-colorid="<?= $color->id ?>" data-colorname="<?= $color->name ?>" data-colorcode="<?= $color->code ?>" data-category="<?= $color->category ?>">
                        <div class="cl-color-option-preview" style="background-color: <?= $color->code ?>;"></div>
                        <div class="cl-color-option-text">
                            <div><?= $color->title ?></div>
                            <div class="cl-color-option-code"><?= $color->name ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
            
            <!-- Border Colors Group -->
            <?php 
            $borderColors = array_filter($colors, function($color) { 
                return $color->category === 'border-color'; 
            });
            ?>
            <?php if (!empty($borderColors)): ?>
                <div class="cl-color-group-header"><?= Lang_cl::__('Border Colors', 'cl') ?></div>
                <?php foreach ($borderColors as $color): ?>
                    <div class="cl-color-option" data-colorid="<?= $color->id ?>" data-colorname="<?= $color->name ?>" data-colorcode="<?= $color->code ?>" data-category="<?= $color->category ?>">
                        <div class="cl-color-option-preview" style="background-color: <?= $color->code ?>;"></div>
                        <div class="cl-color-option-text">
                            <div><?= $color->title ?></div>
                            <div class="cl-color-option-code"><?= $color->name ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
            
            <!-- Shadow Colors Group -->
            <?php 
            $shadowColors = array_filter($colors, function($color) { 
                return $color->category === 'shadow-color'; 
            });
            ?>
            <?php if (!empty($shadowColors)): ?>
                <div class="cl-color-group-header"><?= Lang_cl::__('Shadow Colors', 'cl') ?></div>
                <?php foreach ($shadowColors as $color): ?>
                    <div class="cl-color-option" data-colorid="<?= $color->id ?>" data-colorname="<?= $color->name ?>" data-colorcode="<?= $color->code ?>" data-category="<?= $color->category ?>">
                        <div class="cl-color-option-preview" style="background-color: <?= $color->code ?>;"></div>
                        <div class="cl-color-option-text">
                            <div><?= $color->title ?></div>
                            <div class="cl-color-option-code"><?= $color->name ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>