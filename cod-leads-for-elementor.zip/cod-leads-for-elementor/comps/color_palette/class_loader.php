<?php
$dirPath = plugin_dir_path( __FILE__ );
if( $isAdminAria ) {    

    // This is the new controller for the standard settings page.
    require_once $dirPath  . 'backend/controllers/colorPaletteSettingsControllerBK.php';

    // These are the existing files for the AJAX CRUD functionality.
    require_once $dirPath  . 'backend/controllers/colorPaletteControllerBK.php';
    require_once $dirPath  . 'backend/models/colorPaletteModelBK.php';
    require_once $dirPath  . 'backend/class/colorPaletteValidatorBK.php';
}
if($isPublicAria) {

}