<?php
return [
    /*-----------My Store component--------*/
    'mystore' => [
        'name'      => 'mystore',
        'is_active' => 'yes',  
        'admin_hooks' => [
            1 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            2 => 'template_redirect',
            3 => 'wp_head',
        ],
        'public_filters' => []
    ],
    /*-----------Sales Funnel component--------*/
    'sales_funnel' => [
        'name'      => 'sales_funnel',
        'is_active' => 'yes',
        'admin_hooks' => [
            4 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            5 => 'template_redirect',
            6 => 'wp_head',
            7 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Cart component--------*/
    'cart' => [
        'name'      => 'cart',
        'is_active' => 'yes',
        'admin_hooks' => [
            8 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            9 => 'template_redirect',
            10 => 'wp_head',
            11 => 'wp_enqueue_scripts',
            53 => 'wp_footer',
        ],
        'public_filters' => [
            12 => 'the_content',
        ]
    ],
    /*-----------Checkout component--------*/
    'checkout' => [
        'name'      => 'checkout',
        'is_active' => 'yes',
        'admin_hooks' => [
            13 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            14 => 'template_redirect',
            15 => 'wp_head',
            16 => 'wp_enqueue_scripts',
        ],
        'public_filters' => [
            17 => 'the_content',
        ]
    ],
    /*-----------Product component--------*/
    'product' => [
        'name'      => 'product',
        'is_active' => 'yes',
        'admin_hooks' => [
            18 => 'admin_head',
            19 => 'admin_footer',
            20 => 'manage_post_posts_custom_column',
            21 => 'admin_enqueue_scripts',
            22 => 'add_meta_boxes',
            23 => 'save_post_product',
        ],
        'admin_filters' => [
            24 => 'manage_edit-post_columns',
        ],
        'public_hooks' => [
            25 => 'template_redirect',
            26 => 'wp_head',
            27 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Thank You component--------*/
    'thankyou' => [
        'name'      => 'thankyou',
        'is_active' => 'yes',
        'admin_hooks' => [
            28 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            29 => 'template_redirect',
            30 => 'wp_head',
            31 => 'wp_enqueue_scripts',
        ],
        'public_filters' => [
            32 => 'the_content',
        ]
    ],
    /*-----------Google Sheet component--------*/
    'google_sheet' => [
        'name'      => 'google_sheet',
        'is_active' => 'yes',  
        'admin_hooks' => [
            33 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            34 => 'template_redirect',
            35 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Top Bar component--------*/
    'top_bar' => [
        'name'      => 'top_bar',
        'is_active' => 'yes',
        'admin_hooks' => [],
        'admin_filters' => [],
        'public_hooks' => [
            36 => 'template_redirect',
            37 => 'wp_body_open',
            54 => 'wp_head',
        ],
        'public_filters' => []
    ],
    /*-----------WhatsApp component--------*/
    'whatsapp' => [
        'name'      => 'whatsapp',
        'is_active' => 'yes',
        'admin_hooks' => [],
        'admin_filters' => [],
        'public_hooks' => [
            38 => 'template_redirect',
            39 => 'wp_footer',
        ],
        'public_filters' => []
    ],
    /*-----------Tracking component--------*/
    'tracking' => [
        'name'      => 'tracking',
        'is_active' => 'yes',
        'admin_hooks' => [],
        'admin_filters' => [],
        'public_hooks' => [
            40 => 'template_redirect',
            41 => 'wp_head',
            42 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Order component--------*/
    'order' => [
        'name'      => 'order',
        'is_active' => 'yes',
        'admin_hooks' => [
            43 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Order Status component--------*/
    'order_statuses' => [
        'name'      => 'order_statuses',
        'is_active' => 'yes',
        'admin_hooks' => [
            44 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Products Listing component--------*/
    'plist1' => [
        'name'      => 'plist1',
        'is_active' => 'yes',
        'admin_hooks' => [
            45 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Categories Listing component--------*/
    'categories_listing' => [
        'name'      => 'categories_listing',
        'is_active' => 'yes',
        'admin_hooks' => [
            46 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Insights component--------*/
    'insights' => [
        'name'      => 'insights',
        'is_active' => 'yes',
        'admin_hooks' => [
            47 => 'admin_enqueue_scripts',
            48 => 'manage_post_posts_custom_column',
        ],
        'admin_filters' => [
            49 => 'manage_edit-post_columns',
        ],
        'public_hooks' => [
            50 => 'template_redirect',
            51 => 'wp_head',
            52 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
   /*----------- tools_sys  this is a system component --------*/
    'tools_sys' => [
        'name'      => 'tools_sys',
        'is_active' => 'yes',
        'admin_hooks' => [
            53 => 'admin_enqueue_scripts'
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [
        ],
        'public_filters' => []
    ],
   /*----------- shipping_options  --------*/
    'shipping_options' => [
        'name'      => 'shipping_options',
        'is_active' => 'yes',
        'admin_hooks' => [
            54 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
   /*----------- simulator  this is a system component --------*/
    'simulator' => [
        'name'      => 'simulator',
        'is_active' => 'yes',
        'admin_hooks' => [
            55 => 'admin_enqueue_scripts',
            56 => 'admin_head'
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [
        ],
        'public_filters' => []
    ],

];
