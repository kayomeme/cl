<?php
return [
    /*-----------My Store component--------*/
    'mystore' => [
        'name'      => 'mystore',
        'is_active' => 'yes',  
        'admin_hooks' => [
            1 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            2 => 'template_redirect',
            3 => 'wp_head',
        ],
        'public_filters' => []
    ],
    /*-----------Sales Funnel component--------*/
    'sales_funnel' => [
        'name'      => 'sales_funnel',
        'is_active' => 'yes',
        'admin_hooks' => [
            7 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            8 => 'template_redirect',
            9 => 'wp_head',
            10 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Cart component--------*/
    'cart' => [
        'name'      => 'cart',
        'is_active' => 'yes',
        'admin_hooks' => [
            11 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            12 => 'template_redirect',
            13 => 'wp_head',
            14 => 'wp_enqueue_scripts',
            15 => 'wp_footer',
        ],
        'public_filters' => [
            16 => 'the_content',
        ]
    ],
    /*-----------Checkout component--------*/
    'checkout' => [
        'name'      => 'checkout',
        'is_active' => 'yes',
        'admin_hooks' => [
            17 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            18 => 'template_redirect',
            19 => 'wp_head',
            20 => 'wp_enqueue_scripts',
            21 => 'wp_footer',
        ],
        'public_filters' => [
            22 => 'the_content',
        ]
    ],
    /*-----------Category component--------*/
    'category' => [
        'name'      => 'category',
        'is_active' => 'yes',
        'admin_hooks' => [
            23 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            24 => 'template_redirect',
            25 => 'wp_head',
            26 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Product component--------*/
    'product' => [
        'name'      => 'product',
        'is_active' => 'yes',
        'admin_hooks' => [
            27 => 'admin_head',
            28 => 'admin_footer',
            29 => 'manage_post_posts_custom_column',
            30 => 'admin_enqueue_scripts',
            31 => 'add_meta_boxes',
            32 => 'save_post_product',
        ],
        'admin_filters' => [
            33 => 'manage_edit-post_columns',
        ],
        'public_hooks' => [
            34 => 'template_redirect',
            35 => 'wp_head',
            36 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------qty_offers component--------*/
    'qty_offers' => [
        'name'      => 'qty_offers',
        'is_active' => 'yes',
        'admin_hooks' => [
            100 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            // Register the new hooks for the qty_offers component
            101 => 'template_redirect', // for qty_offers_tr.php
            102 => 'wp_head',
            103 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    
    /*----------- variations component--------*/
    'variations' => [
        'name'      => 'variations',
        'is_active' => 'yes',
        'admin_hooks' => [
            104 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            105 => 'template_redirect',
            106 => 'wp_head',
            107 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    
    /*-----------Thank You component--------*/
    'thankyou' => [
        'name'      => 'thankyou',
        'is_active' => 'yes',
        'admin_hooks' => [
            37 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            38 => 'template_redirect',
            39 => 'wp_head',
            40 => 'wp_enqueue_scripts',
        ],
        'public_filters' => [
            41 => 'the_content',
        ]
    ],
    /*-----------Google Sheet component--------*/
    'google_sheet' => [
        'name'      => 'google_sheet',
        'is_active' => 'yes',  
        'admin_hooks' => [
            42 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            43 => 'template_redirect',
            44 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------WhatsApp component--------*/
    'whatsapp' => [
        'name'      => 'whatsapp',
        'is_active' => 'yes',
        'admin_hooks' => [],
        'admin_filters' => [],
        'public_hooks' => [
            48 => 'template_redirect',
            49 => 'wp_footer',
        ],
        'public_filters' => []
    ],
    /*-----------Tracking component--------*/
    'tracking' => [
        'name'      => 'tracking',
        'is_active' => 'yes',
        'admin_hooks' => [],
        'admin_filters' => [],
        'public_hooks' => [
            50 => 'template_redirect',
            51 => 'wp_head',
            52 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Order component--------*/
    'order' => [
        'name'      => 'order',
        'is_active' => 'yes',
        'admin_hooks' => [
            53 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Order Status component--------*/
    'order_statuses' => [
        'name'      => 'order_statuses',
        'is_active' => 'yes',
        'admin_hooks' => [
            54 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Products Listing component--------*/
    'plist1' => [
        'name'      => 'plist1',
        'is_active' => 'yes',
        'admin_hooks' => [
            55 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [
            56 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Products Listing compo for thankyou upsell --------*/
    'plist5' => [
        'name'      => 'plist5',
        'is_active' => 'yes',
        'admin_hooks' => [
            57 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Categories Listing component--------*/
    'categories_listing' => [
        'name'      => 'categories_listing',
        'is_active' => 'yes',
        'admin_hooks' => [
            58 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Insights component--------*/
    'insights' => [
        'name'      => 'insights',
        'is_active' => 'yes',
        'admin_hooks' => [
            59 => 'admin_enqueue_scripts',
            60 => 'manage_post_posts_custom_column',
        ],
        'admin_filters' => [
            61 => 'manage_edit-post_columns',
        ],
        'public_hooks' => [
            62 => 'template_redirect',
            63 => 'wp_head',
            64 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
   /*----------- tools_sys  this is a system component --------*/
    'tools_sys' => [
        'name'      => 'tools_sys',
        'is_active' => 'yes',
        'admin_hooks' => [
            65 => 'admin_enqueue_scripts'
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [
        ],
        'public_filters' => []
    ],
       /*----------- Style Manager  --------*/
    'style_manager' => [
        'name'      => 'style_manager',
        'is_active' => 'yes',
        'admin_hooks' => [
            66 => 'admin_enqueue_scripts',
            67 => 'admin_footer',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
       /*----------- color_palette  --------*/
    'color_palette' => [
        'name'      => 'color_palette',
        'is_active' => 'yes',
        'admin_hooks' => [
            115 => 'admin_enqueue_scripts',
            116 => 'admin_footer',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
       /*----------- icons_manager  --------*/
    'icons_manager' => [
        'name'      => 'icons_manager',
        'is_active' => 'yes',
        'admin_hooks' => [
            68 => 'admin_enqueue_scripts',
            69 => 'admin_footer',
        ],
        'admin_filters' => [],
        'public_hooks' => [],
        'public_filters' => []
    ],
   /*----------- simulator  this is a system component --------*/
    'simulator' => [
        'name'      => 'simulator',
        'is_active' => 'yes',
        'admin_hooks' => [
            70 => 'admin_enqueue_scripts',
            71 => 'admin_head'
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [
        ],
        'public_filters' => []
    ],
    /*----------- header component--------*/
    'header' => [
        'name'      => 'header',
        'is_active' => 'yes',  
        'admin_hooks' => [
            89 => 'admin_enqueue_scripts', 
        ],
        'admin_filters' => [],
        'public_hooks' => [
            90 => 'template_redirect',
            91 => 'wp_head',
            92 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*----------- footer component--------*/
    'footer' => [
        'name'      => 'footer',
        'is_active' => 'yes',  
        'admin_hooks' => [
            94 => 'admin_enqueue_scripts', 
        ],
        'admin_filters' => [],
        'public_hooks' => [
            95 => 'template_redirect',
            96 => 'wp_head',
            97 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
];