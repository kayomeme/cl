<?php if($categoryImgUrl) { ?>
<div class="cl-category-image">
    <a href="<?= $categoryLink ?>">
        <img src="<?= $categoryImgUrl ?>" alt="<?= $categoryTitle ?>" title="<?= $categoryTitle ?>" />
    </a>
</div>
<?php } ?>