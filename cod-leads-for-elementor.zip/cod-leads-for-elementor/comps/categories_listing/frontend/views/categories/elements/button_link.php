<a class="cl-button-link" href="<?= $categoryLink ?>">
    <?php if( $compoSettings['categories_show_bt_icon'] == 'yes' ) { ?>
    <i class="cl-icon icon-clipboard"></i>&nbsp;
    <?php } ?>
    <?= $compoSettings['categories_bt_text'] ?>
</a>