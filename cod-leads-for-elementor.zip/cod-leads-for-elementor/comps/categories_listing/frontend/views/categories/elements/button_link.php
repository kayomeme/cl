<a class="clfe-button-link" href="<?= $categoryLink ?>">
    <?php if( $compoSettings['categories_show_bt_icon'] == 'yes' ) { ?>
    <i class="clfe-icon icon-clipboard"></i>&nbsp;
    <?php } ?>
    <?= $compoSettings['categories_bt_text'] ?>
</a>