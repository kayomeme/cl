<div class="cl-categories-list">
<?php 
    foreach ($categories as $key => $category) {
        $categoryLink = get_category_link($category->term_id);
        $categoryTitle  = $category->name;
        $categoryImgUrl = get_term_meta($category->term_id, 'cl_category_img_url', true);
        ?>
        <div class="category_item">
            <?php 
                $categories_elements = explode(',', $compoSettings['categories_listing_elements_order']);
                // if any new element you should add it here directly in this array with a position
                foreach ($categories_elements as $element) {
                    include 'elements/'.$element.'.php';
                }
            ?>
        </div>
        <?php 
    }
?>
</div>