<a class="clfe-buy-button" href="<?= $productLink ?>">
    <?php if( $compoSettings['products_show_bt_icon'] == 'yes' ) { ?>
    <i class="clfe-icon icon-clipboard"></i>&nbsp;
    <?php } ?>
    <?= $compoSettings['products_bt_text'] ?>
</a>