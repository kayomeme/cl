<a class="cl-buy-button" href="<?= $productLink ?>">
    <?php if( $compoSettings['products_show_bt_icon'] == 'yes' ) { ?>
    <i class="cl-icon icon-clipboard"></i>&nbsp;
    <?php } ?>
    <?= $compoSettings['products_bt_text'] ?>
</a>