<div class="cl-product-prices">
    <?php if( $compoSettings['products_show_sale_price'] == 'yes' ) { ?>
    <div class="sale_price"> 
        <?= isset( $productDetails['sale_price'] ) ? $productDetails['sale_price'].' '.$mystoreSettings['currency_label'] : '' ?> 
    </div>
    <?php } ?>
    <?php if( $compoSettings['products_show_regular_price'] == 'yes' ) { ?>
    <div class="regular_price"> 
        <?= isset( $productDetails['regular_price'] ) ? $productDetails['regular_price'].' '.$mystoreSettings['currency_label'] : '' ?> 
    </div>
    <?php } ?>
</div>