<div class="clfe-product-image">
    <a href="<?= $productLink ?>">
        <?= has_post_thumbnail() ? get_the_post_thumbnail(get_the_ID(), 'full') : '' ?>
    </a>
</div>