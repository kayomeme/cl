<div class="clfe-products-list">
<?php 
    while ($posts_query->have_posts()) {
        $posts_query->the_post();
        $productLink = get_permalink();
        $productTitle = get_the_title();

        // Get post meta data
        $productDetails = get_post_meta(get_the_ID(), 'clfe_product_details', true);
        //var_dump($productDetails);
        ?>
        <div class="product_item">
            <?php 
                $products_elements = explode(',', $compoSettings['categories_listing_elements_order']);
                // if any new element you should add it here directly in this array with a position
                foreach ($products_elements as $element) {
                    include 'elements/'.$element.'.php';
                }
            ?>
        </div>
        <?php 
    }
?>
</div>