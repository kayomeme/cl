<?php
/**
 */
class CategoriesListingControllerFR_cl {
    public $id;
    public $type = 'product';
    


    public function __construct() {

    }
    
    public function default($atts) {
        $compoApp = is_admin() ? new AdminCompo_cl() : new PublicCompo_cl();
        // Extract shortcode attributes
        $atts = shortcode_atts(array(
            'category_id' => 0,
            'max_products' => 4, // -1 for all posts
            'settings_model_id' => 0
        ), $atts);

        // Query parameters
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $atts['max_products'],
        );

        // Add category parameter to query if specified
        if ( $atts['category_id'] ) { 
           $args['cat'] = $atts['category_id'];  
        }

        $settingsModelId = $atts['settings_model_id'];
        
        // Query posts
        $posts_query = new WP_Query($args);

        // Output posts
        $output = 'No posts found';
        
        $compoName = 'listing';
        $compoSettings = $compoApp::getSettings($compoName, $settingsModelId);
        $mystoreSettings = $compoApp::getSharedSettings($settingsModelId);
        if ($posts_query->have_posts()) {
            ob_start();
            include MainApp_cl::$compsPath.$compoName.'/frontend/views/products/index.php';
            $output = ob_get_contents();
            ob_get_clean();
        }
        
        $CategoriesListingCss = $compoApp::getGeneratedCss($compoName, $settingsModelId);

        // Restore original post data
        wp_reset_postdata();

        $content = $output.$CategoriesListingCss;
        
        return $content;
    }
    /*
     * 
     */
    public function getJsProduct() {
        $jsProduct = [];
        
        $jsProduct['id']                = $this->id;
        
        return jsonEncodeForJs_cl($jsProduct);
    }
    /*
     * 
     */
}
