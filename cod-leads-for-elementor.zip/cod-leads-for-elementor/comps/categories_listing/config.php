<?php

/**
 * general
 */
return array(
    'setting' => [
        'categories_show_title' => 'yes',
        'categories_show_bt_icon' => 'yes',
        'categories_listing_elements_order' => 'button_link,image,title',
    ],
    'lang' => [
        'categories_bt_text' => 'View all products',
    ],
    'style' => [
        'categories_item_style' => 'border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:#ffffff;border-style:solid;border-top-left-radius:58px;border-top-right-radius:13px;border-bottom-left-radius:5px;border-bottom-right-radius:5px;background-color:#f9f9f9;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;box-shadow:1px 7px 5px -1px #333333;',
        'categories_image_style' => 'border-top-width:10px;border-right-width:5px;border-bottom-width:0px;border-left-width:10px;border-color:#428bca;border-style:solid;border-top-left-radius:31px;border-top-right-radius:38px;border-bottom-left-radius:134px;border-bottom-right-radius:53px;',
        'categories_title_style' => 'font-size:15px;color:#3399ff;font-weight:700;text-align:center;padding-top:5px;padding-right:5px;padding-bottom:5px;padding-left:5px;',
        'categories_bt_style' => 'width:auto;font-size:15px;color:#ffffff;font-weight:700;text-align:center;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-color:#5cb85c;border-style:solid;border-top-left-radius:1px;border-top-right-radius:1px;border-bottom-left-radius:1px;border-bottom-right-radius:1px;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;background-image:linear-gradient(17deg,#8BC34A,#4CAF50);box-shadow:1px 5px 2px -1px #008744;;',
    ]
);
