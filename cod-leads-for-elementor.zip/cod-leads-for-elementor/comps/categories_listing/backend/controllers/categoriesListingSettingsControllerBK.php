<?php

class CategoriesListingSettingsControllerBK_clfe
{
    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'categories_listing';
        $tabName = isset($_GET['tab']) ? $_GET['tab'] : 'categories_listing';

        $defaultSettings    = AdminCompo_clfe::getDefaultSettings($compoName, $settings);
        $adminStyle         = new AdminStyle_clfe($defaultSettings);

        $categoriesElements = adminUtils_clfe::getElementsOrder($defaultSettings['categories_listing_elements_order'], $settings['categories_listing_elements_order']);           
        $settings['categories_listing_elements_order'] = implode(',', $categoriesElements);

        include AdminApp_clfe::$viewsPath . 'global_settings/index.php';
    }
    public static function save_settings($compoName, $settingsModelId, $args)
    {
        $response = AdminCompo_clfe::saveSettings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }

    private static function getSharedSettings($args)
    {
        $sharedSettings = [];

        return $sharedSettings;
    }
}
