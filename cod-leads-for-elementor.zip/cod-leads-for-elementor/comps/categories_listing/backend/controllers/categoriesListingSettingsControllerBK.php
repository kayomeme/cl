<?php

class CategoriesListingSettingsControllerBK_cl
{
    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'categories_listing';
        $tabName = isset($_GET['tab']) ? $_GET['tab'] : 'categories_listing';

        $defaultSettings    = AdminCompo_cl::getDefaultSettings($compoName, $settings);

        $categoriesElements = adminUtils_cl::getElementsOrder($defaultSettings['categories_listing_elements_order'], $settings['categories_listing_elements_order']);           
        $settings['categories_listing_elements_order'] = implode(',', $categoriesElements);
        
        $generatorSettings  = AdminCompo_cl::getStyleGenerator($compoName, $settings);
        $styleManager         = new StyleManagerBK_cl($defaultSettings, $settings, $generatorSettings);

        include AdminApp_cl::$viewsPath . 'global_settings/index.php';
    }
    public static function save_settings($compoName, $settingsModelId, $args)
    {
        $response = AdminCompo_cl::saveSettings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }

    private static function getSharedSettings($args)
    {
        $sharedSettings = [];

        return $sharedSettings;
    }
}
