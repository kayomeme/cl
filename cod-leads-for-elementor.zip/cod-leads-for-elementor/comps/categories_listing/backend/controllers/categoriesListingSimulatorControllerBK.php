<?php

/**
 */
class CategoriesListingSimulatorControllerBK_clfe
{

    public static function getPreview($args)
    {
        $compoApp = is_admin() ? new AdminCompo_clfe() : new PublicCompo_clfe();
        // Extract shortcode attributes
        $atts = shortcode_atts(array(
            'category' => '',
            'max_posts' => 4, // -1 for all posts
            'settings_model_id' => 0
        ), $atts = []);

        // Query parameters
        $args = array(
            'hierarchical' => 1,
            'show_option_none' => '',
            'number' => $atts['max_posts'],
            'orderby' => 'ID',
            'hide_empty' => 0, // Set to 0 to show empty categories and 1 to hide them
            /*'parent' => $parent_id,*/
            'taxonomy' => 'category'
        );

        // Add category parameter to query if specified
        if (!empty($atts['category'])) {
            $args['category_name'] = $atts['category'];
        }

        $settingsModelId = $atts['settings_model_id'];

        // Query posts
        $categories = get_categories($args);

        // Output posts
        $output = 'No posts found';

        $compoName = 'categories_listing';
        $compoSettings = $compoApp::getSettings($compoName, $settingsModelId);
        $mystoreSettings = $compoApp::getSettings('mystore', $settingsModelId);
        if ($categories) {
            ob_start();
            include MainApp_clfe::$compsPath . $compoName . '/frontend/views/categories/index.php';
            $output = ob_get_contents();
            ob_get_clean();
        }

        $categoriesListingCss = $compoApp::getGeneratedCss($compoName, $settingsModelId);

        $content = $output . $categoriesListingCss;

        return response_clfe(1, Lang_clfe::__('Preview loaded successfully', 'clfe'), $content);
    }
}
