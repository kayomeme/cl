<div id="clfe_categories_listing_tab" class="clfe-single-tab">
    <?php include 'partails/categories/index.php'; ?>
</div>