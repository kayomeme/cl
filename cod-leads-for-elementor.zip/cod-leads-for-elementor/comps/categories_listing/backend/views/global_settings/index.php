<div id="cl_categories_listing_tab" class="cl-single-tab">
    <?php include 'partails/categories/index.php'; ?>
</div>