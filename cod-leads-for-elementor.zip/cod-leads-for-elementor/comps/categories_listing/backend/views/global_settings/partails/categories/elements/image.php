<div class="cl-row" _attachedsection="image">
    <span class="dashicons dashicons-format-image"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Category image', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>