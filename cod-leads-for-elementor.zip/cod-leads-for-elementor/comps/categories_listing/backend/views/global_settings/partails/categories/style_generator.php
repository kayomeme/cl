<?php
return array(
    'categories_item_style' => [
        'modal_title' => Lang_cl::__('Category container style', 'cl'),
        'style_attached_to' => '.cl-categories-list .category_item',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'box-shadow' => 'yes'
    ],
    'categories_image_style' => [
        'modal_title' => Lang_cl::__('Category image style', 'cl'),
        'style_attached_to' => '.cl-categories-list .cl-category-image img',
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    'categories_title_style' => [
        'modal_title' => Lang_cl::__('Category title style', 'cl'),
        'style_attached_to' => '.cl-categories-list .category_title',
        'font' => 'yes',
        'padding' => 'yes',
    ],
    'categories_bt_style' => [
        'modal_title' => Lang_cl::__('Button style', 'cl'),
        'style_attached_to' => '.cl-categories-list .cl-button-link',
        'predefined_width' => 'yes', 
        'font' => 'yes', 
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes', 
        'linear-gradient' => 'yes', 
        'box-shadow' => 'yes'
    ],
);