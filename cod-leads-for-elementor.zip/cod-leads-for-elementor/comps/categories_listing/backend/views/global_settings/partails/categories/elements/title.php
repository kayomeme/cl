<div class="cl-row" _attachedsection="title">
    <span class="dashicons dashicons-heading"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Category title', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>