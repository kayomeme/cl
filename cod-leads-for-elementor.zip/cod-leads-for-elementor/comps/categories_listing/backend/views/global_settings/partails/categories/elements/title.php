<div class="clfe-row" _attachedsection="title">
    <span class="dashicons dashicons-heading"></span>
    <span class="clfe-label-draggable">
        <?= Lang_clfe::_e('Category title', 'clfe') ?>
    </span>
    <div class="clfe-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>