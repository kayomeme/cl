<?php 
$generatorSettings = require 'style_generator.php';
?>
<div class="cl-row">
    <div class="cl-td-full">
        <div class="cl-sub-section">

            <div class="cl-row ">
                <div class="cl-th">
                    <?= Lang_cl::_e('Category container style', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php 
                        $styleManager->getAllCss('categories_item_style', $generatorSettings['categories_item_style']); 
                    ?>
                </div>
            </div>

            <div class="cl-row ">
                <div class="cl-th">
                    <?= Lang_cl::_e('Category image style', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php 
                        $styleManager->getAllCss('categories_image_style', $generatorSettings['categories_image_style']); 
                    ?>
                </div>
            </div>

            <div class="cl-row ">
                <div class="cl-th">
                    <?= Lang_cl::_e('Category title style', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php 
                        $styleManager->getAllCss('categories_title_style', $generatorSettings['categories_title_style']); 
                    ?>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Button text', 'cl') ?>
    </div>
    <div class="cl-td">
        <input type="text"  name="categories_bt_text" value="<?= $settings['categories_bt_text'] ?>" textAttachedTo=".cl-categories-list .cl-buy-button">
        
        <?php 
            $styleManager->getAllCss('categories_bt_style', $generatorSettings['categories_bt_style']); 
        ?>
        <div class="cl-sub-section">
            <div class="cl-th">
                <?= Lang_cl::_e('Show button icon', 'cl') ?>
            </div>
            <div class="cl-td">
                <?php
                $styleManager->getSwitchButton([
                    'name' => 'categories_show_bt_icon',
                    'value' => $settings['categories_show_bt_icon']
                ]);
                ?>
            </div>
        </div>
    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Sections Order', 'cl') ?>
    </div>
    <div class="cl-td">
        <input type="hidden"  name="categories_listing_elements_order" value="<?= $settings['categories_listing_elements_order'] ?>">

        <div class="cl-sub-section cl-categories-listing-elements">
            <?php 
                // if any new element you should add it here directly in this array with a position
                foreach ($categoriesElements as $element) {
                    include 'elements/'.$element.'.php';
                }
            ?>
        </div>
        <div class="cl-alert cl-alert-info">
                <?= Lang_cl::_e('To change the order of display on the frontend, simply drag and drop the elements in the list.', 'cl') ?>
        </div>
    </div>
</div>