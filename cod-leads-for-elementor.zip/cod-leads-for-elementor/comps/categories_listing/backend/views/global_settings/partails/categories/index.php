<div class="clfe-row">
    <div class="clfe-td-full">
        <div class="clfe-sub-section">

            <div class="clfe-row ">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Category container style', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Category container style', 'clfe'),
                            'styleAttachedTo' => '.clfe-categories-list .category_item',
                            'border' => 'yes',
                            'padding' => 'yes',
                            'background' => 'yes',
                            'box-shadow' => 'yes'
                        ];
                        $adminStyle->getAllCss('categories_item_style', $settings['categories_item_style'], $activeOptions); 
                    ?>
                </div>
            </div>

            <div class="clfe-row ">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Category image style', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Category image style', 'clfe'),
                            'styleAttachedTo' => '.clfe-categories-list .clfe-category-image img',
                            'border' => 'yes',
                        ];
                        $adminStyle->getAllCss('categories_image_style', $settings['categories_image_style'], $activeOptions); 
                    ?>
                </div>
            </div>

            <div class="clfe-row ">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Category title style', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Category title style', 'clfe'),
                            'styleAttachedTo' => '.clfe-categories-list .category_title',
                            'font' => 'yes',
                            'padding' => 'yes',
                        ];
                        $adminStyle->getAllCss('categories_title_style', $settings['categories_title_style'], $activeOptions); 
                    ?>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Button text', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <input type="text"  name="categories_bt_text" value="<?= $settings['categories_bt_text'] ?>" textAttachedTo=".clfe-categories-list .clfe-buy-button">
        
        <?php 
            $activeOptions = [
                'modalTitle' => Lang_clfe::__('Button style', 'clfe'),
                'styleAttachedTo' => '.clfe-categories-list .clfe-button-link',
                'predefined_width' => 'yes', 
                'font' => 'yes', 
                'border' => 'yes', 
                'padding' => 'yes', 
                'linear-gradient' => 'yes', 
                'box-shadow' => 'yes'
            ];
            $adminStyle->getAllCss('categories_bt_style', $settings['categories_bt_style'], $activeOptions); 
        ?>
        <div class="clfe-sub-section">
            <div class="clfe-th">
                <label>
                    <?= Lang_clfe::_e('Show button icon', 'clfe') ?>
                </label>
            </div>
            <div class="clfe-td">
                <label class="clfe-switch">
                  <input type="checkbox" <?= $settings['categories_show_bt_icon'] == 'yes' ? 'checked="checked"' : '' ?> >
                  <span class="clfe-slider clfe-round"></span>
                  <input type="hidden" name="categories_show_bt_icon" value="<?= $settings['categories_show_bt_icon'] ?>">
                </label>
                
            </div>
        </div>
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Sections Order', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <input type="hidden"  name="categories_listing_elements_order" value="<?= $settings['categories_listing_elements_order'] ?>">

        <div class="clfe-sub-section clfe-categories-listing-elements">
            <?php 
                // if any new element you should add it here directly in this array with a position
                foreach ($categoriesElements as $element) {
                    include 'elements/'.$element.'.php';
                }
            ?>
        </div>
        <div class="clfe-alert clfe-alert-info">
                <?= Lang_clfe::_e('To change the order of display on the frontend, simply drag and drop the elements in the list.', 'clfe') ?>
        </div>
    </div>
</div>