<div class="cl-row" _attachedsection="button_link">
    <span class="dashicons dashicons-cart"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Button link', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>