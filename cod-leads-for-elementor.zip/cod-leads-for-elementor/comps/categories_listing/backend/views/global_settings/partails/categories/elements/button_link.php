<div class="clfe-row" _attachedsection="button_link">
    <span class="dashicons dashicons-cart"></span>
    <span class="clfe-label-draggable">
        <?= Lang_clfe::_e('Button link', 'clfe') ?>
    </span>
    <div class="clfe-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>