<style>
    .clfe-categories-list {
        display: grid;
        /*grid-template-columns: repeat(2, minmax(0, 1fr));*/
        grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
        gap: 20px;
        row-gap: 30px;
    }
    .clfe-categories-list .category_item {
        <?= $settings['categories_item_style'] ?>
    }
    .clfe-category-image {
        height: 220px;
    }
    .clfe-categories-list .clfe-category-image img {
        position: relative;
        height: 100%;
        width: 100%;
        object-fit: cover;
        object-position: center center;
         <?= $settings['categories_image_style'] ?>
    }
    .category_title {
        display: block;
        <?= $settings['categories_title_style'] ?>
    }
    .clfe-categories-list .clfe-button-link {
        display: block;
        margin: auto;
        text-decoration: none;
        <?= $settings['categories_bt_style'] ?>
    }
@media screen and (max-width: 600px) {
    .clfe-categories-list {
        gap: 10px;
        row-gap: 20px;
    }
}
</style>