<style>
    .cl-categories-list {
        display: grid;
        /*grid-template-columns: repeat(2, minmax(0, 1fr));*/
        grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
        gap: 20px;
        row-gap: 30px;
    }
    .cl-categories-list .category_item {
        <?= $settings['categories_item_style'] ?>
    }
    .cl-category-image {
        height: 220px;
    }
    .cl-categories-list .cl-category-image img {
        position: relative;
        height: 100%;
        width: 100%;
        object-fit: cover;
        object-position: center center;
         <?= $settings['categories_image_style'] ?>
    }
    .category_title {
        display: block;
        <?= $settings['categories_title_style'] ?>
    }
    .cl-categories-list .cl-button-link {
        display: block;
        margin: auto;
        text-decoration: none;
        <?= $settings['categories_bt_style'] ?>
    }
@media screen and (max-width: 600px) {
    .cl-categories-list {
        gap: 10px;
        row-gap: 20px;
    }
}
</style>