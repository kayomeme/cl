<button tab="cl_categories_listing_tab">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_cl::_e('Categories listing', 'cl') ?>
</button>