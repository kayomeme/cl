<button tab="clfe_categories_listing_tab">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_clfe::_e('Categories listing', 'clfe') ?>
</button>