<?php

if( isset($_REQUEST['page']) && $_REQUEST['page'] == 'cl_global_settings' && isset($_REQUEST['compo']) && $_REQUEST['compo'] == 'categories_listing' ) {
    //wp_enqueue_style( MainApp_cl::$assetsPrefix.$hook['compName'], MainApp_cl::$compsUrl.$hook['compName']. '/backend/assets/css/mystore_bk.css', [], $assetsVersion );
    wp_enqueue_script( MainApp_cl::$assetsPrefix.$hook['compName'], MainApp_cl::$compsUrl.$hook['compName']. '/backend/assets/js/categories_listing_settings_bk.js', [], $assetsVersion );

}