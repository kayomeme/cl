(function( $ ) {
	'use strict';

        $(document).ready( function () {

            // dragable elemnts
            $(".cl-categories-listing-elements").sortable({
                update: function( event, ui ) {
                    var fieldsFileName = $('.cl-categories-listing-elements div').map(function () { return $(this).attr("_attachedsection"); });
                    $("input[name=categories_listing_elements_order]").val(fieldsFileName.toArray());
                    $("input[name=categories_listing_elements_order]").change();
                    
                    AdminFn_cl.autoSaveSettings();
                }
            });
            
        } );

})( jQuery );