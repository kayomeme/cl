(function( $ ) {
	'use strict';

        $(document).ready( function () {

            // dragable elemnts
            $(".clfe-categories-listing-elements").sortable({
                update: function( event, ui ) {
                    var fieldsFileName = $('.clfe-categories-listing-elements div').map(function () { return $(this).attr("_attachedsection"); });
                    $("input[name=categories_listing_elements_order]").val(fieldsFileName.toArray());
                    $("input[name=categories_listing_elements_order]").change();
                    
                    AdminFn_clfe.autoSaveSettings();
                }
            });
            
        } );

})( jQuery );