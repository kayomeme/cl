<?php
$dirPath = plugin_dir_path( __FILE__ );

// backend
if($isAdminAria) {
    // backend
    require_once $dirPath.'backend/controllers/categoriesListingSimulatorControllerBK.php';
    require_once $dirPath.'backend/controllers/categoriesListingSettingsControllerBK.php';
}