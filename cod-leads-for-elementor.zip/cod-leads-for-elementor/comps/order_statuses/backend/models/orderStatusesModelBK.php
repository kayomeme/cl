<?php



class OrderStatusesModelBK_clfe {
    private static $tableName = 'order_statuses';
    
    private static $tableColumns = [
        'id', 'slug', 'title', 'next_step', 'is_woo_status', 'is_default', 'is_active', 'position', 'cost', 'bg_color', 'text_color', 
        'settings_model_id', 'email_enabled', 'email_subject', 'email_content', 'email_attach_invoice', 
        'whatsapp_enabled', 'whatsapp_content', 'sms_enabled', 'sms_content', 
        'notification_delay', 'can_edit_order', 'can_delete_order'
    ];
    
    private static $requiredColumns = [
        'slug', 'title'
    ];

    public static function getAllBySettingsModelId($limit, $settingsModelId) {

        $query = "SELECT * FROM table_name where settings_model_id = {$settingsModelId}  ORDER BY ID ASC LIMIT {$limit}";
        $result = adminDB_clfe::getResultsAsObjects(self::$tableName, $query);

        return $result;
    }
    
    public static function getStatusesForOrder($limit, $settingsModelId) {

        $query = "SELECT id, slug, title, bg_color, text_color, cost FROM table_name where settings_model_id = {$settingsModelId}  ORDER BY ID ASC LIMIT {$limit}";
        $result = adminDB_clfe::getResultsAsArray(self::$tableName, $query);

        return $result;
    }

    public static function getStatusesForSheet($limit, $settingsModelId) {

        $query = "SELECT CONCAT(slug, '-', id) as id, slug, title, bg_color, text_color, cost FROM table_name where settings_model_id = {$settingsModelId}  ORDER BY ID ASC LIMIT {$limit}";
        $result = adminDB_clfe::getResultsAsArray(self::$tableName, $query);

        return $result;
    }
    
    
    
    public static function addNew($args) {
        foreach (self::$requiredColumns as $fieldName) {
            if ( !isset($args[$fieldName]) || empty($args[$fieldName]) ) {
                return response_clfe(0, Lang_clfe::__($fieldName, 'clfe').Lang_clfe::__(' is required', 'clfe'), null);
            }
        }
        
        $dataToAdd = [];
        foreach (self::$tableColumns as $fieldName) {
            if (isset($args[$fieldName])) {
                $dataToAdd[$fieldName] = $args[$fieldName];
            }
        }
        
        $response = adminDB_clfe::insert(self::$tableName, $dataToAdd);

        return $response;
    }
    
    public static function getSingle($id) {
        $response = adminDB_clfe::getSingleById(self::$tableName, $id);

        return $response;
    }
    
    public static function getSingleBySlug($slug) {
        $where = [
            'slug' => $slug
        ];
        
        $response = adminDB_clfe::getSingleByWhere(self::$tableName, $where, 'bg_color,text_color');

        return $response;
    }
    
    public static function update($statusId, $args) {
        $dataToUpdate = [];
        
        foreach (self::$tableColumns as $fieldName) {
            if (isset($args[$fieldName])) {
                $dataToUpdate[$fieldName] = $args[$fieldName];
            }
        }
        
        $where = [
            'id' => $statusId,
        ];
        

        $response = adminDB_clfe::update(self::$tableName, $dataToUpdate, $where);

        return $response;
    }
    
    public static function delete($orderStatusId) {
        $where = [
            'id' => $orderStatusId
        ];
        return adminDB_clfe::delete(self::$tableName, $where);
    }
    
    private static function getNextOrderID() {
        $lastOrderID = (int)publicDB_clfe::getVar('wc_orders', 'max(id)');
        
        $lastOrderID++;
        
        return $lastOrderID;
    }
}
