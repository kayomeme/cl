(function ($) {
    'use strict';

    $(document).ready(function () {
        
        $('.save-delete-order-status').on('click', function (ev) {
            ev.preventDefault();

            if( confirm(jsLang.delete_confirm_msg) == true ) {   
                $("input[name=status_id]").val( $(this).attr('status_id') );

                const clfe_controller = 'clfe_order_statuses';
                const clfe_action = 'clfe_delete_order_status';
                const formData = AdminFn_clfe.getFormDatas(clfe_action);
                AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
                AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);


                // Wait for the custom event before accessing the modified variable
                document.addEventListener(clfe_action + 'lastResponse', function (event) {

                    if (jsArgs.lastResponse.code == 1) {
                        const statusId = $("input[name=status_id]").val();
                        const statusElement = $('#status-' + statusId);

                        statusElement.css('background-color', '#ffebee').animate({opacity: 0}, 600, function() {
                            $(this).slideUp(200, function() {
                                $(this).remove();
                            });
                        });
                    }
                });
            
            }
        });
        
        
        
    });

})(jQuery);