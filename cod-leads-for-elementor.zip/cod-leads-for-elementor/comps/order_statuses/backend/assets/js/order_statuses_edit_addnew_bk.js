(function ($) {
    'use strict';

    $(document).ready(function () {

        $('#save-update-status').on('click', function (ev) {
            ev.preventDefault();

            //if( confirm(jsLang.delete_confirm_msg) == true ) {   }
            //$("input[name=status_id]").val( $(this).attr('status_id') );

            const clfe_controller = 'clfe_order_statuses';
            const clfe_action = 'clfe_update_order_status';
            const formData = AdminFn_clfe.getFormDatas(clfe_action);
            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);


            // Wait for the custom event before accessing the modified variable
            document.addEventListener(clfe_action + 'lastResponse', function (event) {
                console.log(jsArgs.lastResponse);
                if (jsArgs.lastResponse.code == 1) {

                }
            });
        });
        
        $('#save-new-order-status').on('click', function (ev) {
            ev.preventDefault();

            //if( confirm(jsLang.delete_confirm_msg) == true ) {   }
            //$("input[name=status_id]").val( $(this).attr('status_id') );

            const clfe_controller = 'clfe_order_statuses';
            const clfe_action = 'clfe_addnew_order_status';
            const formData = AdminFn_clfe.getFormDatas(clfe_action);
            AdminFn_clfe.beforeSendAjaxRequest(clfe_action);
            AdminFn_clfe.sendAjaxRequest(clfe_controller, clfe_action, formData);


            // Wait for the custom event before accessing the modified variable
            document.addEventListener(clfe_action + 'lastResponse', function (event) {
                console.log(jsArgs.lastResponse);
                if (jsArgs.lastResponse.code == 1) {

                }
            });
        });

    });

})(jQuery);

document.addEventListener('DOMContentLoaded', function () {
    // Handle notification toggles
    const toggles = document.querySelectorAll('input[type="checkbox"][name$="_enabled"]');
    toggles.forEach(toggle => {
        toggle.addEventListener('change', function () {
            const type = this.name.replace('_enabled', '');
            const details = document.querySelector(`.notification-details[data-type="${type}"]`);
            if (details) {
                details.style.display = this.checked ? 'block' : 'none';
            }
        });

        // Initial state
        toggle.dispatchEvent(new Event('change'));
    });

    // Preview color changes
    const bgColorInput = document.querySelector('.status-bg-color');
    const textColorInput = document.querySelector('.status-text-color');
    const preview = document.querySelector('.edit-status__preview');

    function updatePreview() {
        preview.style.backgroundColor = bgColorInput.value;
        preview.style.color = textColorInput.value;
    }

    bgColorInput.addEventListener('input', updatePreview);
    textColorInput.addEventListener('input', updatePreview);
});