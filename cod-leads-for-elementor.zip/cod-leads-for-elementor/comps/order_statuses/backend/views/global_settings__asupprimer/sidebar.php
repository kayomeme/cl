
<button tab="clfe_order_status_tab">
    <?= Lang_clfe::_e('List of Order Statuses', 'clfe') ?>
</button>