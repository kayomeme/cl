<div class="c-element" id="row-status-id-<?= $value['id'] ?>">
    <div class="clfe-accordion">
        <?= $value['slug'].' / '.$value['title'] ?>
        <div class="clfe-draggable-icons-container">
            <span class="dashicons dashicons-sort"></span>
        </div>
    </div> 
    
    <div class="clfe-accordion-panel c-element-panel" style="display: none">
            <div class="clfe-hide">
                <input type="hidden" elementName="id" isRequired="yes" value="<?= $value['id'] ?>" />
                <input type="hidden" elementName="settings_model_id" isRequired="yes" value="<?= $value['settings_model_id'] ?>" />
                <input type="hidden" elementName="is_woo_status" isRequired="yes" value="<?= $value['is_woo_status'] ?>" />
            </div>
            <div>
                <label><?= Lang_clfe::_e('Slug', 'clfe') ?></label><br/>
                <input type="text" elementName="slug" value="<?= $value['slug'] ?>" <?= $value['is_woo_status'] == 'yes' ?'disabled':'' ?> />
            </div>
            <div>
                <label><?= Lang_clfe::_e('Title', 'clfe') ?></label><br/>
                <input type="text" elementName="title" value="<?= $value['title'] ?>" />
            </div>
            <div>
                <label><?= Lang_clfe::_e('Cost', 'clfe') ?></label><br/>
                <input type="number" elementName="cost" isRequired="yes" value="<?= $value['cost'] ?>" placeholder="<?= Lang_clfe::_e('Status cost', 'clfe') ?>" />
            </div>

            <div>
                <label><?= Lang_clfe::_e('BG color', 'clfe') ?></label><br/>
                <input type="color" elementName="row_bg_color" isRequired="yes" value="<?= $value['row_bg_color'] ?>" />
            </div>
            <div>
                <label><?= Lang_clfe::_e('Text Color', 'clfe') ?></label><br/>
                <input type="color" elementName="row_text_color" isRequired="yes" value="<?= $value['row_text_color'] ?>" />
            </div>

            <div>
                <button type="button" class="clfe-image-selector">
                    <span>
                        <i class="dashicons dashicons-cloud-upload"></i>
                        <?= Lang_clfe::_e('Upload the thumbnail image', 'clfe') ?>
                    </span> <br/>
                    <img src="<?= isset($value['thumbnail_url']) ? $value['thumbnail_url'] : "" ?>" alt="" title="<?= Lang_clfe::_e('Select offer image', 'clfe') ?>" /> <br/>
                    <input type="hidden" class="clfe_img_id" elementName="thumbnail_id" value="<?= isset($value['thumbnail_id']) ? $value['thumbnail_id'] : "" ?>" />
                    <input type="hidden" class="clfe_img_url" elementName="thumbnail_url" value="<?= isset($value['thumbnail_url']) ? $value['thumbnail_url'] : "" ?>" />
                </button>
            </div>

            <div class="clfe-element-buttons">
                <?php if( $value['is_woo_status'] == 'yes' ) {  ?>
                    <div class="clfe-alert clfe-alert-infos">
                    <?= Lang_clfe::_e('This is a status system and cannot be deleted.', 'clfe') ?>
                    </div>
                <?php } else { ?>
                <button type="button" class="clfe-remove-status-bt deleteElement" skip_normal_delete="yes" status_id="<?= $value['id'] ?>" title="<?= Lang_clfe::_e('Remove this status', 'clfe') ?>">
                    <?= Lang_clfe::_e('Remove', 'clfe') ?>
                    <span class="dashicons dashicons-trash"></span>
                </button>
                <?php } ?>
            </div>
    </div>
</div>