<div id="clfe_order_status" class="clfe-single-tab order-status">

    <div class="clfe-row">
        <div class="clfe-td-full">
            <div class="dynamic-elements order-status-dynamic-elements" attachedSettingName="order_status">
                <?php
                foreach ($orderStatus['elements'] as $value) {
                    if (isset($value['slug'])) {
                        include 'partails/c_element_status.php';
                    }
                }
                ?>
            </div>
            <button type="button" class="clfe-add-dynamic-element" dynamic-elements-container="order-status">
                <span class="dashicons dashicons-plus"></span>
                <?= Lang_clfe::_e('Add new status', 'clfe') ?>
            </button>
            <input type="text"  name="order_status" value="<?= adminUtils_clfe::cleanInput($settings['order_status']) ?>">


            <div class="clfe-empty-elements" style="display: none !important">
                <?php
                $value = $defaultValue;
                include 'partails/c_element_status.php';
                ?>
            </div>
        </div>
    </div>
</div>

<div id="clfe_delete_order_status">
    <input type="text" name="status_id" />
    <div class="clfe-user-fedback">
        <div class="clfe-msg_box">
            <div class="clfe-wait_msg"></div>
            <div class="alert"></div>
        </div>
    </div>
</div>