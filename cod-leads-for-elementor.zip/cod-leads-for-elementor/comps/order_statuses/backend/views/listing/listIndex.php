<div class="statuses-wrapper">
    <div class="clfe-header-tab">
        <div class="clfe-title-tab">
            <?= Lang_clfe::_e('Order Statuses', 'clfe') ?>
        </div>
        <a href="<?= admin_url('admin.php?page=clfe_order_statuses&action=addnew') ?>" class="clfe-button clfe-addnew">
            <span class="dashicons dashicons-plus"></span>
            <?= Lang_clfe::_e('Add New Order status', 'clfe') ?>
        </a>
    </div>
    <div class="statuses">
        <?php foreach ($orderStatuses as $status): ?>
        <div id="status-<?= $status->id ?>" class="status" style="border-left-color: <?= $status->bg_color ?>">
                <div class="status__header">
                    <div class="status__title">
                        <h3>
                            <span class="status__badge" style="background: <?= $status->bg_color ?>; color: <?= $status->text_color ?>">
                            <?= $status->title ?>
                            </span>
                        </h3>
                        <!--<span class="status__badge" style="background: <?= $status->bg_color ?>; color: <?= $status->text_color ?>">
                        <?= $status->slug ?>
                        </span> -->
                        <?php if ($status->is_default): ?>
                            <span class="status__tag"><?= Lang_clfe::__('Default status', 'clfe') ?></span>
                        <?php endif; ?>

                        <span class="status__cost"><?= Lang_clfe::__('Cost: ', 'clfe') . $status->cost ?> USD</span>

                    </div>
                    <div class="status__actions">
                        <?php if ($status->can_edit_order): ?>
                            <a href="<?= admin_url('admin.php?page=clfe_order_statuses&action=edit&status_id=' . $status->id) ?>" class="clfe-button button button-primary">
                                <span class="dashicons dashicons-edit"></span>
                                <?= Lang_clfe::__('Edit', 'clfe') ?> 
                            </a>

                        <?php endif; ?>
                        <?php if (!$status->is_system_status): ?>
                            <button class="clfe-button status__btn--delete save-delete-order-status" status_id="<?= $status->id ?>">
                                <?= Lang_clfe::__('Delete', 'clfe') ?>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>


                <div class="status__details">
                    <?php if ($status->next_step): ?>
                        <div class="status__next-step">
                            <span class="dashicons dashicons-editor-help"></span>
                            <?= $status->next_step ?>
                        </div>
                    <?php endif; ?>

                    <!-- tmp desactivate 
                <div class="status__features">
                    <?php if ($status->email_enabled): ?>
                            <span class="status__feature">
                                <i class="icon icon-email"></i> 
                        <?= Lang_clfe::__('Email Enabled', 'clfe') ?>
                            </span>
                    <?php endif; ?>
                    
                    <?php if ($status->whatsapp_enabled): ?>
                            <span class="status__feature">
                                <i class="icon icon-whatsapp"></i> 
                        <?= Lang_clfe::__('WhatsApp Enabled', 'clfe') ?>
                            </span>
                    <?php endif; ?>
                    
                    <?php if ($status->sms_enabled): ?>
                            <span class="status__feature">
                                <i class="icon icon-sms"></i> 
                        <?= Lang_clfe::__('SMS Enabled', 'clfe') ?>
                            </span>
                    <?php endif; ?>

                    <span class="status__feature">
                        <i class="icon icon-palette"></i>
                        <span class="status__color" style="background: <?= $status->bg_color ?>"></span>
                    <?= Lang_clfe::__('Background', 'clfe') ?>
                    </span>

                    <span class="status__feature">
                        <i class="icon icon-text"></i>
                        <span class="status__color" style="background: <?= $status->text_color ?>"></span>
                    <?= Lang_clfe::__('Text', 'clfe') ?>
                    </span>
                </div>
                    -->

                </div>



            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Update the actions div with fixed positioning -->
<div id="clfe_delete_order_status">
    <div id="clfe-sticky-bottom-bar">
        <div class="clfe-container">
            <input type="hidden" name="status_id" clfe_ischanged="yes">
            <div class="clfe-user-fedback">
                <div class="clfe-msg_box">
                    <div class="clfe-wait_msg"></div>
                    <div class="alert"></div>
                </div>
            </div>
        </div>        
    </div>

</div>