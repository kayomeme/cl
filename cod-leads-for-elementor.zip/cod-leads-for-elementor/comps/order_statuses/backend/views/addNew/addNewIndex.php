<div id="clfe_addnew_order_status" class="edit-status__wrapper">
    <div class="edit-status__header">
        <h2><?= Lang_clfe::__('Add New Status', 'clfe') ?></h2>
        <div class="edit-status__preview" style="background: #ffffff; color: #000000">
            <?= Lang_clfe::__('Preview', 'clfe') ?>
        </div>
    </div>
    <form class="edit-status" method="POST" action="">
        <!-- Main Content -->
        <div class="edit-status__main">
            <div class="edit-status__section">

                    <div class="clfe-group clfe-group--flex">
                        <label><?= Lang_clfe::__('Title', 'clfe') ?></label>
                        <input type="text" name="title" required>
                    </div>

                    <div class="clfe-group clfe-group--flex">
                        <label><?= Lang_clfe::__('Slug', 'clfe') ?></label>
                        <input type="text" name="slug" maxlength="17" required>
                        <div class="clfe-alert clfe-alert-info">
                           <?= Lang_clfe::__('Slug must be 16 characters maximum in latin chars a-z. Once saved, the slug cannot be modified.', 'clfe') ?>
                        </div>
                    </div>  
                



                <div class="form-row-flex">
                    <div class="clfe-group clfe-group--flex">
                        <label><?= Lang_clfe::__('Cost', 'clfe') ?></label>
                        <input type="number" name="cost" value="0" step="1">
                    </div>

                    <div class="clfe-group clfe-group--flex">
                        <label><?= Lang_clfe::__('Background Color', 'clfe') ?></label>
                        <input type="color" name="bg_color" class="status-bg-color" value="#ffffff">
                    </div>

                    <div class="clfe-group clfe-group--flex">
                        <label><?= Lang_clfe::__('Text Color', 'clfe') ?></label>
                        <input type="color" name="text_color" class="status-text-color" value="#000000">
                    </div>
                </div>

                <div class="clfe-group">
                    <label><?= Lang_clfe::__('Next Step description', 'clfe') ?></label>
                    <input type="text" name="next_step">
                </div>

                <div class="form-row-flex">
                    <div class="clfe-group clfe-group--flex">
                        <label><?= Lang_clfe::__('Can Edit Orders', 'clfe') ?></label>
                        <select name="can_edit_order" class="clfe-select">
                            <option value="1"><?= Lang_clfe::__('Yes', 'clfe') ?></option>
                            <option value="0"><?= Lang_clfe::__('No', 'clfe') ?></option>
                        </select>
                    </div>
                    <div class="clfe-group clfe-group--flex">
                        <label><?= Lang_clfe::__('Can Delete Orders', 'clfe') ?></label>
                        <select name="can_delete_order" class="clfe-select">
                            <option value="1"><?= Lang_clfe::__('Yes', 'clfe') ?></option>
                            <option value="0"><?= Lang_clfe::__('No', 'clfe') ?></option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="edit-status__sidebar">
            <div class="edit-status__section">
                <h3><?= Lang_clfe::__('Notifications : when the status is affected', 'clfe') ?></h3>

                <!-- Email -->
                <div class="clfe-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="email_enabled">
                        <?= Lang_clfe::__('Enable Email Notifications', 'clfe') ?>
                    </label>
                </div>

                <div class="notification-details" data-type="email">
                    <div class="clfe-group">
                        <label><?= Lang_clfe::__('Email Subject', 'clfe') ?></label>
                        <input type="text" name="email_subject">
                    </div>

                    <div class="clfe-group">
                        <label><?= Lang_clfe::__('Email Content', 'clfe') ?></label>
                        <textarea name="email_content" rows="4"></textarea>
                    </div>

                    <div class="clfe-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="email_attach_invoice">
                            <?= Lang_clfe::__('Attach Invoice', 'clfe') ?>
                        </label>
                    </div>
                </div>

                <!-- WhatsApp -->
                <div class="clfe-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="whatsapp_enabled">
                        <?= Lang_clfe::__('Enable WhatsApp Notifications', 'clfe') ?>
                    </label>
                </div>

                <div class="notification-details" data-type="whatsapp">
                    <div class="clfe-group">
                        <label><?= Lang_clfe::__('WhatsApp Message', 'clfe') ?></label>
                        <textarea name="whatsapp_content" rows="4"></textarea>
                    </div>
                </div>

                <!-- SMS -->
                <div class="clfe-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="sms_enabled">
                        <?= Lang_clfe::__('Enable SMS Notifications', 'clfe') ?>
                    </label>
                </div>

                <div class="notification-details" data-type="sms">
                    <div class="clfe-group">
                        <label><?= Lang_clfe::__('SMS Message', 'clfe') ?></label>
                        <textarea name="sms_content" rows="2"></textarea>
                    </div>
                </div>

                <div class="clfe-group">
                    <label><?= Lang_clfe::__('Notification Delay (minutes)', 'clfe') ?></label>
                    <input type="number" name="notification_delay" value="0" min="0">
                </div>
            </div>
        </div>

        <!-- Actions -->
        <div id="clfe-sticky-bottom-bar">
            <div class="clfe-container">
                <div class="edit-status__actions">
                    <button id="save-new-order-status" type="submit" class="clfe-button button button-primary">
                        <?= Lang_clfe::__('Add Status', 'clfe') ?>
                    </button>
                    <a href="#" class="button button-secondary">
                        <?= Lang_clfe::__('Cancel', 'clfe') ?>
                    </a>
                </div>

                <div class="clfe-user-fedback">
                    <div class="clfe-msg_box">
                        <div class="clfe-wait_msg"></div>
                        <div class="alert"></div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>