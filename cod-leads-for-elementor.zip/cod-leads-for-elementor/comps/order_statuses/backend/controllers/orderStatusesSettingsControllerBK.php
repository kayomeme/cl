<?php

class OrderStatusesSettingsControllerBK_clfe
{
    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'order_statuses';
        $tabName = isset($urlArgs['tab']) ? $urlArgs['tab'] : 'general';

        //$orderStatus = jsonDecode_clfe($settings['order_statuses']);
        $orderStatus['elements'] = OrderStatusesModelBK_clfe::getAllBySettingsModelId($limit = 30,$settingsModelId);

        // this is used also for the empty element
        $defaultValue = [
            'id' => '0',
            'settings_model_id' => $settingsModelId,
            'is_woo_status' => 'no',
            'slug' => '',
            'title' => '',
            'cost' => '0',
            'row_bg_color' => '#ffffff',
            'row_text_color' => '#000000',
            'thumbnail_id' => '',
            'thumbnail_url' => '',
            'email_subject' => '',
            'email_content' => '',
            'whatsapp_content' => '',
            'sms_content' => ''
        ];
        if (!isset($orderStatus['elements']) || empty($orderStatus['elements'])) {
            $orderStatus['elements'][] = $defaultValue;
        }

        include AdminApp_clfe::$viewsPath . 'global_settings/index.php';
    }
    public static function save_settings($compoName, $settingsModelId, $args)
    {
        
        $sharedSettings = [];

        $orderStatus = jsonDecode_clfe($args['order_statuses']);
        if (!isset($orderStatus['elements']) || empty($orderStatus['elements'])) {
            $errorMsg = Lang_clfe::__('Please consider adding at least one status', 'clfe');
            return response_clfe(0, $errorMsg, null);
        }

        $existErrorAddOrUpdateStatus = false;
        foreach ($orderStatus['elements'] as $key => $status) {
            if ($status['id']) {
                $response = OrderStatusModelBK_clfe::update($status['id'], $status);
            } else {
                $response = OrderStatusModelBK_clfe::add($status);
                $orderStatus['elements'][$key]['id'] = $response->res['insert_id'];
            }

            if ($response->code == 0) {
                $existErrorAddOrUpdateStatus = true;
            }
        }

        $args['order_statuses'] = jsonEncode_clfe($orderStatus);

        AdminCompo_clfe::saveSettings($compoName, $settingsModelId, $args);

        if ($existErrorAddOrUpdateStatus) {
            $errorMsg = Lang_clfe::__('Error when adding or updating order statuses', 'clfe');
            return response_clfe(0, $errorMsg, null);
        }

        $sharedSettings['default_status'] = $orderStatus['elements'][0]['slug'];
        AdminCompo_clfe::saveSharedSettings($settingsModelId, $sharedSettings);


        $response = SheetControllerBk_clfe::synchronizeOrderStatusesWithGoogleSheets($orderStatus, $settingsModelId);

        if ($response->code == 1) {
            $response->res['reload'] = "yes";
        } else {
            $response->msg = Lang_clfe::__('Statuses are updated successfully, ', 'clfe') . $response->msg;
        }

        return $response;
    }

    private static function getSharedSettings($args)
    {
        $sharedSettings = [];

        return $sharedSettings;
    }
}
