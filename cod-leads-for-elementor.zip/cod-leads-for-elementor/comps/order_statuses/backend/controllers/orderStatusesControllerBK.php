<?php

/**
 */
class OrderStatusesControllerBK_clfe {

    /*
     * Ajax Routes
     */
    public static function routes($action, $args) {
        $response = false;
        switch ($action) {
            case 'clfe_update_order_status':
                $response = self::saveUpdate($args);
                break;
            case 'clfe_addnew_order_status':
                $response = self::saveAddNew($args);
                break;
            case 'clfe_delete_order_status':
                $response = self::deleteStatus($args);
                break;
        }

        return $response;
    }

    /*
     * http Routes
     */
    public function index() {
        $action = isset( $_REQUEST['action'] ) ? $_REQUEST['action'] : 'list';
        switch ($action) {
            case 'edit':
                self::editIndex();
                break;
            case 'addnew':
                self::addNewIndex();
                break;
            case 'list':
                self::listIndex();
                break;
        }
    }
    
    public static function addNewIndex() {
        $sharedSettings = AdminCompo_clfe::getSharedSettings($settingsModelId=0);
        $currencyCode = $sharedSettings['currency_code'];
       
        
        include MainApp_clfe::$compsPath.'order_statuses/backend/views/addnew/addNewIndex.php';
    }
    
    public static function saveAddNew($args) {
        
        $args['slug'] = adminUtils_clfe::sanitizeSlugstring($args['slug']);
        
        var_dump($args['slug']);
        
        $response = OrderStatusesModelBK_clfe::addNew($args);
        
        if( $response->code == 1 && isset( $response->res['insert_id'] )  ) {
            SheetControllerBk_clfe::synchronizeOrderStatusesWithGoogleSheets($settingsModelId = 0);
            $response->res['redirect_to'] = admin_url('admin.php?page=clfe_order_statuses&action=edit&status_id='.$response->res['insert_id']);
        }
        
        return $response;
    }
    
    public static function editIndex() {
        $statusId = isset($_GET['status_id']) ? intval($_GET['status_id']) : 0;
        if (!$statusId) {
            wp_die(Lang_clfe::__('Invalid status ID', 'clfe'));
        }

        // Get order status for edit
        $response = OrderStatusesModelBK_clfe::getSingle($statusId);
        if ($response->code === 0) {
            wp_die($response->msg);
        }

        $orderStatus = $response->res;
        
        
        $sharedSettings = AdminCompo_clfe::getSharedSettings($settingsModelId=0);
        $currencyCode = $sharedSettings['currency_code'];
       
        
        include MainApp_clfe::$compsPath.'order_statuses/backend/views/edit/editIndex.php';
    }
    
    public static function saveUpdate($args) {
        $statusId = isset( $args['id'] ) && $args['id'] > 0 ? $args['id'] : false;
        
        if( !$statusId ) {
            return response_clfe(0, Lang_clfe::__('Invalid status ID', 'clfe'), null);
        }
        
        $response = OrderStatusesModelBK_clfe::update($statusId, $args);
        
        if( $response->code == 1 && isset( $response->res['count_updated'] ) && $response->res['count_updated'] > 0  ) {
            SheetControllerBk_clfe::synchronizeOrderStatusesWithGoogleSheets($settingsModelId = 0);
        }
        
        return $response;
    }
   
    
    public static function listIndex() {
        $currentUrl = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
        $limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 50;
        $orderStatuses = OrderStatusesModelBK_clfe::getAllBySettingsModelId($limit, $settingsModelId = 0);
        
        include MainApp_clfe::$compsPath.'order_statuses/backend/views/listing/listIndex.php';
    }
    
    /*
     * The main function
    
    public function index($args) {
        $currentUrl = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);

        $limit = isset( $_REQUEST['limit'] ) ? $_REQUEST['limit'] : 50;
        $orders = OrderModelBK_clfe::GetLastOrders($limit);
        include MainApp_clfe::$compsPath.'order_status/backend/views/index.php';
    } */
    
    public static function deleteStatus($args) {
        
        $response = OrderStatusesModelBK_clfe::delete($args['status_id']);
        
        if( $response->code == 1 ) {
           // $response->res['reload'] = 1;
        }

        return $response;
    }
    

}
