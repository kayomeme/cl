<?php

if( !isset( $_REQUEST['page'] ) || $_REQUEST['page'] != 'clfe_order_statuses' ) {
    return;
}
if(  !isset( $_REQUEST['action'] ) ) {
    wp_enqueue_style( 'order_statuses_list_bk_css', MainApp_clfe::$compsUrl.'order_statuses/backend/assets/css/order_statuses_list_bk.css', [], $assetsVersion );
    wp_enqueue_script( 'order_statuses_list_bk_js', MainApp_clfe::$compsUrl.'order_statuses/backend/assets/js/order_statuses_list_bk.js', [], $assetsVersion );
}

if(  isset( $_REQUEST['action'] ) && ( $_REQUEST['action'] == 'edit' || $_REQUEST['action'] == 'addnew') ) {
    wp_enqueue_style( 'order_statuses_edit_bk_css', MainApp_clfe::$compsUrl.'order_statuses/backend/assets/css/order_statuses_edit_addnew_bk.css', [], $assetsVersion );
    wp_enqueue_script( 'order_statuses_edit_bk_js', MainApp_clfe::$compsUrl.'order_statuses/backend/assets/js/order_statuses_edit_addnew_bk.js', [], $assetsVersion );
}