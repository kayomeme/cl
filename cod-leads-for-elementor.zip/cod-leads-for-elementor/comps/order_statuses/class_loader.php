<?php
$dirPath = plugin_dir_path( __FILE__ );

// backend
if($isAdminAria) {
    require_once $dirPath  . 'backend/controllers/orderStatusesSettingsControllerBK.php';

    require_once $dirPath  . 'backend/controllers/orderStatusesControllerBK.php';
    require_once $dirPath  . 'backend/models/orderStatusesModelBK.php';
}

if($isPublicAria) {

}

