<?php
$dirPath = plugin_dir_path( __FILE__ );

if( $isAdminAria ) {    
    // Loads the controller for the header settings page in the WordPress admin area.
    require_once $dirPath . 'backend/controllers/headerSettingsControllerBK.php';
}

if($isPublicAria) {
    // Loads the controller responsible for displaying the header on the live site.
    require_once $dirPath . 'frontend/controllers/headerControllerFR.php';
}