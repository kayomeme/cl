(function( $ ) {
	'use strict';

    $(document).ready( function () {

        // Make the header blocks container sortable
        $("#cl-header-elements").sortable({
            update: function( event, ui ) {
                var blocksOrder = $('#cl-header-elements .cl-row').map(function () { 
                    return $(this).attr("_attachedsection"); 
                });
                $("input[name=header_blocks_order]").val(blocksOrder.toArray().join(','));
                $("input[name=header_blocks_order]").change();
                AdminFn_cl.autoSaveSettings();
            }
        });

        // --- Logic for Display Rules Overrides ---
        function updateHeaderOverridesJson() {
            var overrides = {};
            
            // 1. Handle the Global rule first
            var $globalContainer = $('#cl-header-overrides-container [data-override-scope="global"]');
            var globalSource = $globalContainer.find('[data-type="source"]').val();
            var globalCustomBlockId = $globalContainer.find('[data-type="custom_block_id"]').val();

            overrides.global = {
                'source': globalSource
            };
            if (globalSource === 'custom_block') {
                overrides.global['custom_block_id'] = globalCustomBlockId;
            }
            
            // 2. Handle the Page-Specific Overrides
            $('#cl-header-overrides-container .cl-sub-section').each(function() {
                var scope = $(this).data('override-scope');
                var isActive = $(this).find('[data-type="is_active"]').is(':checked');

                // Only add the override to the JSON if it's active
                if (isActive) {
                    var source = $(this).find('[data-type="source"]').val();
                    var customBlockId = $(this).find('[data-type="custom_block_id"]').val();

                    overrides[scope] = {
                        'is_active': 'yes',
                        'source': source
                    };

                    if (source === 'custom_block') {
                        overrides[scope]['custom_block_id'] = customBlockId;
                    }
                }
            });
            
            // 3. Update the hidden input field with the complete JSON string
            $('input[name="header_overrides"]').val(JSON.stringify(overrides)).trigger('change');
        }

        // Listen for changes on any override control (global or specific)
        $(document).on('change', '#cl-header-overrides-container input, #cl-header-overrides-container select, #cl-header-overrides-container textarea', function() {
            updateHeaderOverridesJson();
        });

        // Initial build of the JSON on page load to ensure it's correct
        updateHeaderOverridesJson();

    } );

})( jQuery );