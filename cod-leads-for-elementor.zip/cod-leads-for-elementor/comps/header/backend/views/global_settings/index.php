<div id="cl_display_rules_tab" class="cl-single-tab">
    <?php include 'blocks/display_rules/' . $settings['display_rules_version'] . '/index.php'; ?>
</div>

<div id="cl_top_bar_tab" class="cl-single-tab">
    <?php include 'blocks/top_bar/' . $settings['top_bar_version'] . '/index.php'; ?>
</div>

<div id="cl_main_header_tab" class="cl-single-tab">
    <?php include 'blocks/main_header/' . $settings['main_header_version'] . '/index.php'; ?>
</div>

<div id="cl_bottom_header_tab" class="cl-single-tab">
    <?php include 'blocks/bottom_header/' . $settings['bottom_header_version'] . '/index.php'; ?>
</div>

<div id="cl_header_blocks_order_tab" class="cl-single-tab">
    <?php include 'blocks_order.php'; ?>
</div>

<div style="display: none;">
    <input type="text" name="display_rules_version" value="<?= esc_attr($settings['display_rules_version']) ?>">
    <input type="text" name="header_blocks_order" value="<?= esc_attr($settings['header_blocks_order']) ?>">
    <input type="text" name="top_bar_version" value="<?= esc_attr($settings['top_bar_version']) ?>">
    <input type="text" name="main_header_version" value="<?= esc_attr($settings['main_header_version']) ?>">
    <input type="text" name="bottom_header_version" value="<?= esc_attr($settings['bottom_header_version']) ?>">
</div>