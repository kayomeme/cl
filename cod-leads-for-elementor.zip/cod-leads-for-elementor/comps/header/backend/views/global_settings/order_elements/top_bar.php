<div class="cl-row" _attachedsection="top_bar">
    <span class="dashicons dashicons-cart"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Top bar', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>