<div class="cl-row" _attachedsection="main_header">
    <span class="dashicons dashicons-cart"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Main header', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>