<!-- Sub-tab Navigation -->
<ul class="cl-sidetab-submenu" attachedButonTab="cl_main_header_tab">
    <li tab="cl_main_header_container">
        <span class="dashicons dashicons-align-wide"></span>
        <?= Lang_cl::_e('Container', 'cl') ?>
    </li>
    <li tab="cl_main_header_logo">
        <span class="dashicons dashicons-lightbulb"></span>
        <?= Lang_cl::_e('Logo', 'cl') ?>
    </li>
    <li tab="cl_main_header_main_nav">
        <span class="dashicons dashicons-menu"></span>
        <?= Lang_cl::_e('Main Navigation', 'cl') ?>
    </li>
    <li tab="cl_main_header_end_menu">
        <span class="dashicons dashicons-menu-alt"></span>
        <?= Lang_cl::_e('End Menu', 'cl') ?>
    </li>
</ul>

<!-- Sub-tab Content: Container -->
<div id="cl_main_header_container" class="cl-subtab">
    <div class="cl-row">  
        <div class="cl-th">  
            <?= Lang_cl::_e('Main Header Section', 'cl') ?>  
        </div>  
        <div class="cl-td">  
            <div class="cl-sub-section">  
                <div class="cl-row">  
                    <div class="cl-th">  
                        <?= Lang_cl::_e('Is Active', 'cl') ?>  
                    </div>  
                    <div class="cl-td cl-style-container">  
                        <?php
                        $styleManager->getSwitchButton(['name' => 'main_header_is_active', 'value' => $settings['main_header_is_active']]);
                        $styleManager->getAllCss('main_header_container_style');
                        ?>  
                    </div>  
                </div>  
                <div class="cl-row">  
                    <div class="cl-th">  
                        <?= Lang_cl::_e('Header Layout', 'cl') ?>  
                    </div>  
                    <div class="cl-td">  
                        <select name="main_header_layout">  
                            <option value="logo-start-mainmenu-start-endmenu-end" <?= selected($settings['main_header_layout'], 'logo-start-mainmenu-start-endmenu-end') ?>>  
                                <?= Lang_cl::_e('Logo Start, Main Menu Start, End Menu End', 'cl') ?>  
                            </option>  
                            <option value="logo-start-mainmenu-center-endmenu-end" <?= selected($settings['main_header_layout'], 'logo-start-mainmenu-center-endmenu-end') ?>>  
                                <?= Lang_cl::_e('Logo Start, Main Menu Center, End Menu End', 'cl') ?>  
                            </option>  
                            <option value="logo-center-mainmenu-start-endmenu-end" <?= selected($settings['main_header_layout'], 'logo-center-mainmenu-start-endmenu-end') ?>>  
                                <?= Lang_cl::_e('Logo Center, Main Menu Start, End Menu End', 'cl') ?>  
                            </option>  
                        </select>  
                    </div>  
                </div>  
                <?php
                $styleManager->getSingleCss('background-color', 'main_header_container_style');
                $styleManager->getSingleCss('max-width', 'main_header_container_style');
                $styleManager->getSingleCss('margin-top', 'main_header_container_style');
                $styleManager->getSingleCss('margin-bottom', 'main_header_container_style');
                ?>  
            </div>  
        </div>  
    </div>
    <div class="cl-row">  
        <div class="cl-th">  
            <?= Lang_cl::_e('Sticky Header Section', 'cl') ?>  
        </div>  
        <div class="cl-td">  
            <div class="cl-sub-section">  
                <div class="cl-row">  
                    <div class="cl-th">  
                        <?= Lang_cl::_e('Activate Sticky', 'cl') ?>  
                    </div>  
                    <div class="cl-td">  
                        <?php
                        $styleManager->getSwitchButton(['name' => 'main_header_is_sticky', 'value' => $settings['main_header_is_sticky']]);
                        ?>  
                    </div>  
                </div>  
                <?php
                $styleManager->getAllCss('main_header_sticky_style');
                $styleManager->getSingleCss('background-color', 'main_header_sticky_style');
                $styleManager->getSingleCss('margin-top', 'main_header_sticky_style');
                $styleManager->getSingleCss('margin-bottom', 'main_header_sticky_style');
                ?>  
                <div class="cl-alert cl-alert-info">  
                    <?= Lang_cl::_e('These styles will only apply when the header becomes sticky.', 'cl') ?>  
                </div>  
            </div>  
        </div>  
    </div>
</div>

<!-- Sub-tab Content: Logo -->
<div id="cl_main_header_logo" class="cl-subtab">
    <div class="cl-row">  
        <div class="cl-sub-section">  
            <div class="cl-row">  
                <div class="cl-th">  
                    <?= Lang_cl::_e('Logo Section : is active', 'cl') ?>  
                </div>  
                <div class="cl-td cl-style-container">  
                    <?php
                    $styleManager->getSwitchButton(['name' => 'logo_is_active', 'value' => $settings['logo_is_active']]);
                    $styleManager->getAllCss('logo_container_style');
                    ?>  
                </div>  
            </div>  
            <div class="cl-row">  
                <div class="cl-th"><?= Lang_cl::_e('Logo Image', 'cl') ?></div>  
                <div class="cl-td">  
                    <div class="cl-sub-section">  
                        <div class="cl-row">  
                            <div class="cl-th">  
                                <?= Lang_cl::_e('Is active', 'cl') ?>  
                            </div>  
                            <div class="cl-td cl-style-container">  
                                <?php
                                $styleManager->getSwitchButton(['name' => 'logo_image_is_active', 'value' => $settings['logo_image_is_active']]);
                                $styleManager->getAllCss('logo_image_style');
                                ?>  
                            </div>  
                        </div>  
                        <div class="cl-row">  
                            <div class="cl-th"><?= Lang_cl::_e('Select', 'cl') ?></div>  
                            <div class="cl-td cl-style-container">  
                                <button type="button" class="cl-image-selector">  
                                    <img src="<?= esc_url($settings['logo_image_url']) ?>" alt="<?= Lang_cl::_e('Select image', 'cl') ?>" />  
                                    <input type="hidden" class="cl_img_id" name="logo_image_id" value="<?= esc_attr($settings['logo_image_id']) ?>" />  
                                    <input type="hidden" class="cl_img_url" name="logo_image_url" value="<?= esc_url($settings['logo_image_url']) ?>" />  
                                </button>  
                            </div>  
                        </div>  
                        <?php $styleManager->getSingleCss('max-width', 'logo_image_style'); ?>  
                    </div>  
                </div>  
            </div>  
            <div class="cl-row">  
                <div class="cl-th"><?= Lang_cl::_e('Logo Text', 'cl') ?></div>  
                <div class="cl-td">  
                    <div class="cl-sub-section">  
                        <div class="cl-row">  
                            <div class="cl-th">  
                                <?= Lang_cl::_e('Is active', 'cl') ?>  
                            </div>  
                            <div class="cl-td cl-style-container">  
                                <?php
                                $styleManager->getSwitchButton(['name' => 'logo_text_is_active', 'value' => $settings['logo_text_is_active']]);
                                $styleManager->getAllCss('logo_text_style');
                                ?>  
                            </div>  
                        </div>  
                        <div class="cl-row">
                            <div class="cl-td-full">
                                <input type="text" name="logo_text" value="<?= esc_attr($settings['logo_text']) ?>" placeholder="<?= Lang_cl::_e('Shop Name', 'cl') ?>">  
                            </div>
                        </div>
                        <?= $styleManager->getPositionCss('logo_text_position_style'); ?>  
                    </div>  
                </div>  
            </div>  
        </div>  
    </div>
</div>

<!-- Sub-tab Content: Main Navigation -->
<div id="cl_main_header_main_nav" class="cl-subtab">

    <div class="cl-row">  
        <div class="cl-th">  
            <?= Lang_cl::_e('Main Navigation', 'cl') ?>  
        </div>  
        <div class="cl-td">  
            <div class="cl-sub-section">  
                <div class="cl-row">  
                    <div class="cl-th">  
                        <?= Lang_cl::_e('Is active', 'cl') ?>  
                    </div>  
                    <div class="cl-td cl-style-container">  
                        <?php
                        $styleManager->getSwitchButton(['name' => 'main_nav_is_active', 'value' => $settings['main_nav_is_active']]);
                        $styleManager->getAllCss('main_nav_container_style');
                        ?>  
                    </div>  
                </div>  
                <div class="cl-row">  
                    <div class="cl-th"><?= Lang_cl::_e('Select Menu', 'cl') ?></div>  
                    <div class="cl-td">  
                        <select name="main_nav_menu_id">  
                            <option value=""><?= Lang_cl::_e('-- Select a Menu --', 'cl') ?></option>  
                            <?php foreach ($wpMenus as $menu) : ?>  
                                <option value="<?= esc_attr($menu->term_id) ?>" <?= selected($settings['main_nav_menu_id'], $menu->term_id, false) ?>>  
                                    <?= esc_html($menu->name) ?>  
                                </option>  
                            <?php endforeach; ?>  
                        </select>  
                    </div>  
                </div>  
            </div>  
        </div>  
    </div>

    <div class="admin_toggle_block" is_open="no">
        <div class="admin_toggle_header"><?= Lang_cl::_e('Main Navigation : Sticky State', 'cl') ?></div>
        <div class="admin_toggle_body" show_in_open>
            <div class="cl-row">  
                <div class="cl-th">  
                    <?= Lang_cl::_e('Main Navigation', 'cl') ?>  
                </div>  
                <div class="cl-td">  
                    <div class="cl-sub-section">  
                        <?php
                        $styleManager->getAllCss('main_nav_sticky_style');
                        $styleManager->getSingleCss('color', 'main_nav_sticky_style');
                        ?>
                    </div>  
                </div>  
            </div>
        </div>
    </div>

    <div class="admin_toggle_block" is_open="no">
        <div class="admin_toggle_header"><?= Lang_cl::_e('Dynamic "More" Menu (FlexNav)', 'cl') ?></div>
        <div class="admin_toggle_body" show_in_open>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Enable FlexNav', 'cl') ?>
                </div>
                <div class="cl-td">
                    <div class="cl-sub-section">
                        <div class="cl-row">
                            <div class="cl-th">
                                <?= Lang_cl::_e('Is Active', 'cl') ?>
                            </div>
                            <div class="cl-td">
                                <?php $styleManager->getSwitchButton(['name' => 'main_nav_flexnav_is_active', 'value' => $settings['main_nav_flexnav_is_active']]); ?>
                            </div>
                                <div class="cl-alert cl-alert-info">
                                    <?= Lang_cl::_e("Automatically moves menu items into a 'More' dropdown when there isn't enough space.", 'cl') ?>
                                </div>
                        </div>
                        
                        <div class="cl-row">
                            <div class="cl-th-full">
                                <?= Lang_cl::_e('More Button [text & icon]', 'cl') ?>
                            </div>
                            <div class="cl-td-full">
                                <input type="text" name="main_nav_flexnav_more_button_text" value="<?= esc_attr($settings['main_nav_flexnav_more_button_text']) ?>" placeholder="<?= Lang_cl::_e('More', 'cl') ?>">
                                <?php
                                IconsSelectorBK_cl::getButton(['name' => 'main_nav_flexnav_more_button_icon_id', 'value' => $settings['main_nav_flexnav_more_button_icon_id']]);
                                $styleManager->getAllCss('main_nav_flexnav_more_button_style');
                                ?>
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th">
                                <?= Lang_cl::_e('Count Bubble Style', 'cl') ?>
                            </div>
                            <div class="cl-td">
                                <?php $styleManager->getAllCss('main_nav_flexnav_count_style'); ?>
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th">
                                <?= Lang_cl::_e('Dropdown Container', 'cl') ?>
                            </div>
                            <div class="cl-td">
                                <?php $styleManager->getAllCss('main_nav_flexnav_dropdown_style'); ?>
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th">
                                <?= Lang_cl::_e('Dropdown Items', 'cl') ?>
                            </div>
                            <div class="cl-td">
                                <?php $styleManager->getAllCss('main_nav_flexnav_dropdown_item_style'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Sub-tab Content: End Menu -->
<div id="cl_main_header_end_menu" class="cl-subtab">
    <div class="cl-row">  
        <div class="cl-th">  
            <?= Lang_cl::_e('End Menu Section', 'cl') ?>  
        </div>  
        <div class="cl-td">   
            <div class="cl-sub-section">  
                <div class="cl-row">  
                    <div class="cl-th">  
                        <?= Lang_cl::_e('Is active', 'cl') ?>  
                    </div>  
                    <div class="cl-td">  
                        <?php $styleManager->getSwitchButton(['name' => 'end_menu_is_active', 'value' => $settings['end_menu_is_active']]); ?>  
                    </div>  
                </div>  
                <div class="cl-row">
                    <div class="cl-th"><?= Lang_cl::_e('Menu', 'cl') ?></div>
                    <div class="cl-td">
                        <div class="cl-sub-section">
                            <div class="cl-row">  
                                <div class="cl-th"><?= Lang_cl::_e('Select Menu', 'cl') ?></div>  
                                <div class="cl-td">  
                                    <select name="end_menu_menu_id">  
                                        <option value=""><?= Lang_cl::_e('-- Select a Menu --', 'cl') ?></option>  
                                        <?php foreach ($wpMenus as $menu) : ?>  
                                            <option value="<?= esc_attr($menu->term_id) ?>" <?= selected($settings['end_menu_menu_id'], $menu->term_id, false) ?>>  
                                                <?= esc_html($menu->name) ?>  
                                            </option>  
                                        <?php endforeach; ?>  
                                    </select>  
                                </div>  
                            </div>
                            <div class="cl-row">  
                                <div class="cl-th">  
                                    <?= Lang_cl::_e('Style', 'cl') ?>  
                                </div>  
                                <div class="cl-td cl-style-container">  
                                    <?php $styleManager->getAllCss('end_menu_container_style'); ?>  
                                </div>  
                            </div> 
                        </div>
                    </div>
                </div>
            </div>  
        </div>
    </div>

    <div class="admin_toggle_block" is_open="no">
        <div class="admin_toggle_header"><?= Lang_cl::_e('End Menu Section : Sticky State', 'cl') ?></div>
        <div class="admin_toggle_body" show_in_open>
            <div class="cl-row">  
                <div class="cl-th">  
                    <?= Lang_cl::_e('End Menu', 'cl') ?>  
                </div>  
                <div class="cl-td">  
                    <div class="cl-sub-section">  
                        <?php
                        $styleManager->getAllCss('end_menu_sticky_style');
                        $styleManager->getSingleCss('color', 'end_menu_sticky_style');
                        ?>
                    </div>  
                </div>  
            </div>
        </div>
    </div>
    
    <div class="admin_toggle_block" is_open="no">
        <div class="admin_toggle_header"><?= Lang_cl::_e('End Menu : Additional Items', 'cl') ?></div>
        <div class="admin_toggle_body" show_in_open>
                <div class="cl-row">
                    <div class="cl-th"><?= Lang_cl::_e('Cart icon & text', 'cl') ?></div>
                    <div class="cl-td">
                        <div class="cl-sub-section">
                            <div class="cl-row">
                                <div class="cl-th">
                                    <?= Lang_cl::_e('Is active', 'cl') ?>
                                </div>
                                <div class="cl-td cl-style-container">
                                    <?php
                                    $styleManager->getSwitchButton(['name' => 'end_menu_cart_icon_is_active', 'value' => $settings['end_menu_cart_icon_is_active']]);
                                    $styleManager->getAllCss('end_menu_cart_icon_container_style');
                                    ?>
                                </div>
                            </div>
                            <div class="cl-row">
                                <div class="cl-th"><?= Lang_cl::_e('Icon', 'cl') ?></div>
                                <div class="cl-td cl-style-container">
                                    <?php IconsSelectorBK_cl::getButton(['name' => 'end_menu_cart_icon_id', 'value' => $settings['end_menu_cart_icon_id']]); ?>
                                </div>
                            </div>
                            <div class="cl-row">
                                <div class="cl-th">
                                    <?= Lang_cl::_e('Text', 'cl') ?>
                                </div>
                                <div class="cl-td">
                                    <input type="text" name="end_menu_cart_icon_text" value="<?= esc_attr($settings['end_menu_cart_icon_text']) ?>" placeholder="<?= Lang_cl::_e('Cart', 'cl') ?>">
                                </div>
                            </div>
                            <div class="cl-row">
                                <div class="cl-th">
                                    <?= Lang_cl::_e('Count Bubble', 'cl') ?>
                                </div>
                                <div class="cl-td cl-style-container">
                                    <?php
                                    $styleManager->getPositionCss('end_menu_cart_count_position_style');
                                    $styleManager->getAllCss('end_menu_cart_count_style');
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </div>

    <div class="admin_toggle_block" is_open="no">
        <div class="admin_toggle_header"><?= Lang_cl::_e('Dynamic "More" Menu (FlexNav)', 'cl') ?></div>
        <div class="admin_toggle_body" show_in_open>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Enable FlexNav', 'cl') ?>
                </div>
                <div class="cl-td">
                    <div class="cl-sub-section">
                        <div class="cl-row">
                            <div class="cl-th">
                                <?= Lang_cl::_e('Is Active', 'cl') ?>
                            </div>
                            <div class="cl-td">
                                <?php $styleManager->getSwitchButton(['name' => 'end_menu_flexnav_is_active', 'value' => $settings['end_menu_flexnav_is_active']]); ?>
                            </div>
                            <div class="cl-alert cl-alert-info">
                                <?= Lang_cl::_e("Automatically moves menu items into a 'More' dropdown when there isn't enough space.", 'cl') ?>
                            </div>
                        </div>
                        
                        <div class="cl-row">
                            <div class="cl-th-full">
                                <?= Lang_cl::_e('More Button [text & icon]', 'cl') ?>
                            </div>
                            <div class="cl-td-full">
                                <input type="text" name="end_menu_flexnav_more_button_text" value="<?= esc_attr($settings['end_menu_flexnav_more_button_text']) ?>" placeholder="<?= Lang_cl::_e('More', 'cl') ?>">
                                <?php
                                IconsSelectorBK_cl::getButton(['name' => 'end_menu_flexnav_more_button_icon_id', 'value' => $settings['end_menu_flexnav_more_button_icon_id']]);
                                $styleManager->getAllCss('end_menu_flexnav_more_button_style');
                                ?>
                            </div>
                        </div>
                        
                        <div class="cl-row">
                            <div class="cl-th">
                                <?= Lang_cl::_e('Count Bubble Style', 'cl') ?>
                            </div>
                            <div class="cl-td">
                                <?php $styleManager->getAllCss('end_menu_flexnav_count_style'); ?>
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th">
                                <?= Lang_cl::_e('Dropdown Container', 'cl') ?>
                            </div>
                            <div class="cl-td">
                                <?php $styleManager->getAllCss('end_menu_flexnav_dropdown_style'); ?>
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-th">
                                <?= Lang_cl::_e('Dropdown Items', 'cl') ?>
                            </div>
                            <div class="cl-td">
                                <?php $styleManager->getAllCss('end_menu_flexnav_dropdown_item_style'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>