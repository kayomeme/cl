<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Top Bar Section', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    // Renders the On/Off switch
                    $styleManager->getSwitchButton([
                        'name' => 'top_bar_is_active',
                        'value' => $settings['top_bar_is_active']
                    ]);
                    
                    // Renders the style editor button for the container
                    $styleManager->getAllCss('top_bar_container_style'); 
                    ?>
                </div>
            </div>
            
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Custom Message', 'cl') ?>
                </div>
                <div class="cl-td">
                    <input type="text" 
                           name="top_bar_custom_message" 
                           value="<?= esc_attr($settings['top_bar_custom_message']) ?>" 
                           placeholder="<?= Lang_cl::_e('Enter your message here', 'cl') ?>"
                           style="width: 100%;">
                </div>
            </div>
            
            <!-- Sticky Setting -->
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Make top bar Sticky', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'top_bar_is_sticky',
                        'value' => $settings['top_bar_is_sticky']
                    ]);
                    ?>
                    <div class="cl-alert cl-alert-info">
                        <?= Lang_cl::_e('When enabled, the top bar will stick to the top when scrolling past it', 'cl') ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>