<?php
/**
 * Helper function to render the source selection UI for the header (JSON method).
 */
function render_header_source_selector_for_json($scope, $current_rule, $custom_blocks) {
    $selected_source = isset($current_rule['source']) ? $current_rule['source'] : 'plugin';
    $selected_block_id = isset($current_rule['custom_block_id']) ? $current_rule['custom_block_id'] : '';
?>
    <div class="cl-row">
        <div class="cl-th"><?= Lang_cl::_e('Header Source', 'cl') ?></div>
        <div class="cl-td">
            <select data-scope="<?= $scope ?>" data-type="source" blocks-to-hide=".<?= $scope ?>-header-source-fields">
                <option value="plugin" block-to-show=".<?= $scope ?>-header-source-plugin" <?= selected($selected_source, 'plugin', false) ?>>
                    <?= Lang_cl::_e('Cod Leads Header', 'cl') ?>
                </option>
                <option value="theme" block-to-show=".<?= $scope ?>-header-source-theme" <?= selected($selected_source, 'theme', false) ?>>
                    <?= Lang_cl::_e('Theme Header', 'cl') ?>
                </option>
                <option value="hide" block-to-show=".<?= $scope ?>-header-source-hide" <?= selected($selected_source, 'hide', false) ?>>
                    <?= Lang_cl::_e('Hide Header', 'cl') ?>
                </option>
                <option value="custom_block" block-to-show=".<?= $scope ?>-header-source-custom_block" <?= selected($selected_source, 'custom_block', false) ?>>
                    <?= Lang_cl::_e('Custom Block', 'cl') ?>
                </option>
            </select>
        </div>
    </div>
    <div class="cl-row <?= $scope ?>-header-source-fields <?= $scope ?>-header-source-custom_block">
        <div class="cl-th"><?= Lang_cl::_e('Select Block', 'cl') ?></div>
        <div class="cl-td">
            <select data-scope="<?= $scope ?>" data-type="custom_block_id">
                <option value=""><?= Lang_cl::_e('-- Select a Custom Block --', 'cl') ?></option>
                <?php foreach ($custom_blocks as $block) { ?>
                    <option value="<?= esc_attr($block->ID) ?>" <?= selected($selected_block_id, $block->ID, false) ?>>
                        <?= esc_html($block->post_title) ?>
                    </option>
                <?php } ?>
            </select>
        </div>
    </div>
<?php
}

$overrides = json_decode($settings['header_overrides'], true);
if (!is_array($overrides)) { $overrides = array(); }
$global_rule = isset($overrides['global']) ? $overrides['global'] : array('source' => 'plugin');
?>

<div id="cl-header-overrides-container">
    <!-- Global Display Rules -->
    <div class="cl-row">
        <div class="cl-th">
            <?= Lang_cl::_e('Global Display Rules', 'cl') ?>
            <div class="cl-alert cl-alert-info">
                <?= Lang_cl::_e('This is the default header that will be used across your entire website, unless overridden by a page-specific rule below.', 'cl') ?>
            </div>
        </div>
        <div class="cl-td">
            <div class="admin_toggle_block" is_open="yes">
                <div class="admin_toggle_header"><?= Lang_cl::_e('Global Scope', 'cl') ?></div>
                <div class="admin_toggle_body" show_in_open>
                    <div class="cl-sub-section" data-override-scope="global">
                        <?php render_header_source_selector_for_json('global', $global_rule, $custom_blocks); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Page Specific Overrides -->
    <div class="cl-row">
        <div class="cl-th">
            <?= Lang_cl::_e('Page Specific Overrides', 'cl') ?>
            <div class="cl-alert cl-alert-info">
                <?= Lang_cl::_e('Define different headers for specific page types. If an override is enabled, it will be used instead of the global rule.', 'cl') ?>
            </div>
        </div>
        <div class="cl-td">
            <?php 
            foreach ($override_pages as $scope => $label) {
                $current_override = isset($overrides[$scope]) ? $overrides[$scope] : array();
                $is_active = isset($current_override['is_active']) && $current_override['is_active'] === 'yes';
            ?>
                <div class="admin_toggle_block" is_open="no">
                    <div class="admin_toggle_header"><?= $label ?></div>
                    <div class="admin_toggle_body" show_in_open>
                        <div class="cl-sub-section" data-override-scope="<?= $scope ?>">
                            <div class="cl-row">
                                <div class="cl-th"><?= Lang_cl::_e('Enable Override', 'cl') ?></div>
                                <div class="cl-td">
                                    <label class="cl-switch">
                                      <input type="checkbox" class="state-on-off" data-scope="<?= $scope ?>" data-type="is_active" <?= checked($is_active, true, false) ?>>
                                      <span class="cl-slider cl-round"></span>
                                    </label>
                                </div>
                            </div>
                            <?php render_header_source_selector_for_json($scope, $current_override, $custom_blocks); ?>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
        <input type="hidden" name="header_overrides" value="<?= esc_attr($settings['header_overrides']) ?>">
    </div>
</div>