<style>
    .cl-header-main {
        display: flex;
        align-items: center;
        width: 100%;
        flex-wrap: nowrap;
        position: relative;
        gap: 20px;
        <?= $settings['main_header_container_style'] ?>
        margin-left: auto;
        margin-right: auto;
    }
    .cl-header-main .main-nav, .cl-header-main .end-menu {
        flex-grow: 1;
    }

    /* Sticky State */
    .is-sticky .cl-header-main {
        <?= $settings['main_header_sticky_style'] ?>
    }

    /* --- LAYOUTS --- */
    .layout-logo-start-mainmenu-start-endmenu-end .main-nav {
        justify-content: flex-start;
    }
    .layout-logo-start-mainmenu-center-endmenu-end {
        justify-content: space-between;
    }
    .layout-logo-start-mainmenu-center-endmenu-end .main-nav {
        justify-content: center;
    }
    .layout-logo-center-mainmenu-start-endmenu-end {
        justify-content: space-between;
    }
    .cl-header-main.layout-logo-center-mainmenu-start-endmenu-end .main-nav {
        width: min-content;
    }

    /* Logo Styles */
    .cl-header-main .logo-container {
        position: relative;
        <?= $settings['logo_container_style'] ?>
    }
    .cl-header-main .logo-container img {
        display: block;
        height: auto;
        <?= $settings['logo_image_style'] ?>
    }
    .cl-header-main .logo-container .logo-text {
        <?= $settings['logo_text_style'] ?>
        <?= $settings['logo_text_position_style'] ?>
        width: max-content;
    }
    .cl-header-main .logo-container a {
        text-decoration: none;
        display: inline-block;
    }

    /* Navigation Styles */
    .cl-header-main .main-nav,
    .cl-header-main .end-menu {
        display: flex;
        align-items: center;
        flex-wrap: nowrap;
        width: max-content;
    }
    .cl-header-main .main-nav {
        <?= $settings['main_nav_container_style'] ?>
    }
    .cl-header-main .end-menu {
        gap: 15px;
        justify-content: flex-end;
        <?= $settings['end_menu_container_style'] ?>
    }

    /* Sticky State Styles */
    .cl-site-header.is-sticky .cl-header-main .main-nav {
        <?= $settings['main_nav_sticky_style'] ?>
    }
    .cl-site-header.is-sticky .cl-header-main .end-menu {
        <?= $settings['end_menu_sticky_style'] ?>
    }

    /* Common Menu UL Styles */
    .cl-header-main .main-nav ul,
    .cl-header-main .end-menu ul {
        margin: 0;
        padding: 0;
        list-style: none;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        column-gap: 20px;
    }
    .cl-header-main .main-nav ul a,
    .cl-header-main .end-menu ul a {
        text-decoration: none;
        color: inherit;
    }
    
    /* Cart Icon Styles */
    .cl-header-main .end-menu .cl-cart-icon-container {
        display: flex;
        align-items: center;
        gap: 1px;
        text-decoration: none;
        color: inherit;
        position: relative;
        <?= $settings['end_menu_cart_icon_container_style'] ?>
    }
    .cl-header-main .end-menu .cl_count_products {
        <?= $settings['end_menu_cart_count_style'] ?>
        <?= $settings['end_menu_cart_count_position_style'] ?>
        line-height: 1;
        min-width: 16px;
        text-align: center;
    }

    /* FlexNav "More" Button Styles */
    .main-nav .cl_more_flexnav button {
        <?= $settings['main_nav_flexnav_more_button_style'] ?>
    }
    .end-menu .cl_more_flexnav button {
        <?= $settings['end_menu_flexnav_more_button_style'] ?>
    }
    .main-nav .cl_more_flexnav .cl_count {
        <?= $settings['main_nav_flexnav_count_style'] ?>
    }
    .end-menu .cl_more_flexnav .cl_count {
        <?= $settings['end_menu_flexnav_count_style'] ?>
    }

    /* FlexNav Dropdown Styles */
    .main-nav .cl_dropdown_flexnav {
        <?= $settings['main_nav_flexnav_dropdown_style'] ?>
    }
    .end-menu .cl_dropdown_flexnav {
        <?= $settings['end_menu_flexnav_dropdown_style'] ?>
    }
    .main-nav .cl_dropdown_flexnav a {
        <?= $settings['main_nav_flexnav_dropdown_item_style'] ?>
    }
    .end-menu .cl_dropdown_flexnav a {
        <?= $settings['end_menu_flexnav_dropdown_item_style'] ?>
    }
</style>