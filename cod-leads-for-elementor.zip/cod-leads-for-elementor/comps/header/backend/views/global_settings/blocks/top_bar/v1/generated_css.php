<style>
.cl-header-top-bar {
    <?= $settings['top_bar_container_style'] ?>
}
</style>