<style>
.cl-header-bottom-bar {
    <?= $settings['bottom_header_container_style'] ?>
}
</style>