<?php return array (
  'setting' => 
  array (
    'display_rules_version' => 'v1',
    'header_overrides' => '{"global":{"source":"theme"},"single_product":{"is_active":"yes","source":"plugin"}}',
  ),
  'lang' => 
  array (
  ),
  'style' => 
  array (
  ),
);