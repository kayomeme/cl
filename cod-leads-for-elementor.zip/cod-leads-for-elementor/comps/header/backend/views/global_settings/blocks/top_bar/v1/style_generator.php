<?php
return array(
    'top_bar_container_style' => [
        'modal_title' => Lang_cl::__('Top Bar: Container Styling', 'cl'),
        'style_attached_to' => '.cl-header-top-bar', // CSS selector for live preview
        'font-with-align' => 'yes',
        'background' => 'yes',
        'border' => 'yes',
        'padding' => 'yes',
        'margin' => 'yes',
    ],
);