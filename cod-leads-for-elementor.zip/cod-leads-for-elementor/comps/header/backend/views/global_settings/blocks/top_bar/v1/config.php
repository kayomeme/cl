<?php return array (
  'setting' => 
  array (
    'top_bar_is_active' => 'yes',
    'top_bar_version' => 'v1',
    'top_bar_is_sticky' => 'no',
  ),
  'lang' => 
  array (
    'top_bar_custom_message' => 'Livraison gratuite dés 400 dhs',
  ),
  'style' => 
  array (
    'top_bar_container_style' => 'background-color:#2d3748;color:#ffffff;padding:8px 16px;text-align:center;font-size:14px;',
  ),
);