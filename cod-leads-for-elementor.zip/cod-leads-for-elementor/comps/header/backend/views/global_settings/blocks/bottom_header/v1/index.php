<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Bottom Header Section', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    // Renders the On/Off switch
                    $styleManager->getSwitchButton([
                        'name' => 'bottom_header_is_active',
                        'value' => $settings['bottom_header_is_active']
                    ]);
                    
                    // Renders the style editor button for the container
                    $styleManager->getAllCss('bottom_header_container_style'); 
                    ?>
                </div>
            </div>
            
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Simple Message', 'cl') ?>
                </div>
                <div class="cl-td">
                    <input type="text" 
                           name="bottom_header_message" 
                           value="<?= esc_attr($settings['bottom_header_message']) ?>" 
                           placeholder="<?= Lang_cl::_e('Enter your message here', 'cl') ?>"
                           style="width: 100%;">
                </div>
            </div>
        </div>
    </div>
</div>