<?php
return array(
    'bottom_header_container_style' => [
        'modal_title' => Lang_cl::__('Bottom Header: Container Styling', 'cl'),
        'style_attached_to' => '.cl-header-bottom-bar',
        'font-with-align' => 'yes',
        'background' => 'yes',
        'border' => 'yes',
        'padding' => 'yes',
        'margin' => 'yes',
    ],
);