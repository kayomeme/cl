<?php return array (
  'setting' => 
  array (
    'bottom_header_is_active' => 'no',
    'bottom_header_version' => 'v1',
  ),
  'lang' => 
  array (
    'bottom_header_message' => 'A simple message for the bottom header.',
  ),
  'style' => 
  array (
    'bottom_header_container_style' => 'background-color:#f7fafc;color:#4a5568;padding:8px 16px;text-align:center;font-size:12px;border-top:1px solid #e2e8f0;',
  ),
);