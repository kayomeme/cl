<?php
return array(
    'main_header_container_style' => [
        'modal_title' => Lang_cl::__('Main Header: Container Styling', 'cl'),
        'style_attached_to' => '.cl-header-main',
        'single_css_supported' => ['background-color', 'max-width', 'margin-top', 'margin-bottom'],
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'box-shadow' => 'yes',
    ],
    
    'main_header_sticky_style' => [
        'hide_style_bt' => 'yes',
        'style_attached_to' => '.cl-site-header.is-sticky .cl-header-main',
        'single_css_supported' => ['background-color', 'margin-top', 'margin-bottom'],
    ],
    
    'logo_container_style' => [
        'modal_title' => Lang_cl::__('Main Header: Logo Container Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .logo-container',
        'padding' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    
    'logo_image_style' => [
        'modal_title' => Lang_cl::__('Main Header: Logo Image Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .logo-container img',
        'single_css_supported' => ['max-width'],
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    
    'logo_text_style' => [
        'modal_title' => Lang_cl::__('Main Header: Logo Text Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .logo-container .logo-text',
        'font' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
    ],
    
    'logo_text_position_style' => [
        'modal_title' => Lang_cl::__('Position', 'cl'),
        'style_attached_to' => '.cl-header-main .logo-container .logo-text',
        'active_positions' => ['top_center_transformed', 'bottom_center_transformed', 'inside']
    ],
    
    'main_nav_container_style' => [
        'modal_title' => Lang_cl::__('Main Header: Main Navigation Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .main-nav',
        'font' => 'yes',
        'padding' => 'yes',
    ],
    
    'main_nav_sticky_style' => [
        'hide_style_bt' => 'yes',
        'style_attached_to' => '.cl-site-header.is-sticky .cl-header-main .main-nav',
        'single_css_supported' => ['color'],
    ],
    
    'main_nav_flexnav_more_button_style' => [
        'modal_title' => Lang_cl::__('"More" Button Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .main-nav .more-menu-button',
        'font' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    
    'main_nav_flexnav_count_style' => [
        'modal_title' => Lang_cl::__('"More" Button Count Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .main-nav .cl_count',
        'font' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    
    'main_nav_flexnav_dropdown_style' => [
        'modal_title' => Lang_cl::__('"More" Dropdown Container Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .main-nav .cl_dropdown_flexnav',
        'padding' => 'yes',
        'background' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'box-shadow' => 'yes',
    ],
    
    'main_nav_flexnav_dropdown_item_style' => [
        'modal_title' => Lang_cl::__('"More" Dropdown Item Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .main-nav .cl_dropdown_flexnav a',
        'font' => 'yes',
        'padding' => 'yes',
    ],
    
    'end_menu_container_style' => [
        'modal_title' => Lang_cl::__('Main Header: End Menu Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .end-menu',
        'font' => 'yes',
        'padding' => 'yes',
    ],
    
    'end_menu_sticky_style' => [
        'hide_style_bt' => 'yes',
        'style_attached_to' => '.cl-site-header.is-sticky .cl-header-main .end-menu',
        'single_css_supported' => ['color'],
    ],
    
    'end_menu_flexnav_more_button_style' => [
        'modal_title' => Lang_cl::__('"More" Button Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .end-menu .more-menu-button',
        'font' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    
    'end_menu_flexnav_count_style' => [
        'modal_title' => Lang_cl::__('"More" Button Count Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .end-menu .cl_count',
        'font' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    
    'end_menu_flexnav_dropdown_style' => [
        'modal_title' => Lang_cl::__('"More" Dropdown Container Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .end-menu .cl_dropdown_flexnav',
        'padding' => 'yes',
        'background' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'box-shadow' => 'yes',
    ],
    
    'end_menu_flexnav_dropdown_item_style' => [
        'modal_title' => Lang_cl::__('"More" Dropdown Item Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .end-menu .cl_dropdown_flexnav a',
        'font' => 'yes',
        'padding' => 'yes',
    ],
    
    'end_menu_cart_icon_container_style' => [
        'modal_title' => Lang_cl::__('Cart Icon: Container Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .end-menu .cl-cart-icon-container',
        'font' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    
    'end_menu_cart_count_style' => [
        'modal_title' => Lang_cl::__('Cart Icon: Count Bubble Styling', 'cl'),
        'style_attached_to' => '.cl-header-main .end-menu .cl_count_products',
        'font' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    
    'end_menu_cart_count_position_style' => [
        'modal_title' => Lang_cl::__('Position', 'cl'),
        'only_show_selectbox' => 'yes',
        'style_attached_to' => '.cl-header-main .end-menu .cl_count_products',
        'active_positions' => ['top_left', 'top_right', 'bottom_left', 'bottom_right', 'inside', 'center']
    ],
);