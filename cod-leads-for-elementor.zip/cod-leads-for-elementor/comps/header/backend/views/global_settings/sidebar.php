<button tab="cl_display_rules_tab" _section="cl_display_rules">
    <span class="dashicons dashicons-admin-settings"></span>
    <?= Lang_cl::_e('Display Rules', 'cl') ?>
</button>

<button tab="cl_top_bar_tab" _section="cl_top_bar">
    <span class="dashicons dashicons-arrow-up-alt"></span>
    <?= Lang_cl::_e('Top Bar', 'cl') ?>
</button>

<button tab="cl_main_header_tab" _section="cl_main_header">
    <span class="dashicons dashicons-menu-alt3"></span>
    <?= Lang_cl::_e('Main Header', 'cl') ?>
</button>

<button tab="cl_bottom_header_tab" _section="cl_bottom_header">
    <span class="dashicons dashicons-arrow-down-alt"></span>
    <?= Lang_cl::_e('Bottom Header', 'cl') ?>
</button>

<button tab="cl_header_blocks_order_tab" _section="cl_header_blocks_order">
    <span class="dashicons dashicons-sort"></span>
    <?= Lang_cl::_e('Blocks Order', 'cl') ?>
</button>