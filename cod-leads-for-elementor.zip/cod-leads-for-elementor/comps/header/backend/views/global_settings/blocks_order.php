<div class="cl-row">
    <div class="cl-th">
        <label>
            <?= Lang_cl::_e('Header Blocks Order', 'cl') ?>
        </label>
        <div class="cl-alert cl-alert-info">
            <?= Lang_cl::_e('Drag and drop the blocks to reorder them on the frontend.', 'cl') ?>
        </div>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div id="cl-header-elements">
                <?php 
                // Loop through the blocks in their current order
                foreach ($headerBlocksOrder as $blockName) {
                    // Include the corresponding draggable element template
                    include 'order_elements/' . $blockName . '.php';
                }
                ?>
            </div>
        </div>
    </div>
</div>