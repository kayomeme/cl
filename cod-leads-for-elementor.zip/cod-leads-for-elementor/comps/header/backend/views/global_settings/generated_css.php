<?php
// Include Top Bar CSS if active
if ($settings['top_bar_is_active'] == 'yes') {
    include 'blocks/top_bar/' . $settings['top_bar_version'] . '/generated_css.php';
}

// Include Main Header CSS if active
if ($settings['main_header_is_active'] == 'yes') {
    include 'blocks/main_header/' . $settings['main_header_version'] . '/generated_css.php';
}

// Include Bottom Header CSS if active
if ($settings['bottom_header_is_active'] == 'yes') {
    include 'blocks/bottom_header/' . $settings['bottom_header_version'] . '/generated_css.php';
}
?>