<?php

if (isset($_REQUEST['page']) && $_REQUEST['page'] == 'cl_global_settings' && isset($_REQUEST['compo']) && $_REQUEST['compo'] == 'header') {
    
    // Enqueue the new backend CSS for the header component
    wp_enqueue_style(
        MainApp_cl::$assetsPrefix . 'header_bk_css',
        MainApp_cl::$compsUrl . 'header/backend/assets/css/header_bk.css',
        array(),
        $assetsVersion
    );

    // Enqueue the backend JavaScript for the header component
    wp_enqueue_script(
        MainApp_cl::$assetsPrefix . 'header_bk_js',
        MainApp_cl::$compsUrl . 'header/backend/assets/js/header_bk.js',
        ['jquery', 'jquery-ui-sortable'], // Add jquery-ui-sortable as a dependency
        $assetsVersion,
        true // Load in footer
    );
}