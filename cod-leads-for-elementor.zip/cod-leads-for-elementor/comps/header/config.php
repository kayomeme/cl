<?php

/**
 * Header component configuration.
 * Defines the structure for the 3 blocks and their default order.
 */
return array(
    'setting' => [
        'active_blocks' => 'display_rules,top_bar,main_header,bottom_header',
        'header_blocks_order' => 'top_bar,main_header,bottom_header',
    ],
    'lang' => [
        // No global language strings for the main component container.
        // Language strings are defined within each block's config.
    ],
    'style' => [
        // No global styles for the main component container.
        // Styles are defined within each block's config.
    ]
);