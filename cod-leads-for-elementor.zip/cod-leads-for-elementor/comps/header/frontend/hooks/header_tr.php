<?php
// This hook initializes the header controller on every page load.
global $header_cl;
$header_cl = new HeaderControllerFR_cl();