<?php

/**
 * Frontend controller for the Header component.
 */
class HeaderControllerFR_cl {
    
    public $settings;
    private $header_source_to_render = 'plugin'; // Default to plugin header

    /**
     * Constructor.
     * Initializes the controller, loads settings, and determines which header to render.
     */
    public function __construct() {
        global $settingsModelId;
        
        $compoName = 'header';
        $this->settings = PublicCompo_cl::getSettings($compoName, $settingsModelId);
        
        // Determine the correct header source to use
        $this->determine_header_source();
    }
    
    /**
     * Determines which header source to use based on the unified JSON override setting.
     */
    private function determine_header_source() {
        $settings = $this->settings;
        $current_page_scope = $this->get_current_page_scope();

        $overrides = json_decode($settings['header_overrides'], true);
        if (!is_array($overrides)) { 
            $overrides = array(); 
        }

        $rule_to_use = null;

        // Check if there is an active override for the current page type
        if ($current_page_scope && isset($overrides[$current_page_scope]) && isset($overrides[$current_page_scope]['is_active']) && $overrides[$current_page_scope]['is_active'] === 'yes') {
            $rule_to_use = $overrides[$current_page_scope];
        } else {
            // Fall back to the global setting from within the JSON
            $rule_to_use = isset($overrides['global']) ? $overrides['global'] : array('source' => 'plugin');
        }

        // Set the final source based on the determined rule
        $this->header_source_to_render = $rule_to_use['source'];
        
        if ($this->header_source_to_render === 'custom_block') {
            $this->header_source_to_render = array(
                'type' => 'custom_block',
                'id'   => isset($rule_to_use['custom_block_id']) ? $rule_to_use['custom_block_id'] : ''
            );
        }
    }
    
    /**
     * Identifies the current page type to check for overrides.
     * The order of checks is optimized for performance, checking most common cases first.
     */
    private function get_current_page_scope() {
        if (is_front_page()) { return 'homepage'; }
        if (is_singular('product')) { return 'single_product'; }
        if (is_tax('product_cat')) { return 'product_cat'; }
        
        if ( is_singular('page') ) {
            $currentPageId = get_the_ID();
            global $salesFunnel_cl;
                    
            if (isset($salesFunnel_cl)) {
                switch ($currentPageId) {
                    case $salesFunnel_cl->cartPageId: return 'cart';
                    case $salesFunnel_cl->checkoutPageId: return 'checkout';
                    case $salesFunnel_cl->thankyouPageId: return 'thankyou';
                }
            }
        }
        
        return null;
    }

    /**
     * Public method to check if the theme's header should be loaded.
     */
    public function themeHeaderIsSelected() {
        return $this->header_source_to_render === 'theme';
    }

    /**
     * Main method to render the header component based on the determined source.
     */
    public function index() {
        if ($this->header_source_to_render === 'hide') {
            return;
        }

        if (is_array($this->header_source_to_render) && $this->header_source_to_render['type'] === 'custom_block') {
            if (!empty($this->header_source_to_render['id'])) {
                echo do_shortcode('[custom_block id="' . intval($this->header_source_to_render['id']) . '"]');
            }
            return;
        }
        
        $settings = $this->settings;
        $mainNavMenu = ($settings['main_nav_is_active'] == 'yes' && !empty($settings['main_nav_menu_id'])) 
            ? wp_get_nav_menu_items($settings['main_nav_menu_id']) 
            : [];
        $endMenu = ($settings['end_menu_is_active'] == 'yes' && !empty($settings['end_menu_menu_id'])) 
            ? wp_get_nav_menu_items($settings['end_menu_menu_id']) 
            : [];
        
        require_once MainApp_cl::$compsPath . 'header/frontend/views/index.php';
    }
}