<?php
/**
 * Frontend view for the Bottom Header block.
 */

// Only render if the bottom header is active and has a message.
if ($settings['bottom_header_is_active'] == 'yes' && !empty($settings['bottom_header_message'])) :
?>
    <div class="cl-header-bottom-bar">
        <?= esc_html($settings['bottom_header_message']) ?>
    </div>
<?php 
endif;
?>