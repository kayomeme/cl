<?php if ($settings['logo_is_active'] == 'yes') { ?>
<div class="logo-container">
    <a href="<?= esc_url(home_url('/')) ?>">
        <?php if (!empty($settings['logo_image_url']) && $settings['logo_image_is_active'] == 'yes') : ?>
            <img src="<?= esc_url($settings['logo_image_url']) ?>" alt="<?= esc_attr(get_bloginfo('name')) ?>">
        <?php endif; ?>

        <?php if ($settings['logo_text_is_active'] == 'yes' && !empty($settings['logo_text'])) : ?>
            <span class="logo-text"><?= esc_html($settings['logo_text']) ?></span>
        <?php endif; ?>
    </a>
</div>

<?php } ?>