<?php // Main Navigation with Dynamic Flex Navigation
if ($settings['main_nav_is_active'] == 'yes' && !empty($mainNavMenu)) { 
    $flexNavClass = $settings['main_nav_flexnav_is_active'] == 'yes' ? 'cl_flexnav' : '';
?>
    <nav class="main-nav <?= $flexNavClass ?>">
        <ul>
            <?php foreach ($mainNavMenu as $menu_item) { ?>
                <li><a href="<?= esc_url($menu_item->url) ?>"><?= esc_html($menu_item->title) ?></a></li>
            <?php } ?>
        </ul>
        
        <?php // This structure is required by FlexNav_cl.js if the feature is active
        if ($settings['main_nav_flexnav_is_active'] == 'yes') { 
            publicUtils_cl::renderFlexNavButtonAndDropdownHtmlCode($settings['main_nav_flexnav_more_button_text'], $settings['main_nav_flexnav_more_button_icon_id']);
        ?>

        <?php } ?>
    </nav>
<?php } ?>