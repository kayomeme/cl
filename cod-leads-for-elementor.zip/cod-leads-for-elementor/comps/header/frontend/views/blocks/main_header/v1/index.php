<?php
/**
 * Frontend view for the Main Header block.
 * Renders logo, main nav, and end menu as direct children for flexible layout control.
 */

// Only render if the main header is active.
if ($settings['main_header_is_active'] == 'yes') {

    // Determine the layout class from settings.
    $layout_class = 'layout-' . esc_attr($settings['main_header_layout']);
    
    // Check if the header should be hided in sticky global header container.
    $hide_in_sticky = $settings['main_header_is_sticky'] != 'yes' ? 'hide_in_sticky' : '';
?>

        <div class="cl-header-main <?= $layout_class ?> <?= $hide_in_sticky ?>">
            
            <?php 
            if( $settings['main_header_layout'] == 'logo-center-mainmenu-start-endmenu-end' ) {
                include 'main_menu.php';
                include 'logo.php';
                include 'end_menu.php';
            } else {
                include 'logo.php';
                include 'main_menu.php';
                include 'end_menu.php';
            }
                
            ?>





        </div>

<?php 
}
?>