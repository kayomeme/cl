<?php // End Menu with Dynamic Flex Navigation
if ($settings['end_menu_is_active'] == 'yes') { 
    $flexNavClass = $settings['end_menu_flexnav_is_active'] == 'yes' ? 'cl_flexnav' : '';
?>
    <nav class="end-menu <?= $flexNavClass ?>">
        <ul>
            <?php 
            if (!empty($endMenu)) {
                foreach ($endMenu as $menu_item) { ?>
                    <li><a href="<?= esc_url($menu_item->url) ?>"><?= esc_html($menu_item->title) ?></a></li>
                <?php } 
            } 
            ?>
                
            <?php // Cart Icon is treated as a regular menu item for FlexNav logic
            if ($settings['end_menu_cart_icon_is_active'] == 'yes') { 
                global $iconsSelectorFR_cl;
            ?>
                <li>
                    <a href="#" class="cl-cart-icon-container">
                        <?php 
                        if (!empty($settings['end_menu_cart_icon_id'])) {
                            echo $iconsSelectorFR_cl->getIconCode($settings['end_menu_cart_icon_id']);
                        }
                        if (!empty($settings['end_menu_cart_icon_text'])) {
                            echo '<span>' . esc_html($settings['end_menu_cart_icon_text']) . '</span>';
                        }
                        ?>
                        <span class="cl_count_products">0</span>
                    </a>
                </li>
            <?php } ?>
        </ul>
        
        <?php // This structure is required by FlexNav_cl.js if the feature is active
        if ($settings['end_menu_flexnav_is_active'] == 'yes') { 
            publicUtils_cl::renderFlexNavButtonAndDropdownHtmlCode($settings['end_menu_flexnav_more_button_text'], $settings['end_menu_flexnav_more_button_icon_id']);
        } ?>
    </nav>
<?php } ?>