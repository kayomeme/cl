<?php
/**
 * Frontend view for the Top Bar block.
 */

// Only render if the top bar is active and has a message.
if ($settings['top_bar_is_active'] == 'yes' && !empty($settings['top_bar_custom_message'])) :
?>
    <div class="cl-header-top-bar <?= $topBarHideWhenItStickyContainer ?>">
        <?= esc_html($settings['top_bar_custom_message']) ?>
    </div>
<?php 
endif;
?>