<?php
/**
 * Main frontend view for the Header component.
 * Renders the header blocks in the order defined in the settings.
 */

if (!isset($settings['header_blocks_order'])) {
    return;
}

$header_blocks_order = explode(',', $settings['header_blocks_order']);

$canBeStickyCss = $settings['main_header_is_sticky'] == 'yes' || $settings['top_bar_is_sticky'] == 'yes' ? 'cl_can_be_sticky' : '';
//$mainHeaderHideWhenItStickyContainer = $settings['main_header_is_sticky'] != 'yes' ? 'hide_in_sticky' : '';
$topBarHideWhenItStickyContainer = $settings['top_bar_is_sticky'] != 'yes' ? 'hide_in_sticky' : '';
?>

<header class="cl-site-header <?= $canBeStickyCss ?>">
    <?php
    foreach ($header_blocks_order as $blockName) {
        $block_path = MainApp_cl::$compsPath . 'header/frontend/views/blocks/' . $blockName . '/v1/index.php';
        if (file_exists($block_path)) {
            include $block_path;
        }
    }
    ?>
</header>