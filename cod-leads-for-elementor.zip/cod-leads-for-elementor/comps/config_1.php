<?php
return [
    /*-----------Product component--------*/
    'sales_funnel' => [
        'name'      => 'sales_funnel',
        'is_active' => 'yes',
        'admin_hooks' => [
            1 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [
            1 => 'template_redirect',
            2 => 'wp_head',
            3 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Product component--------*/
    'product' => [
        'name'      => 'product',
        'is_active' => 'yes',
        'admin_hooks' => [
            2 => 'admin_head',
            3 => 'admin_footer',
            4 => 'manage_post_posts_custom_column',
            5 => 'admin_enqueue_scripts',
            6 => 'add_meta_boxes',
            7 => 'save_post_product',
        ],
        'admin_filters' => [
            1 => 'manage_edit-post_columns',
        ],
        'public_hooks' => [
            4 => 'template_redirect',
            5 => 'wp_head',
            6 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------cart component--------*/
    'cart' => [
        'name'      => 'cart',
        'is_active' => 'yes',
        'admin_hooks' => [
            7 => 'admin_enqueue_scripts'
        ],
        'admin_filters' => [],
        'public_hooks' => [
            3 => 'template_redirect',
            4 => 'wp_head',
            5 => 'wp_enqueue_scripts',
            //6 => 'wp_body_open',
        ],
        'public_filters' => [
            1 => 'the_content'
        ]
    ],
    /*-----------Checkout component--------*/
    'checkout' => [
        'name'      => 'checkout',
        'is_active' => 'yes',
        'admin_hooks' => [
            8 => 'admin_enqueue_scripts'
        ],
        'admin_filters' => [],
        'public_hooks' => [
            7 => 'template_redirect',
            8 => 'wp_head',
            9 => 'wp_enqueue_scripts',
            //10 => 'wp_body_open',
        ],
        'public_filters' => [
            1 => 'the_content'
        ]
    ],
    /*----------- thankyou component-------- */
    'thankyou' => [
        'name'      => 'thankyou',
        'is_active' => 'yes',
        'admin_hooks' => [
            9 => 'admin_enqueue_scripts'
        ],
        'admin_filters' => [],
        'public_hooks' => [
            11 => 'template_redirect',
            12 => 'wp_head',
            13 => 'wp_enqueue_scripts',
        ],
        'public_filters' => [
            2 => 'the_content'
        ]
    ],
    /*-----------GoogleSheet component--------*/
    'google_sheet' => [
        'name'      => 'google_sheet',
        'is_active' => 'yes',  
        'admin_hooks' => [
            10 => 'admin_enqueue_scripts'
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [
            14 => 'template_redirect',
            27 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------Top bar component--------*/
    'top_bar' => [
        'name'      => 'top_bar',
        'is_active' => 'yes',
        'admin_hooks' => [],
        'admin_filters' => [],
        'public_hooks' => [
            15 => 'template_redirect',
            16 => 'wp_body_open',
        ],
        'public_filters' => []
    ],
    /*-----------Top bar component--------*/
    'whatsapp' => [
        'name'      => 'whatsapp',
        'is_active' => 'yes',
        'admin_hooks' => [],
        'admin_filters' => [],
        'public_hooks' => [
            17 => 'template_redirect',
            18 => 'wp_footer',
        ],
        'public_filters' => []
    ],
    /*-----------Tracking component--------*/
    'tracking' => [
        'name'      => 'tracking',
        'is_active' => 'yes',
        'admin_hooks' => [],
        'admin_filters' => [],
        'public_hooks' => [
            19 => 'template_redirect',
            20 => 'wp_head',
            26 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------order component--------*/
    'order' => [
        'name'      => 'order',
        'is_active' => 'yes',
        'admin_menus' => [],
        'admin_hooks' => [
            11 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------order status--------*/
    'order_status' => [
        'name'      => 'order_status',
        'is_active' => 'yes',
        'admin_menus' => [],
        'admin_hooks' => [
            12 => 'admin_enqueue_scripts',
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [],
        'public_filters' => []
    ],
    /*-----------Listing component--------*/
    'plist1' => [
        'name'      => 'plist1',
        'is_active' => 'yes',
        'admin_hooks' => [
            13 => 'admin_enqueue_scripts'
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [
        ],
        'public_filters' => []
    ],
    'categories_listing' => [
        'name'      => 'categories_listing',
        'is_active' => 'yes',
        'admin_hooks' => [
            14 => 'admin_enqueue_scripts'
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [
        ],
        'public_filters' => []
    ],
    /*-----------Insights component--------*/
    'insights' => [
        'name'      => 'insights',
        'is_active' => 'yes',
        'admin_hooks' => [
            15 => 'admin_enqueue_scripts',
            16 => 'manage_post_posts_custom_column',
            
        ],
        'admin_filters' => [
            2 => 'manage_edit-post_columns'
        ],
        'public_hooks' => [
            21 => 'template_redirect',
            22 => 'wp_head',
            23 => 'wp_enqueue_scripts',
        ],
        'public_filters' => []
    ],
    /*-----------System customizer component--------*/
    'mystore' => [
        'name'      => 'mystore',
        'is_active' => 'yes',  
        'admin_hooks' => [
            17 => 'admin_enqueue_scripts'
        ],
        'admin_filters' => [
        ],
        'public_hooks' => [
            24 => 'template_redirect',
            25 => 'wp_head',
        ],
        'public_filters' => []
    ],
];
