<?php

class PList1SettingsControllerBK_clfe
{
    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'plist1';
        $tabName = isset($_GET['tab']) ? $_GET['tab'] : 'plist1';

        $defaultSettings    = AdminCompo_clfe::getDefaultSettings($compoName, $settings);
        $adminStyle         = new AdminStyle_clfe($defaultSettings);

        $productsElements   = adminUtils_clfe::getElementsOrder($defaultSettings['plist1_blocks_order'], $settings['plist1_blocks_order']);
        
        $settings['plist1_blocks_order'] = implode(',', $productsElements);

        include AdminApp_clfe::$viewsPath . 'global_settings/index.php';
    }
    public static function save_settings($compoName, $settingsModelId, $args)
    {
        $response = AdminCompo_clfe::saveSettings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }

    private static function getSharedSettings($args)
    {
        $sharedSettings = [];

        return $sharedSettings;
    }
}
