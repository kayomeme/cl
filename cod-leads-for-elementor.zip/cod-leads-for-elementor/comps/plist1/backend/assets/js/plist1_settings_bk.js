(function( $ ) {
	'use strict';

        $(document).ready( function () {

            // dragable elemnts
            $(".plist1-product-elements").sortable({
                update: function( event, ui ) {
                    var fieldsFileName = $('.plist1-product-elements div').map(function () { return $(this).attr("_attachedsection"); });
                    $("input[name=plist1_blocks_order]").val(fieldsFileName.toArray());
                    $("input[name=plist1_blocks_order]").change();
                    
                    AdminFn_clfe.autoSaveSettings();
                }
            });
            
        } );

})( jQuery );