<style>
    main#content {
        max-width: 1124px;
        margin: auto;  
    }
    .plist1 {
        display: grid;
        /*grid-template-columns: repeat(2, minmax(0, 1fr));*/
        grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
        gap: 20px;
        row-gap: 30px;
        max-width: 1124px;
        margin: auto;
    }
    .plist1 a, .plist1 button {
        text-decoration: none !important;
        cursor: pointer;
    }
    .plist1-product {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        <?= $settings['plist1_product_style'] ?>
    }


@media screen and (max-width: 600px) {
    .plist1 {
        gap: 10px;
        row-gap: 20px;
    }
}
</style>
<?php 
//if ($settings['cart_empty_is_active'] == 'yes') {}
    include 'blocks/actions/' . $settings['actions_version'] . '/generated_css.php';

    include 'blocks/image/' . $settings['image_version'] . '/generated_css.php';
    include 'blocks/title/' . $settings['title_version'] . '/generated_css.php';
    include 'blocks/prices/' . $settings['prices_version'] . '/generated_css.php';
    include 'blocks/variations/' . $settings['variations_version'] . '/generated_css.php';
?>