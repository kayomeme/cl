
<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Product container style', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <?php
        $activeOptions = [
            'modalTitle' => Lang_clfe::__('Product container style', 'clfe'),
            'styleAttachedTo' => '.plist1-product',
            'border' => 'yes',
            'padding' => 'yes',
            'background' => 'yes',
            'box-shadow' => 'yes'
        ];
        $adminStyle->getAllCss('plist1_product_style', $settings['plist1_product_style'], $activeOptions);
        ?>
    </div>
</div>


<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Product blocks Order', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <input type="text"  name="plist1_blocks_order" value="<?= $settings['plist1_blocks_order'] ?>">

        <div class="clfe-sub-section plist1-product-elements">
            <?php
            // if any new element you should add it here directly in this array with a position
            foreach ($productsElements as $element) {
                include 'elements/' . $element . '.php';
            }
            ?>
        </div>
        <div class="clfe-alert clfe-alert-info">
            <?= Lang_clfe::_e('To change the order of display on the frontend, simply drag and drop the elements in the list.', 'clfe') ?>
        </div>
    </div>
</div>