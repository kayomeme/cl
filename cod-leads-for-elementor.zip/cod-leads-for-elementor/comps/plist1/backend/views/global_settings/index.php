<div id="clfe_general_tab" class="clfe-single-tab">
    <?php include 'general.php'; ?>
</div>

<div id="clfe_image_tab" class="clfe-single-tab">
    <?php include 'blocks/image/'.$settings['image_version'].'/index.php'; ?>
</div>

<div id="clfe_title_tab" class="clfe-single-tab">
    <?php include 'blocks/title/'.$settings['title_version'].'/index.php'; ?>
</div>

<div id="clfe_prices_tab" class="clfe-single-tab">
    <?php include 'blocks/prices/'.$settings['prices_version'].'/index.php'; ?>
</div>

<div id="clfe_actions_tab" class="clfe-single-tab">
    <?php include 'blocks/actions/'.$settings['actions_version'].'/index.php'; ?>
</div>

<div id="clfe_variations_tab" class="clfe-single-tab">
    <?php include 'blocks/variations/'.$settings['variations_version'].'/index.php'; ?>
</div>



<div>
    <input type="text" name="prices_version" value="<?= $settings['prices_version'] ?>">
    <input type="text" name="actions_version" value="<?= $settings['actions_version'] ?>">
    <input type="text" name="image_version" value="<?= $settings['image_version'] ?>">
    <input type="text" name="title_version" value="<?= $settings['title_version'] ?>">
    <input type="text" name="variations_version" value="<?= $settings['variations_version'] ?>">
</div>