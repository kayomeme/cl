<button tab="clfe_general_tab">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_clfe::_e('General', 'clfe') ?>
</button>
<button tab="clfe_prices_tab" _section="clfe_prices">
    <span class="dashicons dashicons-money-alt"></span>
    <?= Lang_clfe::_e('Prices', 'clfe') ?>
</button>
<button tab="clfe_image_tab" _section="clfe_image">
    <span class="dashicons dashicons-format-image"></span>
    <?= Lang_clfe::_e('Image', 'clfe') ?>
</button>
<button tab="clfe_title_tab" _section="clfe_title">
    <span class="dashicons dashicons-heading"></span>
    <?= Lang_clfe::_e('Title', 'clfe') ?>
</button>
<button tab="clfe_actions_tab" _section="clfe_actions">
    <span class="dashicons dashicons-button"></span>
    <?= Lang_clfe::_e('Action buttons', 'clfe') ?>
</button>
<button tab="clfe_variations_tab" _section="clfe_variations">
    <span class="dashicons dashicons-button"></span>
    <?= Lang_clfe::_e('Variations', 'clfe') ?>
</button>