<div class="clfe-row" _attachedsection="actions">
    <span class="dashicons dashicons-cart"></span>
    <span class="clfe-label-draggable">
        <?= Lang_clfe::_e('Actions', 'clfe') ?>
    </span>
    <div class="clfe-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>