<div class="clfe-row" _attachedsection="prices">
    <span class="dashicons dashicons-money-alt"></span>
    <span class="clfe-label-draggable">
        <?= Lang_clfe::_e('Product prices', 'clfe') ?>
    </span>
    <div class="clfe-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>