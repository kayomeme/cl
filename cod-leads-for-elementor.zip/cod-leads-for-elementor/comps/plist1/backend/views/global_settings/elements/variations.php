<div class="clfe-row" _attachedsection="variations">
    <span class="dashicons dashicons-heading"></span>
    <span class="clfe-label-draggable">
        <?= Lang_clfe::_e('Product variations', 'clfe') ?>
    </span>
    <div class="clfe-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>