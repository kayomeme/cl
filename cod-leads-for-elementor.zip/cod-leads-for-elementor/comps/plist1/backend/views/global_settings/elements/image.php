<div class="clfe-row" _attachedsection="image">
    <span class="dashicons dashicons-format-image"></span>
    <span class="clfe-label-draggable">
        <?= Lang_clfe::_e('Product image', 'clfe') ?>
    </span>
    <div class="clfe-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>