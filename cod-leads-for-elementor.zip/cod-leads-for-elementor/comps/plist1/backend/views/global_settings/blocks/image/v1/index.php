

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Product Image', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <div class="clfe-sub-section">
                        <div class="clfe-row">
                            <div class="clfe-th">
                                <label>
                                    <?= Lang_clfe::_e('Is active', 'clfe') ?>
                                </label>
                            </div>
                            <div class="clfe-td">
                                <label class="clfe-switch">
                                    <input type="checkbox" <?= $settings['product_image_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                                    <span class="clfe-slider clfe-round"></span>
                                    <input type="hidden" name="product_image_is_active" value="<?= $settings['product_image_is_active'] ?>">
                                </label>
                                
                                <?php 
                                    $activeOptions = [
                                        'modalTitle' => Lang_clfe::__('Product image style', 'clfe'),
                                        'styleAttachedTo' => '.plist1 .clfe_image img',
                                        'border' => 'yes',
                                        'padding' => 'yes',
                                    ];
                                    $adminStyle->getAllCss('product_image_style', $settings['product_image_style'], $activeOptions); 
                                ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            