<?php
return array(
    'setting' =>
    array(
        'actions_version' => 'v1',
        'actions_flex_direction' => 'column',
        'product_link_is_active' => 'yes',
        'product_link_icon_is_active' => 'yes',
        'add_to_cart_bt_is_active' => 'yes',
        'add_to_cart_bt_icon_is_active' => 'yes',
    ),
    'lang' =>
    array(
        'product_link_text' => 'View Product',
        'add_to_cart_bt_text' => 'Add to Cart',
    ),
    'style' =>
    array(
        'product_link_style' => 'width:auto;font-size:15px;color:#ffffff;font-weight:700;text-align:center;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-color:#5cb85c;border-style:solid;border-top-left-radius:1px;border-top-right-radius:1px;border-bottom-left-radius:1px;border-bottom-right-radius:1px;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;background-image:linear-gradient(17deg,#8BC34A,#4CAF50);box-shadow:1px 5px 2px -1px #008744;;',
        'product_link_icon_style' => 'font-size:16px;color:#ffffff;',
        'add_to_cart_bt_style' => 'width:auto;font-size:15px;color:#ffffff;font-weight:700;text-align:center;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-color:#0066cc;border-style:solid;border-top-left-radius:1px;border-top-right-radius:1px;border-bottom-left-radius:1px;border-bottom-right-radius:1px;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;background-image:linear-gradient(17deg,#0088cc,#0066cc);box-shadow:1px 5px 2px -1px #004a92;;',
        'add_to_cart_bt_icon_style' => 'font-size:16px;color:#ffffff;',
        'actions_container_style' => 'border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:#ffffff;border-style:solid;border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;background-color:#ffffff;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;margin-top:15px;margin-right:0px;margin-bottom:0px;margin-left:0px;box-shadow:0px 0px 0px 0px #b0a6a6;',
    ),
);