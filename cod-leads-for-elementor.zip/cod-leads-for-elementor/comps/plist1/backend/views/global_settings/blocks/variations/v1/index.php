<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Product Variations', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <label class="clfe-switch">
            <input type="checkbox" <?= $settings['variations_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
            <span class="clfe-slider clfe-round"></span>
            <input type="hidden" name="variations_is_active" value="<?= $settings['variations_is_active'] ?>">
        </label>
        <?php
        $activeOptions = [
            'modalTitle' => Lang_clfe::__('Product Variations container style', 'clfe'),
            'styleAttachedTo' => '.plist1 .clfe_variations',
            'background' => 'yes',
            'padding' => 'yes',
        ];
        $adminStyle->getAllCss('variations_container_style', $settings['variations_container_style'], $activeOptions);
        ?>
    </div>
    <div class="clfe-alert clfe-alert-info">
        <?= Lang_clfe::_e('The style settings for individual variation items inherit the settings from the product settings page. On this setting, you can only customize the container style that holds all variations.', 'clfe') ?>
    </div>
</div>
<?php $adminStyle->getSingleCss('margin-top', 'variations_container_style', $settings['variations_container_style']); ?>