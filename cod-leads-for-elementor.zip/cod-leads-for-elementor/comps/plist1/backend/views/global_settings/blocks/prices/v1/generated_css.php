<style>
    <?php if( $settings['sale_price_is_active'] == 'yes' || $settings['regular_price_is_active'] == 'yes' ) { ?>
        .plist1 .clfe_prices {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: center;
            /*text-align:center;
            justify-content: center;*/
            <?= $settings['prices_container_style'] ?>
        }
        .plist1 .clfe_currency {
          display: flex;  
        }
        
        .plist1 .prices_part {
            <?= $settings['discount_position'] != 'start' ? 'flex: auto;' : ''?>
            display: flex;
            gap: 10px;
            flex-direction: row;
            align-items: center;
            float: inline-start;
        }
        .plist1 .regular_price {
            display: flex;
            gap: 2px;
            text-decoration: line-through;
            <?= $settings['regular_price_style'] ?>
        }
        .plist1 .sale_price {
            display: flex;
            gap: 2px;
            <?= $settings['sale_price_style'] ?>
        } 
        
        .plist1 .product_discount {
            display: flex;
            gap: 2px;
            <?= $settings['discount_style'] ?>
        }
        
        /* Currency styles */
        <?php if($settings['regular_price_currency_custom'] == 'yes') { ?>
        .plist1 .regular_price .clfe_currency {
            <?= $settings['regular_price_currency_style'] ?>
        }
        <?php } ?>
        
        <?php if($settings['sale_price_currency_custom'] == 'yes') { ?>
        .plist1 .sale_price .clfe_currency {
            <?= $settings['sale_price_currency_style'] ?>
        }
        <?php } ?>
        
        <?php if($settings['discount_currency_custom'] == 'yes') { ?>
        .plist1 .product_discount .clfe_currency {
            <?= $settings['discount_currency_style'] ?>
        }
        <?php } ?>
        
    <?php } ?>
</style>