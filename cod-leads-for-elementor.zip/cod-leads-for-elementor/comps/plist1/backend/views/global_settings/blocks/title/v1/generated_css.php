<style>
       .plist1 .clfe_title a {
        display: block;
        <?= $settings['product_title_style'] ?>
    }
</style>