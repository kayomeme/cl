<?php return array (
  'setting' => 
  array (
    'image_version' => 'v1',
    'product_image_is_active' => 'yes',  
  ),
  'lang' => 
  array (
  ),
  'style' => 
  array (
        'product_image_style' => 'border-top-width:10px;border-right-width:5px;border-bottom-width:0px;border-left-width:10px;border-color:#428bca;border-style:solid;border-top-left-radius:31px;border-top-right-radius:38px;border-bottom-left-radius:134px;border-bottom-right-radius:53px;',
      ),
);