<?php return array (
  'setting' => 
  array (
    'prices_version' => 'v1',
    'regular_price_is_active' => 'yes',
    'sale_price_is_active' => 'yes',
    'discount_is_active' => 'yes',
    'discount_position' => 'end',
    'discount_type' => 'fixed', // Setting for discount type (fixed or percentage)
    'regular_price_currency_custom' => 'no',  // Whether to use custom currency style for regular price
    'sale_price_currency_custom' => 'no',     // Whether to use custom currency style for sale price
    'discount_currency_custom' => 'no',       // Whether to use custom currency style for discount
  ),
  'lang' => 
  array (
    'regular_price_text' => '@regular_price',
    'sale_price_text' => '@sale_price',
    'discount_text' => 'ÉCONOMISEZ @discount_value',
  ),
  'style' => 
  array (
    'prices_container_style' => 'border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:#ffffff;border-style:solid;border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;background-color:#ffffff;padding-top:5px;padding-right:5px;padding-bottom:5px;padding-left:5px;margin-top:5px;margin-right:0px;margin-bottom:0px;margin-left:0px;box-shadow:0px 0px 0px 0px #b0a6a6;',
    'regular_price_style' => 'font-size:16px;color:#ba0303;font-weight:700;text-align:center;text-shadow:;',
    'sale_price_style' => 'font-size:24px;color:#008744;font-weight:700;text-align:center;text-shadow:1px 1px 2;',
    'discount_style' => 'font-size:13px;color:#ffffff;font-weight:700;text-align:end;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-color:#008000;border-style:solid;border-top-left-radius:5px;border-top-right-radius:5px;border-bottom-left-radius:5px;border-bottom-right-radius:5px;padding-top:4px;padding-right:10px;padding-bottom:4px;padding-left:10px;background-image:linear-gradient(6deg,#008000,#5cb85c);text-shadow:;',
    'regular_price_currency_style' => 'font-size:14px;color:#ba0303;font-weight:500;',  // Style for regular price currency
    'sale_price_currency_style' => 'font-size:18px;color:#008744;font-weight:500;',     // Style for sale price currency
    'discount_currency_style' => 'font-size:11px;color:#ffffff;font-weight:500;',       // Style for discount currency
  ),
);