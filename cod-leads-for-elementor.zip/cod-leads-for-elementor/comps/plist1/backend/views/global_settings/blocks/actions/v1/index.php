<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Product actions container', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row ">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Container style', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Product container actions style', 'clfe'),
                        'styleAttachedTo' => '.clfe_actions',
                        'flex-options' => [
                            'blockTitle' => Lang_clfe::__('Buttons Layout', 'clfe'),
                            'flex-direction' => 'yes',
                            'align-items' => 'yes',
                            'justify-content' => 'yes',
                            'gap' => 'yes',
                        ],
                        'border' => 'yes',
                        'padding' => 'yes',
                        'background' => 'yes'
                    ];
                    $adminStyle->getAllCss('actions_container_style', $settings['actions_container_style'], $activeOptions);
                    ?>
                </div>
            </div>
            <?php $adminStyle->getSingleCss('margin-top', 'actions_container_style', $settings['actions_container_style']); ?>
            
            <!-- Buttons Direction Setting 
            <div class="clfe-row ">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Buttons direction', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <select name="actions_flex_direction" class="clfe-style-element">
                        <option value="column" <?= $settings['actions_flex_direction'] == 'column' ? 'selected' : '' ?>><?= Lang_clfe::_e('Column (vertical)', 'clfe') ?></option>
                        <option value="column-reverse" <?= $settings['actions_flex_direction'] == 'column-reverse' ? 'selected' : '' ?>><?= Lang_clfe::_e('Column Reverse (vertical, reversed order)', 'clfe') ?></option>
                        <option value="row" <?= $settings['actions_flex_direction'] == 'row' ? 'selected' : '' ?>><?= Lang_clfe::_e('Row (horizontal)', 'clfe') ?></option>
                        <option value="row-reverse" <?= $settings['actions_flex_direction'] == 'row-reverse' ? 'selected' : '' ?>><?= Lang_clfe::_e('Row Reverse (horizontal, reversed order)', 'clfe') ?></option>
                    </select>
                </div>
            </div>-->
        </div>
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('View Product Button', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">

        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['product_link_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="product_link_is_active" value="<?= $settings['product_link_is_active'] ?>">
                    </label>
                    
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('View Product Button Style', 'clfe'),
                        'styleAttachedTo' => '.product-link-button',
                        'predefined_width' => 'yes',
                        'font' => 'yes',
                        'border' => 'yes',
                        'padding' => 'yes',
                        'linear-gradient' => 'yes'
                    ];
                    $adminStyle->getAllCss('product_link_style', $settings['product_link_style'], $activeOptions);
                    ?>
                </div>
            </div>
            
            <div class="clfe-row">
                <div class="clfe-td-full">
                    <input type="text" name="product_link_text" value="<?= $settings['product_link_text'] ?>" textAttachedTo=".product-link-button">
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Icon is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['product_link_icon_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="product_link_icon_is_active" value="<?= $settings['product_link_icon_is_active'] ?>">
                    </label>
                    
                    <!-- Icon Style Settings -->
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('View Product Icon Style', 'clfe'),
                        'styleAttachedTo' => '.product-link-button i',
                        'font' => 'yes'
                    ];
                    $adminStyle->getAllCss('product_link_icon_style', $settings['product_link_icon_style'], $activeOptions);
                    ?>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Add to Cart Button Settings -->
<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Add to Cart Button', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['add_to_cart_bt_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="add_to_cart_bt_is_active" value="<?= $settings['add_to_cart_bt_is_active'] ?>">
                    </label>
                    
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Add to Cart Button Style', 'clfe'),
                        'styleAttachedTo' => '.add-to-cart-bt-button',
                        'predefined_width' => 'yes',
                        'font' => 'yes',
                        'border' => 'yes',
                        'padding' => 'yes',
                        'linear-gradient' => 'yes'
                    ];
                    $adminStyle->getAllCss('add_to_cart_bt_style', $settings['add_to_cart_bt_style'], $activeOptions);
                    ?>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-td-full">
                    <input type="text" name="add_to_cart_bt_text" value="<?= $settings['add_to_cart_bt_text'] ?>" textAttachedTo=".add-to-cart-bt-button">
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Icon is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['add_to_cart_bt_icon_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="add_to_cart_bt_icon_is_active" value="<?= $settings['add_to_cart_bt_icon_is_active'] ?>">
                    </label>
                    
                    <!-- Icon Style Settings -->
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Add to Cart Icon Style', 'clfe'),
                        'styleAttachedTo' => '.add-to-cart-bt-button i',
                        'font' => 'yes'
                    ];
                    $adminStyle->getAllCss('add_to_cart_bt_icon_style', $settings['add_to_cart_bt_icon_style'], $activeOptions);
                    ?>
                </div>
            </div>
            
        </div>


    </div>
</div>