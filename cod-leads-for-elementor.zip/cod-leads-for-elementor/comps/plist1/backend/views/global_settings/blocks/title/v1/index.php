            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Product title', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <div class="clfe-sub-section">
                        <div class="clfe-row">
                            <div class="clfe-th">
                                <label>
                                    <?= Lang_clfe::_e('Is active', 'clfe') ?>
                                </label>
                            </div>
                            <div class="clfe-td">
                                <label class="clfe-switch">
                                    <input type="checkbox" <?= $settings['product_title_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                                    <span class="clfe-slider clfe-round"></span>
                                    <input type="hidden" name="product_title_is_active" value="<?= $settings['product_title_is_active'] ?>">
                                </label>
                                
                                <?php 
                                    $activeOptions = [
                                        'modalTitle' => Lang_clfe::__('Product title style', 'clfe'),
                                        'styleAttachedTo' => '.plist1 .clfe_title a',
                                        'font-with-align' => 'yes',
                                        'padding' => 'yes',
                                    ];
                                    $adminStyle->getAllCss('product_title_style', $settings['product_title_style'], $activeOptions); 
                                ?>
                            </div>
                        </div>
                        <?php $adminStyle->getSingleCss('margin-top', 'product_title_style', $settings['product_title_style']); ?>
                    </div>

                </div>
            </div>
            