<style>
    /* Container for action buttons */
    .clfe_actions {
        display: flex;
        <?= $settings['actions_container_style'] ?>
    }
    .product-link-button, .add-to-cart-bt-button {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
    }
    .product-link-button {
        <?= $settings['product_link_style'] ?>
    }
    .product-link-button i {
        <?= $settings['product_link_icon_style'] ?>
    }
    .add-to-cart-bt-button {
        <?= $settings['add_to_cart_bt_style'] ?>
    }
    .add-to-cart-bt-button i {
        <?= $settings['add_to_cart_bt_icon_style'] ?>
    }
</style>