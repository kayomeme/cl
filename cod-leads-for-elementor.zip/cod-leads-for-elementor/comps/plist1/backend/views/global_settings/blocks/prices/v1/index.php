<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Product prices container', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row ">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Container style', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Product container prices style', 'clfe'),
                        'styleAttachedTo' => '.plist1 .clfe_prices',
                        'border' => 'yes',
                        'padding' => 'yes',
                        'background' => 'yes',
                        'box-shadow' => 'yes'
                    ];
                    $adminStyle->getAllCss('prices_container_style', $settings['prices_container_style'], $activeOptions);
                    ?>
                </div>
            </div>
            <?php  $adminStyle->getSingleCss('margin-top', 'prices_container_style', $settings['prices_container_style']); ?>
        </div>
    </div>
</div>

<div class="clfe-row">

    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('product regular price', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['regular_price_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="regular_price_is_active" value="<?= $settings['regular_price_is_active'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Product regular price style', 'clfe'),
                        'styleAttachedTo' => '.plist1 .regular_price',
                        'font' => 'yes',
                        'text-shadow' => 'yes',
                    ];
                    $adminStyle->getAllCss('regular_price_style', $settings['regular_price_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <!-- New section for regular price currency styling -->
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Custom currency style', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['regular_price_currency_custom'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="regular_price_currency_custom" value="<?= $settings['regular_price_currency_custom'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Regular price currency style', 'clfe'),
                        'styleAttachedTo' => '.plist1 .regular_price .clfe_currency',
                        'font' => 'yes',
                        'flex-options' => [
                            'blockTitle' => Lang_clfe::__('Align', 'clfe'),
                            'align-items' => Lang_clfe::__('Vertical', 'clfe'),
                        ]
                    ];
                    $adminStyle->getAllCss('regular_price_currency_style', $settings['regular_price_currency_style'], $activeOptions);
                    ?>
                </div>
            </div>
            <!-- End of regular price currency styling -->

            <div class="clfe-row">
                <div class="clfe-td-full">
                    <label>
                        <?= Lang_clfe::_e('Text', 'clfe') ?>
                    </label>
                    <input type="text"  name="regular_price_text" textAttachedTo=".regular_price" value="<?= $settings['regular_price_text'] ?>">
                </div>
                <div class="clfe-alert clfe-alert-info">
                    <?= Lang_clfe::_e('Use @regular_price where you want the regular price to appear', 'clfe') ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('product sale price', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['sale_price_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="sale_price_is_active" value="<?= $settings['sale_price_is_active'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('product sale price style', 'clfe'),
                        'styleAttachedTo' => '.plist1 .sale_price',
                        'font' => 'yes',
                        'text-shadow' => 'yes',
                    ];
                    $adminStyle->getAllCss('sale_price_style', $settings['sale_price_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <!-- New section for sale price currency styling -->
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Custom currency style', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['sale_price_currency_custom'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="sale_price_currency_custom" value="<?= $settings['sale_price_currency_custom'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Sale price currency style', 'clfe'),
                        'styleAttachedTo' => '.plist1 .sale_price .clfe_currency',
                        'font-with-align' => 'yes',
                    ];
                    $adminStyle->getAllCss('sale_price_currency_style', $settings['sale_price_currency_style'], $activeOptions);
                    ?>
                </div>
            </div>
            <!-- End of sale price currency styling -->

            <div class="clfe-row">
                <div class="clfe-td-full">
                    <label>
                        <?= Lang_clfe::_e('Text', 'clfe') ?>
                    </label>
                    <input type="text"  name="sale_price_text" textAttachedTo=".sale_price" value="<?= $settings['sale_price_text'] ?>">
                </div>
                <div class="clfe-alert clfe-alert-info">
                    <?= Lang_clfe::_e('Use @sale_price where you want the sale price to appear', 'clfe') ?>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="clfe-row">

    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('product discount', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['discount_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="discount_is_active" value="<?= $settings['discount_is_active'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Product discount style', 'clfe'),
                        'styleAttachedTo' => '.plist1 .product_discount',
                        'font' => 'yes',
                        'border' => 'yes',
                        'padding' => 'yes',
                        'linear-gradient' => 'yes',
                        'text-shadow' => 'yes',
                    ];
                    $adminStyle->getAllCss('discount_style', $settings['discount_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <!-- New section for discount currency styling -->
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Custom currency style', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['discount_currency_custom'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="discount_currency_custom" value="<?= $settings['discount_currency_custom'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Discount currency style', 'clfe'),
                        'styleAttachedTo' => '.plist1 .product_discount .currency',
                        'font-with-align' => 'yes',
                    ];
                    $adminStyle->getAllCss('discount_currency_style', $settings['discount_currency_style'], $activeOptions);
                    ?>
                </div>
            </div>
            <!-- End of discount currency styling -->

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Discount position', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <select name="discount_position" class="clfe-style-element" value="<?= $settings['discount_position'] ?>">
                        <option value="start"><?= Lang_clfe::_e('Next to prices', 'clfe') ?></option>
                        <option value="end"><?= Lang_clfe::_e('In the End', 'clfe') ?></option>
                    </select>
                </div>
            </div>
            
            <!-- Discount type setting -->
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Discount type', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <select name="discount_type" class="clfe-style-element" value="<?= $settings['discount_type'] ?>">
                        <option value="fixed" <?= $settings['discount_type'] == 'fixed' ? 'selected' : '' ?>><?= Lang_clfe::_e('Fixed value', 'clfe') ?></option>
                        <option value="percentage" <?= $settings['discount_type'] == 'percentage' ? 'selected' : '' ?>><?= Lang_clfe::_e('Percentage', 'clfe') ?></option>
                    </select>
                </div>
            </div>
            
            <div class="clfe-row">
                <div class="clfe-td-full">
                    <label>
                        <?= Lang_clfe::_e('Text', 'clfe') ?>
                    </label>
                    <input type="text" name="discount_text" textAttachedTo=".product-discount-text" value="<?= $settings['discount_text'] ?>">
                </div>
                <div class="clfe-alert clfe-alert-info">
                    <?= Lang_clfe::_e('Use @discount_value where you want the discount value to appear', 'clfe') ?>
                </div>
            </div>
        </div>
    </div>
</div>