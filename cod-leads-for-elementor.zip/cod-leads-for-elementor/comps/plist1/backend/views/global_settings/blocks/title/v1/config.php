<?php return array (
  'setting' => 
  array (
    'title_version' => 'v1',
      'product_title_is_active' => 'yes',
  ),
  'lang' => 
  array (
  ),
  'style' => 
  array (
        'product_title_style' => 'font-size:15px;color:#3399ff;font-weight:700;text-align:center;padding-top:5px;padding-right:5px;padding-bottom:5px;padding-left:5px;',
      ),
);