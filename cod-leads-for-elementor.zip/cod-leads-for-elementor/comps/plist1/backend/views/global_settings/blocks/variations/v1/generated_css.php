<?php
$oldSettings = $settings;
if( $settings['variations_is_active'] == 'yes' ) {
    $settings = AdminCompo_clfe::getSettings('product', $settingsModelId = 0);
    //var_dump($settings);
    include MainApp_clfe::$compsPath.'product/backend/views/global_settings/blocks/variations/v1/generated_css.php';
}

$settings = $oldSettings;
?>

<style>
    .plist1 .clfe_variations {
        <?= $settings['variations_container_style'] ?>
    }
</style>