<style>
    .plist1 .clfe_image {
        height: 220px;
    }
    .plist1 .clfe_image img {
        position: relative;
        height: 100%;
        width: 100%;
        object-fit: cover;
        object-position: center center;
         <?= $settings['product_image_style'] ?>
    }
</style>