<?php
$dirPath = plugin_dir_path( __FILE__ );

if($isPublicAria) {
    require_once   $dirPath.'frontend/controllers/pList1ControllerFR.php';
} else {
    // backend
    require_once $dirPath.'backend/controllers/pList1SettingsControllerBK.php';
}