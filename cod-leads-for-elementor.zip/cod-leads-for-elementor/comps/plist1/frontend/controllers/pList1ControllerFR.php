<?php
/**
 */
class PList1ControllerFR_clfe {
    public $id;
    public $type = 'product';
    


    public function __construct() {

    }
    
    public function default($atts) {
        $compoApp = is_admin() ? new AdminCompo_clfe() : new PublicCompo_clfe();
        // Extract shortcode attributes
        $atts = shortcode_atts(array(
            'category_id' => 0,
            'max_products' => 4, // -1 for all posts
            'settings_model_id' => 0
        ), $atts);

        // Query parameters
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => $atts['max_products'],
        );

        // Add category parameter to query if specified
        if ( $atts['category_id'] ) { 
           $args['cat'] = $atts['category_id'];  
        }

        $settingsModelId = $atts['settings_model_id'];
        
        // Query posts
        $posts_query = new WP_Query($args);

        // Output posts
        $output = 'No posts found';
        
        $compoName = 'plist1';
        $compoSettings = $compoApp::getSettings($compoName, $settingsModelId);
        $mystoreSettings = $compoApp::getSharedSettings($settingsModelId);
        if ($posts_query->have_posts()) {
            ob_start();
           // include MainApp_clfe::$compsPath.$compoName.'/frontend/views/products/index.php';
            $output = ob_get_contents();
            ob_get_clean();
        }
        
        $PList1Css = $compoApp::getGeneratedCss($compoName, $settingsModelId);

        // Restore original post data
        wp_reset_postdata();

        $content = $output.$PList1Css;
        
        return $content;
    }
    /*
     * 
     */
    public function getJsProduct() {
        $jsProduct = [];
        
        $jsProduct['id']                = $this->id;
        
        return jsonEncodeForJs_clfe($jsProduct);
    }
    /*
     * 
     */
}
