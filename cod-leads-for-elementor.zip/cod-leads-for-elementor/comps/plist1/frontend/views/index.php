<?php 
$settingsModelId = 0;
$compoApp = is_admin() ? new AdminCompo_clfe() : new PublicCompo_clfe();
$compoName = 'plist1';
    
$pList1Css = $compoApp::getGeneratedCssForComps($settingsModelId, ['plist1']);
echo $pList1Css;
?>
<div class="plist1">
    <?php
    
    // Output posts
    $output = 'No posts found';

    $settings = $compoApp::getSettings($compoName, $settingsModelId);
    $mystoreSettings = $compoApp::getSharedSettings($settingsModelId);
    while (have_posts()) {
        the_post();
        $productLink = get_permalink();
        $productTitle = get_the_title();
        $productId = get_the_ID();

        $savedProductDetails = ProductModelFR_clfe::getDetails($productId);
        $productDetails = array_merge(ProductModelFR_clfe::$default_details, $savedProductDetails);
        $productVariations = ProductModelFR_clfe::getVariations($productId);
        ?>
        <div class="plist1-product clfe_product clfe_product_<?= $productId ?>" >
            <?php
            $plist1_blocks_order = explode(',', $settings['plist1_blocks_order']);

            foreach ($plist1_blocks_order as $block) {
                include 'blocks/' . $block . '/' . $settings[$block . '_version'] . '/index.php';
            }
            ?>
        </div>
        <?php
    }
    
    // Restore original post data
    wp_reset_postdata();

    

    /* while ( have_posts() ) {
      the_post();
      $post_link = get_permalink();
      ?>
      <article class="post">
      <?php
      printf( '<h2 class="%s"><a href="%s">%s</a></h2>', 'entry-title', esc_url( $post_link ), wp_kses_post( get_the_title() ) );
      if ( has_post_thumbnail() ) {
      printf( '<a href="%s">%s</a>', esc_url( $post_link ), get_the_post_thumbnail( $post, 'large' ) );
      }
      the_excerpt();
      ?>
      </article>
      <?php } */
    ?>
</div>