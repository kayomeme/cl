<?php if( $settings['product_title_is_active'] == 'yes' ) { ?>
<div _attachedsection="title" class="clfe_title">
    <a href="<?= $productLink ?>"> 
        <?= $productTitle ?> 
    </a>
</div>
<?php } ?>