<div _attachedsection="image" class="clfe_image">
    <a href="<?= $productLink ?>">
        <?= has_post_thumbnail() ? get_the_post_thumbnail(get_the_ID(), 'full') : '' ?>
    </a>
</div>