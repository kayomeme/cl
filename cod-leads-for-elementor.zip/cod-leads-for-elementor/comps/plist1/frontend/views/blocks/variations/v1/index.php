<?php
if ($settings['variations_is_active'] == 'no' || empty($productVariations['elements'][0]['title'])) {
    return;
}
?>

<div _attachedsection="variations" class="clfe_variations ">
    <div class="clfe_variation_element">
        <div class="clfe-variations-items">
            <?php
            $variationsPath = MainApp_clfe::$compsPath.'product/frontend/views/blocks/variations/v1/';
            foreach ($productVariations['elements'] as $key => $variation) {
                include $variationsPath.$variation['type'] . '.php';
            }
            ?>
        </div>
    </div>
</div>
