<?php 


// Calculate discount based on type
if ($productDetails['_sale_price'] > 0 && $productDetails['_regular_price'] > 0) {
    $discount_fixed = $productDetails['_regular_price'] - $productDetails['_sale_price'];
    $discount_percentage = round(($discount_fixed / $productDetails['_regular_price']) * 100);

    if ($settings['discount_type'] == 'fixed') {
        $discount_value = $discount_fixed;
        
        // Format discount with styled currency if enabled
        if ($settings['discount_currency_custom'] == 'yes') {
            $discount_display = publicUtils_clfe::formatPriceWithCurrency($discount_value, $mystoreSettings['currency_label'], true);
        } else {
            $discount_display = $discount_value . ' ' . $mystoreSettings['currency_label'];
        }
    } else {
        // For percentage type
        $discount_value = $discount_percentage;
        $discount_display = $discount_value . '%';
    }
} else {
    $discount_value = 0;
    
    // Format zero discount with styled currency if enabled
    if ($settings['discount_currency_custom'] == 'yes' && $settings['discount_type'] == 'fixed') {
        $discount_display = publicUtils_clfe::formatPriceWithCurrency(0, $mystoreSettings['currency_label'], true);
    } else {
        $discount_display = '0 ' . $mystoreSettings['currency_label'];
    }
}

// Format regular and sale prices
$regular_price_formatted = $settings['regular_price_currency_custom'] == 'yes' 
    ? publicUtils_clfe::formatPriceWithCurrency($productDetails['_regular_price'], $mystoreSettings['currency_label'], true)
    : $productDetails['_regular_price'] . ' ' . $mystoreSettings['currency_label'];
    
$sale_price_formatted = $settings['sale_price_currency_custom'] == 'yes'
    ? publicUtils_clfe::formatPriceWithCurrency($productDetails['_sale_price'], $mystoreSettings['currency_label'], true)
    : $productDetails['_sale_price'] . ' ' . $mystoreSettings['currency_label'];

if ($settings['sale_price_is_active'] == 'yes' || $settings['regular_price_is_active'] == 'yes') { 
?>
<div _attachedsection="prices" class="clfe_prices">
    <div class="prices_part">
        <?php if ($settings['sale_price_is_active'] == 'yes') { ?>
        <div class="sale_price">
            <?= publicUtils_clfe::parseVar($settings['sale_price_text'], '@sale_price', $sale_price_formatted) ?>
        </div>
        <?php } ?>

        <?php if ($settings['regular_price_is_active'] == 'yes' && $productDetails['_sale_price'] > 0) { ?>
        <div class="regular_price">
            <?= publicUtils_clfe::parseVar($settings['regular_price_text'], '@regular_price', $regular_price_formatted) ?>
        </div>
        <?php } ?>
    </div>
    <?php if ($settings['discount_is_active'] == 'yes' && $productDetails['_sale_price'] > 0 && $discount_value > 0) { ?>
    <div class="product_discount">
        <?= publicUtils_clfe::parseVar($settings['discount_text'], '@discount_value', $discount_display) ?>
    </div>
    <?php } ?>
    
    
</div>
<?php } ?>