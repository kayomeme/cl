<?php if($settings['product_link_is_active'] == 'yes' || $settings['add_to_cart_bt_is_active'] == 'yes') { ?>
<div _attachedsection="actions" class="clfe_actions">
    <?php if( $settings['product_link_is_active'] == 'yes' ) { ?>
    <a class="product-link-button" href="<?= $productLink ?>">
        <?php if( $settings['product_link_icon_is_active'] == 'yes' ) { ?>
        <i class="clfe-icon icon-eye"></i>
        <?php } ?>
        <?= $settings['product_link_text'] ?>
    </a>
    <?php } ?>
    
    <!-- Add to Cart Button -->
    <?php if( $settings['add_to_cart_bt_is_active'] == 'yes' ) { 
        $pdata = [
            'product_id' => $productId,
            'title' => $productTitle,
            'short_image_url' => get_the_post_thumbnail_url($productId, 'thumbnail'),
            'regular_price' => $productDetails['_regular_price'],
            'sale_price' => $productDetails['_sale_price'],
            'discount_per_product' => $productDetails['_regular_price'] - $productDetails['_sale_price'],
            'qty' => 1,
            'added_via' => 'category'
        ];
        
    ?>
    <button class="add-to-cart-bt-button" pdata='<?= jsonEncodeForJs_clfe($pdata) ?>' >
        <?php if( $settings['add_to_cart_bt_icon_is_active'] == 'yes' ) { ?>
        <i class="clfe-icon icon-shopping-cart"></i>
        <?php } ?>
        <?= $settings['add_to_cart_bt_text'] ?>
    </button>
    <?php } ?>
</div>
<?php } ?>