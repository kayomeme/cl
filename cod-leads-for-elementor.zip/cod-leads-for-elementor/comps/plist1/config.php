<?php

/**
 * general
 */
return array(
    'setting' => [
        'active_blocks' => 'image,title,prices,actions,variations',  
        'plist1_blocks_order' => 'image,title,prices,actions,variations',
        //'plist1_blocks_order' => 'prices,buy_button,image,title',
        
    ],
    'lang' => [
        /*'plist1_regular_price_text_before' => 'Original Price',
        'plist1_regular_price_text_after' => '',
        'plist1_sale_price_text_before' => 'Sale Price',
        'plist1_sale_price_text_after' => 'Sale Price',
        'plist1_bt_text' => 'Click here to order',*/
    ],
    'style' => [
        'plist1_product_style' => 'border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:#ffffff;border-style:solid;border-top-left-radius:58px;border-top-right-radius:13px;border-bottom-left-radius:5px;border-bottom-right-radius:5px;background-color:#f9f9f9;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;box-shadow:1px 7px 5px -1px #333333;',
    ]
);
