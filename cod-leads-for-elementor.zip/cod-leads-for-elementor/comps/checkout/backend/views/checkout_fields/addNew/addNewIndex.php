<!-- 

Update this like the edit template so you can have the same design

-->

<div id="cl_addnew_checkout_field" class="edit-field__wrapper">
    <div class="edit-field__header">
        <h2><?= Lang_cl::__('Add New Checkout Field', 'cl') ?></h2>
    </div>
    <form class="edit-checkout-field" method="POST" action="">
        <!-- Main Content -->
        <div class="edit-field__main">
            <div class="edit-field__section">
                <div class="cl-group cl-group--flex">
                    <label><?= Lang_cl::__('Field Name', 'cl') ?></label>
                    <input type="text" name="name" required>
                    <div class="cl-alert cl-alert-info">
                        <?= Lang_cl::__('The field name should be unique and contain only lowercase letters, numbers, and underscores.', 'cl') ?>
                    </div>
                </div>

                <div class="cl-group cl-group--flex">
                    <label><?= Lang_cl::__('Field Type', 'cl') ?></label>
                    <select name="type" required>
                        <?php foreach ($fieldTypes as $value => $label): ?>
                            <option value="<?= htmlspecialchars($value) ?>">
                                <?= $label ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-row-flex">
                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Label', 'cl') ?></label>
                        <input type="text" name="label">
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Placeholder', 'cl') ?></label>
                        <input type="text" name="placeholder">
                    </div>
                </div>

                <div class="form-row-flex">
                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Default Value', 'cl') ?></label>
                        <input type="text" name="default_value">
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('CSS Class', 'cl') ?></label>
                        <input type="text" name="css_class">
                    </div>
                </div>

                <div class="form-row-flex">
                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Is Required', 'cl') ?></label>
                        <select name="is_required" class="cl-select">
                            <option value="no"><?= Lang_cl::__('No', 'cl') ?></option>
                            <option value="yes"><?= Lang_cl::__('Yes', 'cl') ?></option>
                        </select>
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Is Active', 'cl') ?></label>
                        <select name="is_active" class="cl-select">
                            <option value="yes"><?= Lang_cl::__('Yes', 'cl') ?></option>
                            <option value="no"><?= Lang_cl::__('No', 'cl') ?></option>
                        </select>
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Position', 'cl') ?></label>
                        <input type="number" name="position" value="0" min="0">
                    </div>
                </div>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Error Message', 'cl') ?></label>
                    <input type="text" name="error_message">
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="edit-field__sidebar">
            <div class="edit-field__section">
                <h3><?= Lang_cl::__('Validation Settings', 'cl') ?></h3>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Minimum Length', 'cl') ?></label>
                    <input type="number" name="min_length" value="0" min="0">
                </div>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Maximum Length', 'cl') ?></label>
                    <input type="number" name="max_length" value="100" min="0">
                </div>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Custom Validation Pattern', 'cl') ?></label>
                    <input type="text" name="validation_pattern">
                    <div class="cl-alert cl-alert-info">
                        <?= Lang_cl::__('Enter a regular expression for custom validation.', 'cl') ?>
                    </div>
                </div>
            </div>

            <div class="edit-field__section">
                <h3><?= Lang_cl::__('Display Options', 'cl') ?></h3>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Icon', 'cl') ?></label>
                    <select name="icon" class="cl-select">
                        <option value=""><?= Lang_cl::__('No Icon', 'cl') ?></option>
                        <?php foreach ($iconList as $value => $label): ?>
                            <option value="<?= htmlspecialchars($value) ?>">
                                <?= $label ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="cl-group">
                    <label><?= Lang_cl::__('Is System Field', 'cl') ?></label>
                    <select name="is_system_field" class="cl-select">
                        <option value="no"><?= Lang_cl::__('No', 'cl') ?></option>
                        <option value="yes"><?= Lang_cl::__('Yes', 'cl') ?></option>
                    </select>
                    <div class="cl-alert cl-alert-warning">
                        <?= Lang_cl::__('System fields are core checkout fields. Only set this to Yes if you are recreating a standard field.', 'cl') ?>
                    </div>
                </div>
            </div>

            <div class="edit-field__section">
                <h3><?= Lang_cl::__('Condition Rules', 'cl') ?></h3>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Condition Variable', 'cl') ?></label>
                    <select name="condition_variable" class="cl-select">
                        <option value=""><?= Lang_cl::__('Select an option', 'cl') ?></option>
                        <option value="city"><?= Lang_cl::__('City', 'cl') ?></option>
                        <option value="total"><?= Lang_cl::__('Total', 'cl') ?></option>
                    </select>
                </div>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Condition Operator', 'cl') ?></label>
                    <select name="condition_operator" class="cl-select">
                        <option value=""></option>
                        <?php foreach ($conditionOperators as $value => $title): ?>
                            <option value="<?= htmlspecialchars($value) ?>"><?= $title ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Condition Value', 'cl') ?></label>
                    <input type="text" name="condition_value">
                    <div id="condition_value_info" class="cl-alert cl-alert-info cl-hide">
                        <?= Lang_cl::__('For multiple values, separate them by commas (e.g., value1,value2,value3). The condition will match if any of these values are found in the input.', 'cl') ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Actions -->
        <div id="cl-sticky-bottom-bar">
            <div class="cl-container">
                <div class="edit-field__actions">
                    <button id="save-new-checkout-field" type="submit" class="cl-button button button-primary">
                        <?= Lang_cl::__('Add Checkout Field', 'cl') ?>
                    </button>
                    <a href="<?= admin_url('admin.php?page=cl_checkout_fields') ?>" class="button button-secondary">
                        <?= Lang_cl::__('Cancel', 'cl') ?>
                    </a>
                </div>

                <div class="cl-user-fedback">
                    <div class="cl-msg_box">
                        <div class="cl-wait_msg"></div>
                        <div class="alert"></div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>