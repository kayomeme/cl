<?php
/**
 * Edit Checkout Field Form Template
 */
?>
<div id="cl_update_checkout_field" class="edit-field__wrapper">
    <div class="edit-field__header">

    </div>
    <form class="edit-checkout-field" method="POST" action="">
        <!-- Main Content -->
        <div class="edit-field__main">
                <div class="form-row-flex">
                    <h2><?= Lang_cl::__('Edit Checkout Field:', 'cl') ?> <?= $checkoutField->name ?> </h2>
                    
                    <?php if ($checkoutField->is_system_field == 'no') { ?>
                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Field Type', 'cl') ?></label>
                        <select name="type" required>
                            <?php foreach ($fieldTypes as $value => $label): ?>
                                <option value="<?= htmlspecialchars($value) ?>" <?= $checkoutField->type == $value ? 'selected' : '' ?>>
                                    <?= $label ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php } ?>
                    
                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Is Active', 'cl') ?></label>
                        <select name="is_active" class="cl-select">
                            <option value="yes" <?= $checkoutField->is_active == 'yes' ? 'selected' : '' ?>>
                                <?= Lang_cl::__('Yes', 'cl') ?>
                            </option>
                            <option value="no" <?= $checkoutField->is_active == 'no' ? 'selected' : '' ?>>
                                <?= Lang_cl::__('No', 'cl') ?>
                            </option>
                        </select>
                    </div>
                </div>
            
            <div class="edit-field__section">
                <div class="form-row-flex">
                <div class="cl-group cl-group--flex">
                    <label><?= Lang_cl::__('Field Name', 'cl') ?></label>
                    <input type="text" name="name" value="<?= $checkoutField->name ?>" required <?= $checkoutField->is_system_field == 'yes' ? 'readonly' : '' ?>>
                    <?php if ($checkoutField->is_system_field == 'yes'): ?>
                        <div class="cl-alert cl-alert-info">
                            <?= Lang_cl::__('System field names cannot be changed.', 'cl') ?>
                        </div>
                    <?php else: ?>
                        <div class="cl-alert cl-alert-info">
                            <?= Lang_cl::__('The field name should be unique and contain only lowercase letters, numbers, and underscores.', 'cl') ?>
                        </div>
                    <?php endif; ?>
                </div>

                    <div class="cl-group">
                        <?php 
                        IconsSelectorBK_cl::getButton([
                            'name' => 'icon_id',
                            'value' => $checkoutField->icon_id,
                        ]);
                        ?>
                    </div>
                </div>
                <div class="form-row-flex">
                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Label', 'cl') ?></label>
                        <input type="text" name="label" value="<?= $checkoutField->label ?>">
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Placeholder', 'cl') ?></label>
                        <input type="text" name="placeholder" value="<?= $checkoutField->placeholder ?>">
                    </div>
                </div>

                <!--<div class="form-row-flex">
                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Default Value', 'cl') ?></label>
                        <input type="text" name="default_value" value="<?= $checkoutField->default_value ?>">
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('CSS Class', 'cl') ?></label>
                        <input type="text" name="css_class" value="<?= $checkoutField->css_class ?>">
                    </div>
                </div> -->

                <h3><?= Lang_cl::__('Validation Settings', 'cl') ?></h3>    
                <div class="form-row-flex">


                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Is Required', 'cl') ?></label>
                        <select name="is_required" class="cl-select">
                            <option value="no" <?= $checkoutField->is_required == 'no' ? 'selected' : '' ?>>
                                <?= Lang_cl::__('No', 'cl') ?>
                            </option>
                            <option value="yes" <?= $checkoutField->is_required == 'yes' ? 'selected' : '' ?>>
                                <?= Lang_cl::__('Yes', 'cl') ?>
                            </option>
                        </select>
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Minimum Length', 'cl') ?></label>
                        <input type="number" name="min_length" value="<?= $checkoutField->min_length ?>" min="0">
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Maximum Length', 'cl') ?></label>
                        <input type="number" name="max_length" value="<?= $checkoutField->max_length ?>" min="0">
                    </div>

                </div>
                
                <div class="form-row-flex">                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Custom Validation Pattern', 'cl') ?></label>
                        <input type="text" name="validation_pattern" value="<?= $checkoutField->validation_pattern ?>">
                        <div class="cl-alert cl-alert-info">
                            <?= Lang_cl::__('Enter a regular expression for custom validation.', 'cl') ?>
                        </div>
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Error Message', 'cl') ?></label>
                        <input type="text" name="error_message" value="<?= $checkoutField->error_message ?>">
                    </div>
                </div>


            </div>

        </div>

        <!-- Sidebar -->
        <div class="edit-field__sidebar">

            <div class="edit-field__section">
                <h3><?= Lang_cl::__('Condition Rules', 'cl') ?></h3>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Condition Variable', 'cl') ?></label>
                    <select name="condition_variable" class="cl-select">
                        <option value=""><?= Lang_cl::__('Select an option', 'cl') ?></option>
                        <option value="city" <?= $checkoutField->condition_variable == 'city' ? 'selected' : '' ?>>
                            <?= Lang_cl::__('City', 'cl') ?>
                        </option>
                        <option value="total" <?= $checkoutField->condition_variable == 'total' ? 'selected' : '' ?>>
                            <?= Lang_cl::__('Total', 'cl') ?>
                        </option>
                    </select>
                </div>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Condition Operator', 'cl') ?></label>
                    <select name="condition_operator" class="cl-select">
                        <option value=""></option>
                        <?php foreach ($conditionOperators as $value => $title): ?>
                            <option value="<?= htmlspecialchars($value) ?>" <?= ($checkoutField->condition_operator === $value) ? 'selected' : '' ?>>
                                <?= $title ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Condition Value', 'cl') ?></label>
                    <input type="text" name="condition_value" value="<?= $checkoutField->condition_value ?>">
                    <div id="condition_value_info" class="cl-alert cl-alert-info cl-hide">
                        <?= Lang_cl::__('For multiple values, separate them by commas (e.g., value1,value2,value3). The condition will match if any of these values are found in the input.', 'cl') ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Update the actions div with fixed positioning -->
        <div id="cl-sticky-bottom-bar">
            <div class="cl-container">
                <div class="edit-field__actions">
                    <input type="hidden" name="id" value="<?= $checkoutField->id ?>" cl-ischanged="yes">
                    <button id="save-update-checkout-field" type="submit" class="cl-button button button-primary">
                        <?= Lang_cl::__('Update Checkout Field', 'cl') ?>
                    </button>
                    <a href="<?= admin_url('admin.php?page=cl_checkout_fields') ?>" class="button button-secondary">
                        <?= Lang_cl::__('Cancel', 'cl') ?>
                    </a>
                </div>

                <div class="cl-user-fedback">
                    <div class="cl-msg_box">
                        <div class="cl-wait_msg"></div>
                        <div class="alert"></div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>