<div class="checkout-fields-wrapper">
    <div class="cl-header-tab">
        <div class="cl-title-tab">
            <?= Lang_cl::_e('Checkout Fields', 'cl') ?>
        </div>
        <a href="<?= admin_url('admin.php?page=cl_checkout_fields&action=addnew') ?>" class="cl-button cl-addnew">
            <span class="dashicons dashicons-plus"></span>
            <?= Lang_cl::_e('Add New Checkout Field', 'cl') ?>
        </a>
    </div>
    <div class="checkout-fields">
        <?php foreach ($checkoutFields as $field): ?>
        <div id="field-<?= $field->id ?>" class="checkout-field <?= $field->is_active == 'yes' ? 'field-active' : 'field-inactive' ?> <?= $field->is_system_field == 'yes' ? 'field-system' : '' ?>">
            <div class="checkout-field__header">
                <div class="checkout-field__title">
                    <h3>
                        <?php if (!empty($field->icon)): ?>
                            <span class="dashicons dashicons-<?= $field->icon ?>"></span>
                        <?php endif; ?>
                        <?= $field->name ?>
                        <?php if ($field->is_system_field == 'yes'): ?>
                            <span class="checkout-field__system-tag"><?= Lang_cl::__('System', 'cl') ?></span>
                        <?php endif; ?>
                    </h3>
                    
                    <span class="checkout-field__type">
                        <?= isset($fieldTypes[$field->type]) ? $fieldTypes[$field->type] : $field->type ?>
                    </span>
                    
                    <span class="checkout-field__required">
                        <?= Lang_cl::__('Required: ', 'cl') . ($field->is_required == 'yes' ? Lang_cl::__('Yes', 'cl') : Lang_cl::__('No', 'cl')) ?>
                    </span>
                    
                    <?php if ($field->is_active != 'yes'): ?>
                        <span class="checkout-field__inactive-tag"><?= Lang_cl::__('Inactive', 'cl') ?></span>
                    <?php endif; ?>
                </div>
                <div class="checkout-field__actions">
                    <a href="<?= admin_url('admin.php?page=cl_checkout_fields&action=edit&field_id=' . $field->id) ?>" class="cl-button button button-primary">
                        <span class="dashicons dashicons-edit"></span>
                        <?= Lang_cl::__('Edit', 'cl') ?>
                    </a>
                    <?php if ($field->is_system_field != 'yes'): ?>
                    <button class="cl-button checkout-field__btn--delete save-delete-checkout-field" field_id="<?= $field->id ?>">
                        <?= Lang_cl::__('Delete', 'cl') ?>
                    </button>
                    <?php endif; ?>
                </div>
            </div>

            <div class="checkout-field__details">
                <?php if (!empty($field->label)): ?>
                    <div class="checkout-field__placeholder">
                        <span class="dashicons dashicons-tag"></span>
                        <?= Lang_cl::__('Label: ', 'cl') ?> <?= $field->label ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($field->placeholder)): ?>
                    <div class="checkout-field__placeholder">
                        <span class="dashicons dashicons-welcome-write-blog"></span>
                        <?= Lang_cl::__('Placeholder: ', 'cl') ?> <?= $field->placeholder ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($field->condition_variable)): ?>
                    <div class="checkout-field__condition">
                        <span class="dashicons dashicons-filter"></span>
                        <?= Lang_cl::__('Condition: ', 'cl') ?>
                        <code><?= $field->condition_variable ?></code>
                        <?= $field->condition_operator == 'equals' ? '=' : 
                           ($field->condition_operator == 'not_equals' ? '≠' : 
                           ($field->condition_operator == 'contains' ? 'contains' : 
                           ($field->condition_operator == 'not_contains' ? 'not contains' : 
                           ($field->condition_operator == 'greater_than' ? '>' : 
                           ($field->condition_operator == 'less_than' ? '<' : $field->condition_operator))))) ?>
                        <code><?= $field->condition_value ?></code>
                    </div>
                <?php endif; ?>
                
                <div class="checkout-field__validation">
                    <span class="dashicons dashicons-shield"></span>
                    <?= Lang_cl::__('Validation: ', 'cl') ?>
                    <?php if ($field->min_length > 0 || $field->max_length > 0): ?>
                        <?= Lang_cl::__('Length ', 'cl') ?>
                        <?php if ($field->min_length > 0): ?>
                            <?= Lang_cl::__('min:', 'cl') ?> <?= $field->min_length ?>
                        <?php endif; ?>
                        <?php if ($field->max_length > 0): ?>
                            <?= Lang_cl::__('max:', 'cl') ?> <?= $field->max_length ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if (!empty($field->validation_pattern)): ?>
                        <?= Lang_cl::__('Pattern: ', 'cl') ?> <code><?= $field->validation_pattern ?></code>
                    <?php endif; ?>
                    <?php if (empty($field->min_length) && empty($field->max_length) && empty($field->validation_pattern)): ?>
                        <?= Lang_cl::__('None', 'cl') ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        
        <?php if (empty($checkoutFields)): ?>
        <div class="checkout-field">
            <p><?= Lang_cl::__('No checkout fields found. Click "Add New Checkout Field" to create one.', 'cl') ?></p>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Delete confirmation and feedback -->
<div id="cl_delete_checkout_field">
    <div id="cl-sticky-bottom-bar">
        <div class="cl-container">
            <input type="hidden" name="field_id" cl-ischanged="yes">
            <div class="cl-user-fedback">
                <div class="cl-msg_box">
                    <div class="cl-wait_msg"></div>
                    <div class="alert"></div>
                </div>
            </div>
        </div>        
    </div>
</div>