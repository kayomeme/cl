<?php
/**
 * Edit Shipping Option Form Template
 */
?>
<div id="cl_update_shipping_option" class="edit-option__wrapper">
    <div class="edit-option__header">
        <h2><?= Lang_cl::__('Edit Shipping Option:', 'cl') ?> <?= $shippingOption->title ?> </h2>
    </div>
    <form class="edit-shipping-option" method="POST" action="">
        <!-- Main Content -->
        <div class="edit-option__main">
            <div class="edit-option__section">
                <div class="cl-group cl-group--flex">
                    <label><?= Lang_cl::__('Title', 'cl') ?></label>
                    <input type="text" name="title" value="<?= $shippingOption->title ?>" required>
                </div>

                <div class="cl-group cl-group--flex">
                    <label><?= Lang_cl::__('Subtitle', 'cl') ?></label>
                    <input type="text" name="subtitle" value="<?= $shippingOption->subtitle ?>">
                </div>

                <div class="form-row-flex">
                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Cost Value', 'cl') ?> (<?= $currencyCode ?>)</label>
                        <input type="number" name="cost_value" value="<?= $shippingOption->cost_value ?>" step="0.01">
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Cost Label', 'cl') ?></label>
                        <input type="text" name="cost_label" value="<?= $shippingOption->cost_label ?>" placeholder="<?= Lang_cl::__('e.g. En 3 jours', 'cl') ?>">
                    </div>
                </div>

                <div class="form-row-flex">
                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Badge Text', 'cl') ?></label>
                        <input type="text" name="badge_text" value="<?= $shippingOption->badge_text ?>" placeholder="<?= Lang_cl::__('e.g. FREE, FAST', 'cl') ?>">
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Active', 'cl') ?></label>
                        <select name="is_active" class="cl-select">
                            <option value="yes" <?= $shippingOption->is_active == 'yes' ? 'selected' : '' ?>>
                                <?= Lang_cl::__('Yes', 'cl') ?>
                            </option>
                            <option value="no" <?= $shippingOption->is_active == 'no' ? 'selected' : '' ?>>
                                <?= Lang_cl::__('No', 'cl') ?>
                            </option>
                        </select>
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Position', 'cl') ?></label>
                        <input type="number" name="position" value="<?= $shippingOption->position ?>" min="0">
                    </div>
                </div>
            </div>

            <div class="edit-option__section">
                <h3><?= Lang_cl::__('Media', 'cl') ?></h3>
                
                <div class="form-row-flex">
                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Thumbnail', 'cl') ?></label>
                        <div class="cl-media-upload" data-target="thumbnail">
                            <input type="hidden" name="thumbnail_id" value="<?= $shippingOption->thumbnail_id ?>">
                            <input type="hidden" name="thumbnail_url" value="<?= $shippingOption->thumbnail_url ?>">
                            <div class="cl-media-preview">
                                <?php if(!empty($shippingOption->thumbnail_url)): ?>
                                    <img src="<?= $shippingOption->thumbnail_url ?>" alt="Thumbnail">
                                <?php endif; ?>
                            </div>
                            <button type="button" class="button select-media"><?= Lang_cl::__('Select Image', 'cl') ?></button>
                            <button type="button" class="button remove-media" <?= empty($shippingOption->thumbnail_url) ? 'style="display:none"' : '' ?>>
                                <?= Lang_cl::__('Remove', 'cl') ?>
                            </button>
                        </div>
                    </div>

                    <div class="cl-group cl-group--flex">
                        <label><?= Lang_cl::__('Background Image', 'cl') ?></label>
                        <div class="cl-media-upload" data-target="bg">
                            <input type="hidden" name="bg_id" value="<?= $shippingOption->bg_id ?>">
                            <input type="hidden" name="bg_url" value="<?= $shippingOption->bg_url ?>">
                            <div class="cl-media-preview">
                                <?php if(!empty($shippingOption->bg_url)): ?>
                                    <img src="<?= $shippingOption->bg_url ?>" alt="Background">
                                <?php endif; ?>
                            </div>
                            <button type="button" class="button select-media"><?= Lang_cl::__('Select Image', 'cl') ?></button>
                            <button type="button" class="button remove-media" <?= empty($shippingOption->bg_url) ? 'style="display:none"' : '' ?>>
                                <?= Lang_cl::__('Remove', 'cl') ?>
                            </button>
                        </div>
                    <div class="cl-alert cl-alert-info">
                        <?= Lang_cl::_e('When you choose the background image option, all other elements such as thumbnail, title, and prices will be automatically hidden.', 'cl') ?>
                    </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="edit-option__sidebar">
            <div class="edit-option__section">
                <h3><?= Lang_cl::__('Condition Rules', 'cl') ?></h3>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Condition Variable', 'cl') ?></label>
                    <select name="condition_variable" class="cl-select">
                        <option></option>
                        <option value="city" <?= $shippingOption->condition_variable == 'city' ? 'selected' : '' ?>>
                            <?= Lang_cl::__('City', 'cl') ?>
                        </option>
                        <option value="total" <?= $shippingOption->condition_variable == 'total' ? 'selected' : '' ?>>
                            <?= Lang_cl::__('Total', 'cl') ?>
                        </option>
                    </select>
                </div>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Condition Operator', 'cl') ?></label>
                    <select name="condition_operator" class="cl-select">
                        <option></option>
                        <?php foreach ($conditionOperators as $value => $title): ?>
                            <option value="<?= htmlspecialchars($value) ?>" <?= ($shippingOption->condition_operator === $value) ? 'selected' : '' ?>>
                                <?= $title ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="cl-group">
                    <label><?= Lang_cl::__('Condition Value', 'cl') ?></label>
                    <input type="text" name="condition_value" value="<?= $shippingOption->condition_value ?>">
                    <div id="condition_value_info" class="cl-alert cl-alert-info cl-hide">
                        <?= Lang_cl::__('For multiple values, separate them by commas (e.g., value1,value2,value3). The condition will match if any of these values are found in the input.', 'cl') ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Update the actions div with fixed positioning -->
        <div id="cl-sticky-bottom-bar">
            <div class="cl-container">
                <div class="edit-option__actions">
                    <input type="hidden" name="id" value="<?= $shippingOption->id ?>" cl-ischanged="yes">
                    <button id="save-update-shipping-option" type="submit" class="cl-button button button-primary">
                        <?= Lang_cl::__('Update Shipping Option', 'cl') ?>
                    </button>
                    <a href="<?= admin_url('admin.php?page=cl_shipping_options') ?>" class="button button-secondary">
                        <?= Lang_cl::__('Cancel', 'cl') ?>
                    </a>
                </div>

                <div class="cl-user-fedback">
                    <div class="cl-msg_box">
                        <div class="cl-wait_msg"></div>
                        <div class="alert"></div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>