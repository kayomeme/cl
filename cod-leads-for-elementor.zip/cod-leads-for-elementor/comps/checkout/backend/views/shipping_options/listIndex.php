<div class="shipping-options-wrapper">
    <div class="cl-header-tab">
        <div class="cl-title-tab">
            <?= Lang_cl::_e('Shipping Options', 'cl') ?>
        </div>
        <a href="<?= admin_url('admin.php?page=cl_shipping_options&action=addnew') ?>" class="cl-button cl-addnew">
            <span class="dashicons dashicons-plus"></span>
            <?= Lang_cl::_e('Add New Shipping Option', 'cl') ?>
        </a>
    </div>
    <div class="shipping-options">
        <?php foreach ($shippingOptions as $option): ?>
        <div id="option-<?= $option->id ?>" class="shipping-option <?= $option->is_active == 'yes' ? 'option-active' : 'option-inactive' ?>">
            <div class="shipping-option__header">
                <div class="shipping-option__title">
                    <h3>
                        <?php if (!empty($option->badge_text)): ?>
                            <span class="shipping-option__badge">
                                <?= $option->badge_text ?>
                            </span>
                        <?php endif; ?>
                        <?= $option->title ?>
                    </h3>
                    
                    <?php if (!empty($option->subtitle)): ?>
                        <span class="shipping-option__subtitle"><?= $option->subtitle ?></span>
                    <?php endif; ?>
                    
                    <span class="shipping-option__cost">
                        <?= Lang_cl::__('Cost: ', 'cl') . $option->cost_value ?> <?= $sharedSettings['currency_code'] ?>
                        <?php if (!empty($option->cost_label)): ?>
                            <span class="shipping-option__cost-label">(<?= $option->cost_label ?>)</span>
                        <?php endif; ?>
                    </span>
                    
                    <?php if ($option->is_active != 'yes'): ?>
                        <span class="shipping-option__inactive-tag"><?= Lang_cl::__('Inactive', 'cl') ?></span>
                    <?php endif; ?>
                </div>
                <div class="shipping-option__actions">
                    <a href="<?= admin_url('admin.php?page=cl_shipping_options&action=edit&option_id=' . $option->id) ?>" class="cl-button button button-primary">
                        <span class="dashicons dashicons-edit"></span>
                        <?= Lang_cl::__('Edit', 'cl') ?> 
                    </a>
                    <button class="cl-button shipping-option__btn--delete save-delete-shipping-option" option_id="<?= $option->id ?>">
                        <?= Lang_cl::__('Delete', 'cl') ?>
                    </button>
                </div>
            </div>

            <div class="shipping-option__details">
                <?php if (!empty($option->condition_variable)): ?>
                    <div class="shipping-option__condition">
                        <span class="dashicons dashicons-filter"></span>
                        <?= Lang_cl::__('Condition: ', 'cl') ?>
                        <code><?= $option->condition_variable ?></code>
                        <?= $option->condition_operator == 'equals' ? '=' : 
                           ($option->condition_operator == 'not_equals' ? '≠' : 
                           ($option->condition_operator == 'contains' ? 'contains' : 
                           ($option->condition_operator == 'not_contains' ? 'not contains' : 
                           ($option->condition_operator == 'greater_than' ? '>' : 
                           ($option->condition_operator == 'less_than' ? '<' : $option->condition_operator))))) ?>
                        <code><?= $option->condition_value ?></code>
                    </div>
                <?php endif; ?>

                <div class="shipping-option__media">
                    <?php if (!empty($option->thumbnail_url)): ?>
                        <span class="shipping-option__feature">
                            <span class="dashicons dashicons-format-image"></span>
                            <?= Lang_cl::__('Has Thumbnail', 'cl') ?>
                        </span>
                    <?php endif; ?>
                    
                    <?php if (!empty($option->bg_url)): ?>
                        <span class="shipping-option__feature">
                            <span class="dashicons dashicons-admin-appearance"></span>
                            <?= Lang_cl::__('Has Background', 'cl') ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Delete confirmation and feedback -->
<div id="cl_delete_shipping_option">
    <div id="cl-sticky-bottom-bar">
        <div class="cl-container">
            <input type="hidden" name="option_id" cl-ischanged="yes">
            <div class="cl-user-fedback">
                <div class="cl-msg_box">
                    <div class="cl-wait_msg"></div>
                    <div class="alert"></div>
                </div>
            </div>
        </div>        
    </div>
</div>