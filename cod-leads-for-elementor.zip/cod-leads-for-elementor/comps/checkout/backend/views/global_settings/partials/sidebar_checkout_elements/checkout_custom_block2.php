<div class="clfe-row" _attachedsection="checkout_custom_block2">
    <span class="dashicons dashicons-yes"></span>
    <span class="clfe-label-draggable">
        <?= Lang_clfe::_e('Custom block2', 'clfe') ?>
    </span>
    <div class="clfe-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>