<div class="clfe-row clfe-type-select">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Error messages placement', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <select name="error_placement" class="clfe-style-element" value="<?= $settings['error_placement'] ?>">
            <option value="before_submit_button"><?= Lang_clfe::_e('Before submit button', 'clfe') ?></option>
            <option value="after_submit_button"><?= Lang_clfe::_e('After submit button', 'clfe') ?></option>
            <option value="after_every_field"><?= Lang_clfe::_e('After every field', 'clfe') ?></option>
            <!--<option value="show_in_popup"><?= Lang_clfe::_e('Show in popup', 'clfe') ?></option>-->
        </select> 
        
        <?php 
            $activeOptions = [
               'font' => 'yes', 'border' => 'yes'
            ];
            $adminStyle->getAllCss('error_msg_style', $settings['error_msg_style'], $activeOptions); 
        ?>
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('waiting messages to show after the button is clicked', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <input type="text"  name="error_wait_text" value="<?= $settings['error_wait_text'] ?>">
        <?php 
            $activeOptions = [
                'font' => 'yes'
            ];
            $adminStyle->getAllCss('error_wait_text_style', $settings['error_wait_text_style'], $activeOptions); 
        ?>
        
        <div class="clfe-sub-section">
            <div class="clfe-td">
                <label>
                    <?= Lang_clfe::_e('Show wait icon', 'clfe') ?>
                </label>
            </div>
            <div class="clfe-td">
                <label class="clfe-switch">
                  <input type="checkbox" <?= $settings['error_wait_icon_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                  <span class="clfe-slider clfe-round"></span>
                  <input type="hidden" name="error_wait_icon_is_active" value="<?= $settings['error_wait_icon_is_active'] ?>">
                </label>
                
            </div>
        </div>
    </div>
</div>

<div class="clfe-row clfe-type-select">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Error message when the variation is not selected', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <input type="text"  name="error_variation_not_selected" value="<?= $settings['error_variation_not_selected'] ?>">
        
    </div>
</div>