<div class="clfe-row" _attachedsection="checkout_custom_block1">
    <span class="dashicons dashicons-yes"></span>
    <span class="clfe-label-draggable">
        <?= Lang_clfe::_e('Custom block1', 'clfe') ?>
    </span>
    <div class="clfe-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>