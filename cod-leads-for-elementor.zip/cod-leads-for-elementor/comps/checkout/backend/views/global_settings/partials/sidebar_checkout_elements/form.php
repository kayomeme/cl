<div class="clfe-row" _attachedsection="form">
    <span class="dashicons dashicons-list-view"></span>
    <span class="clfe-label-draggable">
        <?= Lang_clfe::_e('Form', 'clfe') ?>
    </span>
    <div class="clfe-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>