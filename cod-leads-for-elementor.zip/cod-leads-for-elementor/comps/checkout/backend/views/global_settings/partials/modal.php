<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Modal settings', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row clfe-type-select">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Transparency color', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <select name="checkout_modal_bg_transparency_color" class="clfe-style-element" value="<?= $settings['checkout_modal_bg_transparency_color'] ?>">
                        <option value="0,0,0"><?= Lang_clfe::_e('Black', 'clfe') ?></option>
                        <option value="255,255,255"><?= Lang_clfe::_e('White', 'clfe') ?></option>
                    </select> 
                </div>
            </div>
            <div class="clfe-row clfe-type-select">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Transparency level', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="number" class="clfe-style-element" name="checkout_modal_bg_transparency_level" min="0" max="99" value="<?= $settings['checkout_modal_bg_transparency_level'] ?>">

                </div>
            </div>
            <div class="clfe-row ">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Header close button', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['checkout_modal_header_close_bt_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="checkout_modal_header_close_bt_is_active" value="<?= $settings['checkout_modal_header_close_bt_is_active'] ?>">
                    </label>

                    <?php 
                        $activeOptions = [
                            'font' => 'yes', 'background' => 'yes' , 'border' => 'yes', 'padding' => 'yes'
                        ];
                        $adminStyle->getAllCss('checkout_modal_header_close_bt_style', $settings['checkout_modal_header_close_bt_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            <div class="clfe-row ">
                <div class="clfe-th-full clfe-style-container">
                    <label>
                        <?= Lang_clfe::_e('Footer close button', 'clfe') ?>
                    </label>
                    <?php 
                        $activeOptions = [
                            'font' => 'yes', 'border' => 'yes', 'padding' => 'yes'
                        ];
                        $adminStyle->getAllCss('checkout_modal_footer_text_close_style', $settings['checkout_modal_footer_text_close_style'], $activeOptions); 
                    ?>
                </div>
                <div class="clfe-td-full">
                    <input type="text"  name="checkout_modal_footer_text_close" value="<?= $settings['checkout_modal_footer_text_close'] ?>">
                    <div class="clfe-alert clfe-alert-info"><?= Lang_clfe::_e('leave it empty if you don\'t want to show it', 'clfe') ?></div>
                </div>
            </div>
        </div>
        

    </div>
</div>