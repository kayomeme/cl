
<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Checkout Sections Order', 'clfe') ?>
        </label>
        <div class="clfe-alert clfe-alert-info">
            Drag and drop to reorder the sections in your checkout. The new order will update how they appear on the frontend.
        </div>
    </div>
    <div class="clfe-td">
        <input type="text"  name="checkout_blocks_order" value="<?= $settings['checkout_blocks_order'] ?>">

        <div class="clfe-sub-section">
            <div id="clfe-checkout-elements">
            <?php 
                foreach ($checkoutBlocksOrder as $checkoutElement) {
                    include 'sidebar_checkout_elements/'.$checkoutElement.'.php';
                }
            ?>
            </div>
        </div>
        <div class="clfe-alert clfe-alert-info">
                <?= Lang_clfe::_e('To change the order of display on the frontend, simply drag and drop the elements in the list.', 'clfe') ?>
        </div>
    </div>
</div>