<div class="clfe-row" _attachedsection="shipping_options">
    <span class="dashicons dashicons-cart"></span>
    <span class="clfe-label-draggable">
        <?= Lang_clfe::_e('Shipping options', 'clfe') ?>
    </span>
    <div class="clfe-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>