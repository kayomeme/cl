<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Checkout container', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Style', 'clfe') ?>
                    </label> 
                </div>
                <div class="clfe-td">

                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Checkout container style', 'clfe'),
                            'styleAttachedTo' => '.clfe-product-container',
                            'border' => 'yes', 'padding' => 'yes', 'linear-gradient' => 'yes', 'box-shadow' => 'yes'
                        ];
                        $adminStyle->getAllCss('checkout_container_style', $settings['checkout_container_style'], $activeOptions); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="clfe-row checkout-modal-settings">
    <?php include 'modal.php'; ?>
</div>
