
<div class="cl-row ">
    <div class="cl-th">
        <label>
            <?= Lang_cl::_e('Checkout Sections Order', 'cl') ?>
        </label>
        <div class="cl-alert cl-alert-info">
            Drag and drop to reorder the sections in your checkout. The new order will update how they appear on the frontend.
        </div>
    </div>
    <div class="cl-td">
        <input type="text"  name="checkout_blocks_order" value="<?= $settings['checkout_blocks_order'] ?>">

        <div class="cl-sub-section">
            <div id="cl-checkout-elements">
            <?php 
                foreach ($checkoutBlocksOrder as $checkoutElement) {
                    include 'blocks_order_elements/'.$checkoutElement.'.php';
                }
            ?>
            </div>
        </div>
        <div class="cl-alert cl-alert-info">
                <?= Lang_cl::_e('To change the order of display on the frontend, simply drag and drop the elements in the list.', 'cl') ?>
        </div>
    </div>
</div>