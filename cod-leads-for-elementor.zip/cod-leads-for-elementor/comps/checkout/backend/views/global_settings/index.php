<div id="clfe_general_tab" class="clfe-single-tab">
    <?php include 'partials/general.php'; ?>
</div>

<div id="clfe_shipping_options_tab" class="clfe-single-tab">
    <?php include 'blocks/shipping_options/'.$settings['shipping_options_version'].'/index.php'; ?>
</div>

<div id="clfe_form_tab" class="clfe-single-tab">
    <?php include 'blocks/form/'.$settings['form_version'].'/index.php'; ?>
</div>

<div id="clfe_submit_button_tab" class="clfe-single-tab">
    <?php include 'blocks/submit_button/'.$settings['submit_button_version'].'/index.php'; ?>
</div>


<div id="clfe_summary_tab" class="clfe-single-tab">
    <?php include 'blocks/summary/'.$settings['summary_version'].'/index.php'; ?>
</div>

<div id="clfe_checkout_custom_blocks_tab" class="clfe-single-tab">
    <?php include 'blocks/checkout_custom_block1/'.$settings['checkout_custom_block1_version'].'/index.php'; ?>
    <?php include 'blocks/checkout_custom_block2/'.$settings['checkout_custom_block2_version'].'/index.php'; ?>
</div>

<?php /*  ?>
<div id="clfe_checkout_custom_block1_tab" class="clfe-single-tab">
    <?php include 'blocks/custom_block1/'.$settings['checkout_custom_block1_version'].'/index.php'; ?>
</div>

<div id="clfe_checkout_custom_block2_tab" class="clfe-single-tab">
    <?php include 'blocks/custom_block2/'.$settings['checkout_custom_block2_version'].'/index.php'; ?>
</div>

<?php */ ?>

<div id="clfe_checkout_blocks_order_tab" class="clfe-single-tab">
    <?php include 'partials/blocks_order.php'; ?>
</div>


<div id="clfe_error_handling_tab" class="clfe-single-tab">
    <?php include 'partials/error_handling.php'; ?>
</div>

<input type="text" name="checkout_blocks_order" value="<?= $settings['checkout_blocks_order'] ?>">
<input type="text" name="form_version" value="<?= $settings['form_version'] ?>">
<input type="text" name="summary_version" value="<?= $settings['summary_version'] ?>">
<input type="text" name="shipping_options_version" value="<?= $settings['shipping_options_version'] ?>">
<input type="text" name="submit_button_version" value="<?= $settings['submit_button_version'] ?>">
<input type="text" name="checkout_custom_block1_version" value="<?= $settings['checkout_custom_block1_version'] ?>">
<input type="text" name="checkout_custom_block2_version" value="<?= $settings['checkout_custom_block2_version'] ?>">