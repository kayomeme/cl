<div id="cl_general_tab" class="cl-single-tab">
    <?php include 'blocks/general/v1/index.php'; ?>
</div>

<div id="cl_shipping_options_tab" class="cl-single-tab">
    <?php include 'blocks/shipping_options/'.$settings['shipping_options_version'].'/index.php'; ?>
</div>

<div id="cl_form_tab" class="cl-single-tab">
    <?php include 'blocks/form/'.$settings['form_version'].'/index.php'; ?>
</div>

<div id="cl_submit_button_tab" class="cl-single-tab">
    <?php include 'blocks/submit_button/'.$settings['submit_button_version'].'/index.php'; ?>
</div>


<div id="cl_summary_tab" class="cl-single-tab">
    <?php include 'blocks/summary/'.$settings['summary_version'].'/index.php'; ?>
</div>

<div id="cl_checkout_custom_blocks_tab" class="cl-single-tab">
    <?php include 'custom_blocks.php'; ?>
</div>

<?php /*  ?>
<div id="cl_checkout_custom_block1_tab" class="cl-single-tab">
    <?php include 'blocks/custom_block1/'.$settings['checkout_custom_block1_version'].'/index.php'; ?>
</div>

<div id="cl_checkout_custom_block2_tab" class="cl-single-tab">
    <?php include 'blocks/custom_block2/'.$settings['checkout_custom_block2_version'].'/index.php'; ?>
</div>

<?php */ ?>

<div id="cl_checkout_modal_tab" class="cl-single-tab">
    <?php include 'blocks/checkout_modal/'.$settings['checkout_modal_version'].'/index.php'; ?>
</div>

<div id="cl_checkout_blocks_order_tab" class="cl-single-tab">
    <?php include 'blocks_order.php'; ?>
</div>


<div id="cl_error_handling_tab" class="cl-single-tab">
    <?php include 'error_handling.php'; ?>
</div>

<div style="display: none">
<input type="text" name="checkout_blocks_order" value="<?= $settings['checkout_blocks_order'] ?>">
<input type="text" name="form_version" value="<?= $settings['form_version'] ?>">
<input type="text" name="summary_version" value="<?= $settings['summary_version'] ?>">
<input type="text" name="shipping_options_version" value="<?= $settings['shipping_options_version'] ?>">
<input type="text" name="submit_button_version" value="<?= $settings['submit_button_version'] ?>">
<input type="text" name="checkout_custom_block1_version" value="<?= $settings['checkout_custom_block1_version'] ?>">
<input type="text" name="checkout_custom_block2_version" value="<?= $settings['checkout_custom_block2_version'] ?>">
<input type="text" name="checkout_modal_version" value="<?= $settings['checkout_modal_version'] ?>">
</div>