<button tab="clfe_general_tab" _section="clfe-checkout-sections">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_clfe::_e('General', 'clfe') ?>
</button>
<button tab="clfe_form_tab" _section="clfe_form">
    <span class="dashicons dashicons-list-view"></span>
    <?= Lang_clfe::_e('Form', 'clfe') ?>
</button>
<button tab="clfe_submit_button_tab" _section="clfe_submit_button">
    <span class="dashicons dashicons-yes"></span>
    <?= Lang_clfe::_e('Submit button', 'clfe') ?>
</button>
<button tab="clfe_shipping_options_tab" _section="clfe_shipping_options">
    <span class="dashicons dashicons-admin-multisite"></span>
    <?= Lang_clfe::_e('Shipping options', 'clfe') ?>
</button>
<button tab="clfe_summary_tab" _section="clfe_summary">
    <span class="dashicons dashicons-cart"></span>
    <?= Lang_clfe::_e('Order summary', 'clfe') ?>
</button>

<button tab="clfe_checkout_custom_blocks_tab">
    <span class="dashicons dashicons-cart"></span>
    <?= Lang_clfe::_e('Custom blocks', 'clfe') ?>
</button>

<ul class="clfe-sidetab-submenu" attachedButonTab="clfe_checkout_custom_blocks_tab">
    <li tab="clfe_checkout_custom_block1_tab" _section="clfe_checkout_custom_block1">
        <?= Lang_clfe::_e('Custom block1', 'clfe') ?>
    </li>
    <li tab="clfe_checkout_custom_block2_tab" _section="clfe_checkout_custom_block2">
        <?= Lang_clfe::_e('Custom block2', 'clfe') ?>
    </li>
</ul>

<!--<button tab="clfe_checkout_custom_blocks_tab" _section="clfe_checkout_custom_blocks" class="clfe_checkout_custom_block1 clfe_checkout_custom_block2">
    <span class="dashicons dashicons-cart"></span>
    <?= Lang_clfe::_e('Custom blocks', 'clfe') ?>
</button>

<ul class="clfe-sidetab-submenu clfe_checkout_custom_blocks_tab_submenu">
    <li tab="clfe_checkout_custom_block1_tab" _section="clfe_checkout_custom_block1">
        <?= Lang_clfe::_e('Custom block1', 'clfe') ?>
    </li>
    <li tab="clfe_checkout_custom_block2_tab" _section="clfe_checkout_custom_block2">
        <?= Lang_clfe::_e('Custom block2', 'clfe') ?>
    </li>
</ul> -->


<button tab="clfe_error_handling_tab">
    <span class="dashicons dashicons-dismiss"></span>
    <?= Lang_clfe::_e('Error handling', 'clfe') ?>
</button>

<button tab="clfe_checkout_blocks_order_tab" _section="clfe_checkout_blocks_order">
    <span class="dashicons dashicons-layout"></span>
    <?= Lang_clfe::_e('Checkout blocks order', 'clfe') ?>
</button>