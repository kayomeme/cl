<button tab="cl_general_tab" _section="cl-checkout-sections">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_cl::_e('General', 'cl') ?>
</button>
<button tab="cl_form_tab" _section="cl_form">
    <span class="dashicons dashicons-list-view"></span>
    <?= Lang_cl::_e('Form', 'cl') ?>
</button>
<button tab="cl_submit_button_tab" _section="cl_submit_button">
    <span class="dashicons dashicons-yes"></span>
    <?= Lang_cl::_e('Submit button', 'cl') ?>
</button>
<button tab="cl_shipping_options_tab" _section="cl_shipping_options">
    <span class="dashicons dashicons-admin-multisite"></span>
    <?= Lang_cl::_e('Shipping options', 'cl') ?>
</button>
<button tab="cl_summary_tab" _section="cl_summary">
    <span class="dashicons dashicons-cart"></span>
    <?= Lang_cl::_e('Order summary', 'cl') ?>
</button>

<button tab="cl_checkout_custom_blocks_tab">
    <span class="dashicons dashicons-cart"></span>
    <?= Lang_cl::_e('Custom blocks', 'cl') ?>
</button>

<!--<button tab="cl_checkout_custom_blocks_tab" _section="cl_checkout_custom_blocks" class="cl_checkout_custom_block1 cl_checkout_custom_block2">
    <span class="dashicons dashicons-cart"></span>
    <?= Lang_cl::_e('Custom blocks', 'cl') ?>
</button>

<ul class="cl-sidetab-submenu cl_checkout_custom_blocks_tab_submenu">
    <li tab="cl_checkout_custom_block1_tab" _section="cl_checkout_custom_block1">
        <?= Lang_cl::_e('Custom block1', 'cl') ?>
    </li>
    <li tab="cl_checkout_custom_block2_tab" _section="cl_checkout_custom_block2">
        <?= Lang_cl::_e('Custom block2', 'cl') ?>
    </li>
</ul> -->

<button tab="cl_checkout_modal_tab" _section="cl_checkout_modal">
    <span class="dashicons dashicons-controls-play"></span>
    <?= Lang_cl::_e('Checkout Modal options', 'cl') ?>
</button>

<button tab="cl_error_handling_tab">
    <span class="dashicons dashicons-dismiss"></span>
    <?= Lang_cl::_e('Error handling', 'cl') ?>
</button>

<button tab="cl_checkout_blocks_order_tab" _section="cl_checkout_blocks_order">
    <span class="dashicons dashicons-layout"></span>
    <?= Lang_cl::_e('Checkout blocks order', 'cl') ?>
</button>