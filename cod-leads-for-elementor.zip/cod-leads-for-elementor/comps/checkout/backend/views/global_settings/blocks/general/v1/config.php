<?php return array (
  'setting' => 
  array (

  ),
  'lang' => 
  array (

  ),
  'style' => 
  array (
    'checkout_container_style' => 'border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:#333333;border-style:solid;border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;background-image:linear-gradient(0deg,#ffffff,#ffffff);box-shadow:0px 0px 0px 0;',
  ),
);