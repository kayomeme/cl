<style>
    #clfe_checkout_custom_block1 {
        <?= $settings['checkout_custom_block1_container_style'] ?>
    }
</style>