
<div class="cl-row ">
    <div class="cl-th">
        <label>
            <?= Lang_cl::_e('Checkout container', 'cl') ?>
        </label>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <label>
                        <?= Lang_cl::_e('Style', 'cl') ?>
                    </label> 
                </div>
                <div class="cl-td">
                    <?php 
                        $styleManager->getAllCss('checkout_container_style'); 
                    ?>
                </div>
            </div>
            <?php 
            $styleManager->getSingleCss('max-width', 'checkout_container_style');
            ?>
        </div>
    </div>
</div>