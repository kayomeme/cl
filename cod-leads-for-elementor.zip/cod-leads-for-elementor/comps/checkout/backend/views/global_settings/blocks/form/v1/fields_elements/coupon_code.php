    <fieldset class="clfe-row clfe-row-coupon_code" _attachedsection="coupon_code">
        <legend class="clfe-accordion">
            <i class="clfe-icon icon-gift"></i>
            <span class="clfe-label-draggable">
                <?= Lang_clfe::_e('Coupon code', 'clfe') ?>
            </span>
            <div class="clfe-draggable-icons-container">
                <span class="dashicons dashicons-sort"></span>
                <span class="dashicons dashicons-move"></span>
            </div>
        </legend>
        <div class="clfe-accordion-panel clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['coupon_code_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="coupon_code_is_active" value="<?= $settings['coupon_code_is_active'] ?>">
                    </label>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Label', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="coupon_code_label" textAttachedTo=".form-coupon_code-container .form-label-container" value="<?= $settings['coupon_code_label'] ?>">

                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Placeholder', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="coupon_code_placeholder" textAttachedTo="input[name=coupon_code]" value="<?= $settings['coupon_code_placeholder'] ?>">
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is required', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['coupon_code_is_req'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="coupon_code_is_req" value="<?= $settings['coupon_code_is_req'] ?>">
                    </label>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Min length', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="number"  name="coupon_code_minlength" value="<?= $settings['coupon_code_minlength'] ?>">
                    <div class="clfe-alert clfe-alert-info"><?= Lang_clfe::_e('The min length is verified only for required field', 'clfe') ?></div>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Error coupon_code', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="coupon_code_error_msg" value="<?= $settings['coupon_code_error_msg'] ?>">
                </div>
            </div>
        </div>
    </fieldset>