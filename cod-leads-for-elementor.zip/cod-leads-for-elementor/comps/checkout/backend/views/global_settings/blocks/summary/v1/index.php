<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Order summary section', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'summary_is_active',
                        'value' => $settings['summary_is_active']
                    ]);

                    $styleManager->getAllCss('summary_container_style'); 
                    ?>
                </div>
            </div>
            <?php $styleManager->getSingleCss('margin-top', 'summary_container_style'); ?>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Show icons', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'summary_icons_is_active',
                        'value' => $settings['summary_icons_is_active']
                    ]);

                    $styleManager->getAllCss('summary_icons_style'); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Order summary header', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'summary_header_is_active',
                        'value' => $settings['summary_header_is_active']
                    ]);
                    $styleManager->getAllCss('summary_header_container_style');
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is open by default', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'summary_header_is_open',
                        'value' => $settings['summary_header_is_open']
                    ]);
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Title', 'cl') ?>
                </div>
                <div class="cl-td cl-sub-section">
                    <div class="cl-row">
                        <div class="cl-th">
                            <?= Lang_cl::_e('Style', 'cl') ?>
                        </div>
                        <div class="cl-td">
                            <?php $styleManager->getAllCss('summary_header_title_style'); ?>
                        </div>
                    </div>
                    <div class="cl-row">
                        <div class="cl-th">
                            <?= Lang_cl::_e('Is open', 'cl') ?>
                        </div>
                        <div class="cl-td cl-style-container">
                            <input type="text" name="summary_header_title_is_open" textAttachedTo=".summary_header_title_is_open" 
                                   value="<?= $settings['summary_header_title_is_open'] ?>" placeholder="<?= Lang_cl::_e('Title when the section is open', 'cl') ?>">
                        </div>
                    </div>
                    <div class="cl-row">
                        <div class="cl-th">
                            <?= Lang_cl::_e('Is closed', 'cl') ?>
                        </div>
                        <div class="cl-td">
                            <input type="text" name="summary_header_title_is_closed" textAttachedTo=".summary_header_title_is_closed" 
                                   value="<?= $settings['summary_header_title_is_closed'] ?>" placeholder="<?= Lang_cl::_e('Title when the section is closed', 'cl') ?>">
                        </div>
                    </div>
                </div>
            </div>

            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Count text', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <input type="text"  name="summary_header_count_text" textAttachedTo=".summary-header-count-text .count_text" value="<?= $settings['summary_header_count_text'] ?>" placeholder="<?= Lang_cl::_e('Count items text', 'cl') ?>">
                    <?php
                    $styleManager->getAllCss('summary_header_count_text_style');
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Icons style', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    $styleManager->getAllCss('summary_header_icon_style');
                    ?>
                </div>
            </div>

            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Total Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'summary_header_total_is_active',
                        'value' => $settings['summary_header_total_is_active']
                    ]);
                    $styleManager->getAllCss('summary_header_total_style');
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Summary Body Container', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Container style', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getAllCss('summary_body_container_style');
                    ?>
                </div>
            </div>

        </div>

    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Cart Products', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'summary_cart_products_is_active',
                        'value' => $settings['summary_cart_products_is_active']
                    ]);
                    
                    $styleManager->getAllCss('summary_cart_products_container_style');
                    ?>
                </div>
            </div>
            <?php $styleManager->getSingleCss('margin-top', 'summary_cart_products_container_style'); ?>
        </div>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Cart Totals', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'summary_cart_totals_is_active',
                        'value' => $settings['summary_cart_totals_is_active']
                    ]);
                    
                    $styleManager->getAllCss('summary_cart_totals_container_style');
                    ?>
                </div>
            </div>
            <?php $styleManager->getSingleCss('margin-top', 'summary_cart_totals_container_style'); ?>
        </div>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Discount options', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'summary_discount_is_active',
                        'value' => $settings['summary_discount_is_active']
                    ]);
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Label', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <input type="text" name="summary_discount_label" textAttachedTo="#cl_summary .p_discount_label" value="<?= $settings['summary_discount_label'] ?>">
                    <?php 
                    $styleManager->getAllCss('summary_discount_label_style'); 
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Text before value', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <input type="text" name="summary_discount_value" textAttachedTo="#cl_summary .p_discount_text" value="<?= $settings['summary_discount_value'] ?>">
                    <?php 
                    $styleManager->getAllCss('summary_discount_value_style'); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Shipping fees options', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'summary_shipping_is_active',
                        'value' => $settings['summary_shipping_is_active']
                    ]);
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th" title="<?= Lang_cl::__('Shipping fees label', 'cl') ?>">
                    <?= Lang_cl::_e('Label', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <input type="text" name="summary_shipping_label" textAttachedTo="#cl_summary .p_shipping_text" value="<?= $settings['summary_shipping_label'] ?>">
                    <?php 
                    $styleManager->getAllCss('summary_shipping_label_style'); 
                    ?>
                </div> 
            </div>
            <div class="cl-row">
                <div class="cl-th" title="<?= Lang_cl::__('Default Shipping fees value', 'cl') ?>">
                    <?= Lang_cl::_e('Default value', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <input type="text" name="summary_shipping_title" textAttachedTo="#cl_summary .shipping-fees .key-price" value="<?= $settings['summary_shipping_title'] ?>">
                    <?php 
                    $styleManager->getAllCss('summary_shipping_title_style'); 
                    ?>
                </div>
                <div class="cl-alert cl-alert-info">
                    <?= Lang_cl::__('This option is applied by default. However, if you have already configured the shipping settings, this will be skipped, and your custom shipping settings will be used.', 'cl') ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Total to pay Options', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th" title="<?= Lang_cl::_e('Total to pay label', 'cl') ?>">
                    <?= Lang_cl::_e('Label', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <input type="text" name="summary_total_label" textAttachedTo="#cl_summary .order-total .key-name" value="<?= $settings['summary_total_label'] ?>">
                    <?php 
                    $styleManager->getAllCss('summary_total_label_style'); 
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th" title="<?= Lang_cl::_e('Total value style', 'cl') ?>">
                    <?= Lang_cl::_e('Value style', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php 
                    $styleManager->getAllCss('summary_total_value_style'); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Footer text', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'summary_payment_msg_is_active',
                        'value' => $settings['summary_payment_msg_is_active']
                    ]);

                    $styleManager->getAllCss('summary_payment_msg_style'); 
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <!-- the textAttachedTo is applicated directly in simulator_bk.js -->
                <textarea name="summary_payment_msg" rows="2"><?= $settings['summary_payment_msg'] ?></textarea>
            </div>
        </div>
    </div>
</div>