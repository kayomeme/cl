<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Order summary section', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['summary_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="summary_is_active" value="<?= $settings['summary_is_active'] ?>">
                    </label>

                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Order summary : Container styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_summary',
                            'border' => 'yes', 'padding' => 'yes', 'margin' => 'yes', 'linear-gradient' => 'yes', 'box-shadow' => 'yes'
                        ];
                        $adminStyle->getAllCss('summary_container_style', $settings['summary_container_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            <?php $adminStyle->getSingleCss('margin-top', 'summary_container_style', $settings['summary_container_style']); ?>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is open by default', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['summary_header_is_open'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="summary_header_is_open" value="<?= $settings['summary_header_is_open'] ?>">
                    </label>
                </div>
            </div>
            <div class="clfe-row ">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Show icons', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['summary_icons_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="summary_icons_is_active" value="<?= $settings['summary_icons_is_active'] ?>">
                    </label>

                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Order summary : icons styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_summary .clfe-icon',
                            'font' => 'yes'
                        ];
                        $adminStyle->getAllCss('summary_icons_style', $settings['summary_icons_style'], $activeOptions); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Order summary header', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['summary_header_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="summary_header_is_active" value="<?= $settings['summary_header_is_active'] ?>">
                    </label>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th-full">
                    <label>
                        <?= Lang_clfe::_e('Title when the section is open', 'clfe') ?>
                    </label>

                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Order summary : title styling', 'clfe'),
                            'styleAttachedTo' => '.order-summary-header-title',
                            'font' => 'yes'
                        ];
                        $adminStyle->getAllCss('summary_header_title_style', $settings['summary_header_title_style'], $activeOptions); 
                    ?>
                </div>
                <div class="clfe-td-full">
                    <input type="text"  name="summary_header_title_is_open" textAttachedTo=".summary_header_title_is_open" value="<?= $settings['summary_header_title_is_open'] ?>" placeholder="<?= Lang_clfe::_e('Title when the section is open', 'clfe') ?>">
                </div>
                <div class="clfe-th-full">
                    <label>
                        <?= Lang_clfe::_e('Title when the section is closed', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td-full">
                    <input type="text"  name="summary_header_title_is_closed" textAttachedTo=".summary_header_title_is_closed" value="<?= $settings['summary_header_title_is_closed'] ?>" placeholder="<?= Lang_clfe::_e('Title when the section is closed', 'clfe') ?>">
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Total Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['summary_header_total_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="summary_header_total_is_active" value="<?= $settings['summary_header_total_is_active'] ?>">
                    </label>

                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Order summary : total styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_summary .clfe_toggle_header .key-price',
                            'font' => 'yes'
                        ];
                        $adminStyle->getAllCss('summary_header_total_style', $settings['summary_header_total_style'], $activeOptions); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Cart Products', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['summary_cart_products_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="summary_cart_products_is_active" value="<?= $settings['summary_cart_products_is_active'] ?>">
                    </label>
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Cart : Container styling', 'clfe'),
                        'styleAttachedTo' => '#clfe_summary_cart_products',
                        'padding' => 'yes',
                    ];
                    $adminStyle->getAllCss('summary_cart_products_container_style', $settings['summary_cart_products_container_style'], $activeOptions);
                    ?>
                </div>
            </div>
            <?php $adminStyle->getSingleCss('margin-top', 'summary_cart_products_container_style', $settings['summary_cart_products_container_style']); ?>
        </div>
    </div>
</div>


<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Cart Totals', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['summary_cart_totals_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="summary_cart_totals_is_active" value="<?= $settings['summary_cart_totals_is_active'] ?>">
                    </label>
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Cart totals : Container styling', 'clfe'),
                        'styleAttachedTo' => '#clfe_summary_cart_totals',
                        'padding' => 'yes',
                    ];
                    $adminStyle->getAllCss('summary_cart_totals_container_style', $settings['summary_cart_totals_container_style'], $activeOptions);
                    ?>
                </div>
            </div>
            <?php $adminStyle->getSingleCss('margin-top', 'summary_cart_totals_container_style', $settings['summary_cart_totals_container_style']); ?>
        </div>
    </div>
</div>



<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Discount options', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label> 
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['summary_discount_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="summary_discount_is_active" value="<?= $settings['summary_discount_is_active'] ?>">
                    </label>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Label', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <input type="text"  name="summary_discount_label" textAttachedTo="#clfe_summary .p_discount_label" value="<?= $settings['summary_discount_label'] ?>">
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Discount label styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_summary .p_discount_label',
                            'font' => 'yes'
                        ];
                        $adminStyle->getAllCss('summary_discount_label_style', $settings['summary_discount_label_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Text before value', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <input type="text"  name="summary_discount_value" textAttachedTo="#clfe_summary .p_discount_text" value="<?= $settings['summary_discount_value'] ?>">
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Discount value styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_summary .clfe-product-discount .key-price',
                            'font' => 'yes', 'background' => 'yes', 'border' => 'yes', 'padding' => 'yes'
                        ];
                        $adminStyle->getAllCss('summary_discount_value_style', $settings['summary_discount_value_style'], $activeOptions); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Shipping fees options', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <?= Lang_clfe::_e('Is active', 'clfe') ?>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['summary_shipping_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="summary_shipping_is_active" value="<?= $settings['summary_shipping_is_active'] ?>">
                    </label>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label title="<?= Lang_clfe::__('Shipping fees label', 'clfe') ?>">
                        <?= Lang_clfe::_e('Label', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <input type="text"  name="summary_shipping_label" textAttachedTo="#clfe_summary .p_shipping_text" value="<?= $settings['summary_shipping_label'] ?>">
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Shipping fees label styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_summary .shipping-fees .key-name',
                            'font' => 'yes'
                        ];
                        $adminStyle->getAllCss('summary_shipping_label_style', $settings['summary_shipping_label_style'], $activeOptions); 
                    ?>
                </div> 
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label title="<?= Lang_clfe::__('Default Shipping fees value', 'clfe') ?>">
                        <?= Lang_clfe::_e('Default value', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <input type="text"  name="summary_shipping_title" textAttachedTo="#clfe_summary .shipping-fees .key-price" value="<?= $settings['summary_shipping_title'] ?>">
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Default Shipping fees value styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_summary .shipping-fees .key-price',
                            'font' => 'yes', 'background' => 'yes', 'border' => 'yes', 'padding' => 'yes'
                        ];
                        $adminStyle->getAllCss('summary_shipping_title_style', $settings['summary_shipping_title_style'], $activeOptions); 
                    ?>
                </div>
                <div class="clfe-alert clfe-alert-info">
                    <?= Lang_clfe::__('This option is applied by default. However, if you have already configured the shipping settings, this will be skipped, and your custom shipping settings will be used.', 'clfe') ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Total to pay Options', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label title="<?= Lang_clfe::_e('Total to pay label', 'clfe') ?>">
                        <?= Lang_clfe::_e('Label', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <input type="text"  name="summary_total_label" textAttachedTo="#clfe_summary .order-total .key-name" value="<?= $settings['summary_total_label'] ?>">
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Total label styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_summary .order-total .key-name',
                            'font' => 'yes'
                        ];
                        $adminStyle->getAllCss('summary_total_label_style', $settings['summary_total_label_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            <div class="clfe-row ">
                <div class="clfe-th">
                    <label title="<?= Lang_clfe::_e('Total value style', 'clfe') ?>">
                        <?= Lang_clfe::_e('Value style', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Total value styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_summary .order-total .key-price',
                            'font' => 'yes'
                        ];
                        $adminStyle->getAllCss('summary_total_value_style', $settings['summary_total_value_style'], $activeOptions); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Footer text', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <?= Lang_clfe::_e('Is active', 'clfe') ?>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['summary_payment_msg_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="summary_payment_msg_is_active" value="<?= $settings['summary_payment_msg_is_active'] ?>">
                    </label>

                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Payment message styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_summary .payment-msg',
                            'font' => 'yes'
                        ];
                        $adminStyle->getAllCss('summary_payment_msg_style', $settings['summary_payment_msg_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            <div class="clfe-row">
                    <!-- the textAttachedTo is applicated directly in simulator_bk.js -->
                <?php wp_editor( $settings['summary_payment_msg'], $editor_id = 'summary_payment_msg', $editorArgs ); ?>
            </div>
        </div>
    </div>
</div>






