<?php
return array(
    'checkout_custom_block2_container_style' => [
        'modal_title' => Lang_cl::__('Checkout Modal header block Container style', 'cl'),
        'style_attached_to' => '.cl-checkout-sections #cl_checkout_custom_block2',
        'single_css_supported' => ['margin-top'],
        'font-with-align' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes', 
        'linear-gradient' => 'yes',
        'padding' => 'yes',
        'box-shadow' => 'yes',
    ],
);