<style>
    .cl_checkout_modal { 
        background-color:rgba(<?= $settings['checkout_modal_bg_transparency_color'] ?>,0.<?= $settings['checkout_modal_bg_transparency_level'] ?>) !important; 
        
    }
    .cl_checkout_modal .cl_modal_container {
        <?= $settings['checkout_modal_container_style'] ?>
        width: 100%;
        max-width: <?= $settings['checkout_modal_max_width'].'px' ?>;
    }
    
    .cl_checkout_modal .cl_modal_header {
        <?= $settings['checkout_modal_header_style'] ?>
    }
    
    .cl_checkout_modal .cl_modal_logo img {
        max-width: <?= $settings['checkout_modal_logo_width'].'px' ?>;
        <?= $settings['checkout_modal_logo_style'] ?>
    }
    
    /*--this important to center the title , dont delete --*/
    .cl_checkout_modal .cl_modal_title {
        min-width: <?= $settings['checkout_modal_logo_width'].'px' ?>;
    }
    
    .cl_checkout_modal .cl_modal_close {
        <?= $settings['checkout_modal_close_bt_style'] ?>
    }
    
    .cl_checkout_modal .cl_modal_body {
        <?= $settings['checkout_modal_body_style'] ?>
    }
    
</style>