<?php return array (
  'setting' => 
  array (
    'form_version' => 'v1',
    'form_heading_is_active' => 'no',
    'form_fields_icon_is_active' => 'yes',
    'form_fields_label_is_active' => 'yes',
  ),
  'lang' => 
  array (
    'form_heading' => 'Pour commander, Merci de remplir le formulaire',
  ),
  'style' => 
  array (
    'form_container_style' => 'margin-top:0px;border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:var(--cl-ButtonsBG);border-style:solid;border-top-left-radius:10px;border-top-right-radius:10px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;box-shadow:0px 0px 0px 0px rgba(0,0,0,0.2);',
    'form_heading_style' => 'font-size:16px;color:#111827;font-weight:700;text-align:center;padding-top:10px;padding-bottom:10px;',
    'form_fields_container_style' => 'padding-top:20px;padding-right:10px;padding-bottom:5px;padding-left:10px;',
    'form_fields_icon_style' => '',
    'form_fields_entry_style' => 'font-size:14px;color:#111827;font-weight:normal;border-width:1px;border-color:#d1d5db;border-style:solid;border-radius:6px;background-color:#ffffff;padding-top:10px;padding-right:12px;padding-bottom:10px;padding-left:12px;',
    'form_fields_label_style' => 'font-size:14px;color:#374151;font-weight:600;',
  ),
);