<div id="clfe_checkout_custom_block1_tab" class="clfe-subtab">
<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Modal header block', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['checkout_custom_block1_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="checkout_custom_block1_is_active" value="<?= $settings['checkout_custom_block1_is_active'] ?>">
                    </label>
                    
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Checkout Modal header block Container style', 'clfe'),
                            'styleAttachedTo' => '.clfe-checkout-sections #clfe_checkout_custom_block1',
                            'border' => 'yes', 
                            'linear-gradient' => 'yes',
                            'margin' => 'yes',
                            'padding' => 'yes',
                            'box-shadow' => 'yes',
                        ];
                        $adminStyle->getAllCss('checkout_custom_block1_container_style', $settings['checkout_custom_block1_container_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            <?php $adminStyle->getSingleCss('margin-top', 'checkout_custom_block1_container_style', $settings['checkout_custom_block1_container_style']); ?>
            <div class="clfe-row">
                <div class="clfe-td-full">
                    <?php wp_editor( $settings['checkout_custom_block1_content'], $editor_id = 'checkout_custom_block1_content', $editorArgs ); ?>
                </div>
            </div>
        </div>
    </div>
</div>
</div>