<style>
#cl_summary {
    <?= $settings['summary_container_style'] ?>
}
#cl_summary > .cl_toggle_header {
    <?= $settings['summary_header_container_style'] ?>
}
#cl_summary > .cl_toggle_header .toggle-title {
    <?= $settings['summary_header_title_style'] ?>
}

.summary-header-count-text {
    <?= $settings['summary_header_count_text_style'] ?>
}
#cl_summary > .cl_toggle_header .cl-icon {
    <?= $settings['summary_header_icon_style'] ?>
}

#cl_summary > .cl_toggle_body {
    <?= $settings['summary_body_container_style'] ?>
}

#cl_summary .detail-row {
    padding: 4px 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

#cl_summary .key-name {
    display: flex;
    align-items: center;
    gap:4px;
}

#cl_summary .order-summary-header-title {<?= $settings['summary_header_title_style'] ?>}
#cl_summary .cl_toggle_header .key-price {<?= $settings['summary_header_total_style'] ?>}
#cl_summary .cl-icon {<?= $settings['summary_icons_style'] ?>}

#cl_summary .cl-product-discount .key-name {<?= $settings['summary_discount_label_style'] ?>}
#cl_summary .cl-product-discount .key-price {<?= $settings['summary_discount_value_style'] ?>}
#cl_summary .cl-product-discount .key-price .icon-gift {<?= $settings['summary_discount_value_style'] ?>}
#cl_summary .shipping-fees .key-name {<?= $settings['summary_shipping_label_style'] ?>}
#cl_summary .shipping-fees .key-price {<?= $settings['summary_shipping_title_style'] ?>}
#cl_summary .order-total .key-name {<?= $settings['summary_total_label_style'] ?>}
#cl_summary .order-total .key-price {<?= $settings['summary_total_value_style'] ?>}
#cl_summary .payment-msg {
    padding-top: 0px;
    <?= StyleManagerBK_cl::convertAlignToJustifyContent($settings['summary_payment_msg_style'])  ?>
}

/*------- overridden cart blocks ----------*/
#cl_summary .cl_cart_products .cl_toggle_body {
    <?= $settings['summary_cart_products_container_style'] ?>
}
#cl_summary .cl_cart_totals {
    <?= $settings['summary_cart_totals_container_style'] ?>
}
    
@media screen and (max-width: 400px) {

}
</style>