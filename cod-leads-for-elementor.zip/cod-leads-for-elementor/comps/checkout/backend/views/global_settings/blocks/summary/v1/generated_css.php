<style>
.clfe-checkout-sections  #clfe_summary {<?= $settings['summary_container_style'] ?>}

#clfe_summary .detail-row {
    padding: 4px 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
#clfe_summary .payment-msg {
    padding-top: 0px;
}


#clfe_summary .order-summary-header-title {<?= $settings['summary_header_title_style'] ?>}
#clfe_summary .clfe_toggle_header .key-price {<?= $settings['summary_header_total_style'] ?>}
#clfe_summary .clfe-icon {<?= $settings['summary_icons_style'] ?>}

#clfe_summary .clfe-product-discount .key-name {<?= $settings['summary_discount_label_style'] ?>}
#clfe_summary .clfe-product-discount .key-price {<?= $settings['summary_discount_value_style'] ?>}
#clfe_summary .clfe-product-discount .key-price .icon-gift {<?= $settings['summary_discount_value_style'] ?>}
#clfe_summary .shipping-fees .key-name {<?= $settings['summary_shipping_label_style'] ?>}
#clfe_summary .shipping-fees .key-price {<?= $settings['summary_shipping_title_style'] ?>}
#clfe_summary .order-total .key-name {<?= $settings['summary_total_label_style'] ?>}
#clfe_summary .order-total .key-price {<?= $settings['summary_total_value_style'] ?>}
#clfe_summary .payment-msg {<?= $settings['summary_payment_msg_style'] ?>}

/*------- overridden cart blocks ----------*/
#clfe_summary .clfe_cart_products {
    <?= $settings['summary_cart_products_container_style'] ?>
}
#clfe_summary .clfe_cart_totals {
    <?= $settings['summary_cart_totals_container_style'] ?>
}
    
@media screen and (max-width: 400px) {

}
</style>