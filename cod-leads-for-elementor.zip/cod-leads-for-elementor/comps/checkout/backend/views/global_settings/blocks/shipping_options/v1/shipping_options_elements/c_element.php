<div class="c-element c-element-flex">
    <div class="clfe-element-body">
        <fieldset>
            <legend class="clfe-accordion">
                <i class="clfe-icon icon-location2"></i>
                <span class="clfe-label-draggable">
                    <?= strlen($value['title']) > 0 ? $value['title'] : Lang_clfe::__('block1', 'clfe') ?>
                </span>
                <div class="clfe-draggable-icons-container">
                    <span class="dashicons dashicons-sort"></span>
                </div>
            </legend>
            <div class="clfe-accordion-panel clfe-sub-section">
                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Is active', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <label class="clfe-switch">
                            <input type="checkbox" <?= $value['is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                            <span class="clfe-slider clfe-round"></span>
                            <input type="hidden" elementName="is_active" value="<?= $value['is_active'] ?>">
                        </label>
                    </div>
                </div>
                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Title', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <input type="text"  elementName="title" value="<?= $value['title'] ?>">
                    </div>
                </div>
                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Sub Title', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <input type="text"  elementName="subtitle" value="<?= $value['subtitle'] ?>">
                    </div>
                </div>
                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Badge text', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <input type="text"  elementName="badge_text" value="<?= $value['badge_text'] ?>">
                    </div>
                </div>
                <div class="clfe-row">
                    <div class="clfe-th-full">
                        <label>
                            <?= Lang_clfe::_e('Only show if the condition is met.', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td-full clfe-flex">
                        <select  elementName="condition_variable" value="<?= $value['condition_variable'] ?>">
                            <option value="" <?= $value['condition_variable'] == '' ? 'selected' : '' ?>><?= Lang_clfe::_e('Choose a value', 'clfe') ?></option>
                            <option value="city" <?= $value['condition_variable'] == 'city' ? 'selected' : '' ?>><?= Lang_clfe::_e('City', 'clfe') ?></option>
                            <option value="total" <?= $value['condition_variable'] == 'total' ? 'selected' : '' ?>><?= Lang_clfe::_e('total', 'clfe') ?></option>
                        </select>
                        <select  elementName="condition_operator" value="<?= $value['condition_operator'] ?>">
                            <option value="" <?= $value['condition_operator'] == '' ? 'selected' : '' ?>><?= Lang_clfe::_e('Choose a value', 'clfe') ?></option>
                            <option value="==" <?= $value['condition_operator'] == '==' ? 'selected' : '' ?>><?= Lang_clfe::_e('Equals', 'clfe') ?></option>
                            <option value=">" <?= $value['condition_operator'] == '>' ? 'selected' : '' ?>><?= Lang_clfe::_e('greater than', 'clfe') ?></option>
                            <option value="<" <?= $value['condition_operator'] == '<' ? 'selected' : '' ?>><?= Lang_clfe::_e('less than', 'clfe') ?></option>
                            <option value="in" <?= $value['condition_operator'] == 'in' ? 'selected' : '' ?>><?= Lang_clfe::_e('contains', 'clfe') ?></option>
                        </select>
                        <input type="text"  elementName="condition_value" value="<?= $value['condition_value'] ?>">
                    </div>
                </div>
                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Cost', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td-full clfe-flex">
                        <input type="number"  elementName="cost_value" value="<?= $value['cost_value'] ?>" placeholder="<?= Lang_clfe::_e('Cost value', 'clfe') ?>">
                        <input type="text"  elementName="cost_label" value="<?= $value['cost_label'] ?>" placeholder="<?= Lang_clfe::_e('Cost label', 'clfe') ?>">
                    </div>
                </div>

                <div class="clfe-row">
                    <button type="button" class="clfe-image-selector">
                        <span>
                            <i class="dashicons dashicons-cloud-upload"></i>
                            <?= Lang_clfe::_e('Upload the thumbnail image', 'clfe') ?>
                        </span> <br />
                        <img src="<?= isset($value['thumbnail_url']) ? $value['thumbnail_url'] : "" ?>" alt="" title="<?= Lang_clfe::_e('Select offer image', 'clfe') ?>" /> <br />
                        <input type="hidden" class="clfe_img_id" elementName="thumbnail_id" value="<?= isset($value['thumbnail_id']) ? $value['thumbnail_id'] : "" ?>" />
                        <input type="hidden" class="clfe_img_url" elementName="thumbnail_url" value="<?= isset($value['thumbnail_url']) ? $value['thumbnail_url'] : "" ?>" />
                    </button>
                </div>
                <div class="clfe-row">
                    <button type="button" class="clfe-image-selector">
                        <span>
                            <i class="dashicons dashicons-cloud-upload"></i>
                            <?= Lang_clfe::_e('Upload the background image', 'clfe') ?>
                        </span> <br />
                        <img src="<?= isset($value['bg_url']) ? $value['bg_url'] : "" ?>" alt="" title="<?= Lang_clfe::_e('Select offer image', 'clfe') ?>" /> <br />
                        <input type="hidden" class="clfe_img_id" elementName="bg_id" value="<?= isset($value['bg_id']) ? $value['bg_id'] : "" ?>" />
                        <input type="hidden" class="clfe_img_url" elementName="bg_url" value="<?= isset($value['bg_url']) ? $value['bg_url'] : "" ?>" />
                    </button>
                    <div class="clfe-alert clfe-alert-info">
                        <?= Lang_clfe::_e('When you choose the background image option, all other elements such as thumbnail, title, and prices will be automatically hidden.', 'clfe') ?>
                    </div>
                </div>
            </div>
        </fieldset>
    </div>
    <div class="clfe-element-buttons">
        <button type="button" class="deleteElement" title="<?= Lang_clfe::_e('Remove this status', 'clfe') ?>">
            <span class="dashicons dashicons-trash"></span>
        </button>
    </div>

</div>