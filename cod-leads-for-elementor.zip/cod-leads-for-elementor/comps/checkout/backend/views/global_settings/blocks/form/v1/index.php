<!-- Checkout Fields Info Section -->
<div class="cl-info-section">
    <div class="cl-info-header">
        <span class="dashicons dashicons-info"></span>
        <p><?= Lang_cl::_e('This page controls the global checkout fields settings. To manage specific checkout field elements, use the link below:', 'cl') ?></p>
    </div>
    <div class="cl-info-links">
        <a href="admin.php?page=cl_checkout_fields" target="_blank">
            <span><?= Lang_cl::_e('Checkout Field Elements', 'cl') ?></span>
            <span class="arrow">→</span>
        </a>
    </div>
</div>
<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Main container', 'cl') ?>
    </div>
    <div class="cl-td"> 
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Container styling', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    $styleManager->getAllCss('form_container_style');
                    ?>
                </div>
            </div>
            <?php $styleManager->getSingleCss('margin-top', 'form_container_style'); ?>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Form heading title', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'form_heading_is_active',
                        'value' => $settings['form_heading_is_active']
                    ]);

                    $styleManager->getAllCss('form_heading_style'); 
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-td-full">
                    <?= Lang_cl::_e('Text', 'cl') ?>
                    <input type="text" name="form_heading" value="<?= $settings['form_heading'] ?>" textAttachedTo="#cl_form_heading" placeholder="<?= Lang_cl::_e('Heading title', 'cl') ?>">
                </div>
            </div>
        </div>
    </div>
</div>


<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Form fields Conatiner', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Container styling', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    $styleManager->getAllCss('form_fields_container_style');
                    ?>
                </div>
            </div>
            
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Entry Fields', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getAllCss('form_fields_entry_style');
                    ?>
                </div>
            </div>
            
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Label', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'form_fields_label_is_active',
                        'value' => $settings['form_fields_label_is_active']
                    ]);

                    $styleManager->getAllCss('form_fields_label_style');
                    ?>
                </div>
            </div>
            
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Icons', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'form_fields_icon_is_active',
                        'value' => $settings['form_fields_icon_is_active']
                    ]);

                    $styleManager->getAllCss('form_fields_icon_style');
                    ?>
                </div>
            </div>


        </div>
    </div>
</div>