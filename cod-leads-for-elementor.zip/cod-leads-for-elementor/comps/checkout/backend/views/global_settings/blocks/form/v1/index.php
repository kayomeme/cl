<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Form container', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Form container styling', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Form fields container style', 'clfe'),
                        'styleAttachedTo' => '#clfe_form',
                        'padding' => 'yes',
                    ];
                    $adminStyle->getAllCss('form_container_style', $settings['form_container_style'], $activeOptions);
                    ?>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Show field icons', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['form_fields_icon_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="form_fields_icon_is_active" value="<?= $settings['form_fields_icon_is_active'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Form field icons style', 'clfe'),
                        'styleAttachedTo' => '.form-entry-field .icon-container .clfe-icon',
                        'font' => 'yes'
                    ];
                    $adminStyle->getAllCss('form_fields_icon_style', $settings['form_fields_icon_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <div class="clfe-row ">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Show fields label', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['form_fields_label_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="form_fields_label_is_active" value="<?= $settings['form_fields_label_is_active'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Form labels style', 'clfe'),
                        'styleAttachedTo' => '.form-label-container',
                        'font' => 'yes'
                    ];
                    $adminStyle->getAllCss('form_fields_label_style', $settings['form_fields_label_style'], $activeOptions);
                    ?>
                </div>
            </div>
            
            <?php $adminStyle->getSingleCss('margin-top', 'form_container_style', $settings['form_container_style']); ?>
        </div>
    </div>
</div>

<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Form heading title', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['form_heading_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="form_heading_is_active" value="<?= $settings['form_heading_is_active'] ?>">
                    </label>

                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Form heading title style', 'clfe'),
                            'styleAttachedTo' => '#clfe_form_heading',
                            'font' => 'yes', 
                            'border' => 'yes', 
                            'padding' => 'yes', 
                            'background' => 'yes'
                        ];
                        $adminStyle->getAllCss('form_heading_style', $settings['form_heading_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-td-full">
                    <label>
                        <?= Lang_clfe::_e('Text', 'clfe') ?>
                    </label>
                    <input type="text"  name="form_heading" value="<?= $settings['form_heading'] ?>" textAttachedTo="#clfe_form_heading" placeholder="<?= Lang_clfe::_e('Heading title', 'clfe') ?>">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="clfe-row">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Form fields container styling', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Form fields container style', 'clfe'),
                        'styleAttachedTo' => '.clfe_form_fields_container',
                        'border' => 'yes',
                        'padding' => 'yes',
                        'background' => 'yes',
                    ];
                    $adminStyle->getAllCss('form_fields_container_style', $settings['form_fields_container_style'], $activeOptions);
                    ?>
                </div>
            </div>
    <div class="clfe-th-full">
        <label>
            <?= Lang_clfe::_e('Form entry Fields Settings', 'clfe') ?>
        </label>

        <?php
        $activeOptions = [
            'modalTitle' => Lang_clfe::__('Fields style for all form elements', 'clfe'),
            'styleAttachedTo' => 'input.form_fields_entry_style',
            'height' => 'yes',
            'font' => 'yes',
            'border' => 'yes',
            'padding' => 'yes'
        ];
        $adminStyle->getAllCss('form_fields_entry_style', $settings['form_fields_entry_style'], $activeOptions);
        ?>
    </div>
    <div class="clfe-td-full">
        <div class="clfe-accordion-container clfe_form_fields_elements">
            <?php
            foreach ($formFieldsOrder as $fieldName) {
                include 'fields_elements/' . $fieldName . '.php';
            }
            ?>
            <input type="hidden" name="form_fields_order" value="<?= $settings['form_fields_order'] ?>">
        </div>


    </div>
</div>