<?php return array (
  'setting' => 
  array (
    'shipping_options' => '{"elements":{"0":{"is_active":"yes","title":"Free shipping","subtitle":"","badge_text":"","condition_variable":"","condition_operator":"","condition_value":"","cost_value":"0","cost_label":"En 3 jours","thumbnail_id":"","thumbnail_url":"","bg_id":"","bg_url":""}}}',
    'shipping_options_is_active' => 'yes',
    'shipping_options_version' => 'v1',
    'shipping_options_layout' => 'list_blocks',
    'shipping_options_header_is_open' => 'yes',
    'shipping_options_column' => '2',
    'shipping_options_header_is_active' => 'yes',
    'shipping_option_subtitle_is_active' => 'yes',
    'shipping_option_radio_bt_is_active' => 'yes',
    'shipping_option_image_is_active' => 'yes',
    'shipping_option_bg_image_is_active' => 'yes',
    'shipping_option_title_is_active' => 'yes',
    'shipping_option_cost_value_is_active' => 'yes',
    'shipping_option_cost_label_is_active' => 'yes',
    'shipping_option_badge_is_active' => 'yes',
  ),
  'lang' => 
  array (
    'shipping_options_header_title_is_open' => '⇡ Choose an option',
    'shipping_options_header_title_is_closed' => '⇣ Choose an option: Click Here to Open',
    'shipping_options_header_count_text' => 'Options',
  ),
  'style' => 
  array (
    'shipping_options_style' => 'border-top-width:px;border-right-width:px;border-bottom-width:px;border-left-width:px;border-color:#ffffff;border-style:solid;border-top-left-radius:px;border-top-right-radius:px;border-bottom-left-radius:px;border-bottom-right-radius:px;background-color:#ffffff;padding-top:5px;padding-right:5px;padding-bottom:5px;padding-left:5px;margin-top:px;margin-right:px;margin-bottom:px;margin-left:px;box-shadow:1px 1px 1px 1px #b0a6a6;',
    'shipping_options_header_style' => 'font-size:15px;color:#000000;font-weight:700;text-align:center;',
    'shipping_option_title_style' => 'font-size:14px;color:#000000;font-weight:700;text-align:initial;',
    'shipping_option_subtitle_style' => 'font-size:12px;color:#000000;font-weight:700;text-align:initial;',
    'shipping_option_radio_bt_style' => 'margin-top:5px;margin-right:5px;margin-bottom:5px;margin-left:5px;',
    'shipping_options_header_count_text_style' => 'font-size:12px;color:#008000;font-weight:700;text-align:initial;',
    'shipping_options_selectbox_style' => 'font-size:27px;color:#0057e7;font-weight:700;text-align:initial;border-top-width:3px;border-right-width:1px;border-bottom-width:3px;border-left-width:1px;border-color:#065535;border-style:solid;border-top-left-radius:10px;border-top-right-radius:10px;border-bottom-left-radius:10px;border-bottom-right-radius:10px;background-color:#ffffff;padding-top:10px;padding-right:5px;padding-bottom:10px;padding-left:5px;',
    'shipping_option_default_style' => 'max-height:80px;min-height:55px;border-top-width:2px;border-right-width:2px;border-bottom-width:2px;border-left-width:2px;border-color:#008744;border-style:solid;border-top-left-radius:5px;border-top-right-radius:5px;border-bottom-left-radius:5px;border-bottom-right-radius:5px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;background-image:linear-gradient(1deg,#ffffff,#ffffff);',
    'shipping_option_selected_style' => 'border-top-width:px;border-right-width:px;border-bottom-width:px;border-left-width:px;border-color:;border-style:solid;border-top-left-radius:px;border-top-right-radius:px;border-bottom-left-radius:px;border-bottom-right-radius:px;background-image:;box-shadow:;',
    'shipping_option_cost_label_style' => 'font-size:14px;color:#17a620;font-weight:700;text-align:end;',
    'shipping_option_cost_value_style' => 'font-size:13px;color:#d62e2e;font-weight:700;text-align:end;',
    'shipping_option_badge_style' => 'font-size:10px;color:#ffffff;font-weight:700;text-align:end;border-top-width:px;border-right-width:px;border-bottom-width:px;border-left-width:px;border-color:#0972b3;border-style:solid;border-top-left-radius:px;border-top-right-radius:px;border-bottom-left-radius:px;border-bottom-right-radius:px;background-color:#4a77bf;padding-top:1px;padding-right:8px;padding-bottom:1px;padding-left:8px;box-shadow:5px 0px 0px 0px #0f0f10;',
    'shipping_option_badge_position_style' => 'bottom:-20px;left: 50%; transform: translate(-50%, -50%)',
  ),
);