<?php
return array(
    'form_container_style' => [
        'modal_title' => Lang_cl::__('Form container style', 'cl'),
        'style_attached_to' => '#cl_form',
        'single_css_supported' => ['margin-top'],
        'border' => 'yes',
        'border-radius' => 'yes',
        'background' => 'yes',
        'box-shadow' => 'yes',
    ],
    'form_heading_style' => [
        'modal_title' => Lang_cl::__('Form heading title style', 'cl'),
        'style_attached_to' => '.cl_form_heading',
        'font-with-align' => 'yes', 
        'padding' => 'yes',
    ],
    'form_fields_container_style' => [
        'modal_title' => Lang_cl::__('Form fields container style', 'cl'),
        'style_attached_to' => '.cl_form_fields_container',
        'padding' => 'yes',
    ],
    'form_fields_entry_style' => [
        'modal_title' => Lang_cl::__('Fields style for all form elements', 'cl'),
        'style_attached_to' => '.form-entry-field',
        'font' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
    ],
    'form_fields_label_style' => [
        'modal_title' => Lang_cl::__('Form labels style', 'cl'),
        'style_attached_to' => '.form-label-container',
        'font' => 'yes'
    ],
    'form_fields_icon_style' => [
        'modal_title' => Lang_cl::__('Form field icons style', 'cl'),
        'style_attached_to' => '.form-entry-field .cl-icon',
        'font' => 'yes'
    ],
);