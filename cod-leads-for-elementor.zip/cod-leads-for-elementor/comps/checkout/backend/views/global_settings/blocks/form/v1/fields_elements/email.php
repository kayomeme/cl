    <fieldset class="clfe-row clfe-row-email" _attachedsection="email">
        <legend class="clfe-accordion">
            <i class="clfe-icon icon-envelop"></i>
            <span class="clfe-label-draggable">
                <?= Lang_clfe::_e('Email', 'clfe') ?>
            </span>
            <div class="clfe-draggable-icons-container">
                <span class="dashicons dashicons-sort"></span>
                <span class="dashicons dashicons-move"></span>
            </div>
        </legend>
        <div class="clfe-accordion-panel clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['email_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="email_is_active" value="<?= $settings['email_is_active'] ?>">
                    </label>
                </div> 
            </div>
        
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Email label', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="email_label" textAttachedTo=".form-email-container .form-label-container" value="<?= $settings['email_label'] ?>">

                </div> 
            </div>

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Email placeholder', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="email_placeholder" textAttachedTo="input[name=email]" value="<?= $settings['email_placeholder'] ?>">
                </div>
            </div>
            
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Email is required', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['email_is_req'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="email_is_req" value="<?= $settings['email_is_req'] ?>">
                    </label>
                </div>
            </div>
            
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Email min length', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="number"  name="email_minlength" value="<?= $settings['email_minlength'] ?>">
                    <div class="clfe-alert clfe-alert-info"><?= Lang_clfe::_e('The min length is verified only for required field', 'clfe') ?></div>
                </div>
            </div>
            
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Email error message', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="email_error_msg" value="<?= $settings['email_error_msg'] ?>">

                </div> 
            </div>
        </div>
    </fieldset>