<?php return array (
  'setting' => 
  array (
    'checkout_custom_block2_is_active' => 'no',
    'checkout_custom_block2_version' => 'v1',
  ),
  'lang' => 
  array (
    'checkout_custom_block2_content' => '<p>Plus de 49,000 Clients Satisfaits<br /></p>',
  ),
  'style' => 
  array (
    'checkout_custom_block2_container_style' => '',
  ),
);