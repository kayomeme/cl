<?php return array (
  'setting' => 
  array (
    'checkout_custom_block2_is_active' => 'yes',
    'checkout_custom_block2_version' => 'v1',
  ),
  'lang' => 
  array (
    'checkout_custom_block2_content' => '<p>Plus de 49,000 Clients Satisfaits<br /></p>',
  ),
  'style' => 
  array (
    'checkout_custom_block2_container_style' => 'border-top-width:px;border-right-width:px;border-bottom-width:px;border-left-width:px;border-color:;border-style:solid;border-top-left-radius:px;border-top-right-radius:px;border-bottom-left-radius:px;border-bottom-right-radius:px;padding-top:px;padding-right:px;padding-bottom:px;padding-left:px;margin-top:px;margin-right:px;margin-bottom:px;margin-left:px;background-image:;box-shadow:;',
  ),
);