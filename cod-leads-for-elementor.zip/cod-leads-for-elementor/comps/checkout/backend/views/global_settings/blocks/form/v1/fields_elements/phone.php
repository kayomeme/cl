
    <fieldset class="clfe-row clfe-row-phone" _attachedsection="phone">
        <legend class="clfe-accordion">
            <i class="clfe-icon icon-mobile"></i>
            <span class="clfe-label-draggable">
                <?= Lang_clfe::_e('Phone', 'clfe') ?>
            </span>
            <div class="clfe-draggable-icons-container">
                <span class="dashicons dashicons-sort"></span>
                <span class="dashicons dashicons-move"></span>
            </div>
        </legend>
        <div class="clfe-accordion-panel clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['phone_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="phone_is_active" value="<?= $settings['phone_is_active'] ?>">
                    </label>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Label', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="phone_label" textAttachedTo=".form-phone-container .form-label-container" value="<?= $settings['phone_label'] ?>">

                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Placeholder', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="phone_placeholder" textAttachedTo="input[name=phone]" value="<?= $settings['phone_placeholder'] ?>">
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is required', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['phone_is_req'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="phone_is_req" value="<?= $settings['phone_is_req'] ?>">
                    </label>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Min length', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="number"  name="phone_minlength" value="<?= $settings['phone_minlength'] ?>">
                </div>
                <div class="clfe-alert clfe-alert-info">
                        <?= Lang_clfe::_e('The min length is verified only for required field', 'clfe') ?>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Max length', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="number"  name="phone_maxlength" value="<?= $settings['phone_maxlength'] ?>">
                </div>
                <div class="clfe-alert clfe-alert-info">
                        <?= Lang_clfe::_e('The max length is verified only for required field', 'clfe') ?>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Error message', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="phone_error_msg" value="<?= $settings['phone_error_msg'] ?>">

                </div>
            </div>

        </div>
    </fieldset>

