<div class="checkout-modal-settings">
    
    <div class="cl-row ">
        <div class="cl-th">
            <?= Lang_cl::_e('Modal container', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Container style', 'cl') ?>
                    </div>
                    <div class="cl-td">
                        <?php
                        $styleManager->getAllCss('checkout_modal_container_style'); 
                        ?>
                    </div>
                </div>
                
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Width', 'cl') ?>
                    </div>
                    <div class="cl-td cl-overlay-container">
                        <input type="number" name="checkout_modal_max_width" value="<?= $settings['checkout_modal_max_width'] ?>" min="270" max="1000">
                        <span class="cl-overlay-text">px</span>
                    </div>
                </div>
                
                <div class="cl-row cl-type-select">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Transparency color', 'cl') ?>
                    </div>
                    <div class="cl-td">
                        <select name="checkout_modal_bg_transparency_color" class="cl-style-element" value="<?= $settings['checkout_modal_bg_transparency_color'] ?>">
                            <option value="0,0,0"><?= Lang_cl::_e('Black', 'cl') ?></option>
                            <option value="255,255,255"><?= Lang_cl::_e('White', 'cl') ?></option>
                        </select> 
                    </div>
                </div>
                <div class="cl-row cl-type-select">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Transparency level', 'cl') ?>
                    </div>
                    <div class="cl-td">
                        <input type="number" class="cl-style-element" name="checkout_modal_bg_transparency_level" min="0" max="99" value="<?= $settings['checkout_modal_bg_transparency_level'] ?>">
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="cl-row ">
        <div class="cl-th">
            <?= Lang_cl::_e('Modal header', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Container Style', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getAllCss('checkout_modal_header_style'); 
                        ?>
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Title', 'cl') ?>
                    </div>
                    <div class="cl-td">
                        <input type="text" name="checkout_modal_title" value="<?= $settings['checkout_modal_title'] ?>">
                    </div>
                </div>

                
                
<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Logo', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'checkout_modal_logo_is_active',
                        'value' => $settings['checkout_modal_logo_is_active']
                    ]);
                    $styleManager->getAllCss('checkout_modal_logo_style'); 
                    ?>
                </div>
            </div>
            
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Logo width', 'cl') ?>
                    </div>
                    <div class="cl-td cl-overlay-container">
                        <input type="number" name="checkout_modal_logo_width" value="<?= $settings['checkout_modal_logo_width'] ?>" min="50" max="300">
                        <span class="cl-overlay-text">px</span>
                    </div>
                </div>
            
            
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Select Logo', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <button type="button" class="cl-image-selector">
                        <img src="<?= $settings['checkout_modal_logo_img_url'] ?>" alt="<?= Lang_cl::_e('Select image', 'cl') ?>" /> <br/>
                        <input type="hidden" class="cl_img_id" name="checkout_modal_logo_img_id" value="<?= $settings['checkout_modal_logo_img_id'] ?>" />
                        <input type="hidden" class="cl_img_url" name="checkout_modal_logo_img_url" value="<?= $settings['checkout_modal_logo_img_url'] ?>" />
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

            </div>
        </div>
    </div>
    
    <div class="cl-row ">
        <div class="cl-th">
            <?= Lang_cl::_e('Modal Close button', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Text', 'cl') ?>
                    </div>
                    <div class="cl-td">
                        <input type="text" name="checkout_modal_close_bt_text" value="<?= $settings['checkout_modal_close_bt_text'] ?>">
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Active icon', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                            $styleManager->getSwitchButton([
                                'name' => 'checkout_modal_close_icon_is_active',
                                'value' => $settings['checkout_modal_close_icon_is_active']
                            ]);
                        ?>

                        <?php 
                            IconsSelectorBK_cl::getButton([
                                'name' => 'checkout_modal_close_icon_id',
                                'value' => $settings['checkout_modal_close_icon_id']
                            ]);
                        ?>
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Style', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getAllCss('checkout_modal_close_bt_style'); 
                        ?>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    
    <div class="cl-row ">
        <div class="cl-th">
            <?= Lang_cl::_e('Modal body', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Modal body container style', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getAllCss('checkout_modal_body_style'); 
                        ?>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    
</div>