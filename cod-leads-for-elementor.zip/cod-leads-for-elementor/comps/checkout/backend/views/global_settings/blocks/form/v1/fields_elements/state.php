    <fieldset class="clfe-row clfe-row-state" _attachedsection="state">
        <legend class="clfe-accordion">
            <i class="clfe-icon icon-location2"></i>
            <span class="clfe-label-draggable">
                <?= Lang_clfe::_e('state', 'clfe') ?>
            </span>
            <div class="clfe-draggable-icons-container">
                <span class="dashicons dashicons-sort"></span>
                <span class="dashicons dashicons-move"></span>
            </div>
        </legend>
        <div class="clfe-accordion-panel clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['state_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="state_is_active" value="<?= $settings['state_is_active'] ?>">
                    </label>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Label', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="state_label" textAttachedTo=".form-state-container .form-label-container" value="<?= $settings['state_label'] ?>">
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Placeholder', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="state_placeholder" textAttachedTo="input[name=state]" value="<?= $settings['state_placeholder'] ?>">
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is required', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['state_is_req'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="state_is_req" value="<?= $settings['state_is_req'] ?>">
                    </label>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Min length', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="number"  name="state_minlength" value="<?= $settings['state_minlength'] ?>">
                    <div class="clfe-alert clfe-alert-info"><?= Lang_clfe::_e('The min length is verified only for required field', 'clfe') ?></div>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Error message', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text"  name="state_error_msg" value="<?= $settings['state_error_msg'] ?>">

                </div>
            </div>

        </div>
    </fieldset>