<style>
    #cl_form {
        <?= $settings['form_container_style'] ?>
    }
    
    .cl_form_heading {
        <?= $settings['form_heading_style'] ?>
    }

    .cl-required {
        color: #e53e3e;
    }

    
<?php if( $settings['form_fields_icon_is_active'] == 'no' ) { ?>
    .form-entry-field input { 
        width: 100% !important; 
    }
<?php } ?>

/*-------errors and feedback-------*/
.cl-wait-text {<?= $settings['error_wait_text_style'] ?>}
.error-element {<?= $settings['error_msg_style'] ?>}    

.cl_form_fields_container {
    <?= $settings['form_fields_container_style'] ?>
}

/* Base styles for the input and select elements so the style in the admin form_fields_entry_style
will be applicated directly to the parent element .form-entry-field
*/
.form-entry-field input, .form-entry-field select, .form-entry-field input:focus, .form-entry-field select:focus {
    width: 100%;
    height: auto !important;
    border: 0 !important;
    padding: 0 0 !important;
    outline: none !important;
    background: transparent !important;
}

.form-entry-field {
    position: relative;
    margin-bottom: 15px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    /*display: flex;*/
    <?= $settings['form_fields_entry_style'] ?>
}

#cl_form_fields div:last-child .form-entry-field {
    margin-bottom: 0px;
}


.form-label-container {
    position: absolute;
    top: -10px;
    left: 10px;
    background-color: white;
    padding: 0 5px;
    display: flex;
    align-items: center;
    gap: 6px;
    border-radius: 4px;
    <?= $settings['form_fields_label_style'] ?>
}


.cl-input-group {
    /*--add dynamiq option in settings---*/
    display: flex;
    gap: 10px;
    align-items: center;
    width: 100%;
    flex-direction: row-reverse;
}
.cl-input-group .cl-icon {<?= $settings['form_fields_icon_style'] ?>}

/*.icon-container {
    width: 30px;
    text-align: center;
    display: flex;
    align-items: center;
}*/
/*------error and succes-------*/
.cl-error-response {
    padding: 10px;
    color: #ee0c0c;
    font-weight: bold;
}
.cl-wait-box {
    display: none;
    width: 100%;
    text-align: center;
    padding: 10px;
}
.cl-wait-icon {
    float: none;
    margin: auto;
    border: 7px solid #f3f3f3;
    border-top: 7px solid #3498db;
    border-radius: 50%;
    width: 25px;
    height: 25px;
    animation: spin 2s linear infinite;
}

.cl-error-border {
    border-color: #c11a1a !important;
}
.error-element {
    display: block;
    margin-bottom: 4px;
}
.cl-input-error {
    display: none;
}
.cl-input-error {
    text-align: center;
    margin-top: -7px;
    background: #fff;
    padding: 1px 5px;
    color: #ef0707;
    font-weight: 500;
    margin-bottom: 10px;
}
</style>