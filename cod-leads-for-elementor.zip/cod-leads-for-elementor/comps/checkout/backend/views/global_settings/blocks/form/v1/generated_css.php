<style>
.form-label-container {<?= $settings['form_fields_label_style'] ?>}
.icon-container .clfe-icon {<?= $settings['form_fields_icon_style'] ?>}

input.form_fields_entry_style {<?= $settings['form_fields_entry_style'] ?>}

<?php if( $settings['form_fields_icon_is_active'] == 'no' ) { ?>
    .form-entry-field input { width: 100% !important; }
<?php } ?>

/*-------errors and feedback-------*/
.clfe-wait-text {<?= $settings['error_wait_text_style'] ?>}
.error-element {<?= $settings['error_msg_style'] ?>}    
    
#clfe_form {
    <?= $settings['form_container_style'] ?>
}

#clfe_form_fields {
    <?= $settings['form_fields_entry_style'] ?>
}

.clfe_form_fields_container {
    <?= $settings['form_fields_container_style'] ?>
}

.form-entry-field {
    margin-bottom: 7px;
    display: flex;
}

#clfe_form_fields div:last-child .form-entry-field {
    margin-bottom: 0px;
}
.form-entry-field input {
    width: calc(100% - 30px) !important;
    display: block;
}

.form-label-container {
    padding: 12px 3px 10px 2px;
    min-width: 26%;
}
.clfe_form_heading {<?= $settings['form_heading_style'] ?>}

.icon-container {
    width: 30px;
    text-align: center;
    display: flex;
    align-items: center;
}
/*------error and succes-------*/
.clfe-error-response {
    padding: 10px;
    color: #ee0c0c;
    font-weight: bold;
}
.clfe-wait-box {
    display: none;
    width: 100%;
    text-align: center;
    padding: 10px;
}
.clfe-wait-icon {
    float: none;
    margin: auto;
    border: 7px solid #f3f3f3;
    border-top: 7px solid #3498db;
    border-radius: 50%;
    width: 25px;
    height: 25px;
    animation: spin 2s linear infinite;
}

.clfe-error-border {
    border-color: #c11a1a !important;
}
.error-element {
    display: block;
    margin-bottom: 4px;
}
.clfe-input-error {
    display: none;
}
.clfe-input-error {
    text-align: center;
    margin-top: -7px;
    background: #fff;
    padding: 1px 5px;
    color: #ef0707;
    font-weight: 500;
    margin-bottom: 10px;
}
</style>