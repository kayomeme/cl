<style>
.clfe-checkout-sections  #clfe_shipping_options {
    <?= $settings['shipping_options_style'] ?>
}
.clfe-shipping-options-section-title {
    width: 98%;
    margin: 0px 1%;
    float: left;
    <?= $settings['shipping_options_header_style'] ?>
}
.shipping-options-header-count-text {
    <?= $settings['shipping_options_header_count_text_style'] ?>
}

<?php
switch ($settings['shipping_options_layout']) {
    case 'select_box': ?>
    .clfe-shipping-options-selectbox {
        width: 100%;
        <?= $settings['shipping_options_selectbox_style'] ?>
    }
    
    <?php        
    break;
    case 'list_blocks': ?>

        .clfe-shipping-options-items {
            display: flex;
            flex-flow: <?= $settings['shipping_options_column'] == 1 ? 'column':'row wrap' ?>;
            justify-content: center;
            float: none;
            width: 100%;
            max-width: 800px;
            margin: auto;
        }
        .clfe-shipping-option {
            flex-grow: 1;
            display: flex;
            justify-content: space-between; /* Ensures the start and end elements are at the opposite sides */
            align-items: center; /* Vertically aligns the elements */
            /*----dontchange the margin is related to the column setting-----*/
            margin: 0px 1% 10px 1%;
            margin-bottom: <?= $settings['shipping_option_badge_is_active'] == 'yes' ? '13px' : '10px' ?>;
            width: <?= $settings['shipping_options_column'] !=1 ? '48%':'98%' ?>;
            position: relative;
            cursor: pointer;
            background-repeat: no-repeat;
            background-origin: content-box;  
            background-position: center;
            <?= $settings['shipping_option_default_style'] ?>
        }
        
        .shipping-option-start {
            display: flex;
            align-items: center;
            column-gap: 7px;
        }
        body .clfe-shipping-option-radio-bt {
            cursor: pointer;
            <?= $settings['shipping_option_radio_bt_style'] ?>
        }
        .shipping-option-thumb { 
            object-fit: contain;
            max-width: 100%;
            max-height: 70px;
        }

        .shipping-option-badge {
            position: absolute;
            justify-content: flex-start;
            display: flex;
            <?= $settings['shipping_option_badge_style'] ?>
            <?= $settings['shipping_option_badge_position_style'] ?>
        }

        .shipping-option-texts {

        }
        .clfe-shipping-option-title {
            <?= $settings['shipping_option_title_style'] ?>
        }
        .clfe-shipping-option-subtitle {
            <?= $settings['shipping_option_subtitle_style'] ?>
        }

        .shipping-option-end {
            display: flex;
            justify-content: end;
        }  
        .clfe-shipping-option-cost {
            display: flex;
            column-gap: 6px;
            width: 100%;
            text-align: end;
            margin-inline-end: 10px;
        }
        .clfe-shipping-option .clfe-cost-label, .clfe-shipping-option .clfe-cost-value {
            display: inline-block;
        }
        .clfe-cost-label {
            <?= $settings['shipping_option_cost_label_style'] ?>
        }
        .clfe-cost-value {
            <?= $settings['shipping_option_cost_value_style'] ?>
        }
        .is-selected-shipping-option {
          <?= $settings['shipping_option_selected_style'] ?>
        }


        @media only screen and (max-width: 500px) {
            .clfe-shipping-option {
                min-width: 98%;
            }
        }

    <?php        
    break;
    default:
        break;
}


?>






</style>