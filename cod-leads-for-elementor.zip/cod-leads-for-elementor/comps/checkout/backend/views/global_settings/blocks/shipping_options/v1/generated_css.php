<style>
#cl_shipping_options {
    <?= $settings['shipping_options_container_style'] ?>
}
#cl_shipping_options .cl_toggle_header {
    <?= $settings['shipping_options_header_container_style'] ?>
}
#cl_shipping_options .toggle-title {
    <?= $settings['shipping_options_header_title_style'] ?>
}

.shipping-options-header-count-text {
    <?= $settings['shipping_options_header_count_text_style'] ?>
}
#cl_shipping_options .cl_toggle_header .cl-icon {
    <?= $settings['shipping_options_header_icon_style'] ?>
}

#cl_shipping_options .cl_toggle_preview {
    <?= $settings['shipping_option_preview_style'] ?>
}

#cl_shipping_options .cl_toggle_body {
    <?= $settings['shipping_options_body_container_style'] ?>
}

<?php
switch ($settings['shipping_options_display_type']) {
    case 'select_box': ?>
    .shipping-options-selectbox {
        width: 100%;
        <?= $settings['shipping_options_selectbox_style'] ?>
    }
    
    <?php        
    break;
    case 'list_blocks': ?>

        .shipping-options-items {
            display: flex;
            flex-direction: <?= $settings['shipping_options_column'] == 1 ? 'column':'row' ?>;
            flex-wrap: wrap;
            gap: 10px;
            <?= $settings['shipping_options_items_style'] ?>
        }
        .shipping-option {
            <?= $settings['shipping_option_default_style'] ?>
            display: flex;
            align-items: center;
            flex-wrap: nowrap;
            column-gap: 10px;
            position: relative;
            cursor: pointer;
            flex-grow: 1;
            <?php         
            switch ($settings['shipping_options_column']) {
             case '1':
                 echo 'width: 100%;';
                 break;
             case '2':
                 echo 'width: calc(50% - 5px);';
                 break;
             case '3':
                 echo 'width: calc(32% - 5px);';
                 break;

         } ?>
            
            <?php if( $settings['shipping_option_bg_image_is_active'] == 'yes' ) { ?>
            background-repeat: no-repeat;
            background-origin: border-box;  
            background-position: center; 
            background-size: cover;
            <?php } ?>
        }
        
        .shipping-option-radio-container {
            display: flex;
            <?= $settings['shipping_option_radio_bt_position_style'] ?>
        }
        .shipping-option-radio-container input {
            margin: 0 !important;
            padding: 0 !important;
        }

        .shipping-option-elements {
            display: flex;
            flex-grow: 1;
            flex-wrap: wrap;
            <?= $settings['shipping_option_elements_layout_style'] ?>
        }
        
        img.shipping-option-thumb { 
            width: 100%;
            object-fit: contain;
            <?= $settings['shipping_option_image_style'] ?>
        }

        .shipping-option-badge {
            justify-content: flex-start;
            display: flex;
            text-align: center;
            <?= $settings['shipping_option_badge_style'] ?>
            <?= $settings['shipping_option_badge_position_style'] ?>
            width: max-content;
            max-width: 95%;
        }
        
        .shipping-option-title {
            <?= $settings['shipping_option_title_style'] ?>
        }
        .shipping-option-subtitle {
            <?= $settings['shipping_option_subtitle_style'] ?>
        }

        .shipping-option-cost {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            column-gap: 10px;
            text-align: center;
        }
        .shipping-option-cost span {
            flex-grow: 1;
        }

        .shipping-option .cost-label {
            <?= $settings['shipping_option_cost_label_style'] ?>
        }
        .shipping-option .cost-value {
            <?= $settings['shipping_option_cost_value_style'] ?>
        }
        .is-selected-shipping-option {
          <?= $settings['shipping_option_selected_style'] ?>
        }

    <?php        
    break;
    default:
        break;
}

?>

</style>