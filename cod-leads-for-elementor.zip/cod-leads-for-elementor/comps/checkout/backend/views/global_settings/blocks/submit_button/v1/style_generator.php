<?php
return array(
    'submit_button_container_style' => [
        'modal_title' => Lang_cl::__('Submit button style', 'cl'),
        'style_attached_to' => '#cl_submit_button',
        'single_css_supported' => ['margin-top'],
        'border' => 'yes',
        'border-radius' => 'yes', 
        'background' => 'yes', 
        'padding' => 'yes',
    ],
    'submit_button_style' => [
        'modal_title' => Lang_cl::__('Submit button style', 'cl'),
        'style_attached_to' => '#cl-submit-bt',
        'width_pct' => 'yes', 
        'font' => 'yes', 
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes',
        'linear-gradient' => 'yes', 
        'box-shadow' => 'yes'
    ],
);