<?php return array (
  'setting' => 
  array (
    'submit_button_icon_is_active' => 'yes',
    'submit_button_icon_id' => '14',
    'submit_button_version' => 'v1',
  ),
  'lang' => 
  array (
    'submit_button_text' => 'Cliquez ici pour commander',
  ),
  'style' => 
  array (
    'submit_button_container_style' => 'margin-top:10px;',
    'submit_button_style' => 'width:100%;font-size:16px;color:#ffffff;font-weight:600;border-radius:8px;padding-top:14px;padding-right:24px;padding-bottom:14px;padding-left:24px;background-color:#10b981;',
  ),
);