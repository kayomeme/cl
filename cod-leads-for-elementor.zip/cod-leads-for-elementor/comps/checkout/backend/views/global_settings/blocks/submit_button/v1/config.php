<?php return array (
  'setting' => 
  array (
    'submit_button_is_active' => 'yes',
    'submit_button_icon_is_active' => 'yes',
    'submit_button_version' => 'v1',
  ),
  'lang' => 
  array (
    'submit_button_text' => 'Cliquez ici pour commander',
  ),
  'style' => 
  array (
    'submit_button_style' => 'width:100%;font-size:15px;color:#ffffff;font-weight:700;text-align:center;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-color:#4cae50;border-style:solid;border-top-left-radius:4px;border-top-right-radius:5px;border-bottom-left-radius:5px;border-bottom-right-radius:5px;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;margin-top:5px;margin-right:px;margin-bottom:5px;margin-left:px;background-image:linear-gradient(17deg,#8BC34A,#4CAF50);box-shadow:1px 1px 1px 1px #008744;',
  ),
);