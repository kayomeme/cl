<?php return array (
  'setting' => 
  array (
    'checkout_modal_version' => 'v1',
    'checkout_modal_bg_transparency_color' => '17,24,39',
    'checkout_modal_bg_transparency_level' => '90',
    'checkout_modal_max_width' => '600',
    'checkout_modal_close_icon_is_active' => 'yes',
    'checkout_modal_close_icon_id' => '22',
    'checkout_modal_logo_is_active' => 'no',
    'checkout_modal_logo_width' => '120',
    'checkout_modal_logo_img_id' => '1262',
    'checkout_modal_logo_img_url' => 'http://woo.test/wp-content/uploads/2025/08/logoo.png',
  ),
  'lang' => 
  array (
    'checkout_modal_title' => 'Complete Your Order',
    'checkout_modal_close_bt_text' => '',
    'checkout_modal_footer_text_close' => 'Fermer',
  ),
  'style' => 
  array (
    'checkout_modal_container_style' => 'border-radius:12px;background-color:#ffffff;',
    'checkout_modal_header_style' => 'padding:16px;border-bottom-width:1px;border-color:#e5e7eb;border-style:solid;',
    'checkout_modal_logo_style' => '',
    'checkout_modal_close_bt_style' => 'font-size:14px;color:#6b7280;',
    'checkout_modal_body_style' => 'padding:16px;',
  ),
);