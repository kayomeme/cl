<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Submit button Container 22', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Container style', 'cl') ?> 
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    
                    $styleManager->getAllCss('submit_button_container_style'); 
                    ?>
                </div>
            </div>
            
            <?php $styleManager->getSingleCss('margin-top', 'submit_button_container_style'); ?>
        </div>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Submit button', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('button style', 'cl') ?> 
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    
                    $styleManager->getAllCss('submit_button_style'); 
                    ?>
                </div>
            </div>
            
            <div class="cl-row">
                <div class="cl-td-full">
                    <?= Lang_cl::_e('Text', 'cl') ?>
                    <input type="text" name="submit_button_text" textAttachedTo="#cl-submit-bt .text_bt" value="<?= $settings['submit_button_text'] ?>">
                </div>
                <div class="cl-alert cl-alert-info">
                    <?= Lang_cl::_e('Use @total where you want the order total to appear', 'cl') ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Show icon', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                        $styleManager->getSwitchButton([
                            'name' => 'submit_button_icon_is_active',
                            'value' => $settings['submit_button_icon_is_active']
                        ]);
                    ?>
                    
                    <?php 
                        IconsSelectorBK_cl::getButton([
                            'name' => 'submit_button_icon_id',
                            'value' => $settings['submit_button_icon_id']
                        ]);
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>