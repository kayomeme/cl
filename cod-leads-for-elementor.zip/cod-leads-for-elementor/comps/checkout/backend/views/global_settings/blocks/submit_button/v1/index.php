<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Submit button', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label> 
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['submit_button_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="submit_button_is_active" value="<?= $settings['submit_button_is_active'] ?>">
                    </label>

                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Submit button style', 'clfe'),
                            'styleAttachedTo' => '#clfe-submit-bt',
                            'width_pct' => 'yes', 'font' => 'yes', 'border' => 'yes', 'padding' => 'yes',
                            'linear-gradient' => 'yes', 'box-shadow' => 'yes'
                        ];
                        $adminStyle->getAllCss('submit_button_style', $settings['submit_button_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            
            <?php $adminStyle->getSingleCss('margin-top', 'submit_button_style', $settings['submit_button_style']); ?>
            
            <div class="clfe-row">
                <div class="clfe-td-full">
                <label><?= Lang_clfe::_e('Text', 'clfe') ?></label> 
                    <input type="text"  name="submit_button_text" textAttachedTo="#clfe-submit-bt .text_bt" value="<?= $settings['submit_button_text'] ?>">
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Show icon', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['submit_button_icon_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="submit_button_icon_is_active" value="<?= $settings['submit_button_icon_is_active'] ?>">
                    </label>
                </div>
            </div>
            
        </div>
    </div>
</div>