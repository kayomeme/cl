<?php
return array(
    'shipping_options_container_style' => [
        'modal_title' => Lang_cl::__('Shipping options container style', 'cl'),
        'style_attached_to' => '#cl_shipping_options',
        'single_css_supported' => ['margin-top'],
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'box-shadow' => 'yes'
    ],
    'shipping_options_items_style' => [
        'hide_style_bt' => 'yes',
        'single_css_supported' => ['gap'],
        'style_attached_to' => '#cl_shipping_options .shipping-options-items',
    ],
    'shipping_options_header_container_style' => [
        'modal_title' => Lang_cl::__('Shipping Options Header container style', 'cl'),
        'style_attached_to' => '#cl_shipping_options .cl_toggle_header',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
    ],
    'shipping_options_header_title_style' => [
        'modal_title' => Lang_cl::__('Shipping Options title style', 'cl'),
        'style_attached_to' => '.cl-shipping-options-header-title',
        'font' => 'yes'
    ],
    'shipping_options_header_count_text_style' => [
        'modal_title' => Lang_cl::__('Count shipping-options text style', 'cl'),
        'style_attached_to' => '.shipping-options-header-count-text',
        'font' => 'yes'
    ],
    'shipping_options_header_icon_style' => [
        'modal_title' => Lang_cl::__('Shipping Options header icons style', 'cl'),
        'style_attached_to' => '#cl_shipping_options .cl_toggle_header .cl-icon',
        'font' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
    ],
    'shipping_option_preview_style' => [
        'modal_title' => Lang_cl::__('Selected value display style', 'cl'),
        'style_attached_to' => '.shipping_option_preview',
        'font' => 'yes',
        'padding' => 'yes'
    ],
    'shipping_options_body_container_style' => [
        'modal_title' => Lang_cl::__('Shipping options body container style', 'cl'),
        'style_attached_to' => '#cl_shipping_options .cl_toggle_body',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'box-shadow' => 'yes'
    ],
    'shipping_options_selectbox_style' => [
        'modal_title' => Lang_cl::__('Shipping options select box style', 'cl'),
        'style_attached_to' => '.shipping-options-selectbox',
        'font' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes'
    ],
    'shipping_option_elements_layout_style' => [
        'modal_title' => Lang_cl::__('Box Elements Layout', 'cl'),
        'style_attached_to' => '.shipping-option-elements',
        'flex-layout' => [
            'title' => Lang_cl::__('Elements Layout', 'cl'),
            'options' => [
                'flex-direction' => [
                    'title' => Lang_cl::__('Direction', 'cl'),
                    'items' => [
                        'row' => Lang_cl::__('Row', 'cl'),
                        'row-reverse' => Lang_cl::__('Row Reverse', 'cl'),
                        'column' => Lang_cl::__('Column', 'cl'),
                        'column-reverse' => Lang_cl::__('Column Reverse', 'cl')
                    ]
                ],
                'align-items' => [
                    'title' => Lang_cl::__('Vertical alignment', 'cl'),
                    'items' => [
                        'flex-start' => Lang_cl::__('Start', 'cl'),
                        'center' => Lang_cl::__('Center', 'cl'),
                        'flex-end' => Lang_cl::__('End', 'cl'),
                        'stretch' => Lang_cl::__('Stretch', 'cl'),
                        'baseline' => Lang_cl::__('Baseline', 'cl')
                    ]
                ],
                'justify-content' => [
                    'title' => Lang_cl::__('Horizontal alignment', 'cl'),
                    'items' => [
                        'flex-start' => Lang_cl::__('Start', 'cl'),
                        'center' => Lang_cl::__('Center', 'cl'),
                        'flex-end' => Lang_cl::__('End', 'cl'),
                        'space-between' => Lang_cl::__('Space Between', 'cl'),
                        'space-around' => Lang_cl::__('Space Around', 'cl'),
                        'space-evenly' => Lang_cl::__('Space Evenly', 'cl')
                    ]
                ],
                'gap' => [
                    'title' => Lang_cl::__('Space between buttons', 'cl'),
                ]
            ]
        ]
    ],
    'shipping_option_default_style' => [
        'modal_title' => Lang_cl::__('Default box style', 'cl'),
        'style_attached_to' => '.shipping-option',
        'single_css_supported' => ['min-height'],
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'linear-gradient' => 'yes'
    ],
    'shipping_option_selected_style' => [
        'hide_style_bt' => 'yes',
        'single_css_supported' => ['border-color', 'background-color'],
        'style_attached_to' => '.is-selected-shipping-option',
    ],
    'shipping_option_cost_value_style' => [
        'modal_title' => Lang_cl::__('Shipping options cost value style', 'cl'),
        'style_attached_to' => '.shipping-option .cost-value',
        'font' => 'yes'
    ],
    'shipping_option_cost_label_style' => [
        'modal_title' => Lang_cl::__('Shipping options cost label style', 'cl'),
        'style_attached_to' => '.shipping-option .cost-label',
        'font' => 'yes'
    ],
    'shipping_option_title_style' => [
        'modal_title' => Lang_cl::__('Single Shipping options title style', 'cl'),
        'style_attached_to' => '.shipping-option-title',
        'font-with-align' => 'yes'
    ],
    'shipping_option_subtitle_style' => [
        'modal_title' => Lang_cl::__('Shipping option sub title style', 'cl'),
        'style_attached_to' => '.shipping-option-subtitle',
        'font-with-align' => 'yes',
    ],
    'shipping_option_image_style' => [
        'modal_title' => Lang_cl::__('Shipping option image style', 'cl'),
        'style_attached_to' => '.shipping-option-thumb',
        'single_css_supported' => ['max-width'],
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    'shipping_option_radio_bt_position_style' => [
        'modal_title' => Lang_cl::__('Position', 'cl'),
        'style_attached_to' => '.shipping-option-radio-container',
    ],
    'shipping_option_badge_position_style' => [
        'modal_title' => Lang_cl::__('Position', 'cl'),
        'style_attached_to' => '.shipping-option-badge',
    ],
    'shipping_option_badge_style' => [
        'modal_title' => Lang_cl::__('Shipping options badge style', 'cl'),
        'style_attached_to' => '.shipping-option-badge',
        'font' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'box-shadow' => 'yes'
    ],
);