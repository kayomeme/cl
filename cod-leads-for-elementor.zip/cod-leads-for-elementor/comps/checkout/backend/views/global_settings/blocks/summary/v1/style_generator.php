<?php
return array(
    'summary_container_style' => [
        'modal_title' => Lang_cl::__('Order summary : Container styling', 'cl'),
        'style_attached_to' => '#cl_summary',
        'single_css_supported' => ['margin-top'],
    ],
    'summary_header_container_style' => [
        'modal_title' => Lang_cl::__('Summary Header container style', 'cl'),
        'style_attached_to' => '#cl_summary .cl_toggle_header',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
    ],
    'summary_header_title_style' => [
        'modal_title' => Lang_cl::__('Summary title style', 'cl'),
        'style_attached_to' => '.cl-summary-header-title',
        'font' => 'yes'
    ],
    'summary_header_count_text_style' => [
        'modal_title' => Lang_cl::__('Count summary text style', 'cl'),
        'style_attached_to' => '.summary-header-count-text',
        'font' => 'yes'
    ],
    'summary_header_icon_style' => [
        'modal_title' => Lang_cl::__('Summary header icons style', 'cl'),
        'style_attached_to' => '#cl_summary .cl_toggle_header .cl-icon',
        'font' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
    ],
    'summary_body_container_style' => [
        'modal_title' => Lang_cl::__('Summary body container style', 'cl'),
        'style_attached_to' => '#cl_summary .cl_toggle_body',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'box-shadow' => 'yes'
    ],
    'summary_icons_style' => [
        'modal_title' => Lang_cl::__('Order summary : icons styling', 'cl'),
        'style_attached_to' => '#cl_summary .cl-icon',
        'font' => 'yes'
    ],
    'summary_header_total_style' => [
        'modal_title' => Lang_cl::__('Order summary : total styling', 'cl'),
        'style_attached_to' => '#cl_summary .cl_toggle_header .key-price',
        'font' => 'yes'
    ],
    'summary_cart_products_container_style' => [
        'modal_title' => Lang_cl::__('Cart : Container styling', 'cl'),
        'style_attached_to' => '#cl_summary_cart_products',
        'single_css_supported' => ['margin-top'],
        'padding' => 'yes',
    ],
    'summary_cart_totals_container_style' => [
        'modal_title' => Lang_cl::__('Cart totals : Container styling', 'cl'),
        'style_attached_to' => '#cl_summary_cart_totals',
        'single_css_supported' => ['margin-top'],
        'padding' => 'yes',
    ],
    'summary_discount_label_style' => [
        'modal_title' => Lang_cl::__('Discount label styling', 'cl'),
        'style_attached_to' => '#cl_summary .p_discount_label',
        'font' => 'yes'
    ],
    'summary_discount_value_style' => [
        'modal_title' => Lang_cl::__('Discount value styling', 'cl'),
        'style_attached_to' => '#cl_summary .cl-product-discount .key-price',
        'font' => 'yes', 
        'background' => 'yes', 
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes'
    ],
    'summary_shipping_label_style' => [
        'modal_title' => Lang_cl::__('Shipping fees label styling', 'cl'),
        'style_attached_to' => '#cl_summary .shipping-fees .key-name',
        'font' => 'yes'
    ],
    'summary_shipping_title_style' => [
        'modal_title' => Lang_cl::__('Default Shipping fees value styling', 'cl'),
        'style_attached_to' => '#cl_summary .shipping-fees .key-price',
        'font' => 'yes', 
        'background' => 'yes', 
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes'
    ],
    'summary_total_label_style' => [
        'modal_title' => Lang_cl::__('Total label styling', 'cl'),
        'style_attached_to' => '#cl_summary .order-total .key-name',
        'font' => 'yes'
    ],
    'summary_total_value_style' => [
        'modal_title' => Lang_cl::__('Total value styling', 'cl'),
        'style_attached_to' => '#cl_summary .order-total .key-price',
        'font' => 'yes'
    ],
    'summary_payment_msg_style' => [
        'modal_title' => Lang_cl::__('Payment message styling', 'cl'),
        'style_attached_to' => '#cl_summary .payment-msg',
        'font-with-align' => 'yes'
    ],
);