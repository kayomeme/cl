<style>
    #cl_checkout_custom_block2 {
        <?= $settings['checkout_custom_block2_container_style'] ?>
    }
</style>