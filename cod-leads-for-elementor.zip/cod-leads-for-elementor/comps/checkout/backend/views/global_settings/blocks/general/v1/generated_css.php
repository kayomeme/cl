<style>
    .cl-checkout-container {
        <?= $settings['checkout_container_style'] ?>
    }
</style>