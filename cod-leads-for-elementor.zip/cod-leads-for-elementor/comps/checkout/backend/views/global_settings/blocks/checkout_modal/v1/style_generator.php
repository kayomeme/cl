<?php
return array(
    'checkout_modal_container_style' => [
        'modal_title' => Lang_cl::__('Checkout Modal container style', 'cl'),
        'style_attached_to' => '#cl-checkout-modal',
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    'checkout_modal_header_style' => [
        'modal_title' => Lang_cl::__('Checkout Modal header style', 'cl'),
        'style_attached_to' => '.cl_checkout_modal .cl_modal_header',
        'font' => 'yes',
        'padding' => 'yes',
        'background' => 'yes'
    ],
    'checkout_modal_logo_style' => [
        'modal_title' => Lang_cl::__('Checkout Modal logo style', 'cl'),
        'style_attached_to' => '.cl_checkout_modal .cl_modal_logo',
        'border' => 'yes',
        'border-radius' => 'yes',
    ],
    
    'checkout_modal_close_bt_style' => [
        'modal_title' => Lang_cl::__('Checkout Modal Close button style', 'cl'),
        'style_attached_to' => '.cl_checkout_modal .cl_modal_close',
        'font' => 'yes', 
        'background' => 'yes', 
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes'
    ],
    'checkout_modal_body_style' => [
        'modal_title' => Lang_cl::__('Checkout Modal body style', 'cl'),
        'style_attached_to' => '.cl_checkout_modal .cl_modal_body',
        'padding' => 'yes',
        'background' => 'yes'
    ]
);