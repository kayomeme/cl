<style>
.cl-qty-and-submit-bt {
    width: 100%;
    display: flex;
    justify-content: center;
}
.cl-qty-container {
    display: flex;
    flex-wrap: nowrap;
    margin-inline-end: 5px;
    align-items: center;
    justify-content: center;
    gap: 0;
}
.cl-qty-container button {
    padding: 8px 9px 8px 9px;
    width: 41px;
    height: 41px;
    background: #ffffff;
    border: 1px solid #efefef;
    cursor: pointer;
    font-size: 24px;
    line-height: 20px;
    color: black; 
}
.cl-qty-container input {
    height: 41px;
    padding: 10px 3px 8px 3px;
    text-align: center;
    background: #ffffff;
    border: 1px solid #efefef;
    font-size: 13px;
    line-height: 20px;
    box-shadow: none;
    -moz-appearance: textfield;
}
.cl-qty-container input::-webkit-outer-spin-button,
.cl-qty-container input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
#cl-submit-bt, .cl-popup-bt {
    cursor: pointer;
    animation-name: shakeMe;
    animation-duration: 8s;
    animation-iteration-count: infinite;
    animation-timing-function: linear;
}
.cl-checkout-sections #cl_submit_button {
    <?= $settings['submit_button_container_style'] ?>
}
    .cl-checkout-sections  #cl-submit-bt {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        min-width: 240px;
        <?= $settings['submit_button_style'] ?>
    }
</style>