<style>
#clfe_submit_button {
    text-align: center;
}
.clfe-qty-and-submit-bt {
    width: 100%;
    display: flex;
}
.clfe-qty-container {
    display: flex;
    flex-wrap: nowrap;
    margin-inline-end: 5px;
    align-items: center;
    justify-content: center;
    gap: 0;
}
.clfe-qty-container button {
    padding: 8px 9px 8px 9px;
    width: 41px;
    height: 41px;
    background: #ffffff;
    border: 1px solid #efefef;
    cursor: pointer;
    font-size: 24px;
    line-height: 20px;
    color: black; 
}
.clfe-qty-container input {
    height: 41px;
    padding: 10px 3px 8px 3px;
    text-align: center;
    background: #ffffff;
    border: 1px solid #efefef;
    font-size: 13px;
    line-height: 20px;
    box-shadow: none;
    -moz-appearance: textfield;
}
.clfe-qty-container input::-webkit-outer-spin-button,
.clfe-qty-container input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
#clfe-submit-bt, .clfe-popup-bt {
    cursor: pointer;
    animation-name: shakeMe;
    animation-duration: 8s;
    animation-iteration-count: infinite;
    animation-timing-function: linear;
}
    .clfe-checkout-sections  #clfe-submit-bt {
        <?php 
        if( $settings['submit_button_is_active'] == 'no' ) {
            echo "visibility: hidden;height: 0;padding: 0;border: 0;font-size: 0;margin: 0;";
        } else { 
            echo 'min-width:130px;';
            echo $settings['submit_button_style']; 
        }
        ?>
    }
</style>