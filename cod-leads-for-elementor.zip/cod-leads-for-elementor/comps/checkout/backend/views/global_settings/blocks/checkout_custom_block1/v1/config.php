<?php return array (
  'setting' => 
  array (
    'checkout_custom_block1_is_active' => 'no',
    'checkout_custom_block1_version' => 'v1',
  ),
  'lang' => 
  array (
    'checkout_custom_block1_content' => '<p>Si vous souhaitez ajouter d\'autres produits à votre panier, fermez cet onglet.</p>',
  ),
  'style' => 
  array (
    'checkout_custom_block1_container_style' => '',
  ),
);