<?php
return array(
    'checkout_container_style' => [
        'modal_title' => Lang_cl::__('Checkout Container style', 'cl'),
        'style_attached_to' => '.cl-checkout-container',
        'single_css_supported' => ['max-width'],
        'border' => 'yes',
        'border-radius' => 'yes', 
        'background' => 'yes',
        'padding' => 'yes',
        'box-shadow' => 'yes',
    ],
);