<?php return array (
  'setting' => 
  array (
    'summary_is_active' => 'yes',
    'summary_version' => 'v1',
    'summary_header_is_open' => 'no',
    'summary_header_is_active' => 'yes',
    'summary_header_total_is_active' => 'yes',
    'summary_cart_products_is_active' => 'yes',
    'summary_cart_totals_is_active' => 'yes',
    'summary_icons_is_active' => 'yes',
    'summary_discount_is_active' => 'yes',
    'summary_shipping_is_active' => 'yes',
    'summary_payment_msg_is_active' => 'yes',
  ),
  'lang' => 
  array (
    'summary_header_title_is_open' => '⇡ Order summary',
    'summary_header_title_is_closed' => '⇣ Order Summary: Click Here to Open',
    'summary_discount_label' => 'Discount',
    'summary_discount_value' => 'Économiser',
    'summary_shipping_label' => 'Shipping fees',
    'summary_shipping_title' => 'Livraison gratuite',
    'summary_total_label' => 'Total To pay',
    'summary_payment_msg' => 'Paiement à la livraison',
  ),
  'style' => 
  array (
    'summary_container_style' => 'border-top-width:px;border-right-width:px;border-bottom-width:px;border-left-width:px;border-color:#eee2e2;border-style:solid;border-top-left-radius:px;border-top-right-radius:px;border-bottom-left-radius:px;border-bottom-right-radius:px;padding-top:7px;padding-right:10px;padding-bottom:7px;padding-left:10px;margin-top:px;margin-right:px;margin-bottom:px;margin-left:px;background-image:;box-shadow:0 0px 8px 0 #ccc;',
    'summary_header_title_style' => 'font-size:14px;color:#008000;font-weight:700;text-align:center;',
    'summary_header_total_style' => 'font-size:14px;color:#008000;font-weight:700;text-align:center;',
    'summary_cart_products_container_style' => '',
    'summary_cart_totals_container_style' => '',
    'summary_icons_style' => 'font-size:10px;color:;font-weight:700;text-align:initial;',
    'summary_discount_label_style' => 'font-size:10px;color:;font-weight:700;text-align:initial;',
    'summary_discount_value_style' => 'font-size:13px;color:#ffffff;font-weight:700;text-align:initial;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-color:#3c2f2f;border-style:solid;border-top-left-radius:9px;border-top-right-radius:24px;border-bottom-left-radius:29px;border-bottom-right-radius:12px;background-color:#3c2f2f;padding-top:3px;padding-right:5px;padding-bottom:3px;padding-left:5px;',
    'summary_shipping_label_style' => 'font-size:14px;color:#030202;font-weight:700;text-align:initial;',
    'summary_shipping_title_style' => 'font-size:14px;color:#475357;font-weight:700;text-align:initial;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-color:#133337;border-style:solid;border-top-left-radius:3px;border-top-right-radius:3px;border-bottom-left-radius:3px;border-bottom-right-radius:3px;background-color:#ffffff;padding-top:5px;padding-right:5px;padding-bottom:5px;padding-left:5px;',
    'summary_total_label_style' => 'font-size:18px;color:#000000;font-weight:700;text-align:initial;',
    'summary_total_value_style' => 'font-size:20px;color:#000000;font-weight:700;text-align:initial;',
    'summary_payment_msg_style' => 'font-size:14px;color:#166a09;font-weight:700;text-align:center;',
  ),
);