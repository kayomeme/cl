<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Shipping options section', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['shipping_options_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="shipping_options_is_active" value="<?= $settings['shipping_options_is_active'] ?>">
                    </label>

                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Shipping options container style', 'clfe'),
                            'styleAttachedTo' => '#clfe_shipping_options',
                            'border' => 'yes',
                            'padding' => 'yes',
                            'background' => 'yes'
                        ];
                        $adminStyle->getAllCss('shipping_options_style', $settings['shipping_options_style'], $activeOptions); 
                    ?>  
                </div>
            </div>
            
            <?php $adminStyle->getSingleCss('margin-top', 'shipping_options_style', $settings['shipping_options_style']); ?>
            
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is open by default', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['shipping_options_header_is_open'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="shipping_options_header_is_open" value="<?= $settings['shipping_options_header_is_open'] ?>">
                    </label>
                </div>
            </div>
            
            <div class="clfe-row clfe-type-select">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Columns layout', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <select name="shipping_options_column" class="clfe-style-element" value="<?= $settings['shipping_options_column'] ?>">
                        <option value="1"><?= Lang_clfe::_e('1 column', 'clfe') ?></option>
                        <option value="2"><?= Lang_clfe::_e('2 columns', 'clfe') ?></option>
                    </select> 

                </div>
            </div>
            
        </div>
        
        
    </div>
</div>

<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Shipping options header', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['shipping_options_header_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="shipping_options_header_is_active" value="<?= $settings['shipping_options_header_is_active'] ?>">
                    </label>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th-full">
                    <label>
                        <?= Lang_clfe::_e('Title when the section is open', 'clfe') ?>
                    </label>

                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Shipping options title style', 'clfe'),
                            'styleAttachedTo' => '.clfe-shipping-options-section-title',
                            'font' => 'yes'
                        ];
                        $adminStyle->getAllCss('shipping_options_header_style', $settings['shipping_options_header_style'], $activeOptions); 
                    ?>
                </div>
                <div class="clfe-td-full">
                    <input type="text"  name="shipping_options_header_title_is_open" textAttachedTo=".shipping_options_header_title_is_open" value="<?= $settings['shipping_options_header_title_is_open'] ?>" placeholder="<?= Lang_clfe::_e('Title when the section is open', 'clfe') ?>">
                </div>
                <div class="clfe-th-full">
                    <label>
                        <?= Lang_clfe::_e('Title when the section is closed', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td-full">
                    <input type="text"  name="shipping_options_header_title_is_closed" textAttachedTo=".shipping_options_header_title_is_closed" value="<?= $settings['shipping_options_header_title_is_closed'] ?>" placeholder="<?= Lang_clfe::_e('Title when the section is closed', 'clfe') ?>">
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Count text', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <input type="text"  name="shipping_options_header_count_text" textAttachedTo=".shipping-options-header-count-text .count_text" value="<?= $settings['shipping_options_header_count_text'] ?>" placeholder="<?= Lang_clfe::_e('Count shipping-options text', 'clfe') ?>">
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Count shipping-options text style', 'clfe'),
                            'styleAttachedTo' => '.shipping-options-header-count-text',
                            'font' => 'yes'
                        ];
                        $adminStyle->getAllCss('shipping_options_header_count_text_style', $settings['shipping_options_header_count_text_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            
        </div>
    </div>

</div>

<div class="shipping_options_layout_settings">
    <div class="clfe-row clfe-type-select">
        <div class="clfe-th">
            <label>
                <?= Lang_clfe::_e('Display layout', 'clfe') ?>
            </label>
        </div>
        <div class="clfe-td">
            <select name="shipping_options_layout" blocks-to-hide='.shipping_options_layout_blocks'>
                <option value="list_blocks" block-to-show=".list_blocks" <?= $settings['shipping_options_layout'] === 'list_blocks' ? 'selected' : '' ?>>
                    <?= Lang_clfe::_e('List blocks', 'clfe') ?>
                </option>
                <option value="select_box" block-to-show=".select_box" <?= $settings['shipping_options_layout'] === 'select_box' ? 'selected' : '' ?>>
                    <?= Lang_clfe::_e('Select box', 'clfe') ?>
                </option>
            </select> 

        </div>
    </div>

    <div class="clfe-row select_box shipping_options_layout_blocks">
        <div class="clfe-th">
            <label>
                <?= Lang_clfe::_e('Select box style', 'clfe') ?>
            </label>
        </div>
        <div class="clfe-td">
            <?php
                  $activeOptions = [
                      'modalTitle' => Lang_clfe::__('Shipping options select box style', 'clfe'),
                      'styleAttachedTo' => '.clfe-shipping-options-selectbox',
                      'font' => 'yes',
                      'border' => 'yes',
                      'padding' => 'yes',
                      'background' => 'yes'
                  ];
                  $adminStyle->getAllCss('shipping_options_selectbox_style', $settings['shipping_options_selectbox_style'], $activeOptions); 
              ?>
        </div>
    </div>

    <div class="clfe-row list_blocks shipping_options_layout_blocks">
        <div class="clfe-th">
            <label>
                <?= Lang_clfe::_e('Offer box', 'clfe') ?>
            </label>
        </div>
        <div class="clfe-td">
            <div class="clfe-sub-section">
                <div class="clfe-row">
                    <div class="clfe-th">
                        <label><?= Lang_clfe::_e('Default box style', 'clfe'); ?></label>
                    </div>
                    <div class="clfe-td">
                        <?php
                            $activeOptions = [
                                'modalTitle' => Lang_clfe::__('Default box style', 'clfe'),
                                'styleAttachedTo' => '.clfe-shipping-option',
                                'min-height' => 'yes', 'border' => 'yes', 'padding' => 'yes', 'linear-gradient' => 'yes'
                            ];
                            $adminStyle->getAllCss('shipping_option_default_style', $settings['shipping_option_default_style'], $activeOptions); 
                        ?>
                    </div>
                </div>
                <div class="clfe-row">
                    <div class="clfe-th">
                        <label> <?= Lang_clfe::_e('Selected box style', 'clfe'); ?> </label>
                    </div>
                    <div class="clfe-td">
                        <?php 
                            $activeOptions = [
                                'modalTitle' => Lang_clfe::__('Selected box style', 'clfe'),
                                'styleAttachedTo' => '.is-selected-shipping-option',
                                'border' => 'yes', 'linear-gradient' => 'yes', 'box-shadow' => 'yes'
                            ];
                            $adminStyle->getAllCss('shipping_option_selected_style', $settings['shipping_option_selected_style'], $activeOptions); 
                        ?>
                    </div>
                </div>

                <div class="clfe-row clfe-row-is-title">
                        <label>
                            <?= Lang_clfe::_e('Box elements', 'clfe') ?> :
                        </label>
                </div>

                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Cost value', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <label class="clfe-switch">
                          <input type="checkbox" <?= $settings['shipping_option_cost_value_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                          <span class="clfe-slider clfe-round"></span>
                          <input type="hidden" name="shipping_option_cost_value_is_active" value="<?= $settings['shipping_option_cost_value_is_active'] ?>">
                        </label>
                        <?php 
                            $activeOptions = [
                                'modalTitle' => Lang_clfe::__('Shipping options cost value style', 'clfe'),
                                'styleAttachedTo' => '.clfe-cost-value',
                                'font' => 'yes'
                            ];
                            $adminStyle->getAllCss('shipping_option_cost_value_style', $settings['shipping_option_cost_value_style'], $activeOptions); 
                        ?>
                    </div>
                </div>

                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('cost label', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <label class="clfe-switch">
                          <input type="checkbox" <?= $settings['shipping_option_cost_label_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                          <span class="clfe-slider clfe-round"></span>
                          <input type="hidden" name="shipping_option_cost_label_is_active" value="<?= $settings['shipping_option_cost_label_is_active'] ?>">
                        </label>

                        <?php 
                            $activeOptions = [
                                'modalTitle' => Lang_clfe::__('Shipping options cost label style', 'clfe'),
                                'styleAttachedTo' => '.clfe-cost-label',
                                'font' => 'yes'
                            ];
                            $adminStyle->getAllCss('shipping_option_cost_label_style', $settings['shipping_option_cost_label_style'], $activeOptions); 
                        ?>
                    </div>
                </div>

                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Show title', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <label class="clfe-switch">
                          <input type="checkbox" <?= $settings['shipping_option_title_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                          <span class="clfe-slider clfe-round"></span>
                          <input type="hidden" name="shipping_option_title_is_active" value="<?= $settings['shipping_option_title_is_active'] ?>">
                        </label>

                        <?php
                            $activeOptions = [
                                'modalTitle' => Lang_clfe::__('Single Shipping options title style', 'clfe'),
                                'styleAttachedTo' => '.clfe-shipping-option-title',
                                'font' => 'yes'
                            ];
                            $adminStyle->getAllCss('shipping_option_title_style', $settings['shipping_option_title_style'], $activeOptions); 
                        ?>
                    </div>
                </div>

                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Show sub title', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <label class="clfe-switch">
                          <input type="checkbox" <?= $settings['shipping_option_subtitle_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                          <span class="clfe-slider clfe-round"></span>
                          <input type="hidden" name="shipping_option_subtitle_is_active" value="<?= $settings['shipping_option_subtitle_is_active'] ?>">
                        </label>

                        <?php
                            $activeOptions = [
                                'modalTitle' => Lang_clfe::__('Shipping-option sub title style', 'clfe'),
                                'styleAttachedTo' => '.clfe-shipping-option-subtitle',
                                'font' => 'yes'
                            ];
                            $adminStyle->getAllCss('shipping_option_subtitle_style', $settings['shipping_option_subtitle_style'], $activeOptions); 
                        ?>
                    </div>
                </div>

                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Show radio button', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <label class="clfe-switch">
                          <input type="checkbox" <?= $settings['shipping_option_radio_bt_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                          <span class="clfe-slider clfe-round"></span>
                          <input type="hidden" name="shipping_option_radio_bt_is_active" value="<?= $settings['shipping_option_radio_bt_is_active'] ?>">
                        </label>

                        <?php
                            $activeOptions = [
                                'modalTitle' => Lang_clfe::__('Radio button style', 'clfe'),
                                'styleAttachedTo' => '.clfe-shipping-option-radio-bt',
                                'margin' => 'yes'
                            ];
                            $adminStyle->getAllCss('shipping_option_radio_bt_style', $settings['shipping_option_radio_bt_style'], $activeOptions); 
                        ?>
                    </div>
                </div>

                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Show image', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <label class="clfe-switch">
                          <input type="checkbox" <?= $settings['shipping_option_image_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                          <span class="clfe-slider clfe-round"></span>
                          <input type="hidden" name="shipping_option_image_is_active" value="<?= $settings['shipping_option_image_is_active'] ?>">
                        </label>

                    </div>
                </div>

                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Show background image', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <label class="clfe-switch">
                          <input type="checkbox" <?= $settings['shipping_option_bg_image_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                          <span class="clfe-slider clfe-round"></span>
                          <input type="hidden" name="shipping_option_bg_image_is_active" value="<?= $settings['shipping_option_bg_image_is_active'] ?>">
                        </label>

                    </div>
                </div>

            </div>
        </div>
    </div>


    <div class="clfe-row list_blocks shipping_options_layout_blocks">
        <div class="clfe-th">
            <label>
                <?= Lang_clfe::_e('Badge', 'clfe') ?>
            </label>
        </div>
        <div class="clfe-td">
            <div class="clfe-sub-section">
                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Is active', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <label class="clfe-switch">
                          <input type="checkbox" <?= $settings['shipping_option_badge_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                          <span class="clfe-slider clfe-round"></span>
                          <input type="hidden" name="shipping_option_badge_is_active" value="<?= $settings['shipping_option_badge_is_active'] ?>">
                        </label>

                        <?php
                  $activeOptions = [
                      'modalTitle' => Lang_clfe::__('Shipping options badge style', 'clfe'),
                      'styleAttachedTo' => '.clfe-shipping-option .shipping-option-badge',
                      'font' => 'yes',
                      'border' => 'yes',
                      'padding' => 'yes',
                      'background' => 'yes',
                      'box-shadow' => 'yes'
                  ];
                  $adminStyle->getAllCss('shipping_option_badge_style', $settings['shipping_option_badge_style'], $activeOptions); 
              ?>
                    </div>
                </div>

                <div class="clfe-row">
                    <div class="clfe-th">
                        <label>
                            <?= Lang_clfe::_e('Badge Position', 'clfe') ?>
                        </label>
                    </div>
                    <div class="clfe-td">
                        <select name="shipping_option_badge_position_style" class="clfe-style-element" value="<?= $settings['shipping_option_badge_position_style'] ?>" styleAttachedTo=".clfe-shipping-option .shipping-option-badge">
                            <option value="top:-6px;left:0px"><?= Lang_clfe::_e('Top Left', 'clfe') ?></option>
                            <option value="top:-6px;right:0px"><?= Lang_clfe::_e('Top Right', 'clfe') ?></option>
                            <option value="top:0px;left: 50%; transform: translate(-50%, -50%)"><?= Lang_clfe::_e('Top Center', 'clfe') ?></option>
                            <option value="bottom:-6px;left:0px"><?= Lang_clfe::_e('Bottom Left', 'clfe') ?></option>
                            <option value="bottom:-6px;right:0px"><?= Lang_clfe::_e('Bottom Right', 'clfe') ?></option>
                            <option value="bottom:-20px;left: 50%; transform: translate(-50%, -50%)"><?= Lang_clfe::_e('Bottom Center', 'clfe') ?></option>
                            <option value="position: initial;margin-inline-start: 5px;"><?= Lang_clfe::_e('Next to shipping-option title', 'clfe') ?></option>
                        </select> 
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>

<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Single blocks content', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td-full">
        <div class="clfe-Shipping-container clfe_shipping_options">
            <div class="clfe-sub-section">

                <div class="dynamic-elements shipping-options-dynamic-elements" attachedSettingName="shipping_options">
                    <?php 
                    foreach ($shippingOptions['elements'] as $value) { 
                        if( isset( $value['is_active'] ) ) {
                            include 'shipping_options_elements/c_element.php';
                        }
                    }
                    ?> 
                </div>
                <button type="button" class="clfe-add-dynamic-element" dynamic-elements-container="clfe_shipping_options" modalTitle="<?= Lang_clfe::_e('Add new Shipping option', 'clfe') ?>">
                    <span class="dashicons dashicons-plus"></span>
                    <?= Lang_clfe::_e('Add new Shipping option', 'clfe') ?>
                </button>
                <input type="text"  name="shipping_options" value="<?= adminUtils_clfe::cleanInput($settings['shipping_options']) ?>">


                <div class="clfe-empty-elements" style="display: none !important">
                    <?php 
                        $value = [
                            'is_active' => 'yes',
                            'is_open' => 'no',
                            'title' => 'new block',
                            'subtitle' => '',
                            'badge_text' => '',
                            'condition_variable' => '',
                            'condition_operator' => '',
                            'condition_value' => '',
                            'cost_value' => '0',
                            'cost_label' => '',
                            'thumbnail_id' => '',
                            'thumbnail_url' => '',
                            'bg_id' => '',
                            'bg_url' => ''
                        ];
                        include 'shipping_options_elements/c_element.php';
                    ?>
                </div>
                
                
            <?php 
                //include 'privacy_elements/block1.php';
                //include 'privacy_elements/block2.php';
            ?>
            </div>
        </div>
    </div> 
</div>