<!-- Shipping options Info Section -->
<div class="cl-info-section">
    <div class="cl-info-header">
        <span class="dashicons dashicons-info"></span>
        <p><?= Lang_cl::_e('This page controls the global shipping options settings. To manage specific shipping option elements, use the link below:', 'cl') ?></p>
    </div>

    <div class="cl-info-links">
        <a href="admin.php?page=cl_shipping_options" >
            <span><?= Lang_cl::_e('Shipping Options Elements', 'cl') ?></span>
            <span class="arrow">→</span>
        </a>
    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Shipping options section', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'shipping_options_is_active',
                        'value' => $settings['shipping_options_is_active']
                    ]);

                    $styleManager->getAllCss('shipping_options_container_style');
                    ?>
                </div>
            </div>

            <?php
            $styleManager->getSingleCss('margin-top', 'shipping_options_container_style');
            ?>

            <div class="cl-row cl-type-select">
                <div class="cl-th">
                    <?= Lang_cl::_e('Display Type', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select name="shipping_options_display_type" blocks-to-hide=".shipping_options_display_type_blocks">
                        <option value="list_blocks" block-to-show=".list_blocks" <?= $settings['shipping_options_display_type'] === 'list_blocks' ? 'selected' : '' ?>>
                            <?= Lang_cl::_e('List blocks', 'cl') ?>
                        </option>
                        <option value="select_box" block-to-show=".select_box" <?= $settings['shipping_options_display_type'] === 'select_box' ? 'selected' : '' ?>>
                            <?= Lang_cl::_e('Select box', 'cl') ?>
                        </option>
                    </select>

                </div>
            </div>

            <div class="cl-row list_blocks shipping_options_display_type_blocks">
                <div class="cl-th">
                    <?= Lang_cl::_e('Columns', 'cl') ?>
                </div>
                <div class="cl-td">
                    <select name="shipping_options_column" class="cl-style-element" value="<?= $settings['shipping_options_column'] ?>">
                        <option value="1" <?= ($settings['shipping_options_column'] == '1') ? 'selected' : '' ?>><?= Lang_cl::_e('1 column', 'cl') ?></option>
                        <option value="2" <?= ($settings['shipping_options_column'] == '2') ? 'selected' : '' ?>><?= Lang_cl::_e('2 columns', 'cl') ?></option>
                        <option value="3" <?= ($settings['shipping_options_column'] == '3') ? 'selected' : '' ?>><?= Lang_cl::_e('3 columns', 'cl') ?></option>
                        <option value="auto" <?= ($settings['shipping_options_column'] == 'auto') ? 'selected' : '' ?>><?= Lang_cl::_e('auto', 'cl') ?></option>
                    </select>
                </div>
            </div>
            
            <div class="list_blocks shipping_options_display_type_blocks">
                <?php
                $styleManager->getAllCss('shipping_options_items_style');
                $styleManager->getSingleCss('gap', 'shipping_options_items_style');
                ?>
            </div>

        </div>

    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Shipping Options header', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'shipping_options_header_is_active',
                        'value' => $settings['shipping_options_header_is_active']
                    ]);
                    $styleManager->getAllCss('shipping_options_header_container_style');
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is open by default', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'shipping_options_header_is_open',
                        'value' => $settings['shipping_options_header_is_open']
                    ]);
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Title', 'cl') ?>
                </div>
                <div class="cl-td cl-sub-section">
                    <div class="cl-row">
                        <div class="cl-th">
                            <?= Lang_cl::_e('Style', 'cl') ?>
                        </div>
                        <div class="cl-td">
                            <?php $styleManager->getAllCss('shipping_options_header_title_style'); ?>
                        </div>
                    </div>
                    <div class="cl-row">
                        <div class="cl-th">
                            <?= Lang_cl::_e('Is open', 'cl') ?>
                        </div>
                        <div class="cl-td cl-style-container">
                            <input type="text"  name="shipping_options_header_title_is_open" textAttachedTo=".shipping_options_header_title_is_open" 
                                   value="<?= $settings['shipping_options_header_title_is_open'] ?>" placeholder="<?= Lang_cl::_e('Title when the section is open', 'cl') ?>">
                        </div>
                    </div>
                    <div class="cl-row">
                        <div class="cl-th">
                            <?= Lang_cl::_e('Is closed', 'cl') ?>
                        </div>
                        <div class="cl-td">
                            <input type="text"  name="shipping_options_header_title_is_closed" textAttachedTo=".shipping_options_header_title_is_closed" 
                                   value="<?= $settings['shipping_options_header_title_is_closed'] ?>" placeholder="<?= Lang_cl::_e('Title when the section is closed', 'cl') ?>">
                        </div>
                    </div>
                </div>
            </div>

            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Count text', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <input type="text"  name="shipping_options_header_count_text" textAttachedTo=".shipping-options-header-count-text .count_text" value="<?= $settings['shipping_options_header_count_text'] ?>" placeholder="<?= Lang_cl::_e('Count options text', 'cl') ?>">
                    <?php
                    $styleManager->getAllCss('shipping_options_header_count_text_style');
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Icons style', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    $styleManager->getAllCss('shipping_options_header_icon_style');
                    ?>
                </div>
            </div>

        </div>
    </div>

</div>

<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Selected Option Preview', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'shipping_option_preview_is_active',
                        'value' => $settings['shipping_option_preview_is_active']
                    ]);

                    $styleManager->getAllCss('shipping_option_preview_style');
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Prefix text', 'cl') ?>
                </div>
                <div class="cl-td">
                    <input type="text" name="shipping_option_preview_prefix_text" textAttachedTo=".shipping_option_preview .prefix_text" 
                           value="<?= $settings['shipping_option_preview_prefix_text'] ?>" placeholder="<?= Lang_cl::_e('Text before selected value', 'cl') ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="cl-alert cl-alert-info">
        <?= Lang_cl::_e('This preview will only show when the section is collapsed, allowing users to quickly see their selected option without expanding the full section.', 'cl') ?>                    
    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Shipping options Body Container', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Container style', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getAllCss('shipping_options_body_container_style');
                    ?>
                </div>
            </div>

        </div>

    </div>
</div>

<div class="shipping_options_display_type_settings">

    <div class="cl-row select_box shipping_options_display_type_blocks">
        <div class="cl-th">
            <?= Lang_cl::_e('Select box style', 'cl') ?>
        </div>
        <div class="cl-td">
            <?php
            $styleManager->getAllCss('shipping_options_selectbox_style');
            ?>
        </div>
    </div>

    <div class="cl-row list_blocks shipping_options_display_type_blocks">
        <div class="cl-th">
            <?= Lang_cl::_e('Shipping option box', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <?php
                $styleManager->getSingleCss('min-height', 'shipping_option_default_style');
                $styleManager->getFlexLayout('shipping_option_elements_layout_style');
                ?>

                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Default box style', 'cl'); ?>
                    </div>
                    <div class="cl-td">
                        <?php
                        $styleManager->getAllCss('shipping_option_default_style');
                        ?>
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th-full">
                        <?= Lang_cl::_e('Selected box style', 'cl'); ?>
                    </div>
                    <div class="cl-td-full">
                        <div class="cl-sub-section">
                            <?php
                            $styleManager->getAllCss('shipping_option_selected_style');
                            $styleManager->getSingleCss('border-color', 'shipping_option_selected_style');
                            $styleManager->getSingleCss('background-color', 'shipping_option_selected_style');
                            ?>
                        </div>
                    </div>
                    <div class="cl-alert cl-alert-info">
                        <?= Lang_cl::_e('This style will be applied to the client\'s selected option, helping to highlight the chosen shipping option', 'cl') ?>                    
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="cl-row list_blocks shipping_options_display_type_blocks">
        <div class="cl-th">
            <?= Lang_cl::_e('Images', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Featured Image', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getSwitchButton([
                            'name' => 'shipping_option_image_is_active',
                            'value' => $settings['shipping_option_image_is_active']
                        ]);

                        $styleManager->getAllCss('shipping_option_image_style');
                        ?>
                    </div>
                    <?php $styleManager->getSingleCss('max-width', 'shipping_option_image_style'); ?>
                </div>
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Background', 'cl') ?>
                    </div>
                    <div class="cl-td">
                        <?php
                        $styleManager->getSwitchButton([
                            'name' => 'shipping_option_bg_image_is_active',
                            'value' => $settings['shipping_option_bg_image_is_active']
                        ]);
                        ?>
                    </div>
                    <div class="cl-alert cl-alert-info">
                        <?= Lang_cl::_e('When you choose the background image option, all other elements such as thumbnail, title, and costs will be automatically hidden.', 'cl') ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="cl-row list_blocks shipping_options_display_type_blocks">
        <div class="cl-th">
            <?= Lang_cl::_e('Option title', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Is active', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getSwitchButton([
                            'name' => 'shipping_option_title_is_active',
                            'value' => $settings['shipping_option_title_is_active']
                        ]);

                        $styleManager->getAllCss('shipping_option_title_style');
                        ?>
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Sub title', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getSwitchButton([
                            'name' => 'shipping_option_subtitle_is_active',
                            'value' => $settings['shipping_option_subtitle_is_active']
                        ]);

                        $styleManager->getAllCss('shipping_option_subtitle_style');
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="cl-row list_blocks shipping_options_display_type_blocks">
        <div class="cl-th">
            <?= Lang_cl::_e('Costs', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">

                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Cost value', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getSwitchButton([
                            'name' => 'shipping_option_cost_value_is_active',
                            'value' => $settings['shipping_option_cost_value_is_active']
                        ]);
                        $styleManager->getAllCss('shipping_option_cost_value_style');
                        ?>
                    </div>
                </div>

                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Cost label', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getSwitchButton([
                            'name' => 'shipping_option_cost_label_is_active',
                            'value' => $settings['shipping_option_cost_label_is_active']
                        ]);

                        $styleManager->getAllCss('shipping_option_cost_label_style');
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="cl-row list_blocks shipping_options_display_type_blocks">
        <div class="cl-th">
            <?= Lang_cl::_e('Radio button', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Is Active', 'cl') ?>
                    </div>
                    <div class="cl-td">
                        <?php
                        $styleManager->getSwitchButton([
                            'name' => 'shipping_option_radio_bt_is_active',
                            'value' => $settings['shipping_option_radio_bt_is_active']
                        ]);
                        ?>
                    </div>
                </div>
                <?= $styleManager->getPositionCss('shipping_option_radio_bt_position_style'); ?>
            </div>

        </div>
    </div>

    <div class="cl-row list_blocks shipping_options_display_type_blocks">
        <div class="cl-th">
            <?= Lang_cl::_e('Badge', 'cl') ?>
        </div>
        <div class="cl-td">
            <div class="cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Is active', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getSwitchButton([
                            'name' => 'shipping_option_badge_is_active',
                            'value' => $settings['shipping_option_badge_is_active']
                        ]);
                        $styleManager->getAllCss('shipping_option_badge_style');
                        ?>
                    </div>
                </div>
                <?= $styleManager->getPositionCss('shipping_option_badge_position_style'); ?>
            </div>

        </div>
    </div>
</div>