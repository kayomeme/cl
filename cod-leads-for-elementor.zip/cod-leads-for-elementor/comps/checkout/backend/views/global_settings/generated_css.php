<?php

include 'blocks/general/v1/generated_css.php';
include 'blocks/form/'.$settings['form_version'].'/generated_css.php';


include 'blocks/submit_button/'.$settings['submit_button_version'].'/generated_css.php';

if( $settings['shipping_options_is_active'] == 'yes' ) {
    include 'blocks/shipping_options/'.$settings['shipping_options_version'].'/generated_css.php';
}

if( $settings['summary_is_active'] == 'yes' ) {
    include 'blocks/summary/'.$settings['summary_version'].'/generated_css.php';
}

if( $settings['checkout_custom_block1_is_active'] == 'yes' ) {
    include 'blocks/checkout_custom_block1/'.$settings['checkout_custom_block1_version'].'/generated_css.php';
}

if( $settings['checkout_custom_block2_is_active'] == 'yes' ) {
    include 'blocks/checkout_custom_block2/'.$settings['checkout_custom_block2_version'].'/generated_css.php';
}

if ($sharedSettings['checkout_mode'] == 'modal') { 
    include 'blocks/checkout_modal/' . $settings['checkout_modal_version'] . '/generated_css.php';
}

?>