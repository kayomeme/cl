<?php


include 'blocks/form/'.$settings['form_version'].'/generated_css.php';


include 'blocks/submit_button/'.$settings['submit_button_version'].'/generated_css.php';

if( $settings['shipping_options_is_active'] == 'yes' ) {
    include 'blocks/shipping_options/'.$settings['shipping_options_version'].'/generated_css.php';
}

if( $settings['summary_is_active'] == 'yes' ) {
    include 'blocks/summary/'.$settings['summary_version'].'/generated_css.php';
}

if( $settings['checkout_custom_block1_is_active'] == 'yes' ) {
    include 'blocks/checkout_custom_block1/'.$settings['checkout_custom_block1_version'].'/generated_css.php';
}

if( $settings['checkout_custom_block2_is_active'] == 'yes' ) {
    include 'blocks/checkout_custom_block2/'.$settings['checkout_custom_block2_version'].'/generated_css.php';
}
?>

<style>
    
<?php 
//if ($settings['checkout_placement'] == 'modal') {} 
// Add a test here to only include the CSS code if the user chooses the checkout model in the sales funnel
?>
    .jquery-modal .modal a.close-modal {
        display: <?= $settings['checkout_modal_header_close_bt_is_active'] == 'yes' ? 'block' : 'none' ?>;
        <?= $settings['checkout_modal_header_close_bt_style'] ?>
    }
    checkout_modal_header_close_bt_is_active
    
    .clfe-popup-footer a {<?= $settings['checkout_modal_footer_text_close_style'] ?>}
    
    .jquery-modal { background-color:rgba(<?= $settings['checkout_modal_bg_transparency_color'] ?>,0.<?= $settings['checkout_modal_bg_transparency_level'] ?>) !important; }
    
</style>