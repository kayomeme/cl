<div class="cl-row cl-type-select">
    <div class="cl-th">
        <label>
            <?= Lang_cl::_e('Error messages placement', 'cl') ?>
        </label>
    </div>
    <div class="cl-td">
        <select name="error_placement" class="cl-style-element" value="<?= $settings['error_placement'] ?>">
            <option value="before_submit_button"><?= Lang_cl::_e('Before submit button', 'cl') ?></option>
            <option value="after_submit_button"><?= Lang_cl::_e('After submit button', 'cl') ?></option>
            <option value="after_every_field"><?= Lang_cl::_e('After every field', 'cl') ?></option>
            <!--<option value="show_in_popup"><?= Lang_cl::_e('Show in popup', 'cl') ?></option>-->
        </select> 
        
        <?php 
            $activeOptions = [
               'font' => 'yes', 'border' => 'yes'
            ];
            $styleManager->getAllCss('error_msg_style', $activeOptions); 
        ?>
    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <label>
            <?= Lang_cl::_e('waiting messages to show after the button is clicked', 'cl') ?>
        </label>
    </div>
    <div class="cl-td">
        <input type="text"  name="error_wait_text" value="<?= $settings['error_wait_text'] ?>">
        <?php 
            $activeOptions = [
                'font' => 'yes'
            ];
            $styleManager->getAllCss('error_wait_text_style', $activeOptions); 
        ?>
        
        <div class="cl-sub-section">
            <div class="cl-td">
                <label>
                    <?= Lang_cl::_e('Show wait icon', 'cl') ?>
                </label>
            </div>
            <div class="cl-td">
                <label class="cl-switch">
                  <input type="checkbox" <?= $settings['error_wait_icon_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                  <span class="cl-slider cl-round"></span>
                  <input type="hidden" name="error_wait_icon_is_active" value="<?= $settings['error_wait_icon_is_active'] ?>">
                </label>
                
            </div>
        </div>
    </div>
</div>

<div class="cl-row cl-type-select">
    <div class="cl-th">
        <label>
            <?= Lang_cl::_e('Error message when the variation is not selected', 'cl') ?>
        </label>
    </div>
    <div class="cl-td">
        <input type="text"  name="error_variation_not_selected" value="<?= $settings['error_variation_not_selected'] ?>">
        
    </div>
</div>