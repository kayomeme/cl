<div class="cl-row" _attachedsection="submit_button">
    <span class="dashicons dashicons-yes"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Submit button', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>