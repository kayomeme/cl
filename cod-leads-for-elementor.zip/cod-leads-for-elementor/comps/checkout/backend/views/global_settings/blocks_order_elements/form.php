<div class="cl-row" _attachedsection="form">
    <span class="dashicons dashicons-list-view"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Form', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>