<div class="cl-row" _attachedsection="shipping_options">
    <span class="dashicons dashicons-cart"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Shipping options', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>