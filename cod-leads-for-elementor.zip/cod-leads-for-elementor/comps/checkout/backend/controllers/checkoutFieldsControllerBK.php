<?php

/**
 * Controller for managing checkout fields
 */
class CheckoutFieldsControllerBK_cl {

    /*
     * Ajax Routes
     */
    public static function routes($action, $args) {
        $response = false;
        switch ($action) {
            case 'cl_update_checkout_field':
                $response = self::saveUpdate($args);
                break;
            case 'cl_addnew_checkout_field':
                $response = self::saveAddNew($args);
                break;
            case 'cl_delete_checkout_field':
                $response = self::deleteField($args);
                break;
        }

        return $response;
    }

    /*
     * http Routes
     */
    public function index() {
        $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 'list';
        switch ($action) {
            case 'edit':
                self::editIndex();
                break;
            case 'addnew':
                self::addNewIndex();
                break;
            case 'list':
                self::listIndex();
                break;
        }
    }
    
    public static function addNewIndex() {
        $sharedSettings = AdminCompo_cl::getSharedSettings($settingsModelId=0);
        
        $fieldTypes = CheckoutFieldsUtilBK_cl::getFieldTypes();
        $conditionOperators = CheckoutFieldsUtilBK_cl::getConditionOperators();
        $iconList = CheckoutFieldsUtilBK_cl::getIcons();
        
        include MainApp_cl::$compsPath.'checkout/backend/views/checkout_fields/addnew/addNewIndex.php';
    }
    
    public static function saveAddNew($args) {
        // Sanitize inputs
        if (isset($args['name'])) {
            $args['name'] = sanitize_text_field($args['name']);
        }
        
        $response = CheckoutFieldsModelBK_cl::addNew($args);
        
        if ($response->code == 1 && isset($response->res['insert_id'])) {
            $response->res['redirect_to'] = admin_url('admin.php?page=cl_checkout_fields&action=edit&field_id='.$response->res['insert_id']);
        }
        
        return $response;
    }
    
    public static function editIndex() {
        $fieldId = isset($_GET['field_id']) ? intval($_GET['field_id']) : 0;
        if (!$fieldId) {
            wp_die(Lang_cl::__('Invalid checkout field ID', 'cl'));
        }

        // Get checkout field for edit
        $response = CheckoutFieldsModelBK_cl::getSingle($fieldId);
        if ($response->code === 0) {
            wp_die($response->msg);
        }

        $checkoutField = $response->res;
        $fieldTypes = CheckoutFieldsUtilBK_cl::getFieldTypes();
        $conditionOperators = CheckoutFieldsUtilBK_cl::getConditionOperators();
        $iconList = CheckoutFieldsUtilBK_cl::getIcons();
        
        $sharedSettings = AdminCompo_cl::getSharedSettings($settingsModelId=0);
        
        include MainApp_cl::$compsPath.'checkout/backend/views/checkout_fields/edit/editIndex.php';
    }
    
    public static function saveUpdate($args) {
        $fieldId = isset($args['id']) && $args['id'] > 0 ? $args['id'] : false;
        
        if (!$fieldId) {
            return response_cl(0, Lang_cl::__('Invalid checkout field ID', 'cl'), null);
        }
        
        $response = CheckoutFieldsModelBK_cl::update($fieldId, $args);
        
        return $response;
    }
   
    public static function listIndex() {
        $currentUrl = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
        $limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 50;
        $checkoutFields = CheckoutFieldsModelBK_cl::getAll($settingsModelId = 0, $limit = null);
        
        $sharedSettings = AdminCompo_cl::getSharedSettings($settingsModelId=0);
        $fieldTypes = CheckoutFieldsUtilBK_cl::getFieldTypes();
        
        include MainApp_cl::$compsPath.'checkout/backend/views/checkout_fields/listing/listIndex.php';
    }
    
    public static function deleteField($args) {
        $response = CheckoutFieldsModelBK_cl::delete($args['field_id']);
        
        return $response;
    }
}