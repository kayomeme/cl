<?php

/**
 * Controller for managing shipping options
 */
class ShippingOptionsControllerBK_cl {

    /*
     * Ajax Routes
     */
    public static function routes($action, $args) {
        $response = false;
        switch ($action) {
            case 'cl_update_shipping_option':
                $response = self::saveUpdate($args);
                break;
            case 'cl_addnew_shipping_option':
                $response = self::saveAddNew($args);
                break;
            case 'cl_delete_shipping_option':
                $response = self::deleteOption($args);
                break;
        }

        return $response;
    }

    /*
     * http Routes
     */
    public function index() {
        $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 'list';
        switch ($action) {
            case 'edit':
                self::editIndex();
                break;
            case 'addnew':
                self::addNewIndex();
                break;
            case 'list':
                self::listIndex();
                break;
        }
    }
    
    public static function addNewIndex() {
        $sharedSettings = AdminCompo_cl::getSharedSettings($settingsModelId=0);
        $currencyCode = $sharedSettings['currency_code'];
        
        $conditionOperators = ShippingOptionsUtilBK_cl::getConditionOperators();
        
        include MainApp_cl::$compsPath.'checkout/backend/views/shipping_options/addNewIndex.php';
    }
    
    public static function saveAddNew($args) {
        // Sanitize inputs
        if (isset($args['title'])) {
            $args['title'] = sanitize_text_field($args['title']);
        }
        
        $response = ShippingOptionsModelBK_cl::addNew($args);
        
        if ($response->code == 1 && isset($response->res['insert_id'])) {
            // Handle any synchronization if needed
            // SheetControllerBk_cl::synchronizeShippingOptionsWithGoogleSheets($settingsModelId = 0);
            $response->res['redirect_to'] = admin_url('admin.php?page=cl_shipping_options&action=edit&option_id='.$response->res['insert_id']);
        }
        
        return $response;
    }
    
    public static function editIndex() {
        $optionId = isset($_GET['option_id']) ? intval($_GET['option_id']) : 0;
        if (!$optionId) {
            wp_die(Lang_cl::__('Invalid shipping option ID', 'cl'));
        }

        // Get shipping option for edit
        $response = ShippingOptionsModelBK_cl::getSingle($optionId);
        if ($response->code === 0) {
            wp_die($response->msg);
        }

        $shippingOption = $response->res;
        $conditionOperators = ShippingOptionsUtilBK_cl::getConditionOperators();
        
        $sharedSettings = AdminCompo_cl::getSharedSettings($settingsModelId=0);
        $currencyCode = $sharedSettings['currency_code'];
        
        include MainApp_cl::$compsPath.'checkout/backend/views/shipping_options/editIndex.php';
    }
    
    public static function saveUpdate($args) {
        $optionId = isset($args['id']) && $args['id'] > 0 ? $args['id'] : false;
        
        if (!$optionId) {
            return response_cl(0, Lang_cl::__('Invalid shipping option ID', 'cl'), null);
        }
        
        $response = ShippingOptionsModelBK_cl::update($optionId, $args);
        
        if ($response->code == 1 && isset($response->res['count_updated']) && $response->res['count_updated'] > 0) {
            // Handle any synchronization if needed
            // SheetControllerBk_cl::synchronizeShippingOptionsWithGoogleSheets($settingsModelId = 0);
        }
        
        return $response;
    }
   
    public static function listIndex() {
        $currentUrl = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
        $limit = isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 50;
        $shippingOptions = ShippingOptionsModelBK_cl::getAll($settingsModelId = 0, $limit = null);
        
        $sharedSettings = AdminCompo_cl::getSharedSettings($settingsModelId=0);
        
        include MainApp_cl::$compsPath.'checkout/backend/views/shipping_options/listIndex.php';
    }
    
    public static function deleteOption($args) {
        $response = ShippingOptionsModelBK_cl::delete($args['option_id']);
        
        if ($response->code == 1) {
            // $response->res['reload'] = 1;
        }

        return $response;
    }
}