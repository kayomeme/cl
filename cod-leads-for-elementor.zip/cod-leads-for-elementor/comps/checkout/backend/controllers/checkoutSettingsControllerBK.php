<?php

class CheckoutSettingsControllerBK_cl
{
    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'checkout';
        $tabName = isset($urlArgs['tab']) ? $urlArgs['tab'] : 'general';

        $sharedSettings = AdminCompo_cl::getSharedSettings($settingsModelId);
        $defaultSettings    = AdminCompo_cl::getDefaultSettings($compoName, $settings);
        
        $checkoutBlocksOrder = adminUtils_cl::getElementsOrder($defaultSettings['checkout_blocks_order'], $settings['checkout_blocks_order']);   
        $settings['checkout_blocks_order'] = implode(',', $checkoutBlocksOrder);
        
        /*$editorArgs = [
            'textarea_rows'  => 5,
            'teeny' => false,
            'quicktags' => true,
            'media_buttons' => true,
            'tinymce'       => [
                'directionality' => $sharedSettings['lang_dir'],
                'toolbar1'      => 'bullist,numlist,forecolor,bold,italic,underline,separator,alignleft,aligncenter,alignright,separator,link,unlink,undo,redo',
                'toolbar2'      => '',
                'toolbar3'      => '',
            ],
        ];*/
        
        $generatorSettings  = AdminCompo_cl::getStyleGenerator($compoName, $settings);
        $styleManager         = new StyleManagerBK_cl($defaultSettings, $settings, $generatorSettings);

        include AdminApp_cl::$viewsPath . 'global_settings/index.php';
    }
    public static function save_settings($compoName, $settingsModelId, $args)
    {
        $response = AdminCompo_cl::saveSettings($compoName, $settingsModelId, $args);


        $checkoutSharedSettings = self::getSharedSettings($args);
        AdminCompo_cl::saveSharedSettings($settingsModelId, $checkoutSharedSettings);
        
        if( $response ) {
            return $response;
        }
    }

    private static function getSharedSettings($args)
    {
        $sharedSettings = [];

        if (isset($args['summary_shipping_title'])) {
            $sharedSettings['shipping_fees'] = (int) preg_replace('/[^0-9]/', '', $args['summary_shipping_title']);
            $sharedSettings['shipping_title'] = $args['summary_shipping_title'];
        }

        if (isset($args['summary_shipping_label'])) {
            $sharedSettings['shipping_label'] = $args['summary_shipping_label'];
        }

        if (isset($args['thankyou_whatsapp_number'])) {
            $sharedSettings['thankyou_whatsapp_number'] = $args['thankyou_whatsapp_number'];
        }

        return $sharedSettings;
    }
}
