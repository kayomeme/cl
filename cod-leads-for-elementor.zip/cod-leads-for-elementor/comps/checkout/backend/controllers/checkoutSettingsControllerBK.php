<?php

class CheckoutSettingsControllerBK_clfe
{
    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'checkout';
        $tabName = isset($urlArgs['tab']) ? $urlArgs['tab'] : 'general';

        $sharedSettings = AdminCompo_clfe::getSharedSettings($settingsModelId);
        $defaultSettings    = AdminCompo_clfe::getDefaultSettings($compoName, $settings);
        
        $adminStyle         = new AdminStyle_clfe($defaultSettings);
        
        $checkoutBlocksOrder = adminUtils_clfe::getElementsOrder($defaultSettings['checkout_blocks_order'], $settings['checkout_blocks_order']);   
        $settings['checkout_blocks_order'] = implode(',', $checkoutBlocksOrder);
        
        $formFieldsOrder = adminUtils_clfe::getElementsOrder($defaultSettings['form_fields_order'], $settings['form_fields_order']);   
        $settings['form_fields_order'] = implode(',', $formFieldsOrder);
        
        $shippingOptions = jsonDecode_clfe($settings['shipping_options']);
        if( !isset($shippingOptions['elements']) || empty( $shippingOptions['elements'] ) ) {  
            $shippingOptions['elements'][] = [
                'title' => 'new block',
                'is_active' => 'yes',
                'is_open' => 'no',
                'content' => '',
            ];
        }
        
        $editorArgs = [
            'textarea_rows'  => 5,
            'teeny' => false,
            'quicktags' => true,
            'media_buttons' => true,
            'tinymce'       => [
                'directionality' => $sharedSettings['lang_dir'],
                'toolbar1'      => 'bullist,numlist,forecolor,bold,italic,underline,separator,alignleft,aligncenter,alignright,separator,link,unlink,undo,redo',
                'toolbar2'      => '',
                'toolbar3'      => '',
            ],
        ];

        include AdminApp_clfe::$viewsPath . 'global_settings/index.php';
    }
    public static function save_settings($compoName, $settingsModelId, $args)
    {
        $response = AdminCompo_clfe::saveSettings($compoName, $settingsModelId, $args);


        $checkoutSharedSettings = self::getSharedSettings($args);
        AdminCompo_clfe::saveSharedSettings($settingsModelId, $checkoutSharedSettings);
        
        if( $response ) {
            return $response;
        }
    }

    private static function getSharedSettings($args)
    {
        $sharedSettings = [];

        if (isset($args['summary_shipping_title'])) {
            $sharedSettings['shipping_fees'] = (int) preg_replace('/[^0-9]/', '', $args['summary_shipping_title']);
            $sharedSettings['shipping_title'] = $args['summary_shipping_title'];
        }

        if (isset($args['summary_shipping_label'])) {
            $sharedSettings['shipping_label'] = $args['summary_shipping_label'];
        }

        if (isset($args['thankyou_whatsapp_number'])) {
            $sharedSettings['thankyou_whatsapp_number'] = $args['thankyou_whatsapp_number'];
        }

        return $sharedSettings;
    }
}
