<?php

class CheckoutFieldsUtilBK_cl {

    public static function getFieldTypes() {
        return [
            'text' => Lang_cl::__('Text', 'cl'),
            'textarea' => Lang_cl::__('Textarea', 'cl'),
            'email' => Lang_cl::__('Email', 'cl'),
            'tel' => Lang_cl::__('Telephone', 'cl'),
            'number' => Lang_cl::__('Number', 'cl'),
            'select' => Lang_cl::__('Select Dropdown', 'cl'),
            'radio' => Lang_cl::__('Radio Buttons', 'cl'),
            'checkbox' => Lang_cl::__('Checkbox', 'cl'),
            'date' => Lang_cl::__('Date', 'cl')
        ];
    }

    public static function getConditionOperators() {
        return [
            '==' => Lang_cl::__('Equals (==)', 'cl'),
            '===' => Lang_cl::__('Strict Equals (===)', 'cl'),
            '!=' => Lang_cl::__('Not Equals (!=)', 'cl'),
            '!==' => Lang_cl::__('Strict Not Equals (!==)', 'cl'),
            '>' => Lang_cl::__('Greater Than (>)', 'cl'),
            '<' => Lang_cl::__('Less Than (<)', 'cl'),
            '>=' => Lang_cl::__('Greater Than or Equal (>=)', 'cl'),
            '<=' => Lang_cl::__('Less Than or Equal (<=)', 'cl'),
            'in' => Lang_cl::__('In (separated values by ,)', 'cl'),
            'contains' => Lang_cl::__('Contains separated values by ,', 'cl')
        ];
    }

    public static function getIcons() {
        return [
            'user' => Lang_cl::__('User', 'cl'),
            'envelope' => Lang_cl::__('Envelope', 'cl'),
            'phone' => Lang_cl::__('Phone', 'cl'),
            'map-marker' => Lang_cl::__('Map Marker', 'cl'),
            'home' => Lang_cl::__('Home', 'cl'),
            'building' => Lang_cl::__('Building', 'cl'),
            'comment' => Lang_cl::__('Comment', 'cl'),
            'calendar' => Lang_cl::__('Calendar', 'cl'),
            'credit-card' => Lang_cl::__('Credit Card', 'cl'),
            'truck' => Lang_cl::__('Truck', 'cl')
        ];
    }
}