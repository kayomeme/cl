<?php

class ShippingOptionsUtilBK_cl {

    public static function getConditionOperators() {
        return [
            '==' => Lang_cl::__('Equals (==)', 'cl'),
            '===' => Lang_cl::__('Strict Equals (===)', 'cl'),
            '!=' => Lang_cl::__('Not Equals (!=)', 'cl'),
            '!==' => Lang_cl::__('Strict Not Equals (!==)', 'cl'),
            '>' => Lang_cl::__('Greater Than (>)', 'cl'),
            '<' => Lang_cl::__('Less Than (<)', 'cl'),
            '>=' => Lang_cl::__('Greater Than or Equal (>=)', 'cl'),
            '<=' => Lang_cl::__('Less Than or Equal (<=)', 'cl'),
            'in' => Lang_cl::__('In (separated values by ,)', 'cl'),
            'contains' => Lang_cl::__('Contains separated values by ,', 'cl')
        ];
    }
}
