<?php
/*if( !IsInCurrentPages(['cl_checkout_fields']) ) {
    return;
}*/

if (IsInCurrentPages(['cl_checkout_fields']) && !isset($_REQUEST['action'])) {
    wp_enqueue_style('checkout_fields_list_css', MainApp_cl::$compsUrl.'checkout/backend/assets/css/checkout_fields_list_bk.css', [], $assetsVersion);
    wp_enqueue_script('checkout_fields_list_js', MainApp_cl::$compsUrl.'checkout/backend/assets/js/checkout_fields_list_bk.js', [], $assetsVersion);
}

if (IsInCurrentPages(['cl_checkout_fields']) && isset($_REQUEST['action']) && ($_REQUEST['action'] == 'edit' || $_REQUEST['action'] == 'addnew')) {
    wp_enqueue_style('checkout_fields_edit_css', MainApp_cl::$compsUrl.'checkout/backend/assets/css/checkout_fields_edit_addnew_bk.css', [], $assetsVersion);
    wp_enqueue_script('checkout_fields_edit_js', MainApp_cl::$compsUrl.'checkout/backend/assets/js/checkout_fields_edit_addnew_bk.js', [], $assetsVersion);
}


if( isset($_REQUEST['page']) && $_REQUEST['page'] == 'cl_global_settings' && isset($_REQUEST['compo']) && $_REQUEST['compo'] == 'checkout' ) {
    wp_enqueue_script( MainApp_cl::$assetsPrefix.$hook['compName'], MainApp_cl::$compsUrl. 'checkout/backend/assets/js/checkout_bk.js', [], $assetsVersion );

}

// shipping options

if (IsInCurrentPages(['cl_shipping_options']) && !isset($_REQUEST['action'])) {
    wp_enqueue_style('shipping_options_list_css', MainApp_cl::$compsUrl.'checkout/backend/assets/css/shipping_options_list_bk.css', [], $assetsVersion);
    wp_enqueue_script('shipping_options_list_js', MainApp_cl::$compsUrl.'checkout/backend/assets/js/shipping_options_list_bk.js', [], $assetsVersion);
}

if (IsInCurrentPages(['cl_shipping_options']) && isset($_REQUEST['action']) && ($_REQUEST['action'] == 'edit' || $_REQUEST['action'] == 'addnew')) {
    wp_enqueue_style('shipping_options_edit_css', MainApp_cl::$compsUrl.'checkout/backend/assets/css/shipping_options_edit_addnew_bk.css', [], $assetsVersion);
    wp_enqueue_script('shipping_options_edit_js', MainApp_cl::$compsUrl.'checkout/backend/assets/js/shipping_options_edit_addnew_bk.js', [], $assetsVersion);
}