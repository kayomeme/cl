(function ($) {
    'use strict';
    $(document).ready(function () {

        const operatorsWithInfo = ['in', 'contains'];
        $('select[name="condition_operator"]').on('change', function() {
            const selectedValue = $(this).val();

            if (operatorsWithInfo.includes(selectedValue)) {
                $('#condition_value_info').removeClass('cl-hide');
            } else {
                $('#condition_value_info').addClass('cl-hide');
            }
        });
        $('select[name="condition_operator"]').change();
        
        // Handle update checkout field submission
        $('#save-update-checkout-field').on('click', function (ev) {
            ev.preventDefault();
            
            const cl_controller = 'cl_checkout_fields';
            const cl_action = 'cl_update_checkout_field';
            const formData = AdminFn_cl.getFormDatas(cl_action);
            AdminFn_cl.beforeSendAjaxRequest(cl_action);
            AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formData);
            
            // Wait for the custom event before accessing the modified variable
            document.addEventListener(cl_action + 'lastResponse', function (event) {
                console.log(jsArgs.lastResponse);
                if (jsArgs.lastResponse.code == 1) {
                    // Handle successful update if needed
                }
            });
        });
        
        // Handle add new checkout field submission
        $('#save-new-checkout-field').on('click', function (ev) {
            ev.preventDefault();
            
            const cl_controller = 'cl_checkout_fields';
            const cl_action = 'cl_addnew_checkout_field';
            const formData = AdminFn_cl.getFormDatas(cl_action);
            AdminFn_cl.beforeSendAjaxRequest(cl_action);
            AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formData);
            
            // Wait for the custom event before accessing the modified variable
            document.addEventListener(cl_action + 'lastResponse', function (event) {
                console.log(jsArgs.lastResponse);
                if (jsArgs.lastResponse.code == 1) {
                    // Handle successful addition if needed
                    if (jsArgs.lastResponse.res.redirect_to) {
                        window.location.href = jsArgs.lastResponse.res.redirect_to;
                    }
                }
            });
        });

    });
})(jQuery);