(function ($) {
    'use strict';
    $(document).ready(function () {
        
        $('.save-delete-checkout-field').on('click', function (ev) {
            ev.preventDefault();
            if( confirm(jsLang.delete_confirm_msg) == true ) {   
                $("input[name=field_id]").val( $(this).attr('field_id') );
                const cl_controller = 'cl_checkout_fields';
                const cl_action = 'cl_delete_checkout_field';
                const formData = AdminFn_cl.getFormDatas(cl_action);
                AdminFn_cl.beforeSendAjaxRequest(cl_action);
                AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formData);
                
                // Wait for the custom event before accessing the modified variable
                document.addEventListener(cl_action + 'lastResponse', function (event) {
                    if (jsArgs.lastResponse.code == 1) {
                        const fieldId = $("input[name=field_id]").val();
                        const fieldElement = $('#field-' + fieldId);
                        fieldElement.css('background-color', '#ffebee').animate({opacity: 0}, 600, function() {
                            $(this).slideUp(200, function() {
                                $(this).remove();
                            });
                        });
                    }
                });
            }
        });
        
    });
})(jQuery);