(function( $ ) {
	'use strict';

        $(document).ready( function () {

            // dragable elemnts
            $("#cl-checkout-elements").sortable({
                update: function( event, ui ) {
                    var fieldsFileName = $('#cl-checkout-elements div').map(function () { return $(this).attr("_attachedsection"); });
                    $("input[name=checkout_blocks_order]").val(fieldsFileName.toArray());
                    $("input[name=checkout_blocks_order]").change();
                    
                    AdminFn_cl.autoSaveSettings();
                }
            });

        } );

})( jQuery );