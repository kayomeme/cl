(function( $ ) {
	'use strict';

        $(document).ready( function () {

            // dragable elemnts
            $(".clfe_form_fields_elements").sortable({
                update: function( event, ui ) {
                    var fieldsFileName = $('.clfe_form_fields_elements fieldset').map(function () { return $(this).attr("_attachedsection"); });
                    $("input[name=form_fields_order]").val(fieldsFileName.toArray());
                    $("input[name=form_fields_order]").change();
                    
                    AdminFn_clfe.autoSaveSettings();
                }
            });
            
            $("#clfe-checkout-elements").sortable({
                update: function( event, ui ) {
                    var fieldsFileName = $('#clfe-checkout-elements div').map(function () { return $(this).attr("_attachedsection"); });
                    $("input[name=checkout_blocks_order]").val(fieldsFileName.toArray());
                    $("input[name=checkout_blocks_order]").change();
                    
                    AdminFn_clfe.autoSaveSettings();
                }
            });

            /*document.getElementById('sidbar-toggle-product-list').addEventListener('click', function() {
                var productItems = document.getElementById('sidbar-product-items');
                if (productItems.style.display === 'none') {
                    productItems.style.display = 'block';
                } else {
                    productItems.style.display = 'none';
                }
            });

            $("#sidbar-product-items button").on('click', function() {
                $("#sidbar-product-items").show();
            });*/

        } );

})( jQuery );