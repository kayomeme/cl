(function ($) {
    'use strict';
    $(document).ready(function () {

        const operatorsWithInfo = ['in', 'contains'];
        $('select[name="condition_operator"]').on('change', function() {
            const selectedValue = $(this).val();

            if (operatorsWithInfo.includes(selectedValue)) {
                $('#condition_value_info').removeClass('cl-hide');
            } else {
                $('#condition_value_info').addClass('cl-hide');
            }
        });
        $('select[name="condition_operator"]').change();

        
        // Handle update shipping option submission
        $('#save-update-shipping-option').on('click', function (ev) {
            ev.preventDefault();
            const cl_controller = 'cl_shipping_options';
            const cl_action = 'cl_update_shipping_option';
            const formData = AdminFn_cl.getFormDatas(cl_action);
            AdminFn_cl.beforeSendAjaxRequest(cl_action);
            AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formData);
            
            // Wait for the custom event before accessing the modified variable
            document.addEventListener(cl_action + 'lastResponse', function (event) {
                if (jsArgs.lastResponse.code == 1) {
                    // Handle successful update if needed
                }
            });
        });
        
        // Handle add new shipping option submission
        $('#save-new-shipping-option').on('click', function (ev) {
            ev.preventDefault();
            const cl_controller = 'cl_shipping_options';
            const cl_action = 'cl_addnew_shipping_option';
            const formData = AdminFn_cl.getFormDatas(cl_action);
            AdminFn_cl.beforeSendAjaxRequest(cl_action);
            AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formData);
            
            // Wait for the custom event before accessing the modified variable
            document.addEventListener(cl_action + 'lastResponse', function (event) {
                console.log(jsArgs.lastResponse);
                if (jsArgs.lastResponse.code == 1) {
                    // Handle successful addition if needed
                }
            });
        });
        
        // Handle shipping option deletion
        $('.save-delete-shipping-option').on('click', function (ev) {
            ev.preventDefault();
            if (confirm(jsLang.delete_confirm_msg) == true) {
                $("input[name=option_id]").val($(this).attr('option_id'));
                const cl_controller = 'cl_shipping_options';
                const cl_action = 'cl_delete_shipping_option';
                const formData = AdminFn_cl.getFormDatas(cl_action);
                AdminFn_cl.beforeSendAjaxRequest(cl_action);
                AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formData);
                
                // Wait for the custom event before accessing the modified variable
                document.addEventListener(cl_action + 'lastResponse', function (event) {
                    console.log(jsArgs.lastResponse);
                    if (jsArgs.lastResponse.code == 1) {
                        // Remove the deleted option from the DOM
                        $('#option-' + $(this).attr('option_id')).remove();
                    }
                });
            }
        });
    });
})(jQuery);

document.addEventListener('DOMContentLoaded', function () {
    // Handle media uploads
    const mediaButtons = document.querySelectorAll('.select-media');
    const removeButtons = document.querySelectorAll('.remove-media');
    
    if (typeof wp !== 'undefined' && wp.media) {
        mediaButtons.forEach(button => {
            button.addEventListener('click', function() {
                const uploadDiv = this.closest('.cl-media-upload');
                const target = uploadDiv.getAttribute('data-target');
                const idInput = uploadDiv.querySelector(`input[name=${target}_id]`);
                const urlInput = uploadDiv.querySelector(`input[name=${target}_url]`);
                const preview = uploadDiv.querySelector('.cl-media-preview');
                const removeBtn = uploadDiv.querySelector('.remove-media');
                
                const mediaUploader = wp.media({
                    title: 'Select Image',
                    button: {
                        text: 'Use this image'
                    },
                    multiple: false
                });
                
                mediaUploader.on('select', function() {
                    const attachment = mediaUploader.state().get('selection').first().toJSON();
                    idInput.value = attachment.id;
                    urlInput.value = attachment.url;
                    
                    // Update preview
                    preview.innerHTML = `<img src="${attachment.url}" alt="Preview">`;
                    removeBtn.style.display = 'inline-block';
                });
                
                mediaUploader.open();
            });
        });
        
        removeButtons.forEach(button => {
            button.addEventListener('click', function() {
                const uploadDiv = this.closest('.cl-media-upload');
                const target = uploadDiv.getAttribute('data-target');
                const idInput = uploadDiv.querySelector(`input[name=${target}_id]`);
                const urlInput = uploadDiv.querySelector(`input[name=${target}_url]`);
                const preview = uploadDiv.querySelector('.cl-media-preview');
                
                // Clear values
                idInput.value = '';
                urlInput.value = '';
                preview.innerHTML = '';
                this.style.display = 'none';
            });
        });
    }
    
});