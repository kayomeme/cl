(function ($) {
    'use strict';
    $(document).ready(function () {
        
        $('.save-delete-shipping-option').on('click', function (ev) {
            ev.preventDefault();
            if( confirm(jsLang.delete_confirm_msg) == true ) {   
                $("input[name=option_id]").val( $(this).attr('option_id') );
                const cl_controller = 'cl_shipping_options';
                const cl_action = 'cl_delete_shipping_option';
                const formData = AdminFn_cl.getFormDatas(cl_action);
                AdminFn_cl.beforeSendAjaxRequest(cl_action);
                AdminFn_cl.sendAjaxRequest(cl_controller, cl_action, formData);
                // Wait for the custom event before accessing the modified variable
                document.addEventListener(cl_action + 'lastResponse', function (event) {
                    if (jsArgs.lastResponse.code == 1) {
                        const optionId = $("input[name=option_id]").val();
                        const optionElement = $('#option-' + optionId);
                        optionElement.css('background-color', '#ffebee').animate({opacity: 0}, 600, function() {
                            $(this).slideUp(200, function() {
                                $(this).remove();
                            });
                        });
                    }
                });
            }
        });
        
    });
})(jQuery);