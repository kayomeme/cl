<?php
class ShippingOptionsModelBK_cl {
    private static $tableName = 'shipping_options';
    
    private static $tableColumns = [
        'id', 'is_active', 'title', 'subtitle', 'badge_text', 'condition_variable', 
        'condition_operator', 'condition_value', 'cost_value', 'cost_label', 
        'thumbnail_id', 'thumbnail_url', 'bg_id', 'bg_url', 'position', 
        'settings_model_id', 'date_created_gmt', 'date_updated_gmt'
    ];
    
    private static $requiredColumns = [
        'title'
    ];
    
    public static function getAll($settingsModelId, $limit = null) {
        if( !$limit ) {
          $limit = 100;  
        }
        $query = "SELECT * FROM table_name WHERE settings_model_id = {$settingsModelId} ORDER BY position ASC LIMIT {$limit}";
        $result = adminDB_cl::getResultsAsObjects(self::$tableName, $query);
        return $result;
    }

    
    public static function addNew($args) {
        foreach (self::$requiredColumns as $fieldName) {
            if (!isset($args[$fieldName]) || empty($args[$fieldName])) {
                return response_cl(0, Lang_cl::__($fieldName, 'cl').Lang_cl::__(' is required', 'cl'), null);
            }
        }
        
        $dataToAdd = [];
        foreach (self::$tableColumns as $fieldName) {
            if (isset($args[$fieldName])) {
                $dataToAdd[$fieldName] = $args[$fieldName];
            }
        }
        
        // Set default values if not provided
        if (!isset($dataToAdd['is_active'])) {
            $dataToAdd['is_active'] = 'yes';
        }
        
        if (!isset($dataToAdd['position'])) {
            // Get the highest position and add 1
            $highestPosition = adminDB_cl::getVar(self::$tableName, 'MAX(position)');
            $dataToAdd['position'] = $highestPosition ? $highestPosition + 1 : 1;
        }
        
        if (!isset($dataToAdd['date_created_gmt'])) {
            $dataToAdd['date_created_gmt'] = current_time('mysql', true);
        }
        
        $response = adminDB_cl::insert(self::$tableName, $dataToAdd);
        return $response;
    }
    
    public static function getSingle($id) {
        $response = adminDB_cl::getSingleById(self::$tableName, $id);
        return $response;
    }
    
    public static function update($optionId, $args) {
        $dataToUpdate = [];
        
        foreach (self::$tableColumns as $fieldName) {
            if (isset($args[$fieldName])) {
                $dataToUpdate[$fieldName] = $args[$fieldName];
            }
        }
        
        // Always update the modified timestamp
        $dataToUpdate['date_updated_gmt'] = current_time('mysql', true);
        
        $where = [
            'id' => $optionId,
        ];
        
        $response = adminDB_cl::update(self::$tableName, $dataToUpdate, $where);
        return $response;
    }
    
    public static function delete($optionId) {
        $where = [
            'id' => $optionId
        ];
        return adminDB_cl::delete(self::$tableName, $where);
    }
   
}