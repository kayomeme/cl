<?php

/**
 * general
 */
return array(
    'setting' => [
        'active_blocks' => 'form,shipping_options,submit_button,summary,checkout_custom_block1,checkout_custom_block2',
        'checkout_blocks_order' => 'form,shipping_options,submit_button,summary,checkout_custom_block1,checkout_custom_block2',
        'checkout_modal_bg_transparency_color' => '255,255,255',
        'checkout_modal_bg_transparency_level' => '99',
        'checkout_modal_header_close_bt_is_active' => 'yes',
        'error_placement' => 'before_submit_button',
        'error_wait_icon_is_active' => 'yes',
    ],
    'lang' => [
        'error_wait_text' => 'Votre demande est encore de traitement ...',
        'error_variation_not_selected' => 'ff',
        'checkout_modal_footer_text_close' => 'Close',
    ],
    'style' => [
        'checkout_container_style' => 'border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:#333333;border-style:solid;border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;background-image:linear-gradient(0deg,#ffffff,#ffffff);box-shadow:0px 0px 0px 0;',
        'error_msg_style' => 'font-size:14px;color:#f10909;font-weight:700;text-align:center;border-top-width:px;border-right-width:px;border-bottom-width:px;border-left-width:px;border-color:;border-style:solid;border-top-left-radius:px;border-top-right-radius:px;border-bottom-left-radius:px;border-bottom-right-radius:px;',
        'error_wait_text_style' => 'font-size:14px;color:#06891c;font-weight:700;text-align:center;',
        'checkout_modal_header_close_bt_style' => '',
        'checkout_modal_footer_text_close_style' => 'font-size:13px;color:#282424;font-weight:700;text-align:right;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-color:#000000;border-style:solid;border-top-left-radius:1px;border-top-right-radius:1px;border-bottom-left-radius:1px;border-bottom-right-radius:1px;padding-top:1px;padding-right:5px;padding-bottom:1px;padding-left:5px;',
    ]
);
