<?php

/**
 * general
 */
return array(
    'setting' => [
        'active_blocks' => 'form,shipping_options,submit_button,summary,checkout_custom_block1,checkout_custom_block2,checkout_modal',
        'checkout_blocks_order' => 'form,shipping_options,submit_button,summary,checkout_custom_block1,checkout_custom_block2',
        'error_placement' => 'before_submit_button',
        'error_wait_icon_is_active' => 'yes',
    ],
    'lang' => [
        'error_wait_text' => 'Votre demande est encore de traitement ...',
        'error_variation_not_selected' => 'ff',
        
    ],
    'style' => [
        'error_msg_style' => 'font-size:14px;color:#f10909;font-weight:700;text-align:center;border-top-width:px;border-right-width:px;border-bottom-width:px;border-left-width:px;border-color:;border-style:solid;border-top-left-radius:px;border-top-right-radius:px;border-bottom-left-radius:px;border-bottom-right-radius:px;',
        'error_wait_text_style' => 'font-size:14px;color:#06891c;font-weight:700;text-align:center;',
          ]
);
