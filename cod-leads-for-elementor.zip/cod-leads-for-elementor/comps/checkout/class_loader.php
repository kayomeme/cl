<?php
$dirPath = plugin_dir_path( __FILE__ );

if( $isAdminAria ) {    
    require_once $dirPath  . 'backend/controllers/checkoutFieldsControllerBK.php';
    if( IsInCurrentPages(['cl_checkout_fields']) ) {
        require_once $dirPath  . 'backend/models/checkoutFieldsModelBK.php';
        require_once $dirPath  . 'backend/class/checkoutFieldsUtilBK.php';
    }
    require_once $dirPath.'backend/controllers/checkoutSettingsControllerBK.php';
    
    // shipping option
    require_once $dirPath  . 'backend/controllers/shippingOptionsControllerBK.php';
    if( IsInCurrentPages(['cl_shipping_options']) ) {
        require_once $dirPath  . 'backend/models/shippingOptionsModelBK.php';
        require_once $dirPath  . 'backend/class/shippingOptionsUtilBK.php';
    }
}

if($isPublicAria) {
    require_once $dirPath  . 'frontend/controllers/checkoutControllerFR.php';
    require_once $dirPath  . 'frontend/models/checkoutFieldsModelFR.php';
    
    require_once $dirPath  . 'frontend/models/shippingOptionsModelFR.php';
}
