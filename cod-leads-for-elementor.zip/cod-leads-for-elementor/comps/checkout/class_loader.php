<?php
$dirPath = plugin_dir_path( __FILE__ );

if( $isAdminAria ) {    
    
    require_once $dirPath.'backend/controllers/checkoutSettingsControllerBK.php';
}

if($isPublicAria) {
    require_once $dirPath  . 'frontend/controllers/checkoutControllerFR.php';
}
