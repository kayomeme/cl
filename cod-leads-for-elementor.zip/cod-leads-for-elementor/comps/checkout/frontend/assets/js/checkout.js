(function ($) {
    //'use strict';

    checkout_clfe = {
        init: function (jsCheckout) {
            console.log(jsCheckout);
            //this.shippingOptions = JSON.parse(jsCheckout.shipping_options);
            this.shippingOptions = jsCheckout.shipping_options;
            
            console.log(this.shippingOptions);

            // set the default value from the order summary settings
            this.selectedShippingOption = {
                cost_value: jsCheckout.shipping_fees,
                cost_label: jsCheckout.shipping_label,
                title: jsCheckout.shipping_title
            };
            // Load checkout data when page loads
            checkout_clfe.loadCheckoutData();
        },
        shippingOptions: {},
        selectedShippingOption: {},
        checkoutData: {
            fields: {},
            shippingOptionId: 0
        },
        loadCheckoutData: function () {
            let storedData = localStorage.getItem('clfe_checkout_data');
            if (storedData) {
                this.checkoutData = JSON.parse(storedData);
                this.fillCheckoutFields();
                this.applyStoredShippingOption();
            }
        },

        saveCheckoutData: function () {
            this.collectCheckoutFields();
            localStorage.setItem('clfe_checkout_data', JSON.stringify(this.checkoutData));

            this.updateSummary();
        },

        collectCheckoutFields: function () {
            const container = $(".clfe-checkout-sections");
            const formInputs = container.find("input, select");

            formInputs.each((index, element) => {
                const $element = $(element);
                const name = $element.attr('name');
                const value = $element.val();
                if (name) {
                    this.checkoutData.fields[name] = value;
                }
            });
        },

        fillCheckoutFields: function () {
            const container = $(".clfe-checkout-sections");
            const formInputs = container.find("input, select");

            formInputs.each((index, element) => {
                const $element = $(element);
                const name = $element.attr('name');
                if (name && this.checkoutData.fields[name]) {
                    $element.val(this.checkoutData.fields[name]);
                }
            });
        },

        saveShippingOption: function (optionId) {
            //const option = Object.entries(this.shippingOptions)[optionId][1];
            this.checkoutData.shippingOptionId = parseInt(optionId);
            this.selectedShippingOption = this.shippingOptions[optionId];
            
            console.log(this.selectedShippingOption);
            
            this.saveCheckoutData();
        },

        applyStoredShippingOption: function () {
            const optionId = this.checkoutData.shippingOptionId;
            if (optionId) {
                // For button-based selection
                $(".clfe-shipping-option").removeClass("is-selected-shipping-option");
                $(`.clfe-shipping-option[option_id="${optionId}"]`).addClass("is-selected-shipping-option").find(".clfe-shipping-option-radio-bt").prop("checked", true);

                // For select-based selection
                $("select.clfe-shipping-options-selectbox").find("option[option_id='" + optionId + "']").attr('selected', 'selected');
            }
        },

        existFormErrors() {
            const container = $(".clfe-checkout-sections");
            const formInputs = container.find(".form-create-order input");

            container.find(".clfe-wait-box").show();
            container.find(".clfe-before-button, .clfe-after-button").html('');
            container.find(".clfe-input-error").hide();
            formInputs.removeClass('clfe-error-border').attr('title', '');

            let existErrorField = false;
            let errorsBeforeBT = "";
            let errorsAfterBT = "";
            let errorsCheckoutModal = "";

            container.find("input[isrequired=yes]").each(function () {
                const $input = $(this);
                const inputValue = $input.val();
                const inputMinLength = parseInt($input.attr('minchars'));
                const inputMaxLength = parseInt($input.attr('maxchars'));

                if (inputValue.length < inputMinLength || inputValue.length > inputMaxLength) {
                    existErrorField = true;
                    const inputName = $input.attr('name');
                    const errorMsg = $input.attr('errormsg');
                    const $inputContainer = $(`.form-${inputName}-container`);

                    $inputContainer.find('input').addClass("clfe-error-border").attr("title", errorMsg);

                    if (inputName === 'phone') {
                        $inputContainer.find('input').focus();
                    }

                    switch (jsCheckout.error_placement) {
                        case 'after_every_field':
                            $inputContainer.find('.clfe-input-error').text(errorMsg).show("slow");
                            break;
                        case 'before_submit_button':
                            errorsBeforeBT += `<span class="error-element error-${inputName}">${errorMsg}</span>`;
                            break;
                        case 'after_submit_button':
                            errorsAfterBT += `<span class="error-element error-${inputName}">${errorMsg}</span>`;
                            break;
                        case 'show_in_popup':
                            errorsCheckoutModal += `<span class="error-element error-${inputName}">${errorMsg}</span>`;
                            break;
                    }
                }
            });

            const errorsMsg = errorsBeforeBT + errorsAfterBT;

            if (existErrorField || errorsMsg.length > 5) {
                container.find(".clfe-wait-box").hide();
                container.find(".clfe-client-response").html(errorsMsg);
            }

            return existErrorField;
        },

        updateSummary() {
            let totalCart = 0;
            let totalDiscount = 0;
            let totalExtraFees = 0;
            
            cart_clfe.products.forEach(product => {
                const qty = Number(product.qty) || 1;
                
                totalDiscount += product.discount_per_product * qty;
                totalCart += product.regular_price * qty;

                if (Array.isArray(product.variations)) {
                    product.variations.forEach(productV => {
                        productV.forEach(productV2 => {
                            const extraFees = parseFloat(productV2.fees);
                            totalExtraFees += extraFees;
                        });
                    });
                }
            });

            order_clfe.total_amount = totalCart + totalExtraFees - totalDiscount;
            order_clfe.total_discount = totalDiscount;

            const formData = FrontendFn_clfe.getFormDatas(".clfe-checkout-sections");
            formData['total'] = order_clfe.total_amount;

            let shippingCost = parseFloat(jsCheckout.shipping_fees);
            let shippingTitle = '<a href="#clfe_shipping_options">' + jsCheckout.summary_shipping_default_text + '</a>';


            if (this.shippingOptions && typeof this.shippingOptions === 'object') {
                Object.values(this.shippingOptions).forEach((option, index) => {
                    if (option.is_active === 'yes') {
                        const $shippingOption = $(".clfe-shipping-option:nth-child(" + (index + 1) + ")");
                        const fieldNameWithSameConditionVarName = formData[option.condition_variable];
                        var metCondition = true;

                        if (FrontendFn_clfe.isset(fieldNameWithSameConditionVarName)) {
                            if (FrontendFn_clfe.evaluateCondition(fieldNameWithSameConditionVarName, option)) {
                                $shippingOption.removeClass("clfe-hide");
                            } else {
                                metCondition = false;

                                if ($shippingOption.hasClass('has-condition-variable')) {
                                    $shippingOption.addClass("clfe-hide");
                                    $shippingOption.removeClass("is-selected-shipping-option");
                                }
                            }
                        }

                        if (this.checkoutData.shippingOptionId === index && metCondition) {
                            shippingCost = parseFloat(option.cost_value);
                            shippingTitle = `${option.title} ${option.cost_label}`;
                        }

                    }
                });
            }

            order_clfe.total_amount = order_clfe.total_amount + shippingCost;
            $(".clfe-total-value").text(order_clfe.total_amount);
            $(".clfe-product-discount .p_discount_value").text(totalDiscount);
            $(".shipping-fees .key-price").html(shippingTitle);
        },

        handleShippingOptionSelectionButton: function (element) {
            $(".clfe-shipping-option").removeClass("is-selected-shipping-option");
            element.addClass("is-selected-shipping-option").find(".clfe-shipping-option-radio-bt").prop("checked", true);

            this.saveShippingOption(element.attr('option_id'));

            console.log('im in the shipping function');
        },

        handleShippingOptionSelectionSelect: function (element) {
            const selectedOption = element.find(":selected");

            $(".clfe-shipping-option").removeClass("is-selected-shipping-option");
            selectedOption.addClass("is-selected-shipping-option");

            this.saveShippingOption(selectedOption.attr('option_id'));
        }
    };

    order_clfe = {
        order_id: 0,
        total_amount: 0,
        total_discount:0,

        /*
         * dont use this
         */
        onSuccessAddOrder: function (response) {
            const result = response.res;
            
            // Order was successful, clear the cart
            cart_clfe.clearCart();

            if (FrontendFn_clfe.isset(result['thankyou_page_url'])) {
                window.location.href = `${result['thankyou_page_url']}`;
                return;
            }
            cart_clfe.updateCartDisplay();
        },
        onErrorAddOrder: function (response) {
            const error = `<div class="clfe-error-response">${response.msg}</div>`;
            $(".clfe-client-response").html(error);
            return;
        },
        addNewOrder: function () {
            //var formData = $( 'form[name="form-create-order"]' ).serializeArray();
            var containerData = ".form-create-order";
            var formData = FrontendFn_clfe.getFormDatas(containerData);

            formData['thankyou_page_id'] = parseInt(jsSalesFunnel.thankyou_page_id);
            formData['sales_funnel_mode'] = parseInt(jsSalesFunnel.mode);

            formData['cart_products'] = JSON.stringify(cart_clfe.products);
            formData['total_amount'] = order_clfe.total_amount;
            formData['total_discount'] = order_clfe.total_discount;

            //formData['shipping'] = JSON.stringify(checkout_clfe.selectedShippingOption);
            
            formData['shipping_id'] = checkout_clfe.checkoutData.shippingOptionId + 1;
            formData['shipping_fees'] = checkout_clfe.selectedShippingOption.cost_value;
            formData['shipping_label'] = checkout_clfe.selectedShippingOption.cost_label;
            formData['shipping_title'] = checkout_clfe.selectedShippingOption.title;
            
            formData['currency'] = jsMystore.currency_code;
            formData['currency_code'] = jsMystore.currency_code;
            formData['currency_label'] = jsMystore.currency_label;
            
            formData['status'] = jsCheckout.default_status;

            formData['clfe_ajax_nonce'] = clfe_ajax_nonce;

            // this line resolve the erreur that return 0
            formData['action'] = jsArgs.ajax_public_action;
            formData['clfe_action_name'] = 'add_new_order';

            FrontendFn_clfe.sendAjaxRequest(formData, this.onSuccessAddOrder, this.onErrorAddOrder);
        }
    };

    $(document).ready(function () {
        checkout_clfe.init(jsCheckout);
        cart_clfe.updateCartDisplay();
        checkout_clfe.updateSummary();

        // Save checkout data when input fields change
        $(".clfe-checkout-sections input, .clfe-checkout-sections select").on('change', function () {
            checkout_clfe.saveCheckoutData();
        });

        // shipping options : display blocks / select box
        $(".clfe-shipping-option").first().click();
        $(".clfe-shipping-option").on('click', function () {
            console.log('im click the shipign option');
            checkout_clfe.handleShippingOptionSelectionButton($(this));
        });
        $("select.clfe-shipping-options-selectbox").on('change', function () {
            checkout_clfe.handleShippingOptionSelectionSelect($(this));
        });



        $('#clfe-submit-bt').on('click', function (ev) {
            ev.preventDefault();

            $('#clfe-submit-bt').prop('disabled', true);
            if (!checkout_clfe.existFormErrors()) {
                order_clfe.addNewOrder();
            }
            $('#clfe-submit-bt').prop('disabled', false);

            // This return prevents the submit event to refresh the page.
            return false;
        });




    });

})(jQuery);