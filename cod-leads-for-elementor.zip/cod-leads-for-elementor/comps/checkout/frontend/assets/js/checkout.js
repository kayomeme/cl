(function ($) {
    //'use strict';

    checkout_cl = {
        init: function (jsCheckout) {
            //this.shippingOptions = JSON.parse(jsCheckout.shipping_options);
            this.shippingOptions = jsCheckout.shipping_options;

            // set the default value from the order summary settings
            this.selectedShippingOption = {
                cost_value: jsCheckout.shipping_fees,
                cost_label: jsCheckout.shipping_label,
                title: jsCheckout.shipping_title
            };
            // Load checkout data when page loads
            checkout_cl.loadCheckoutData();
        },
        shippingOptions: {},
        selectedShippingOption: {},
        checkoutData: {
            fields: {},
            shippingOptionId: 0
        },
        loadCheckoutData: function () {
            let storedData = localStorage.getItem('cl_checkout_data');
            if (storedData) {
                this.checkoutData = JSON.parse(storedData);
                this.fillCheckoutFields();
                this.applyStoredShippingOption();
            }
        },

        saveCheckoutData: function () {
            this.collectCheckoutFields();
            localStorage.setItem('cl_checkout_data', JSON.stringify(this.checkoutData));

            this.updateSummary();
        },

        collectCheckoutFields: function () {
            const container = $(".cl-checkout-sections");
            const formInputs = container.find("input, select");

            formInputs.each((index, element) => {
                const $element = $(element);
                const name = $element.attr('name');
                const value = $element.val();
                if (name) {
                    this.checkoutData.fields[name] = value;
                }
            });
        },

        fillCheckoutFields: function () {
            const container = $(".cl-checkout-sections");
            const formInputs = container.find("input, select");

            formInputs.each((index, element) => {
                const $element = $(element);
                const name = $element.attr('name');
                if (name && this.checkoutData.fields[name]) {
                    $element.val(this.checkoutData.fields[name]);
                }
            });
        },

        saveShippingOption: function (optionId) {
            //const option = Object.entries(this.shippingOptions)[optionId][1];
            this.checkoutData.shippingOptionId = parseInt(optionId);
            this.selectedShippingOption = this.shippingOptions[optionId];
            
            this.saveCheckoutData();
        },

        applyStoredShippingOption: function () {
            const optionId = this.checkoutData.shippingOptionId;
            if (optionId) {
                // For button-based selection
                $(".shipping-option").removeClass("is-selected-shipping-option");
                $(`.shipping-option[option_id="${optionId}"]`).addClass("is-selected-shipping-option").find(".shipping-option-radio-bt").prop("checked", true);

                // For select-based selection
                $("select.shipping-options-selectbox").find("option[option_id='" + optionId + "']").attr('selected', 'selected');
            }
        },

        existFormErrors() {
            const container = $(".cl-checkout-sections");
            const formInputs = container.find(".form-create-order input");

            container.find(".cl-wait-box").show();
            container.find(".cl-before-button, .cl-after-button").html('');
            container.find(".cl-input-error").hide();
            formInputs.removeClass('cl-error-border').attr('title', '');

            let existErrorField = false;
            let errorsBeforeBT = "";
            let errorsAfterBT = "";
            let errorsCheckoutModal = "";

            container.find("input[isrequired=yes]").each(function () {
                const $input = $(this);
                const inputValue = $input.val();
                const inputMinLength = parseInt($input.attr('minchars'));
                const inputMaxLength = parseInt($input.attr('maxchars'));

                if (inputValue.length < inputMinLength || inputValue.length > inputMaxLength) {
                    existErrorField = true;
                    const inputName = $input.attr('name');
                    const errorMsg = $input.attr('errormsg');
                    const $inputContainer = $(`.form-${inputName}-container`);

                    $inputContainer.find('input').addClass("cl-error-border").attr("title", errorMsg);

                    if (inputName === 'phone') {
                        $inputContainer.find('input').focus();
                    }

                    switch (jsCheckout.error_placement) {
                        case 'after_every_field':
                            $inputContainer.find('.cl-input-error').text(errorMsg).show("slow");
                            break;
                        case 'before_submit_button':
                            errorsBeforeBT += `<span class="error-element error-${inputName}">${errorMsg}</span>`;
                            break;
                        case 'after_submit_button':
                            errorsAfterBT += `<span class="error-element error-${inputName}">${errorMsg}</span>`;
                            break;
                        case 'show_in_popup':
                            errorsCheckoutModal += `<span class="error-element error-${inputName}">${errorMsg}</span>`;
                            break;
                    }
                }
            });

            const errorsMsg = errorsBeforeBT + errorsAfterBT;

            if (existErrorField || errorsMsg.length > 5) {
                container.find(".cl-wait-box").hide();
                container.find(".cl-client-response").html(errorsMsg);
            }

            return existErrorField;
        },

        updateSummary() {
            let totalCart = 0;
            let totalDiscount = 0;
            let totalExtraFees = 0;
            
            cart_cl.products.forEach(product => {
                const qty = Number(product.qty) || 1;
                
                totalDiscount += product.discount_per_product * qty;
                totalCart += product.regular_price * qty;

                if (Array.isArray(product.variations)) {
                    product.variations.forEach(productV => {
                        productV.forEach(productV2 => {
                            const extraFees = parseFloat(productV2.fees);
                            totalExtraFees += extraFees;
                        });
                    });
                }
            });

            order_cl.total_amount = totalCart + totalExtraFees - totalDiscount;
            order_cl.total_discount = totalDiscount;

            const formData = FrontendFn_cl.getFormDatas(".cl-checkout-sections");
            formData['total'] = order_cl.total_amount;

            let shippingCost = parseFloat(jsCheckout.shipping_fees);
            let shippingTitle = '<a href="#cl_shipping_options">' + jsCheckout.summary_shipping_default_text + '</a>';


            if (this.shippingOptions && typeof this.shippingOptions === 'object') {
                Object.values(this.shippingOptions).forEach((option, index) => {
                    const currentOptionId = parseInt(option.id);
                    if (option.is_active === 'yes') {
                        const $shippingOption = $(".shipping-option:nth-child(" + (currentOptionId) + ")");
                        const fieldNameWithSameConditionVarName = formData[option.condition_variable];
                        var metCondition = true;

                        if (FrontendFn_cl.isset(fieldNameWithSameConditionVarName)) {
                            if (FrontendFn_cl.evaluateCondition(fieldNameWithSameConditionVarName, option)) {
                                $shippingOption.removeClass("cl-hide");
                            } else {
                                metCondition = false;

                                if ($shippingOption.hasClass('has-condition-variable')) {
                                    $shippingOption.addClass("cl-hide");
                                    $shippingOption.removeClass("is-selected-shipping-option");
                                }
                            }
                        }
                        
                        if (this.checkoutData.shippingOptionId === currentOptionId && metCondition) {
                            shippingCost = parseFloat(option.cost_value);
                            shippingTitle = `${option.title} ${option.cost_label}`;
                        }

                    }
                });
            }

            order_cl.total_amount = order_cl.total_amount + shippingCost;
            $(".cl-total-value").text(order_cl.total_amount);
            $(".cl-product-discount .p_discount_value").text(totalDiscount);
            $(".shipping-fees .key-price").html(shippingTitle);
        },

        handleShippingOptionSelectionButton: function (element) {
            $(".shipping-option").removeClass("is-selected-shipping-option");
            element.addClass("is-selected-shipping-option").find("input[name=shipping_option_radio]").prop("checked", true);

            this.saveShippingOption(element.attr('option_id'));
        },

        handleShippingOptionSelectionSelect: function (element) {
            const selectedOption = element.find(":selected");

            $(".shipping-option").removeClass("is-selected-shipping-option");
            selectedOption.addClass("is-selected-shipping-option");

            this.saveShippingOption(selectedOption.attr('option_id'));
        }
    };

    order_cl = {
        order_id: 0,
        total_amount: 0,
        total_discount:0,

        /*
         * dont use this
         */
        onSuccessAddOrder: function (response) {
            const result = response.res;
            
            // Order was successful, clear the cart
            cart_cl.clearCart();

            if (FrontendFn_cl.isset(result['thankyou_page_url'])) {
                window.location.href = `${result['thankyou_page_url']}`;
                return;
            }
            cart_cl.updateCartDisplay();
        },
        onErrorAddOrder: function (response) {
            const error = `<div class="cl-error-response">${response.msg}</div>`;
            $(".cl-client-response").html(error);
            return;
        },
        addNewOrder: function () {
            var containerData = ".form-create-order";
            var formData = FrontendFn_cl.getFormDatas(containerData);

            formData['thankyou_page_id'] = parseInt(jsSalesFunnel.thankyou_page_id);
            formData['sales_funnel_mode'] = parseInt(jsSalesFunnel.mode);

            formData['cart_products'] = JSON.stringify(cart_cl.products);
            formData['total_amount'] = order_cl.total_amount;
            formData['total_discount'] = order_cl.total_discount;

            //formData['shipping'] = JSON.stringify(checkout_cl.selectedShippingOption);
            
            formData['shipping_id'] = checkout_cl.checkoutData.shippingOptionId + 1;
            formData['shipping_fees'] = checkout_cl.selectedShippingOption.cost_value;
            formData['shipping_label'] = checkout_cl.selectedShippingOption.cost_label;
            formData['shipping_title'] = checkout_cl.selectedShippingOption.title;
            
            formData['currency'] = jsMystore.currency_code;
            formData['currency_code'] = jsMystore.currency_code;
            formData['currency_label'] = jsMystore.currency_label;
            
            formData['status'] = jsCheckout.default_status;

            formData['cl_ajax_nonce'] = cl_ajax_nonce;

            // this line resolve the erreur that return 0
            formData['action'] = jsArgs.ajax_public_action;
            formData['cl_action_name'] = 'add_new_order';

            FrontendFn_cl.sendAjaxRequest(formData, this.onSuccessAddOrder, this.onErrorAddOrder);
        }
    };

    $(document).ready(function () {
        checkout_cl.init(jsCheckout);
        cart_cl.updateCartDisplay();
        checkout_cl.updateSummary();

        // Save checkout data when input fields change
        $(".cl-checkout-sections input, .cl-checkout-sections select").on('change', function () {
            checkout_cl.saveCheckoutData();
        });

        // shipping options : display blocks / select box
        $(".shipping-option").first().click();
        $(".shipping-option").on('click', function () {
            checkout_cl.handleShippingOptionSelectionButton($(this));
        });
        $("select.shipping-options-selectbox").on('change', function () {
            checkout_cl.handleShippingOptionSelectionSelect($(this));
        });



        $('#cl-submit-bt').on('click', function (ev) {
            ev.preventDefault();

            $('#cl-submit-bt').prop('disabled', true);
            if (!checkout_cl.existFormErrors()) {
                order_cl.addNewOrder();
            }
            $('#cl-submit-bt').prop('disabled', false);

            // This return prevents the submit event to refresh the page.
            return false;
        });




    });

})(jQuery);