<?php
class ShippingOptionsModelFR_cl {
    private static $tableName = 'shipping_options';
    
    
    public static function getAll($settingsModelId) {
        /*
         * to-do
         * You should create an option to store all results that will be created or updated every time a new shipping method is added or updated.
         * The query below should only be executed if this option doesn't exist.
         */
        
        $query = "SELECT id,is_active,title, subtitle, badge_text, cost_value, cost_label, thumbnail_url, bg_url,
                 condition_variable, condition_operator, condition_value FROM table_name 
                 WHERE settings_model_id = {$settingsModelId} AND is_active = 'yes' 
                 ORDER BY position ASC";
        $result = publicDB_cl::getResultsAsArray(self::$tableName, $query);
        
        $result = array_column($result, null, 'id');
        return $result;
    }
   
    
}