<?php
class CheckoutFieldsModelFR_cl {
    private static $tableName = 'checkout_fields';
    
    public static function getAll($settingsModelId) {
        /*
         * to-do
         * You should create an option to store all results that will be created or updated every time a new field is added or updated.
         * The query below should only be executed if this option doesn't exist.
         */
        
        $query = "SELECT id, is_active, is_system_field, type, name, label, placeholder, is_required, 
                 error_message, min_length, max_length, default_value, options, css_class, icon_id,
                 condition_variable, condition_operator, condition_value, validation_pattern
                 FROM table_name 
                 WHERE settings_model_id = {$settingsModelId} AND is_active = 'yes' 
                 ORDER BY position ASC";
        $result = publicDB_cl::getResultsAsArray(self::$tableName, $query);
        
        //$result = array_column($result, null, 'id');
        return $result;
    }
    
    /*public static function getActive($settingsModelId) {
        $query = "SELECT id, is_active, is_system_field, type, name, label, placeholder, is_required,
                 error_message, min_length, max_length, default_value, options, css_class, icon 
                 FROM table_name 
                 WHERE settings_model_id = {$settingsModelId} AND is_active = 'yes' 
                 ORDER BY position ASC";
        $result = publicDB_cl::getResultsAsArray(self::$tableName, $query);
        
        return $result;
    }*/
   
}