<?php
//var_dump($checkout_clfe);
if( ! $checkout_clfe ) {
    return;
}
//include $compsPath.$hook['compName'].'/frontend/views/head/index.php';
if( isset( $allCompsGeneratedCss['checkout'] ) ) {
    echo $allCompsGeneratedCss['checkout'];
}
?>
<script> 
// wp_head checkout
<?php if($checkout_clfe) { ?>
jsCheckout = JSON.parse('<?= $checkout_clfe->getJsCheckout() ?>');
<?php } ?>

/*let jsOrder = {};
jsOrder.regular_price = parseFloat(jsProduct.regular_price);
jsOrder.quantity = 1;
jsOrder.discount = parseFloat(jsProduct.discount_value);*/
</script>