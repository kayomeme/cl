<?php
//$hook['compName']
if( $checkout_cl ) {
    wp_enqueue_style( 'cl_checkout_public_css', MainApp_cl::$compsUrl. 'checkout/frontend/assets/css/checkout.css', [], MainApp_cl::$assetsVersion );
    wp_enqueue_script( 'cl_checkout_public_js', MainApp_cl::$compsUrl. 'checkout/frontend/assets/js/checkout.js', array( 'jquery' ), MainApp_cl::$assetsVersion );
}