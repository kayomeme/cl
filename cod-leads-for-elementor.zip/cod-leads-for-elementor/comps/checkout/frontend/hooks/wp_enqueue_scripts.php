<?php
//$hook['compName']
if( $checkout_clfe ) {
    wp_enqueue_style( 'clfe_checkout_public_css', MainApp_clfe::$compsUrl. 'checkout/frontend/assets/css/checkout.css', [], MainApp_clfe::$assetsVersion );
    wp_enqueue_script( 'clfe_checkout_public_js', MainApp_clfe::$compsUrl. 'checkout/frontend/assets/js/checkout.js', array( 'jquery' ), MainApp_clfe::$assetsVersion );
}