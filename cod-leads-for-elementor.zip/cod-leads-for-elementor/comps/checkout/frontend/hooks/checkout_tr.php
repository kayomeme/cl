<?php
$cartSettings = [];

if( $cart_cl ) {
    $cartSettings = $cart_cl->getSettings();
}

$checkout_modes = ['modal', 'in_product'];

if ( ( in_array($salesFunnel_cl->checkout_mode, $checkout_modes) || $isCheckoutPage ) && !$isThankyouPage  ) {
    $checkout_cl = new CheckoutControllerFR_cl($cartSettings);
}
