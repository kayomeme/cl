<?php
$cartSettings = [];

if( $cart_clfe ) {
    $cartSettings = $cart_clfe->getSettings();
}

$checkoutModes = ['modal', 'in_product'];

if ( ($product_id && in_array($salesFunnel_clfe->checkoutMode, $checkoutModes)) || $isCheckoutPage ) {
    $checkout_clfe = new CheckoutControllerFR_clfe($cartSettings);
}
