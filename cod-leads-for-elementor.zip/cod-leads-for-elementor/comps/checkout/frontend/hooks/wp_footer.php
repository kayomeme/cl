<?php
if( !$checkout_cl ) {
    return;
}

$settings = $checkout_cl->getSettings();
$shippingOptions = $checkout_cl->shippingOptions;
$checkoutFields = $checkout_cl->checkoutFields;

include MainApp_cl::$compsPath . 'checkout/frontend/views/blocks/checkout_modal/'.$settings['checkout_modal_version'].'/checkout_modal.php';


