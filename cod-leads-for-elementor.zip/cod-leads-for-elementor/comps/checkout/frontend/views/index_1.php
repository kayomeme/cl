<?php
if (!is_admin()) {
    //var_dump($settings);
}
?> 
<form method="post" name="form-create-order" class="form-create-order">
    <div id="cl-form-index"></div>
    <div class="cl-checkout-container">
        <?php 
            echo '<div class="cl-checkout-sections">';
            foreach ($checkoutBlocksOrder as $blockName) {
                include_once MainApp_cl::$compsPath . 'checkout/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
            }
            echo '</div>';
        ?>

        <?php
        /*if (wp_is_mobile() || is_admin()) {
            echo '<div class="cl-checkout-sections">';
            foreach ($allblocksOrder as $blockName) {
                switch ($blockName) {
                    case in_array($blockName, $checkoutBlocksOrder):
                        include_once MainApp_cl::$compsPath . 'checkout/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
                        break;
                    case in_array($blockName, $cartBlocksOrder):
                       // include_once MainApp_cl::$compsPath . 'cart/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
                        break;
                }
            }
            echo '</div>';
        } else {
            $checkout_col1_blocks_order = explode(',', $settings['checkout_col1_blocks_order']);
            echo '<div class="cl-checkout-sections">';

            foreach ($checkout_col1_blocks_order as $blockName) {
                switch ($blockName) {
                    case in_array($blockName, $checkoutBlocksOrder):
                        include_once MainApp_cl::$compsPath . 'checkout/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
                        break;
                    case in_array($blockName, $cartBlocksOrder):
                        //include_once MainApp_cl::$compsPath . 'cart/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
                        break;
                }
            }

            echo '</div><div class="cl-checkout-sections">';

            $checkout_col2_blocks_order = explode(',', $settings['checkout_col2_blocks_order']);
            foreach ($checkout_col2_blocks_order as $blockName) {
                switch ($blockName) {
                    case in_array($blockName, $checkoutBlocksOrder):
                        include_once MainApp_cl::$compsPath . 'checkout/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
                        break;
                    case in_array($blockName, $cartBlocksOrder):
                        ///include_once MainApp_cl::$compsPath . 'cart/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
                        break;
                }
            }

            echo '</div>';
        }*/
        ?>



    </div>
</form>