<div class="clfe-shipping-options-items">
    <?php
    foreach ($shippingOptions as $key => $shippingOption) {
        $styleTitle = "";
        $bgImage = "";
        $showThumbImg = $settings['shipping_option_image_is_active'];
        $showTitle = $settings['shipping_option_title_is_active'];

        if ($settings['shipping_option_bg_image_is_active'] == 'yes' && !empty($shippingOption['bg_url'])) {
            $bgImage = "background-image: url(" . $shippingOption['bg_url'] . ");background-size: cover;";

            // if background image exist hide all other options automatically
            $showThumbImg = 'no';
            $showTitle = 'no';
        }

        $costValueIsActive = $settings['shipping_option_cost_value_is_active'];
        $costLabelIsActive = $settings['shipping_option_cost_label_is_active'];
        ?>
        <div option_id="<?= $shippingOption['id'] ?>"  class="clfe-shipping-option <?= $shippingOption['condition_variable'] != '' ? 'clfe-hide has-condition-variable' : '' ?>" cost_value="<?= (float) $shippingOption['cost_value'] ?>" style="<?= $bgImage ?>">
            <div class="shipping-option-start">
                <?php if ($settings['shipping_option_radio_bt_is_active'] == 'yes') { ?>
                    <input class="clfe-shipping-option-radio-bt" name="clfe-shipping-option-radio" type="radio">    
                <?php } ?> 

                <?php if ($showThumbImg == 'yes' && !empty($shippingOption['thumbnail_url'])) { ?>
                    <img class="shipping-option-thumb" src="<?= $shippingOption['thumbnail_url'] ?>" title="<?= $shippingOption['title'] ?>">
                <?php } ?>

                <div class="shipping-option-texts">
                    <?php if ($settings['shipping_option_title_is_active'] == 'yes') { ?>
                        <div class="clfe-shipping-option-title">
                            <?= $shippingOption['title'] ?>
                        </div>
                    <?php } ?>
                    <?php if ($settings['shipping_option_subtitle_is_active'] == 'yes') { ?>
                        <div class="clfe-shipping-option-subtitle">
                            <?= $shippingOption['subtitle'] ?>
                        </div>
                    <?php } ?>
                </div>  

            </div>


            <?php if ($settings['shipping_option_badge_is_active'] == 'yes' && isset($shippingOption['badge_text']) && !empty($shippingOption['badge_text'])) { ?>
                <span class="shipping-option-badge">
                    <?= $shippingOption['badge_text'] ?>
                </span>
            <?php } ?>

            <div class="shipping-option-end" style="flex-flow: row wrap;">
                <?php if ($costValueIsActive == 'yes' || $costLabelIsActive == 'yes') { ?>
                    <div class="clfe-shipping-option-cost">
                        <?php if ($costValueIsActive == 'yes' && (float) $shippingOption['cost_value'] > 0) { ?>
                            <span class="clfe-cost-value">
                                <?= $shippingOption['cost_value'] . ' ' . $mystoreSettings['currency_label'] ?>
                            </span>
                        <?php } ?>
                        <?php if ($costLabelIsActive == 'yes' && strlen($shippingOption['cost_label']) > 0) { ?>
                            <span class="clfe-cost-label">
                                <?= $shippingOption['cost_label'] ?>
                            </span>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>

        </div> 
    <?php } ?>
</div>  