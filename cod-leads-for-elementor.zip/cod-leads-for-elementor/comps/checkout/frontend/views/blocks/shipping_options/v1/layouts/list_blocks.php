<div class="shipping-options-items">
    <?php
    $bgImagesStyle = "";
    foreach ($shippingOptions as $key => $shippingOption) {
        $bgImageClass = '';

        $showThumbImg = $settings['shipping_option_image_is_active'] == 'yes' && !empty($shippingOption['thumbnail_url']);
        $showTitle = $settings['shipping_option_title_is_active'] == 'yes';
        $showSubtitle = $settings['shipping_option_subtitle_is_active'] == 'yes';
        $showRadioButton = $settings['shipping_option_radio_bt_is_active'] == 'yes';
        $showBadge = $settings['shipping_option_badge_is_active'] == 'yes' && isset($shippingOption['badge_text']) && !empty($shippingOption['badge_text']);
        $showCostValue = $settings['shipping_option_cost_value_is_active'] == 'yes' && (float) $shippingOption['cost_value'] > 0;
        $showCostLabel = $settings['shipping_option_cost_label_is_active'] == 'yes' && strlen($shippingOption['cost_label']) > 0;
        $showBgImage = $settings['shipping_option_bg_image_is_active'] == 'yes' && !empty($shippingOption['bg_url']);

        if ($showBgImage) {
            /*
             * Using CSS classes instead of inline style attributes to prevent conflicts with admin simulator.
             * When settings change, the simulator regenerates CSS which would overwrite inline styles.
             * so don't change this
             */
            $bgImageClass = "shipping-option" . $key;
            $bgImagesStyle = $bgImagesStyle . ' .' . $bgImageClass . "{ background-image: url(" . $shippingOption['bg_url'] . ") !important;}";

            // if background image exist hide all other options automatically
            $showThumbImg = false;
            $showTitle = false;
            $showSubtitle = false;
            $showBadge = false;
            $showCostValue = false;
            $showCostLabel = false;
        }
        ?>
        <div option_id="<?= $shippingOption['id'] ?>"  
             class="shipping-option <?= $bgImageClass ?> <?= $shippingOption['condition_variable'] != '' ? 'cl-hide has-condition-variable' : '' ?>" 
             cost_value="<?= (float) $shippingOption['cost_value'] ?>">
            <?php if ($showRadioButton) { ?>
                <div class="shipping-option-radio-container">
                    <input name="shipping_option_radio" type="radio">    
                </div>
            <?php } ?> 
            <div class="shipping-option-elements">
                <?php if ($showThumbImg) { ?>
                    <img class="shipping-option-thumb" src="<?= $shippingOption['thumbnail_url'] ?>" title="<?= $shippingOption['title'] ?>">
                <?php } ?>

                <div class="shipping-option-texts">
                    <?php if ($showTitle) { ?>
                        <div class="shipping-option-title">
                            <?= $shippingOption['title'] ?>
                        </div>
                    <?php } ?>
                    <?php if ($showSubtitle) { ?>
                        <div class="shipping-option-subtitle">
                            <?= $shippingOption['subtitle'] ?>
                        </div>
                    <?php } ?>
                </div>  

                <?php if ($showBadge) { ?>
                    <span class="shipping-option-badge">
                        <?= $shippingOption['badge_text'] ?>
                    </span>
                <?php } ?>
                <?php if ($showCostValue || $showCostLabel) { ?>
                    <div class="shipping-option-cost">

                        <?php if ($showCostValue) { ?>
                            <span class="cost-value">
                                <?= $shippingOption['cost_value'] . ' ' . $sharedSettings['currency_label'] ?>
                            </span>
                        <?php } ?>
                        <?php if ($showCostLabel) { ?>
                            <span class="cost-label">
                                <?= $shippingOption['cost_label'] ?>
                            </span>
                        <?php } ?>

                    </div><?php } ?>
            </div>
        </div> 
    <?php } ?>
</div>  

<?php
if ($bgImagesStyle != "") {
    echo '<style>' . $bgImagesStyle . '</style>';
}
?>