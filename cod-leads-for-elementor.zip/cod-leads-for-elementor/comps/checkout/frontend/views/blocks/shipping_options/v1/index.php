<?php
if ($settings['shipping_options_is_active'] === 'no' ||  count($shippingOptions) < 1 ) {
    return;
}
if ($settings['shipping_options_header_is_active'] == 'no') {
    $settings['shipping_options_header_is_open'] = 'yes';
}
$isOpen = $settings['shipping_options_header_is_open'] == 'yes' ? 'yes' : 'no';
$optionsCount = count($shippingOptions);
?>
<div id="cl_shipping_options" _attachedsection="shipping_options" class="cl_toggle_block cl_checkout_block" is_open="<?= $isOpen ?>">
    <?php if ($settings['shipping_options_header_is_active'] == 'yes') { ?>
        <div class="cl_toggle_header">
            <div class="toggle-title">
                <span show_in_open>
                    <?= $settings['shipping_options_header_title_is_open'] ?> 
                </span>
                <span show_in_close>
                    <?= $settings['shipping_options_header_title_is_closed'] ?> 
                </span>
            </div>
            <div class="toggle-close">
                <div class="shipping-options-header-count-text">
                    <span class="count_number"><?= $optionsCount ?> </span>
                    <span class="count_text"><?= $settings['shipping_options_header_count_text'] ?></span>
                </div>
                <?php echo $iconsSelectorFR_cl->getIconCode($sharedSettings['collapse_open_icon_id'], ['class' => 'cl-icon-open']); ?>
                <?php echo $iconsSelectorFR_cl->getIconCode($sharedSettings['collapse_close_icon_id'], ['class' => 'cl-icon-close']); ?>
            </div>
            
        </div>
        <?php if ($settings['shipping_option_preview_is_active'] == 'yes') { ?>
        <div class="cl_toggle_preview" show_in_close>
            <span class="prefix_text"><?= $settings['shipping_option_preview_prefix_text'] ?></span>
            <span class="selected_value_text"></span>
        </div>
        <?php } ?>
    <?php } ?>
    <div class="cl_toggle_body" show_in_open>
        <?php include_once 'layouts/' . $settings['shipping_options_display_type'] . '.php'; ?>
    </div>
</div>