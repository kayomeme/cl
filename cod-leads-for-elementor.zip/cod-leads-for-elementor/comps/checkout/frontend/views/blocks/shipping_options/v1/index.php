<?php
if ($settings['shipping_options_is_active'] === 'no' ||  count($shippingOptions) < 1 ) {
    return;
}
if ($settings['shipping_options_header_is_active'] == 'no') {
    $settings['shipping_options_header_is_open'] = 'yes';
}
?>
<div id="clfe_shipping_options" _attachedsection="shipping_options" class="clfe_toggle_is_active">
    <?php if ($settings['shipping_options_header_is_active'] == 'yes') { ?>
        <div class="clfe_toggle_header" is_open="<?= $settings['shipping_options_header_is_open'] == 'yes' ? 'yes' : 'no' ?>">
            <div class="clfe-shipping-options-section-title">
                <span class="clfe_toToggle_is_open<?= $settings['shipping_options_header_is_open'] == 'yes' ? '_yes' : '_no' ?>">
                    <span class="shipping_options_header_title_is_open"><?= $settings['shipping_options_header_title_is_open'] ?> </span>
                    <span class="shipping-option-title-value"></span>
                </span>
                <span class="shipping_options_header_title_is_closed clfe_toToggle_is_open<?= $settings['shipping_options_header_is_open'] == 'yes' ? '_no' : '_yes' ?>">
                    <?= $settings['shipping_options_header_title_is_closed'] ?>
                </span>
            </div>
            <div class="shipping-options-header-count-text">
                <span class="count_number"><?= (int) count($shippingOptions) ?></span>
                <span class="count_text"> <?= $settings['shipping_options_header_count_text'] ?></span>   
            </div>
        </div>
    <?php } ?>
    <div class="clfe_toggle_body <?= $settings['shipping_options_header_is_open'] == 'yes' ? 'clfe_is_open_yes' : 'clfe_is_open_no' ?>">
        <?php include_once 'layouts/' . $settings['shipping_options_layout'] . '.php'; ?>
    </div>
</div>