<select class="shipping-options-selectbox">
    <?php 
    foreach ($shippingOptions as $key => $shippingOption) { 
        $costText = (float)$shippingOption['cost_value'] > 0 ? ' / '.$shippingOption['cost_value'].' '.$mystoreSettings['currency_label'] : '';
        ?>
        <option option_id="<?= $shippingOption['id'] ?>" value="<?= $shippingOption['title'] ?>" class="shipping-option <?= $shippingOption['condition_variable'] != '' ? 'cl-hide has-condition-variable' : '' ?>" cost_value="<?= (float)$shippingOption['cost_value'] ?>">
            <?= $shippingOption['title'].$costText ?>
        </option> 
    <?php } ?>
</select>  