<?php 
    if ($settings['checkout_custom_block2_is_active'] === 'no') {
        return;
    }
?>
<div id="clfe_checkout_custom_block2" _attachedsection="checkout_custom_block2">

    <?= $settings['checkout_custom_block2_content'] ?>

</div>

