<?php 
    if ($settings['checkout_custom_block2_is_active'] === 'no') {
        return;
    }
?>
<div id="cl_checkout_custom_block2" _attachedsection="checkout_custom_block2">
    <?= do_shortcode($settings['checkout_custom_block2_content']) ?>
</div>

