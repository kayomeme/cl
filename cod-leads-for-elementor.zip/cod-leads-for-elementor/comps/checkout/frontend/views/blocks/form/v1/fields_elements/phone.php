<?php if( $settings['phone_is_active'] == 'yes' ) { ?>
<div class="form-phone-container">
    <div class="form-entry-field">
        <?php if( $settings['form_fields_icon_is_active'] == 'yes' ) { ?>
        <span class="icon-container"><i class="clfe-icon icon-phone"></i></span>
        <?php } ?>
        <?php if( $settings['form_fields_label_is_active'] == 'yes' ) { ?>
        <div class="form-label-container"><?= $settings['phone_label'] ?></div>
        <?php } ?>
        <input name="phone" type="tel" class="form_fields_entry_style" placeholder="<?= $settings['phone_placeholder'] ?>" errormsg="<?= $settings['phone_error_msg'] ?>" isrequired="<?= $settings['phone_is_req'] ?>" minchars="<?= $settings['phone_minlength'] ?>" maxchars="<?= $settings['phone_maxlength'] ?>">
    </div>
    <div class="clfe-input-error error-element"></div>
</div>
<?php } ?>