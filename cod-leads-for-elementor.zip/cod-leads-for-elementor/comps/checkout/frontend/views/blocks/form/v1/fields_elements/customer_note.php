<?php if( $settings['customer_note_is_active'] == 'yes' ) { ?>
    <div class="form-customer_note-container">
        <div class="form-entry-field">  
            <?php if( $settings['form_fields_icon_is_active'] == 'yes' ) { ?>
            <span class="icon-container"><i class="clfe-icon icon-help-circle"></i></span>
            <?php } ?>
            <?php if( $settings['form_fields_label_is_active'] == 'yes' ) { ?>
            <div class="form-label-container"><?= $settings['customer_note_label'] ?></div>
            <?php } ?>
            <input name="customer_note" type="text" class="form_fields_entry_style" placeholder="<?= $settings['customer_note_placeholder'] ?>" errormsg="<?= $settings['customer_note_error_msg'] ?>" isrequired="<?= $settings['customer_note_is_req'] ?>" minchars="<?= $settings['customer_note_minlength'] ?>">
        </div>
        <div class="clfe-input-error error-element"></div>
    </div>
<?php } ?>