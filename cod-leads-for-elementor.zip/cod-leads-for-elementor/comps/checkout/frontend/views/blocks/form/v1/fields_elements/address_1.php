<?php if( $settings['address_1_is_active'] == 'yes' ) { ?>
    <div class="form-address-container">
        <div class="form-entry-field">  
            <?php if( $settings['form_fields_icon_is_active'] == 'yes' ) { ?>
            <span class="icon-container"><i class="clfe-icon icon-home"></i></span>
            <?php } ?>
            <?php if( $settings['form_fields_label_is_active'] == 'yes' ) { ?>
            <div class="form-label-container"><?= $settings['address_1_label'] ?></div>
            <?php } ?>
            <input name="address_1" type="text" class="form_fields_entry_style" placeholder="<?= $settings['address_1_placeholder'] ?>" errormsg="<?= $settings['address_1_error_msg'] ?>" isrequired="<?= $settings['address_1_is_req'] ?>" minchars="<?= $settings['address_1_minlength'] ?>">
        </div>
        <div class="clfe-input-error error-element"></div>
    </div>
<?php } ?>