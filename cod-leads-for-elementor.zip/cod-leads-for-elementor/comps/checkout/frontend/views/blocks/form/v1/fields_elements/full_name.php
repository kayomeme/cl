<?php if( $settings['full_name_is_active'] == 'yes' ) { ?>
        <div class="form-full_name-container">
        <div class="form-entry-field">
            <?php if( $settings['form_fields_icon_is_active'] == 'yes' ) { ?>
            <span class="icon-container"><i class="clfe-icon icon-user"></i></span>
            <?php } ?>
            <?php if( $settings['form_fields_label_is_active'] == 'yes' ) { ?>
            <div class="form-label-container"><?= $settings['full_name_label'] ?></div>
            <?php } ?>
            <input name="full_name" type="text" class="form_fields_entry_style" placeholder="<?= $settings['full_name_placeholder'] ?>" errormsg="<?= $settings['full_name_error_msg'] ?>" isrequired="<?= $settings['full_name_is_req'] ?>" minchars="<?= $settings['full_name_minlength'] ?>">
        </div>
        <div class="clfe-input-error error-element"></div>
    </div>
<?php } ?>