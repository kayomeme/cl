<?php if( $settings['city_is_active'] == 'yes' ) { ?>
<div class="form-city-container">
    <div class="form-entry-field">
        <?php if( $settings['form_fields_icon_is_active'] == 'yes' ) { ?>
        <span class="icon-container"><i class="clfe-icon icon-map-pin"></i></span>
        <?php } ?>
        <?php if( $settings['form_fields_label_is_active'] == 'yes' ) { ?>
        <div class="form-label-container"><?= $settings['city_label'] ?></div>
        <?php } ?>
        <input name="city" type="text" class="form_fields_entry_style" placeholder="<?= $settings['city_placeholder'] ?>" errormsg="<?= $settings['city_error_msg'] ?>" isrequired="<?= $settings['city_is_req'] ?>" minchars="<?= $settings['city_minlength'] ?>">
    </div>   
    <div class="clfe-input-error error-element"></div>
</div>
<?php } ?>