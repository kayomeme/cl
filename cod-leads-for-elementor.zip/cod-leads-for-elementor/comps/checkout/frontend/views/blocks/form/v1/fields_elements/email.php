<?php if( $settings['email_is_active'] == 'yes' ) { ?>
<div class="form-email-container">
    <div class="form-entry-field">
        <?php if( $settings['form_fields_icon_is_active'] == 'yes' ) { ?>
        <span class="icon-container"><i class="clfe-icon icon-at-sign"></i></span>
        <?php } ?>
        <?php if( $settings['form_fields_label_is_active'] == 'yes' ) { ?>
        <div class="form-label-container"><?= $settings['email_label'] ?></div>
        <?php } ?>
        <input name="email" type="email" class="form_fields_entry_style" placeholder="<?= $settings['email_placeholder'] ?>" errormsg="<?= $settings['email_error_msg'] ?>" isrequired="<?= $settings['email_is_req'] ?>">
    </div>
    <div class="clfe-input-error error-element"></div>
</div>
<?php } ?>