<?php if( $settings['state_is_active'] == 'yes' ) { ?>
<div class="form-state-container">
    <div class="form-entry-field">
        <?php if( $settings['form_fields_icon_is_active'] == 'yes' ) { ?>
        <span class="icon-container"><i class="clfe-icon icon-map"></i></span>
        <?php } ?>
        <?php if( $settings['form_fields_label_is_active'] == 'yes' ) { ?>
        <div class="form-label-container"><?= $settings['state_label'] ?></div>
        <?php } ?>
        <input name="state" type="text" class="form_fields_entry_style" placeholder="<?= $settings['state_placeholder'] ?>" errormsg="<?= $settings['state_error_msg'] ?>" isrequired="<?= $settings['state_is_req'] ?>" minchars="<?= $settings['state_minlength'] ?>">
    </div>   
    <div class="clfe-input-error error-element"></div>
</div>
<?php } ?>