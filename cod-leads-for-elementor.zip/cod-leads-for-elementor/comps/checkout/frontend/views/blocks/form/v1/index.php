<div id="clfe_form" _attachedsection="form">
    <?php if( $settings['form_heading_is_active'] == 'yes' ) { ?>
    <div class="clfe_form_heading"> 
        <?= $settings['form_heading'] ?>
    </div>
    <?php } ?>
    <div class="clfe_form_fields_container">
        <?php 
            $fieldsForm = explode(',', $settings['form_fields_order']);
            foreach ($fieldsForm as $fieldName) {
                include 'fields_elements/'.$fieldName.'.php';
            }
        ?>
    </div>
</div>