<div id="cl_form" _attachedsection="form">
    <?php if( $settings['form_heading_is_active'] == 'yes' ) { ?>
    <div class="cl_form_heading"> 
        <?= $settings['form_heading'] ?>
    </div>
    <?php } ?>
    <div class="cl_form_fields_container">
        <?php 
            //$fieldsForm = explode(',', $settings['form_fields_order']);
            foreach ($checkoutFields as $field) {
                include 'fields_elements/'.$field['name'].'.php';
            }
        ?>
    </div>
</div>