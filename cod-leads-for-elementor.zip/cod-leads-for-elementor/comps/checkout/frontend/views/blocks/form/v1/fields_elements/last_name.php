<?php if( $field['is_active'] == 'yes' ) { ?>
<div class="form-last_name-container">
    <div class="form-entry-field">
        <?php if( $settings['form_fields_label_is_active'] == 'yes' ) { ?>
        <div class="form-label-container">
            <?= $field['label'] ?>
            <?php if( $field['is_required'] == 'yes' ) { ?>
                <span class="cl-required">*</span>
            <?php } ?>
        </div>
        <?php } ?>
        
        <div class="cl-input-group">
            <?php if( $settings['form_fields_icon_is_active'] == 'yes' ) { ?>
                <?= $iconsSelectorFR_cl->getIconCode($field['icon_id']); ?>
            <?php } ?>
            <input name="last_name" type="text" class="form_fields_entry_style" placeholder="<?= $field['placeholder'] ?>" errormsg="<?= $field['error_message'] ?>" isrequired="<?= $field['is_required'] ?>" minchars="<?= $field['min_length'] ?>">
        </div>
    </div>
    <div class="cl-input-error error-element"></div>
</div>
<?php } ?>