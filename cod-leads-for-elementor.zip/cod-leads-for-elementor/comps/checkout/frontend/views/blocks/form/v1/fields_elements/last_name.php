<?php if( $settings['last_name_is_active'] == 'yes' ) { ?>
        <div class="form-last_name-container">
        <div class="form-entry-field">
            <?php if( $settings['form_fields_icon_is_active'] == 'yes' ) { ?>
            <span class="icon-container"><i class="clfe-icon icon-user"></i></span>
            <?php } ?>
            <?php if( $settings['form_fields_label_is_active'] == 'yes' ) { ?>
            <div class="form-label-container"><?= $settings['last_name_label'] ?></div>
            <?php } ?>
            <input name="last_name" type="text" class="form_fields_entry_style" placeholder="<?= $settings['last_name_placeholder'] ?>" errormsg="<?= $settings['last_name_error_msg'] ?>" isrequired="<?= $settings['last_name_is_req'] ?>" minchars="<?= $settings['last_name_minlength'] ?>">
        </div>
        <div class="clfe-input-error error-element"></div>
    </div>
<?php } ?>