<?php if( $settings['coupon_code_is_active'] == 'yes' ) { ?>
    <div class="form-coupon_code-container">
        <div class="form-entry-field">  
            <?php if( $settings['form_fields_icon_is_active'] == 'yes' ) { ?>
            <span class="icon-container"><i class="clfe-icon icon-gift"></i></span>
            <?php } ?>
            <?php if( $settings['form_fields_label_is_active'] == 'yes' ) { ?>
            <div class="form-label-container"><?= $settings['coupon_code_label'] ?></div>
            <?php } ?>
            <input name="coupon_code" type="text" class="form_fields_entry_style" value="<?= isset( $_REQUEST['code'] ) ? $_REQUEST['code'] : '' ?>" placeholder="<?= $settings['coupon_code_placeholder'] ?>" errormsg="<?= $settings['coupon_code_error_msg'] ?>" isrequired="<?= $settings['coupon_code_is_req'] ?>" minchars="<?= $settings['coupon_code_minlength'] ?>">
        </div>
        <div class="clfe-input-error error-element"></div>
    </div>
<?php } ?>