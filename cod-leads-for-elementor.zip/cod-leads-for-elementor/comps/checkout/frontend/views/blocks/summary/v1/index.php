<?php
    if ($settings['summary_is_active'] === 'no') {
        return;
    }
    if( $settings['summary_header_is_active'] == 'no' ) {
        $settings['summary_header_is_open'] = 'yes';
    }
    $isOpen = $settings['summary_header_is_open'] == 'yes' ? 'yes' : 'no';
    
    // Count cart items for display
    $cartItemsCount = isset($cart_items) ? count($cart_items) : 0;
    ?>

    <div id="cl_summary" _attachedsection="summary" class="cl_toggle_block cl_product_block" is_open="<?= $isOpen ?>">
        <?php if ($settings['summary_header_is_active'] == 'yes') { ?>
            <div class="cl_toggle_header">
                <div class="toggle-title">
                    <span class="icon-cart"></span> &nbsp;
                    <span show_in_open>
                        <?= $settings['summary_header_title_is_open'] ?>
                    </span>
                    <span show_in_close>
                        <?= $settings['summary_header_title_is_closed'] ?>
                    </span>
                </div>
                <div class="toggle-close">
                    <div class="summary-header-count-text">
                        <span class="count_number"><?= $cartItemsCount ?> </span>
                        <span class="count_text"><?= $settings['summary_header_count_text'] ?></span>
                    </div>
                    <div class="key-price">
                        <?php if( $settings['summary_header_total_is_active'] == 'yes' ) { ?>
                        <span class="cl-total-value"></span>
                        <span class="cl-currency"><?= $sharedSettings['currency_label'] ?></span>
                        <?php } ?>
                    </div>
                    <?php echo $iconsSelectorFR_cl->getIconCode($sharedSettings['collapse_open_icon_id'], ['class' => 'cl-icon-open']); ?>
                    <?php echo $iconsSelectorFR_cl->getIconCode($sharedSettings['collapse_close_icon_id'], ['class' => 'cl-icon-close']); ?>
                </div>
            </div>
        <?php } ?>
        <div class="cl_toggle_body" show_in_open>
            
            <?php 
                if( $settings['summary_cart_products_is_active'] == 'yes' ) {
                    $settings['cart_products_header_is_active'] = 'no';
                    include MainApp_cl::$compsPath . 'cart/frontend/views/blocks/cart_products/v1/index.php';
                }
                if( $settings['summary_cart_totals_is_active'] == 'yes' ) {
                    include MainApp_cl::$compsPath . 'cart/frontend/views/blocks/cart_totals/v1/index.php';
                }
                include MainApp_cl::$compsPath . 'cart/frontend/views/blocks/cart_coupon/v1/index.php';
            ?>
            
            <?php if ($settings['summary_discount_is_active'] == 'yes') { ?>
                <div class="cl-product-discount detail-row">
                    <div class="key-name">
                        <?php if ($settings['summary_icons_is_active'] == 'yes' ) { ?>
                            <i class="cl-icon icon-discounts"></i>
                        <?php } ?>
                        <span class="p_discount_label">
                            <?= $settings['summary_discount_label'] ?>
                        </span>
                    </div>
                    <div class="key-price">
                        <?php if ($settings['summary_icons_is_active'] == 'yes' && strlen($settings['summary_discount_label']) < 2) { ?>
                            <i class="cl-icon icon-gift"></i>
                        <?php } ?>
                        <span class="p_discount_text">
                            <?= $settings['summary_discount_value'] ?>
                        </span>
                        <span class="p_discount_value">
        
                        </span>
                        <span class="cl-currency">
                            <?= $sharedSettings['currency_label'] ?>
                        </span>
                    </div>
                </div>
            <?php } ?>
            <?php if ($settings['summary_shipping_is_active'] == 'yes') { ?>
                <div class="shipping-fees detail-row">
                    <div class="key-name">
                        <?php if ($settings['summary_icons_is_active'] == 'yes') { ?>
                            <i class="cl-icon icon-truck"></i>
                        <?php } ?>
                        <span class="p_shipping_text"><?= $settings['summary_shipping_label'] ?></span>
                    </div>
                    <div class="key-price">
                        <?php
                        if ($sharedSettings['shipping_fees'] > 0) {
                            echo '+ ' . $settings['shipping_fees'] . ' <span class="cl-currency">' . $sharedSettings['currency_label'] . '</span>';
                        } else {
                            echo $settings['summary_shipping_title'];
                        }
                        ?>
                    </div>
                </div>
            <?php } ?>
            <div class="order-total detail-row">
                <div class="key-name">
                    <?php if ($settings['summary_icons_is_active'] == 'yes') { ?>
                        <i class="cl-icon icon-dollar-sign"></i>
                    <?php } ?>
                    <span><?= $settings['summary_total_label'] ?></span>
                </div>
                <div class="key-price">
                    <span class="cl-total-value"></span>
                    <span class="cl-currency"><?= $sharedSettings['currency_label'] ?></span>
                </div>
            </div>
            <?php if ( $settings['summary_payment_msg_is_active'] == 'yes' ) { ?>
                <div class="payment-msg detail-row">
                    <?= $settings['summary_payment_msg'] ?>
                </div>
            <?php } ?>
        </div>

    </div>