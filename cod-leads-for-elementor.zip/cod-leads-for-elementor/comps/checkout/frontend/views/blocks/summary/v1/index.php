<?php
    if ($settings['summary_is_active'] === 'no') {
        return;
    }
    if( $settings['summary_header_is_active'] == 'no' ) {
        $settings['summary_header_is_open'] = 'yes';
    }
    ?>

    <div id="clfe_summary" _attachedsection="summary" class="clfe_toggle_is_active">
        <?php if ($settings['summary_header_is_active'] == 'yes') { ?>
            <div class="clfe_toggle_header" is_open="<?= $settings['summary_header_is_open'] == 'yes' ? 'yes' : 'no' ?>">
                <div class="order-summary-header-title">
                    <span class="icon-cart"></span> &nbsp;
                    <span class="summary_header_title_is_open clfe_toToggle_is_open<?= $settings['summary_header_is_open'] == 'yes' ? '_yes' : '_no' ?>">
                        <?= $settings['summary_header_title_is_open'] ?>
                    </span>
                    <span class="summary_header_title_is_closed clfe_toToggle_is_open<?= $settings['summary_header_is_open'] == 'yes' ? '_no' : '_yes' ?>">
                        <?= $settings['summary_header_title_is_closed'] ?>
                    </span>
                </div>
                <div class="key-price">
                    <?php if( $settings['summary_header_total_is_active'] == 'yes' ) { ?>
                    <span class="clfe-total-value"></span>
                    <span class="clfe-currency"><?= $mystoreSettings['currency_label'] ?></span>
                    <?php } ?>
                </div>
            </div>
        <?php } ?>
        <div class="clfe_toggle_body <?= $settings['summary_header_is_open'] == 'yes' ? 'clfe_is_open_yes' : 'clfe_is_open_no' ?>">
            
            <?php 
                $settings['cart_products_is_active'] = $settings['summary_cart_products_is_active'];
                $settings['cart_products_header_is_active'] = 'no';
                include MainApp_clfe::$compsPath . 'cart/frontend/views/blocks/cart_products/v1/index.php';
                include MainApp_clfe::$compsPath . 'cart/frontend/views/blocks/cart_totals/v1/index.php';
                include MainApp_clfe::$compsPath . 'cart/frontend/views/blocks/cart_coupon/v1/index.php';
            ?>
            
            <?php if ($settings['summary_discount_is_active'] == 'yes') { ?>
                <div class="clfe-product-discount detail-row">
                    <div class="key-name">
                        <?php if ($settings['summary_icons_is_active'] == 'yes' ) { ?>
                            <i class="clfe-icon icon-gift"></i>
                        <?php } ?>
                        <span class="p_discount_label">
                            <?= $settings['summary_discount_label'] ?>
                        </span>
                    </div>
                    <div class="key-price">
                        <?php if ($settings['summary_icons_is_active'] == 'yes' && strlen($settings['summary_discount_label']) < 2) { ?>
                            <i class="clfe-icon icon-gift"></i>
                        <?php } ?>
                        <span class="p_discount_text">
                            <?= $settings['summary_discount_value'] ?>
                        </span>
                        <span class="p_discount_value">
        
                        </span>
                        <span class="clfe-currency">
                            <?= $mystoreSettings['currency_label'] ?>
                        </span>
                    </div>
                </div>
            <?php } ?>
            <?php if ($settings['summary_shipping_is_active'] == 'yes') { ?>
                <div class="shipping-fees detail-row">
                    <div class="key-name">
                        <?php if ($settings['summary_icons_is_active'] == 'yes') { ?>
                            <i class="clfe-icon icon-truck"></i>
                        <?php } ?>
                        <span class="p_shipping_text"><?= $settings['summary_shipping_label'] ?></span>
                    </div>
                    <div class="key-price">
                        <?php
                        if ($sharedSettings['shipping_fees'] > 0) {
                            echo '+ ' . $settings['shipping_fees'] . ' <span class="clfe-currency">' . $mystoreSettings['currency_label'] . '</span>';
                        } else {
                            echo $settings['summary_shipping_title'];
                        }
                        ?>
                    </div>
                </div>
            <?php } ?>
            <div class="order-total detail-row">
                <div class="key-name">
                    <?php if ($settings['summary_icons_is_active'] == 'yes') { ?>
                        <!-- <i class="clfe-icon icon-cart"></i> -->
                    <?php } ?>
                    <span><strong><?= $settings['summary_total_label'] ?></strong></span>
                </div>
                <div class="key-price">
                    <span class="clfe-total-value"></span>
                    <span class="clfe-currency"><?= $mystoreSettings['currency_label'] ?></span>
                </div>
            </div>
            <?php if ( $settings['summary_payment_msg_is_active'] == 'yes' ) { ?>
                <div class="payment-msg detail-row">
                    <?= $settings['summary_payment_msg'] ?>
                </div>
            <?php } ?>
        </div>

    </div>