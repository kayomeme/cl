<div id="clfe_submit_button" _attachedsection="submit_button">

    <div class="clfe-wait-box">
        <div class="clfe-wait-text">
            <?php if ($settings['error_wait_icon_is_active'] == 'yes') { ?>
                <div class="clfe-wait-icon">.</div>
            <?php } ?>
            <?= $settings['error_wait_text'] ?>
        </div>
    </div>

    <?php if ($settings['error_placement'] == 'before_submit_button') { ?>
        <div class="clfe-client-response clfe-before-button"> </div>
    <?php } ?>

    <div class="clfe-qty-and-submit-bt">
        <button id="clfe-submit-bt">
            <?php if ($settings['submit_button_icon_is_active'] == 'yes') { ?>
                <i class="clfe-icon icon-cart1"></i>&nbsp;
            <?php } ?>
            <span class="text_bt">
                <?= $settings['submit_button_text'] ?>
            </span>
        </button>
    </div>


    <?php if ($settings['error_placement'] == 'after_submit_button') { ?>
        <div class="clfe-client-response clfe-after-button"> </div>
    <?php } ?>

</div>

