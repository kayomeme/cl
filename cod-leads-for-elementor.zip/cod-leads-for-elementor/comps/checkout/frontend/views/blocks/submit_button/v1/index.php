<div id="cl_submit_button" _attachedsection="submit_button">

    <div class="cl-wait-box">
        <div class="cl-wait-text">
            <?php if ($settings['error_wait_icon_is_active'] == 'yes') { ?>
                <div class="cl-wait-icon">.</div>
            <?php } ?>
            <?= $settings['error_wait_text'] ?>
        </div>
    </div>

    <?php if ($settings['error_placement'] == 'before_submit_button') { ?>
        <div class="cl-client-response cl-before-button"> </div>
    <?php } ?>

    <div class="cl-qty-and-submit-bt">
        <button id="cl-submit-bt">
            <?php
            if ($settings['submit_button_icon_is_active'] == 'yes') {
                echo $iconsSelectorFR_cl->getIconCode($settings['submit_button_icon_id']);
            }
            ?>
            <span class="text_bt">
                <?= str_replace('@total', '<span class="cl-total-value"></span> ' . $sharedSettings['currency_label'], $settings['submit_button_text']) ?>
            </span>
        </button>
    </div>


    <?php if ($settings['error_placement'] == 'after_submit_button') { ?>
        <div class="cl-client-response cl-after-button"> </div>
    <?php } ?>

</div>

