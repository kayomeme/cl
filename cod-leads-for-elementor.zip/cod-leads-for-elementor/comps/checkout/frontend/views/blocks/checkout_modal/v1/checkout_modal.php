<?php
// is called by checkout\frontend\hooks\wp_footer.php

$checkoutModalBlocksContent = '';
$checkout_modes = ['modal'];
if (in_array($salesFunnel_cl->checkout_mode, $checkout_modes)) {
    $checkoutBlocksOrder = isset($settings['checkout_blocks_order']) ? explode(',', $settings['checkout_blocks_order']) : [];

    ob_start();
    include MainApp_cl::$compsPath . 'cart/frontend/views/blocks/cart_empty/v1/index.php';
    foreach ($checkoutBlocksOrder as $index => $blockName) {
        include MainApp_cl::$compsPath . 'checkout/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
    }
    $checkoutModalBlocksContent = ob_get_clean();
    ?>
<div class="cl-checkout-sections">
    <div class="cl_modal cl_modal_center cl_checkout_modal" style="display: none;">
        <div class="cl_modal_container">
            <div class="cl_modal_header">
                <?php if ($settings['checkout_modal_logo_is_active'] == 'yes' && strlen($settings['checkout_modal_logo_img_url']) > 5) { ?>
                <div class="cl_modal_logo">
                    <img src="<?= $settings['checkout_modal_logo_img_url'] ?>" />
                </div>
                <?php } ?>
                <div class="cl_modal_title">
                    <?= $settings['checkout_modal_title'] ?>
                </div>
                <span class="cl_modal_close">
                    <?php
                    if (strlen($settings['checkout_modal_close_bt_text']) > 0) {
                        echo $settings['checkout_modal_close_bt_text'];
                    }
                    if ($settings['checkout_modal_close_icon_is_active'] == 'yes') {
                        echo $iconsSelectorFR_cl->getIconCode($settings['checkout_modal_close_icon_id']);
                    }
                    ?>
                </span>
            </div>
            <div class="cl_modal_body">
                <?php
                echo $checkoutModalBlocksContent;
                ?>
            </div>

        </div>
    </div>
</div>
    <?php /* ?> <div id="cl-modal-form" class="modal">
        <div class="cl-checkout-sections">
    <?php
    echo $checkoutModalBlocksContent;
    ?>
        </div>

        <div class="cl-popup-footer">
            <a href="#" rel="modal:close"><?= $settings['checkout_modal_footer_text_close'] ?></a>
        </div>
    </div> <?php */ ?>

<?php } ?>