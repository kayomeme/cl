<?php 
    if ($settings['checkout_custom_block1_is_active'] === 'no') {
        return;
    }
?>
<div id="clfe_checkout_custom_block1" _attachedsection="checkout_custom_block1">

    <?= $settings['checkout_custom_block1_content'] ?>

</div>

