<?php 
    if ($settings['checkout_custom_block1_is_active'] === 'no') {
        return;
    }
?>
<div id="cl_checkout_custom_block1" _attachedsection="checkout_custom_block1">
    <?= do_shortcode($settings['checkout_custom_block1_content']) ?> 
</div>

