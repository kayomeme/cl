<?php
if (!is_admin()) {
    //var_dump($settings);
}


?> 
<div class="form-create-order">
    <div id="cl-form-index"></div>
    <?php 
    include_once MainApp_cl::$compsPath . 'cart/frontend/views/blocks/cart_empty/' . $settings['cart_empty_version'] . '/index.php';
    ?>
    <div class="cl-checkout-container">

        <?php
        if (wp_is_mobile() || is_admin()) {
            echo '<div class="cl-checkout-sections">';
            foreach ($checkoutBlocksOrder as $blockName) {
                include_once MainApp_cl::$compsPath . 'checkout/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
            }
            echo '</div>';
        } else {
            echo '<div class="cl-checkout-sections">';
            foreach ($checkoutBlocksOrder as $blockName) {
                if( $blockName != 'summary' ) {
                    include_once MainApp_cl::$compsPath . 'checkout/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
                }
            }

            echo '</div><div class="cl-checkout-sections">';
                include_once MainApp_cl::$compsPath . 'cart/frontend/views/blocks/cart_empty/' . $settings['cart_empty_version'] . '/index.php';
                include_once MainApp_cl::$compsPath . 'checkout/frontend/views/blocks/summary/' . $settings['summary_version'] . '/index.php';
            echo '</div>';
        }
        ?>



    </div>
</div>