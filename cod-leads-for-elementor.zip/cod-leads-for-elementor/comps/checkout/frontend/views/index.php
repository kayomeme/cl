<?php
if (!is_admin()) {
    //var_dump($settings);
}


?> 
<form method="post" name="form-create-order" class="form-create-order">
    <div id="clfe-form-index"></div>
    <?php 
    include_once MainApp_clfe::$compsPath . 'cart/frontend/views/blocks/cart_empty/' . $settings['cart_empty_version'] . '/index.php';
    ?>
    <div class="clfe-checkout-container">

        <?php
        if (wp_is_mobile() || is_admin()) {
            echo '<div class="clfe-checkout-sections">';
            foreach ($checkoutBlocksOrder as $blockName) {
                include_once MainApp_clfe::$compsPath . 'checkout/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
            }
            echo '</div>';
        } else {
            echo '<div class="clfe-checkout-sections">';
            foreach ($checkoutBlocksOrder as $blockName) {
                if( $blockName != 'summary' ) {
                    include_once MainApp_clfe::$compsPath . 'checkout/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
                }
            }

            echo '</div><div class="clfe-checkout-sections">';
                include_once MainApp_clfe::$compsPath . 'cart/frontend/views/blocks/cart_empty/' . $settings['cart_empty_version'] . '/index.php';
                include_once MainApp_clfe::$compsPath . 'checkout/frontend/views/blocks/summary/' . $settings['summary_version'] . '/index.php';
            echo '</div>';
        }
        ?>



    </div>
</form>