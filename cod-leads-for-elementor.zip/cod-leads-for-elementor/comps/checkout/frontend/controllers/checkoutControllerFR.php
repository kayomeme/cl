<?php

/**
 */
class CheckoutControllerFR_clfe {

    public $settings;
    public $shippingOptions = [];

    public function __construct($cartSettings = null) {
        global $settingsModelId;
        $compoName = 'checkout';
        $settings = PublicCompo_clfe::getSettings($compoName, $settingsModelId);
        
        if(is_array($cartSettings) ) {
            $settings = array_merge($settings, $cartSettings);
        }

        $this->settings = $settings;
        $this->settings['shipping_fees'] = (int) preg_replace('/[^0-9]/', '', $this->settings['summary_shipping_title']);
        

        if ($settings['shipping_options_is_active'] == 'yes') {
            $this->shippingOptions = ShippingOptionsModelFR_clfe::getAll($settingsModelId);
        }   
    }

    public function getSettings() {
        return $this->settings;
    }

    public function index() {
        global $salesFunnel_clfe;
        global $mystore_clfe;
        global $sharedSettings;
        global $settingsModelId;
        global $isCartPage;
        global $isCheckoutPage;

        $settings = $this->settings;
        $mystoreSettings = $mystore_clfe->settings;
        

        $shippingOptions = $this->shippingOptions;
        
        $checkoutBlocksOrder    = explode(',', $settings['checkout_blocks_order']);
        $cartBlocksOrder        = isset($settings['cart_blocks_order']) ? explode(',', $settings['cart_blocks_order']) : [];


        include_once MainApp_clfe::$compsPath . 'checkout/frontend/views/index.php';
    }

    public function getJsCheckout() {
        global $sharedSettings;
        $jsCheckout = [];

        $jsCheckout['shipping_fees'] = (int) preg_replace('/[^0-9]/', '', $this->settings['summary_shipping_title']);
        $jsCheckout['summary_shipping_default_text'] = $this->settings['summary_shipping_title'];
        $jsCheckout['shipping_label'] = $this->settings['summary_shipping_label'];
        $jsCheckout['shipping_title'] = $this->settings['summary_shipping_title'];
        $jsCheckout['error_placement'] = $this->settings['error_placement'];
        
        //var_dump($this->settings['shipping_options']);

        $jsCheckout['shipping_options'] = $this->shippingOptions;
        
        $jsCheckout['default_status'] = $sharedSettings['default_status'];

        return jsonEncodeForJs_clfe($jsCheckout);
    }
}
