<?php

/**
 */
class CheckoutControllerFR_cl {

    public $settings;
    public $shippingOptions = [];
    public $checkoutFields = [];

    public function __construct($cartSettings = null) {
        global $settingsModelId;
        $compoName = 'checkout';
        $settings = PublicCompo_cl::getSettings($compoName, $settingsModelId);
        
        if(is_array($cartSettings) ) {
            $settings = array_merge($settings, $cartSettings);
        }

        $this->settings = $settings;
        $this->settings['shipping_fees'] = (int) preg_replace('/[^0-9]/', '', $this->settings['summary_shipping_title']);
        

        if ($settings['shipping_options_is_active'] == 'yes') {
            $this->shippingOptions = ShippingOptionsModelFR_cl::getAll($settingsModelId);
        }   
        
        $this->checkoutFields = CheckoutFieldsModelFR_cl::getAll($settingsModelId);
    }

    public function getSettings() {
        return $this->settings;
    }

    public function index() {
        global $salesFunnel_cl;
        global $mystore_cl;
        global $sharedSettings;
        global $settingsModelId;
        global $isCartPage;
        global $isCheckoutPage;
        
        global $iconsSelectorFR_cl;

        $settings = $this->settings;
        $mystoreSettings = $mystore_cl->settings;
        

        $shippingOptions = $this->shippingOptions;
        $checkoutFields = $this->checkoutFields;
        
        
        
        
        $checkoutBlocksOrder    = explode(',', $settings['checkout_blocks_order']);
        $cartBlocksOrder        = isset($settings['cart_blocks_order']) ? explode(',', $settings['cart_blocks_order']) : [];


        include_once MainApp_cl::$compsPath . 'checkout/frontend/views/index.php';
        
        //var_dump($checkoutFields);
    }

    public function getJsCheckout() {
        global $sharedSettings;
        $jsCheckout = [];

        $jsCheckout['shipping_fees'] = (int) preg_replace('/[^0-9]/', '', $this->settings['summary_shipping_title']);
        $jsCheckout['summary_shipping_default_text'] = $this->settings['summary_shipping_title'];
        $jsCheckout['shipping_label'] = $this->settings['summary_shipping_label'];
        $jsCheckout['shipping_title'] = $this->settings['summary_shipping_title'];
        $jsCheckout['error_placement'] = $this->settings['error_placement'];
        
        //var_dump($this->settings['shipping_options']);

        $jsCheckout['shipping_options'] = $this->shippingOptions;
        
        $jsCheckout['default_status'] = $sharedSettings['default_status'];

        return jsonEncodeForJs_cl($jsCheckout);
    }
}
