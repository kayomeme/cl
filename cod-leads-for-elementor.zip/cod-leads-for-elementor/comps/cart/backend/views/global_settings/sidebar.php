<button tab="cl_general_tab" _section="cl_cart_sections">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_cl::_e('General', 'cl') ?>
</button>
<button tab="cl_cart_products_tab" _section="cl_cart_products">
    <span class="dashicons dashicons-cart"></span>
    <?= Lang_cl::_e('Cart Products', 'cl') ?>
</button>
<button tab="cl_cart_totals_tab" _section="cl_cart_totals">
    <span class="dashicons dashicons-calculator"></span>
    <?= Lang_cl::_e('Cart Totals', 'cl') ?>
</button>
<button tab="cl_cart_coupon_tab" _section="cl_cart_coupon">
    <span class="dashicons dashicons-tickets-alt"></span>
    <?= Lang_cl::_e('Cart Coupon', 'cl') ?>
</button>
<button tab="cl_cart_actions_tab" _section="cl_cart_actions">
    <span class="dashicons dashicons-controls-play"></span>
    <?= Lang_cl::_e('Cart Actions', 'cl') ?>
</button>

<button tab="cl_cart_empty_tab" _section="cl_cart_empty">
    <span class="dashicons dashicons-controls-play"></span>
    <?= Lang_cl::_e('Cart Empty options', 'cl') ?>
</button>

<button tab="cl_cart_modal_tab" _section="cl_cart_modal">
    <span class="dashicons dashicons-controls-play"></span>
    <?= Lang_cl::_e('Cart Modal options', 'cl') ?>
</button>

<button tab="cl_cart_open_tab" _section="cl_cart_open">
    <span class="dashicons dashicons-controls-play"></span>
    <?= Lang_cl::_e('Cart open button', 'cl') ?>
</button>

<button tab="cl_cart_blocks_order_tab" _section="cl_cart_blocks_order">
    <span class="dashicons dashicons-layout"></span>
    <?= Lang_cl::_e('Cart Blocks Order', 'cl') ?>
</button>