<button tab="clfe_general_tab" _section="clfe_cart_sections">
    <span class="dashicons dashicons-admin-generic"></span>
    <?= Lang_clfe::_e('General', 'clfe') ?>
</button>
<button tab="clfe_cart_products_tab" _section="clfe_cart_products">
    <span class="dashicons dashicons-cart"></span>
    <?= Lang_clfe::_e('Cart Products', 'clfe') ?>
</button>
<button tab="clfe_cart_totals_tab" _section="clfe_cart_totals">
    <span class="dashicons dashicons-calculator"></span>
    <?= Lang_clfe::_e('Cart Totals', 'clfe') ?>
</button>
<button tab="clfe_cart_coupon_tab" _section="clfe_cart_coupon">
    <span class="dashicons dashicons-tickets-alt"></span>
    <?= Lang_clfe::_e('Cart Coupon', 'clfe') ?>
</button>
<button tab="clfe_cart_actions_tab" _section="clfe_cart_actions">
    <span class="dashicons dashicons-controls-play"></span>
    <?= Lang_clfe::_e('Cart Actions', 'clfe') ?>
</button>

<button tab="clfe_cart_empty_tab" _section="clfe_cart_empty">
    <span class="dashicons dashicons-controls-play"></span>
    <?= Lang_clfe::_e('Cart Empty options', 'clfe') ?>
</button>

<button tab="clfe_cart_blocks_order_tab" _section="clfe_cart_blocks_order">
    <span class="dashicons dashicons-layout"></span>
    <?= Lang_clfe::_e('Cart Blocks Order', 'clfe') ?>
</button>