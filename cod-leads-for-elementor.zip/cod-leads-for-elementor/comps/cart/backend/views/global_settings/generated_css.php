<?php


// dont remove the commented test because this block is also used the checkout summary
//if ($settings['cart_products_is_active'] == 'yes') {}
include 'blocks/cart_products/' . $settings['cart_products_version'] . '/generated_css.php';


// Cart Totals CSS
if ($settings['cart_totals_is_active'] == 'yes') {
    include 'blocks/cart_totals/' . $settings['cart_totals_version'] . '/generated_css.php';
}

// Cart Coupon CSS
if ($settings['cart_coupon_is_active'] == 'yes') {
    include 'blocks/cart_coupon/' . $settings['cart_coupon_version'] . '/generated_css.php';
}

// Cart Actions CSS
if ($settings['cart_actions_is_active'] == 'yes') {
    include 'blocks/cart_actions/' . $settings['cart_actions_version'] . '/generated_css.php';
}

if ($settings['cart_empty_is_active'] == 'yes') {
    include 'blocks/cart_empty/' . $settings['cart_empty_version'] . '/generated_css.php';
}

if ($sharedSettings['cart_mode'] == 'modal_left' || $sharedSettings['cart_mode'] == 'modal_right') { 
    include 'blocks/cart_modal/' . $settings['cart_modal_version'] . '/generated_css.php';
}

if ($settings['cart_open_is_active'] == 'yes') {
    include 'blocks/cart_open/' . $settings['cart_open_version'] . '/generated_css.php';
}

//include 'partials/generated_css/global.php';
?>
<style>
.cl-cart-wrapper {
    margin-top: 10px;
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
}
.cl-cart-wrapper > div {
    min-width: 40%;
    flex-grow: 1;
}
.cart_empty_text {
    <?= $settings['cart_empty_text_style'] ?>
}
@media screen and (max-width: 768px) {
    .cl-cart-wrapper {
        flex-direction: column;
    }
}    
        
</style>