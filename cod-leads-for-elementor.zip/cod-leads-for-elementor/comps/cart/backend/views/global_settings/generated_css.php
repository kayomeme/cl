<?php


// dont remove the commented test because this block is also used the checkout summary
//if ($settings['cart_products_is_active'] == 'yes') {}
include 'blocks/cart_products/' . $settings['cart_products_version'] . '/generated_css.php';


// Cart Totals CSS
if ($settings['cart_totals_is_active'] == 'yes') {
    include 'blocks/cart_totals/' . $settings['cart_totals_version'] . '/generated_css.php';
}

// Cart Coupon CSS
if ($settings['cart_coupon_is_active'] == 'yes') {
    include 'blocks/cart_coupon/' . $settings['cart_coupon_version'] . '/generated_css.php';
}

// Cart Actions CSS
if ($settings['cart_actions_is_active'] == 'yes') {
    include 'blocks/cart_actions/' . $settings['cart_actions_version'] . '/generated_css.php';
}

if ($settings['cart_empty_is_active'] == 'yes') {
    include 'blocks/cart_empty/' . $settings['cart_empty_version'] . '/generated_css.php';
}

//include 'partials/generated_css/global.php';
?>
<style>
.clfe-cart-wrapper {
    margin-top: 10px;
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
}
.clfe-cart-wrapper > div {
    min-width: 40%;
    flex-grow: 1;
}
.cart_empty_text {
    <?= $settings['cart_empty_text_style'] ?>
}
@media screen and (max-width: 768px) {
    .clfe-cart-wrapper {
        flex-direction: column;
    }
}    


<?php if ($sharedSettings['cart_mode'] == 'modal_left' || $sharedSettings['cart_mode'] == 'modal_right') { ?>
        #clfe-cartside {
            inset-block: .001px 0;
            display: flex;
            flex-direction: column;
            transform: none;
            right: <?= $sharedSettings['cart_mode'] == 'modal_right' ? 0 : 'auto' ?>;
            left: <?= $sharedSettings['cart_mode'] == 'modal_left' ? 0 : 'auto' ?>;
            position: fixed;
            overflow: hidden;
            overflow-y: auto;
            z-index: 1000000;
            width: min(340px, 100vw);
            background-color: #fff;
            <?= $settings['cart_container_style'] ?>
        }
        .cart-modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            padding-bottom: 10px;
        }
        .cart-modal-body {
            display: flex;
            flex-direction: column;
            height: 100%;
            justify-content: space-between;
        }
        .cart-modal-body > div:last-child {
            /*flex-grow: 1;*/
            flex-direction: column;
            display: flex;
            justify-content: flex-end;
        }
        .cart-modal-title {
            <?= $settings['cart_modal_title_style'] ?>
        }
        #cart-modal-close-button {
            <?= $settings['cart_modal_close_style'] ?>
        }
        
        /*---custom for cart_products block ----*/
        #clfe-cartside .cart-product {
            min-width: 85%;
        }
        #clfe-cartside .clfe_cart_products_display {
            /*flex-wrap: nowrap;*/
            column-gap: 2px;
            overflow-x: scroll;
            scrollbar-width: thin;
            scrollbar-color: #00BCD4 transparent;
        }
        
        /*---custom for cart_actions block ----*/
        #clfe-cartside .cart-product-actions {
            position: absolute;
            width: 100%;
            flex-direction: row;
            padding: 0px 5px;
        }
        #clfe-cartside .cart-product-actions .clfe-button {
            /*min-width: 40%;*/
        }
        
<?php } ?>
        
</style>