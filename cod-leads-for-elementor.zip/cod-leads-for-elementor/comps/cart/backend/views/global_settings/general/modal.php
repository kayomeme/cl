<div class="clfe-th-full">
    <label>
        <?= Lang_clfe::_e('Cart modal settings', 'clfe') ?>
    </label>
</div>
<div class="clfe-th-full">
    <div class="clfe-row">
        <div class="clfe-th">
            <label>
                <?= Lang_clfe::_e('Header', 'clfe') ?>
            </label> 
        </div>
        <div class="clfe-td clfe-sub-section">
    <div class="clfe-row">
        <div class="clfe-th">
            <label>
                <?= Lang_clfe::_e('Title', 'clfe') ?>
            </label> 
        </div>
        <div class="clfe-td clfe-style-container">
            <input type="text" name="cart_modal_title" value="<?= $settings['cart_modal_title'] ?>">
            <?php
            $activeOptions = [
                'modalTitle' => Lang_clfe::__('Modal title style', 'clfe'),
                'styleAttachedTo' => '.cart-modal-title',
                'font' => 'yes'
            ];
            $adminStyle->getAllCss('cart_modal_title_style', $settings['cart_modal_title_style'], $activeOptions);
            ?>
        </div>
    </div>
    <div class="clfe-row">
        <div class="clfe-th">
            <label>
                <?= Lang_clfe::_e('Close button', 'clfe') ?>
            </label> 
        </div>
        <div class="clfe-td clfe-style-container">
            <input type="text" name="cart_modal_close_text" value="<?= $settings['cart_modal_close_text'] ?>">
            <?php
            $activeOptions = [
                'modalTitle' => Lang_clfe::__('Close button style', 'clfe'),
                'styleAttachedTo' => '.cart-modal-close-button',
                'font' => 'yes', 'border' => 'yes', 'padding' => 'yes', 'linear-gradient' => 'yes'
            ];
            $adminStyle->getAllCss('cart_modal_close_style', $settings['cart_modal_close_style'], $activeOptions);
            ?>
        </div>
    </div>
        </div>
    </div>
    



</div>