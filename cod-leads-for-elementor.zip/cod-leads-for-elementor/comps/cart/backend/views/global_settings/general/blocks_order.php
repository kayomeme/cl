<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Cart Sections Order', 'clfe') ?>
        </label>
        <div class="clfe-alert clfe-alert-info">
            <?= Lang_clfe::_e('Drag and drop to reorder the sections in your cart. The new order will update how they appear on the frontend.', 'clfe') ?>
        </div>
    </div>
    <div class="clfe-td">
        <input type="hidden"  name="cart_blocks_order" value="<?= $settings['cart_blocks_order'] ?>">

        <div class="clfe-sub-section">
            <div id="clfe-cart-elements">
            <?php 
                foreach ($cartBlocksOrder as $cartElement) {
                    include 'sidebar_cart_elements/'.$cartElement.'.php';
                }
            ?>
            </div>
        </div>
        <div class="clfe-alert clfe-alert-info">
                <?= Lang_clfe::_e('To change the order of display on the frontend, simply drag and drop the elements in the list.', 'clfe') ?>
        </div>
    </div>
</div>