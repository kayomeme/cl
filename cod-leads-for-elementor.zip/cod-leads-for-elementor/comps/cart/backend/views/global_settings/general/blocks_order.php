<div class="cl-row ">
    <div class="cl-th">
        <label>
            <?= Lang_cl::_e('Cart Sections Order', 'cl') ?>
        </label>
        <div class="cl-alert cl-alert-info">
            <?= Lang_cl::_e('Drag and drop to reorder the sections in your cart. The new order will update how they appear on the frontend.', 'cl') ?>
        </div>
    </div>
    <div class="cl-td">
        <input type="hidden"  name="cart_blocks_order" value="<?= $settings['cart_blocks_order'] ?>">

        <div class="cl-sub-section">
            <div id="cl-cart-elements">
            <?php 
                foreach ($cartBlocksOrder as $cartElement) {
                    include 'sidebar_cart_elements/'.$cartElement.'.php';
                }
            ?>
            </div>
        </div>
        <div class="cl-alert cl-alert-info">
                <?= Lang_cl::_e('To change the order of display on the frontend, simply drag and drop the elements in the list.', 'cl') ?>
        </div>
    </div>
</div>