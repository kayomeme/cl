<div class="cl-row" _attachedsection="cart_empty">
    <span class="dashicons dashicons-button"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Cart Empty', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>