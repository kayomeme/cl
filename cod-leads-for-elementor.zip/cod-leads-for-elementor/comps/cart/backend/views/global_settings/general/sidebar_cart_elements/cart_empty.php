<div class="clfe-row" _attachedsection="cart_empty">
    <span class="dashicons dashicons-button"></span>
    <span class="clfe-label-draggable">
        <?= Lang_clfe::_e('Cart Empty', 'clfe') ?>
    </span>
    <div class="clfe-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>