<div class="cl-row" _attachedsection="cart_coupon">
    <span class="dashicons dashicons-button"></span>
    <span class="cl-label-draggable">
        <?= Lang_cl::_e('Cart Coupon', 'cl') ?>
    </span>
    <div class="cl-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>