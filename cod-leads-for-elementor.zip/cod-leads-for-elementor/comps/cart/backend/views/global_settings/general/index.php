<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Cart container', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is active', 'clfe') ?>
                    </label> 
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['cart_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="cart_is_active" value="<?= $settings['cart_is_active'] ?>">
                    </label>

                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Cart container style', 'clfe'),
                            'styleAttachedTo' => '.clfe-cart-container',
                            'border' => 'yes', 'padding' => 'yes', 'linear-gradient' => 'yes', 'box-shadow' => 'yes'
                        ];
                        $adminStyle->getAllCss('cart_container_style', $settings['cart_container_style'], $activeOptions); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="clfe-row cart-modal-settings">
    <?php include 'modal.php'; ?>
</div>