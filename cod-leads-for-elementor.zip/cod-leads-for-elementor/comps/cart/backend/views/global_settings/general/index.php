<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Cart container', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_is_active',
                        'value' => $settings['cart_is_active']
                    ]);
                    
                    $styleManager->getAllCss('cart_container_style', $activeOptions = [
                        'modal_title' => Lang_cl::__('Cart container style', 'cl'),
                        'style_attached_to' => '.cl-cart-container',
                        'border' => 'yes','border-radius' => 'yes', 
                        'padding' => 'yes', 
                        'linear-gradient' => 'yes', 
                        'box-shadow' => 'yes'
                    ]); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>