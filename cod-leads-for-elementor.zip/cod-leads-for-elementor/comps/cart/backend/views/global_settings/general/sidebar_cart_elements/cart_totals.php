<div class="clfe-row" _attachedsection="cart_totals">
    <span class="dashicons dashicons-button"></span>
    <span class="clfe-label-draggable">
        <?= Lang_clfe::_e('Cart Totals', 'clfe') ?>
    </span>
    <div class="clfe-draggable-icons-container">
        <span class="dashicons dashicons-move"></span>
    </div>
</div>