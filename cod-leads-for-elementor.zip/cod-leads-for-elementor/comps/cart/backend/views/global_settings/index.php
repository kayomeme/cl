<div id="cl_general_tab" class="cl-single-tab">
    <?php include 'general/index.php'; ?>
</div>

<div id="cl_cart_products_tab" class="cl-single-tab">
    <?php include 'blocks/cart_products/'.$settings['cart_products_version'].'/index.php'; ?>
</div>

<div id="cl_cart_totals_tab" class="cl-single-tab">
    <?php include 'blocks/cart_totals/'.$settings['cart_totals_version'].'/index.php'; ?>
</div>

<div id="cl_cart_coupon_tab" class="cl-single-tab">
    <?php include 'blocks/cart_coupon/'.$settings['cart_coupon_version'].'/index.php'; ?>
</div>

<div id="cl_cart_actions_tab" class="cl-single-tab">
    <?php include 'blocks/cart_actions/'.$settings['cart_actions_version'].'/index.php'; ?>
</div>

<div id="cl_cart_empty_tab" class="cl-single-tab">
    <?php include 'blocks/cart_empty/'.$settings['cart_empty_version'].'/index.php'; ?>
</div>

<div id="cl_cart_modal_tab" class="cl-single-tab">
    <?php include 'blocks/cart_modal/'.$settings['cart_modal_version'].'/index.php'; ?>
</div>

<div id="cl_cart_open_tab" class="cl-single-tab">
    <?php include 'blocks/cart_open/'.$settings['cart_open_version'].'/index.php'; ?>
</div>

<div id="cl_cart_blocks_order_tab" class="cl-single-tab">
    <?php include 'general/blocks_order.php'; ?>
</div>

<div style="display: none">
<input type="text" name="cart_blocks_order" value="<?= $settings['cart_blocks_order'] ?>">
<input type="text" name="cart_products_version" value="<?= $settings['cart_products_version'] ?>">
<input type="text" name="cart_totals_version" value="<?= $settings['cart_totals_version'] ?>">
<input type="text" name="cart_coupon_version" value="<?= $settings['cart_coupon_version'] ?>">
<input type="text" name="cart_actions_version" value="<?= $settings['cart_actions_version'] ?>">
<input type="text" name="cart_empty_version" value="<?= $settings['cart_empty_version'] ?>">
<input type="text" name="cart_modal_version" value="<?= $settings['cart_modal_version'] ?>">
<input type="text" name="cart_open_version" value="<?= $settings['cart_open_version'] ?>">
</div>