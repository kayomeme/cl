<div id="clfe_general_tab" class="clfe-single-tab">
    <?php include 'general/index.php'; ?>
</div>

<div id="clfe_cart_products_tab" class="clfe-single-tab">
    <?php include 'blocks/cart_products/'.$settings['cart_products_version'].'/index.php'; ?>
</div>

<div id="clfe_cart_totals_tab" class="clfe-single-tab">
    <?php include 'blocks/cart_totals/'.$settings['cart_totals_version'].'/index.php'; ?>
</div>

<div id="clfe_cart_coupon_tab" class="clfe-single-tab">
    <?php include 'blocks/cart_coupon/'.$settings['cart_coupon_version'].'/index.php'; ?>
</div>

<div id="clfe_cart_actions_tab" class="clfe-single-tab">
    <?php include 'blocks/cart_actions/'.$settings['cart_actions_version'].'/index.php'; ?>
</div>

<div id="clfe_cart_empty_tab" class="clfe-single-tab">
    <?php include 'blocks/cart_empty/'.$settings['cart_empty_version'].'/index.php'; ?>
</div>

<div id="clfe_cart_blocks_order_tab" class="clfe-single-tab">
    <?php include 'general/blocks_order.php'; ?>
</div>

<input type="text" name="cart_blocks_order" value="<?= $settings['cart_blocks_order'] ?>">
<input type="text" name="cart_products_version" value="<?= $settings['cart_products_version'] ?>">
<input type="text" name="cart_totals_version" value="<?= $settings['cart_totals_version'] ?>">
<input type="text" name="cart_coupon_version" value="<?= $settings['cart_coupon_version'] ?>">
<input type="text" name="cart_actions_version" value="<?= $settings['cart_actions_version'] ?>">
<input type="text" name="cart_empty_version" value="<?= $settings['cart_empty_version'] ?>">