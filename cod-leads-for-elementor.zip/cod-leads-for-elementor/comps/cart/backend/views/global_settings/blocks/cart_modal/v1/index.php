<div class="cart-modal-settings">
    <div class="cl-row">
        <div class="cl-th">
            <?= Lang_cl::_e('Cart modal container style', 'cl') ?>
        </div>
        <div class="cl-td">
            <?php
            $styleManager->getAllCss('cart_modal_container_style');
            ?>
        </div>
    </div>
    <div class="cl-th-full">
        <div class="cl-row">
            <div class="cl-th">
                <?= Lang_cl::_e('Header', 'cl') ?>
            </div>
            <div class="cl-td cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Container style', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getAllCss('cart_modal_header_container_style');
                        ?>
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Title', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <input type="text" name="cart_modal_header_title" value="<?= $settings['cart_modal_header_title'] ?>">
                        <?php
                        $styleManager->getAllCss('cart_modal_header_title_style');
                        ?>
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Close button', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <input type="text" name="cart_modal_header_close_text" value="<?= $settings['cart_modal_header_close_text'] ?>">
                        <?php
                        $styleManager->getAllCss('cart_modal_header_close_style');
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>