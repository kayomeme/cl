<style>
    .cl_cart_totals {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        column-gap: 15px;
        justify-content: space-between;
        <?= $settings['cart_totals_container_style'] ?>
    }
    .cl_cart_totals .total-row {
        display: flex;
        justify-content: space-between;
        width: 100%;
    }
    .cl_cart_totals .total-label {
        <?= $settings['cart_totals_label_style'] ?>
    }
    .cl_cart_totals .total-value {
        display: flex;
        column-gap: 10px;
    }
    .cl_cart_totals .cart-regular-total {
        text-decoration: line-through;
        <?= $settings['cart_totals_regular_price_style'] ?>
    }

    .cl_cart_totals .cart-sale-total {
        <?= $settings['cart_totals_sale_price_style'] ?>
    }
    @media screen and (max-width: 768px) {
        .cl_cart_totals {
            padding: 15px;
            min-width: 100%;
        }
    }
</style>