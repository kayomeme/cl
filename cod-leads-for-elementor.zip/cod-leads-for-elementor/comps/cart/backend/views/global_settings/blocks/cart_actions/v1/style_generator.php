<?php
return array(
    'cart_actions_container_style' => [
        'modal_title' => Lang_cl::__('Cart Actions: Container styling', 'cl'),
        'style_attached_to' => '#cl_cart_actions',
        'single_css_supported' => ['margin-top'],
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes', 
        'background' => 'yes'
    ],
    'cart_actions_checkout_button_style' => [
        'modal_title' => Lang_cl::__('Checkout button style', 'cl'),
        'style_attached_to' => '.cl_cart_actions .goto-checkout-button',
        'font' => 'yes', 
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes', 
        'background' => 'yes'
    ],
    'cart_actions_continue_button_style' => [
        'modal_title' => Lang_cl::__('Continue button style', 'cl'),
        'style_attached_to' => '.cl_cart_actions .continue-button',
        'font' => 'yes', 
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes', 
        'background' => 'yes'
    ],
);