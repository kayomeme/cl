<?php return array (
  'setting' => 
  array (
    'cart_coupon_is_active' => 'no',
    'cart_coupon_version' => 'v1',
  ),
  'lang' => 
  array (
    'cart_coupon_title' => 'Appliquer un coupon',
    'cart_coupon_placeholder' => 'Entrez le code promo',
    'cart_coupon_button_text' => 'Appliquer',
    'cart_coupon_success_message' => 'Coupon appliqué avec succès',
    'cart_coupon_error_message' => 'Code coupon invalide',
  ),
  'style' => 
  array (
    'cart_coupon_container_style' => 'margin-top:16px;',
    'cart_coupon_input_style' => 'font-size:14px;color:#111827;border:1px solid #d1d5db;border-radius:6px;padding:10px 12px;',
    'cart_coupon_button_style' => 'font-size:14px;color:#3b82f6;font-weight:600;border:1px solid #d1d5db;border-radius:6px;padding:10px 16px;background-color:#f9fafb;',
  ),
);