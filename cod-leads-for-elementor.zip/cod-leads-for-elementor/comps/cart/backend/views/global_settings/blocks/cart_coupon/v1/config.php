<?php return array (
  'setting' => 
  array (
    'cart_coupon_is_active' => 'yes',
    'cart_coupon_version' => 'v1',
  ),
  'lang' => 
  array (
    'cart_coupon_title' => 'Apply Coupon',
    'cart_coupon_placeholder' => 'Enter promo code',
    'cart_coupon_button_text' => 'Apply',
    'cart_coupon_success_message' => 'Coupon applied successfully',
    'cart_coupon_error_message' => 'Invalid coupon code',
  ),
  'style' => 
  array (
    'cart_coupon_container_style' => 'border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:#eee2e2;border-style:solid;border-radius:0px;padding:15px;margin:0px;background-color:#ffffff;',
    'cart_coupon_input_style' => 'font-size:14px;color:#000000;border:1px solid #ddd;border-radius:4px;padding:8px 12px;',
    'cart_coupon_button_style' => 'font-size:14px;color:#3b82f6;font-weight:500;text-align:center;border:1px solid #3b82f6;border-radius:4px;padding:8px 16px;background-color:#ffffff;',
  ),
);