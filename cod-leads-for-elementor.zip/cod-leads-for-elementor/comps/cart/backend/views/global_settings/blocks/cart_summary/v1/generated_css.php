<style>
.clfe-cart-summary {
    margin-top: 10px;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    column-gap: 20px;
    justify-content: space-between;
    <?= $settings['cart_summary_container_style'] ?>
}
.clfe-cart-summary .cart-summary-body {
    display: flex;
    flex-wrap: wrap;
    flex-grow: 1;
    align-items: center;
    column-gap: 20px;
    justify-content: space-between;
}
.clfe-cart-summary .cart-summary-body > div {
    flex: 1;
    min-width: 100%;
    padding: 5px 0px;
}

.cart-summary-total {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    column-gap: 15px;
    max-width: 500px;
    justify-content: space-between;
}

.cart-summary-coupon {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.cart-summary-coupon div:first-child {
    display: flex;
    justify-content: space-between;
}
.cart-summary-coupon .promo-input-group {display:flex;gap:8px;}

.clfe-cart-summary .total-label {<?= $settings['cart_summary_total_label_style'] ?>}
.clfe-cart-summary .total-value {
    display: flex;
    column-gap: 10px;
    <?= $settings['cart_summary_total_value_style'] ?>
}

.clfe-cart-summary .cart-buttons {
    display: flex;
    flex: 1;
    justify-content: end;
}
.cart-buttons .goto-checkout {
    max-width: 500px;
    text-decoration: none;
    <?= $settings['cart_summary_goto_checkout_style'] ?>
}
@media screen and (max-width: 768px) {
    .clfe-cart-summary {padding:15px;}
    .clfe-cart-summary .cart-summary-body {grid-template-columns:1fr;}
    .clfe-cart-summary .promo-input-group {flex-direction:column;}
}
</style>