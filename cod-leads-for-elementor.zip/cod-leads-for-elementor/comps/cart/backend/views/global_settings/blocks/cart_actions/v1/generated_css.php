<style>
.cl_cart_actions {
    display: flex;
    align-items: end;
    justify-content: flex-end;
    gap: 10px;
    <?= $settings['cart_actions_container_style'] ?>
}
.cl_cart_actions .action-buttons {
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-width: 400px;
    width: 100%;
}
.cl_cart_actions .goto-checkout-button {
    text-decoration: none;
    <?= $settings['cart_actions_checkout_button_style'] ?>
}
.cl_cart_actions .continue-button {
    text-decoration: none;
    <?= $settings['cart_actions_continue_button_style'] ?>
}
</style>