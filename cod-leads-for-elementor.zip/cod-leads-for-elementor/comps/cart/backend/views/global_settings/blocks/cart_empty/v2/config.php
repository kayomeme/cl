<?php return array (
  'setting' => 
  array (
    'cart_empty_is_active' => 'no',
    'cart_empty_version' => 'v1',
    'cart_empty_show_icon' => 'yes',
    'cart_empty_subtext_is_active' => 'yes',
    'cart_empty_continue_is_active' => 'yes',
    'cart_empty_continue_custom_url_is_active' => 'no',
    'cart_empty_continue_custom_url' => '',
  ),
  'lang' => 
  array (
    'cart_empty_text' => 'Your cart is empty 222',
    'cart_empty_subtext' => 'Looks like you haven\'t added any items to your cart yet 222',
    'cart_empty_continue_text' => 'Continue Shopping 222',
  ),
  'style' => 
  array (
    'cart_empty_container_style' => 'padding:40px 15px;margin-bottom:20px;background-color:#ffffff;text-align:center;',
    'cart_empty_icon_style' => 'max-width:100px;font-size:16px;color:#d62d20;font-weight:700;text-align:initial;',
    'cart_empty_text_style' => 'font-size:20px;color:#333333;font-weight:600;',
    'cart_empty_subtext_style' => 'font-size:16px;color:#666666;',
    'cart_empty_continue_button_style' => 'font-size:16px;color:#3b82f6;font-weight:600;text-align:center;border:1px solid #3b82f6;border-radius:4px;background-color:#ffffff;',
  ),
);