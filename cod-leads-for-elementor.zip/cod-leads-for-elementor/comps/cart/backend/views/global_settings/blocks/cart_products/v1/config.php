<?php return array (
  'setting' => 
  array (
    'cart_products_is_active' => 'yes',
    'cart_products_version' => 'v1',
    'cart_products_header_is_open' => 'yes',
    'cart_products_header_is_active' => 'no',
    'cart_products_title_is_active' => 'yes',
    'cart_products_image_is_active' => 'yes',
    'cart_products_variations_is_active' => 'yes',
    'cart_products_regular_price_is_active' => 'yes',
    'cart_products_sale_price_is_active' => 'yes',
    'cart_products_edit_button_is_active' => 'yes',
    'cart_products_remove_button_is_active' => 'yes',
  ),
  'lang' => 
  array (
    'cart_products_header_title_is_open' => '⇡ Your cart',
    'cart_products_header_title_is_closed' => '⇣ Open your cart',
    'cart_products_header_count_text' => 'products',
    'cart_products_edit_button_text' => 'Update',
    'cart_products_remove_button_text' => 'Remove',
  ),
  'style' => 
  array (
    'cart_products_container_style' => '',
    'cart_products_header_title_style' => 'font-size:14px;color:#008000;font-weight:700;text-align:center;',
    'cart_products_header_count_text_style' => 'font-size:12px;color:#008000;font-weight:700;text-align:initial;',
    'cart_product_container_style' => 'max-height:px;min-height:px;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-color:#eeeeee;border-style:solid;border-top-left-radius:px;border-top-right-radius:px;border-bottom-left-radius:px;border-bottom-right-radius:px;padding-top:px;padding-right:px;padding-bottom:px;padding-left:px;background-image:;',
    'cart_products_title_style' => '',
    'cart_products_img_style' => 'width:80px;border-top-width:px;border-right-width:px;border-bottom-width:px;border-left-width:px;border-color:;border-style:solid;border-top-left-radius:2px;border-top-right-radius:2px;border-bottom-left-radius:2px;border-bottom-right-radius:2px;',
    'cart_products_variations_style' => 'font-size:11px;color:;font-weight:700;text-align:initial;border-top-width:px;border-right-width:px;border-bottom-width:px;border-left-width:px;border-color:;border-style:solid;border-top-left-radius:px;border-top-right-radius:px;border-bottom-left-radius:px;border-bottom-right-radius:px;',
    'cart_products_regular_price_style' => '',
    'cart_products_sale_price_style' => '',
    'cart_products_edit_button_style' => 'font-size:14px;color:#2980b9;',
    'cart_products_remove_button_style' => 'font-size:14px;color:#e74c3c;',
  ),
);