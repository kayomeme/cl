<?php return array (
  'setting' => 
  array (
    'cart_products_is_active' => 'yes',
    'cart_products_version' => 'v1',
    'cart_products_header_is_open' => 'yes',
    'cart_products_header_is_active' => 'yes',
    'cart_products_title_is_active' => 'yes',
    'cart_products_image_is_active' => 'yes',
    'cart_products_variations_is_active' => 'yes',
    'cart_products_regular_price_is_active' => 'yes',
    'cart_products_sale_price_is_active' => 'yes',
    'cart_products_edit_button_is_active' => 'no',
    'cart_products_remove_button_is_active' => 'yes',
    'cart_products_preview_is_active' => 'no',
  ),
  'lang' => 
  array (
    'cart_products_header_title_is_open' => '⇡ Votre panier',
    'cart_products_header_title_is_closed' => '⇣ Ouvrir votre panier',
    'cart_products_header_count_text' => 'produits',
    'cart_products_preview_prefix_text' => 'Cart: ',
    'cart_products_edit_button_text' => '',
    'cart_products_remove_button_text' => '',
  ),
  'style' => 
  array (
    'cart_products_container_style' => 'padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;margin-top:12px;',
    'cart_products_header_container_style' => 'padding-bottom:12px;border-bottom-width:1px;border-color:#e5e7eb;border-style:solid;',
    'cart_products_header_title_style' => 'font-size:18px;color:#111827;font-weight:600;',
    'cart_products_header_count_text_style' => 'font-size:14px;color:#6b7280;font-weight:normal;margin-left:8px;',
    'cart_products_header_icon_style' => '',
    'cart_products_preview_style' => '',
    'cart_products_body_container_style' => 'padding-top:16px;padding-right:0px;padding-bottom:16px;padding-left:0px;',
    'cart_product_container_style' => 'border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:#f3f4f6;border-style:solid;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;',
    'cart_products_title_style' => 'font-size:14px;color:#111827;font-weight:600;margin-bottom:4px;',
    'cart_products_img_style' => 'width:64px;height:64px;object-fit:cover;border-radius:8px;',
    'cart_products_variations_style' => 'font-size:12px;color:#6b7280;font-weight:normal;',
    'cart_products_regular_price_style' => 'font-size:13px;color:#6b7280;font-weight:normal;',
    'cart_products_sale_price_style' => 'font-size:14px;color:#111827;font-weight:600;',
    'cart_products_edit_button_style' => '',
    'cart_products_remove_button_style' => 'font-size:20px;color:#9ca3af;font-weight:normal;padding-top:4px;padding-right:4px;padding-bottom:4px;padding-left:4px;',
  ),
);