<?php
return array(
    'cart_coupon_container_style' => [
        'modal_title' => Lang_cl::__('Cart Coupon: Container styling', 'cl'),
        'style_attached_to' => '#cl_cart_coupon',
        'single_css_supported' => ['margin-top'],
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes', 
        'background' => 'yes'
    ],
);