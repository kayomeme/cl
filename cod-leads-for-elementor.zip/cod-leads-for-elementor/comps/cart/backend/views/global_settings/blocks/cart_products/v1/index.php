<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Cart Products Section', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_products_is_active',
                        'value' => $settings['cart_products_is_active']
                    ]);
                    
                    $styleManager->getAllCss('cart_products_container_style');
                    ?>
                </div>
            </div>
            <?php $styleManager->getSingleCss('margin-top', 'cart_products_container_style'); ?>
        </div>
    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Cart Products Header', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_products_header_is_active',
                        'value' => $settings['cart_products_header_is_active']
                    ]);
                    $styleManager->getAllCss('cart_products_header_container_style');
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is open by default', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_products_header_is_open',
                        'value' => $settings['cart_products_header_is_open']
                    ]);
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Title', 'cl') ?>
                </div>
                <div class="cl-td cl-sub-section">
                    <div class="cl-row">
                        <div class="cl-th">
                            <?= Lang_cl::_e('Style', 'cl') ?>
                        </div>
                        <div class="cl-td">
                            <?php $styleManager->getAllCss('cart_products_header_title_style'); ?>
                        </div>
                    </div>
                    <div class="cl-row">
                        <div class="cl-th">
                            <?= Lang_cl::_e('Is open', 'cl') ?>
                        </div>
                        <div class="cl-td cl-style-container">
                            <input type="text" name="cart_products_header_title_is_open" textAttachedTo=".cart_products_header_title_is_open" 
                                   value="<?= $settings['cart_products_header_title_is_open'] ?>" placeholder="<?= Lang_cl::_e('Title when the section is open', 'cl') ?>">
                        </div>
                    </div>
                    <div class="cl-row">
                        <div class="cl-th">
                            <?= Lang_cl::_e('Is closed', 'cl') ?>
                        </div>
                        <div class="cl-td">
                            <input type="text" name="cart_products_header_title_is_closed" textAttachedTo=".cart_products_header_title_is_closed" 
                                   value="<?= $settings['cart_products_header_title_is_closed'] ?>" placeholder="<?= Lang_cl::_e('Title when the section is closed', 'cl') ?>">
                        </div>
                    </div>
                </div>
            </div>

            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Count text', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <input type="text" name="cart_products_header_count_text" textAttachedTo=".cart-products-header-count-text .count_text" 
                           value="<?= $settings['cart_products_header_count_text'] ?>" placeholder="<?= Lang_cl::_e('Cart items count text', 'cl') ?>">
                    <?php
                    $styleManager->getAllCss('cart_products_header_count_text_style');
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Icons style', 'cl') ?>
                </div>
                <div class="cl-td">
                    <?php
                    $styleManager->getAllCss('cart_products_header_icon_style');
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Selected Cart Preview', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_products_preview_is_active',
                        'value' => $settings['cart_products_preview_is_active']
                    ]);

                    $styleManager->getAllCss('cart_products_preview_style');
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Prefix text', 'cl') ?>
                </div>
                <div class="cl-td">
                    <input type="text" name="cart_products_preview_prefix_text" textAttachedTo=".cart_products_preview .prefix_text" 
                           value="<?= $settings['cart_products_preview_prefix_text'] ?>" placeholder="<?= Lang_cl::_e('Text before cart summary', 'cl') ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="cl-alert cl-alert-info">
        <?= Lang_cl::_e('This preview will only show when the section is collapsed, allowing users to quickly see their cart summary without expanding the full section.', 'cl') ?>                    
    </div>
</div>

<div class="cl-row ">
    <div class="cl-th">
        <?= Lang_cl::_e('Cart Products Body Container', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Container style', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getAllCss('cart_products_body_container_style');
                    ?>
                </div>
            </div>

        </div>

    </div>
</div>

<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Product box', 'cl'); ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Container style', 'cl'); ?>
                </div>
                <div class="cl-td">
                    <?php
                    $styleManager->getAllCss('cart_product_container_style');
                    ?>
                </div>
            </div>

            <div class="cl-row cl-row-is-title">
                <?= Lang_cl::_e('Product Box elements', 'cl') ?> :
            </div>

            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Title', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_products_title_is_active',
                        'value' => $settings['cart_products_title_is_active']
                    ]);

                    $styleManager->getAllCss('cart_products_title_style');
                    ?>
                </div>
            </div>

            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Image', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_products_image_is_active',
                        'value' => $settings['cart_products_image_is_active']
                    ]);
                    
                    $styleManager->getAllCss('cart_products_img_style');
                    ?>
                </div>
            </div>

            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Variations items', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_products_variations_is_active',
                        'value' => $settings['cart_products_variations_is_active']
                    ]);

                    $styleManager->getAllCss('cart_products_variations_style');
                    ?>
                </div>
            </div>

            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Regular price', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_products_regular_price_is_active',
                        'value' => $settings['cart_products_regular_price_is_active']
                    ]);
                    
                    $styleManager->getAllCss('cart_products_regular_price_style');
                    ?>
                </div>
            </div>

            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Sale price', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_products_sale_price_is_active',
                        'value' => $settings['cart_products_sale_price_is_active']
                    ]);

                    $styleManager->getAllCss('cart_products_sale_price_style');
                    ?>
                </div>
            </div>

            <!-- New settings for Edit button -->
            <div class="cl-row">
                <div class="cl-sub-section">
                    <div class="cl-row">
                        <div class="cl-th">
                            <?= Lang_cl::_e('Edit button', 'cl') ?>
                        </div>
                        <div class="cl-td cl-style-container">
                            <?php
                            $styleManager->getSwitchButton([
                                'name' => 'cart_products_edit_button_is_active',
                                'value' => $settings['cart_products_edit_button_is_active']
                            ]);

                            $styleManager->getAllCss('cart_products_edit_button_style');
                            ?>
                        </div>
                    </div>
                    <div class="cl-row">
                        <div class="cl-td-full">
                            <div class="cl-input-group">
                                <input type="text" name="cart_products_edit_button_text" value="<?= $settings['cart_products_edit_button_text'] ?>" placeholder="<?= Lang_cl::_e('Edit button text', 'cl') ?>">
                                <div class="cl-alert cl-alert-info">
                                    <?= Lang_cl::_e('Leave it empty to only show the icon', 'cl') ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- New settings for Remove button -->
            <div class="cl-row">
                <div class="cl-sub-section">
                    <div class="cl-row">
                        <div class="cl-th">
                            <?= Lang_cl::_e('Remove button', 'cl') ?>
                        </div>
                        <div class="cl-td cl-style-container">
                            <?php
                            $styleManager->getSwitchButton([
                                'name' => 'cart_products_remove_button_is_active',
                                'value' => $settings['cart_products_remove_button_is_active']
                            ]);

                            $styleManager->getAllCss('cart_products_remove_button_style');
                            ?>
                        </div>
                    </div>
                    <div class="cl-row">
                        <div class="cl-td-full">
                            <div class="cl-input-group">
                                <input type="text" name="cart_products_remove_button_text" value="<?= $settings['cart_products_remove_button_text'] ?>" placeholder="<?= Lang_cl::_e('Remove button text', 'cl') ?>">
                                <div class="cl-alert cl-alert-info">
                                    <?= Lang_cl::_e('Leave it empty to only show the icon', 'cl') ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>