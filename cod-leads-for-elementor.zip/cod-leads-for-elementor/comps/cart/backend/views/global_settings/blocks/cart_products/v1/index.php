<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Section', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_products_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_products_is_active" value="<?= $settings['cart_products_is_active'] ?>">
                    </label>
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Cart : Container styling', 'clfe'),
                        'styleAttachedTo' => '.clfe_cart_products',
                        'border' => 'yes',
                        'background' => 'yes',
                        'padding' => 'yes',
                    ];
                    $adminStyle->getAllCss('cart_products_container_style', $settings['cart_products_container_style'], $activeOptions);
                    ?>
                </div>
            </div>
            <?php $adminStyle->getSingleCss('margin-top', 'cart_products_container_style', $settings['cart_products_container_style']); ?>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is open by default', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_products_header_is_open'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_products_header_is_open" value="<?= $settings['cart_products_header_is_open'] ?>">
                    </label>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="clfe-row ">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Header', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_products_header_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_products_header_is_active" value="<?= $settings['cart_products_header_is_active'] ?>">
                    </label>
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th-full">
                    <label>
                        <?= Lang_clfe::_e('Title when the section is open', 'clfe') ?>
                    </label>
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Cart : title styling', 'clfe'),
                        'styleAttachedTo' => '.cart-header-title',
                        'font' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_products_header_title_style', $settings['cart_products_header_title_style'], $activeOptions);
                    ?>
                </div>
                <div class="clfe-td-full">
                    <input type="text"  name="cart_products_header_title_is_open" textAttachedTo=".cart_products_header_title_is_open" value="<?= $settings['cart_products_header_title_is_open'] ?>" placeholder="<?= Lang_clfe::_e('Title when the section is open', 'clfe') ?>">
                </div>
                <div class="clfe-th-full">
                    <label>
                        <?= Lang_clfe::_e('Title when the section is closed', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td-full">
                    <input type="text"  name="cart_products_header_title_is_closed" textAttachedTo=".cart_products_header_title_is_closed" value="<?= $settings['cart_products_header_title_is_closed'] ?>" placeholder="<?= Lang_clfe::_e('Title when the section is closed', 'clfe') ?>">
                </div>
            </div>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Count text', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <input type="text"  name="cart_products_header_count_text" textAttachedTo=".cart-header-count-text" value="<?= $settings['cart_products_header_count_text'] ?>" placeholder="<?= Lang_clfe::_e('cart items count text', 'clfe') ?>">
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('cart items count text style', 'clfe'),
                        'styleAttachedTo' => '.cart-header-count-container',
                        'font' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_products_header_count_text_style', $settings['cart_products_header_count_text_style'], $activeOptions);
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="clfe-row">
    <div class="clfe-th">
        <label><?= Lang_clfe::_e('Product box', 'clfe'); ?></label>
    </div>
    <div class="clfe-td">

        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label><?= Lang_clfe::_e('Container style', 'clfe'); ?></label>
                </div>
                <div class="clfe-td">
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Product container style', 'clfe'),
                        'styleAttachedTo' => '.cart-product',
                        'min-height' => 'yes',
                        'max-height' => 'yes',
                        'border' => 'yes',
                        'padding' => 'yes',
                        'linear-gradient' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_product_container_style', $settings['cart_product_container_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <div class="clfe-row clfe-row-is-title">
                <label>
                    <?= Lang_clfe::_e('Product Box elements', 'clfe') ?> :
                </label>
            </div>

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Title', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_products_title_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_products_title_is_active" value="<?= $settings['cart_products_title_is_active'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Cart product title style', 'clfe'),
                        'styleAttachedTo' => '.clfe-cart-product-title',
                        'font' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_products_title_style', $settings['cart_products_title_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Image', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_products_image_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_products_image_is_active" value="<?= $settings['cart_products_image_is_active'] ?>">
                    </label>
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Cart product image style', 'clfe'),
                        'styleAttachedTo' => '.clfe-cart-product-img',
                        'width' => 'yes',
                        'border' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_products_img_style', $settings['cart_products_img_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Variations items', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_products_variations_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_products_variations_is_active" value="<?= $settings['cart_products_variations_is_active'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Cart product variations items style', 'clfe'),
                        'styleAttachedTo' => '.clfe-cart-product-variations',
                        'font' => 'yes',
                        'border' => 'yes',
                        'padding' => 'yes',
                    ];
                    $adminStyle->getAllCss('cart_products_variations_style', $settings['cart_products_variations_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Regular price', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_products_regular_price_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_products_regular_price_is_active" value="<?= $settings['cart_products_regular_price_is_active'] ?>">
                    </label>
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Cart product regular price style', 'clfe'),
                        'styleAttachedTo' => '.clfe-cart-product-regular-price',
                        'font' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_products_regular_price_style', $settings['cart_products_regular_price_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Sale price', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_products_sale_price_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_products_sale_price_is_active" value="<?= $settings['cart_products_sale_price_is_active'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Cart product sale price style', 'clfe'),
                        'styleAttachedTo' => '.clfe-cart-product-sale-price',
                        'font' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_products_sale_price_style', $settings['cart_products_sale_price_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <!-- New settings for Edit button -->
            <div class="clfe-row">
                <div class="clfe-sub-section">
                    <div class="clfe-row">
                        <div class="clfe-th">
                            <label>
                                <?= Lang_clfe::_e('Edit button', 'clfe') ?>
                            </label>
                        </div>
                        <div class="clfe-td">
                            <label class="clfe-switch">
                                <input type="checkbox" <?= $settings['cart_products_edit_button_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                                <span class="clfe-slider clfe-round"></span>
                                <input type="hidden" name="cart_products_edit_button_is_active" value="<?= $settings['cart_products_edit_button_is_active'] ?>">
                            </label>

                            <?php
                            $activeOptions = [
                                'modalTitle' => Lang_clfe::__('Cart product edit button style', 'clfe'),
                                'styleAttachedTo' => '.clfe-button-update',
                                'font' => 'yes',
                                'border' => 'yes',
                                'padding' => 'yes',
                                'background' => 'yes'
                            ];
                            $adminStyle->getAllCss('cart_products_edit_button_style', $settings['cart_products_edit_button_style'], $activeOptions);
                            ?>

                        </div>
                    </div>
                    <div class="clfe-row">
                        <div class="clfe-td-full">
                        <div class="clfe-input-group">
                            <input type="text" name="cart_products_edit_button_text" value="<?= $settings['cart_products_edit_button_text'] ?>" placeholder="<?= Lang_clfe::_e('Edit button text', 'clfe') ?>">
                            <div class="clfe-alert clfe-alert-info">
                                <?= Lang_clfe::_e('Leave it empty to only show the icon', 'clfe') ?>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>

            </div>


            <!-- New settings for Remove button -->
            <div class="clfe-row">
                <div class="clfe-sub-section">
                    <div class="clfe-row">
                        <div class="clfe-th">
                            <label>
                                <?= Lang_clfe::_e('Remove button', 'clfe') ?>
                            </label>
                        </div>
                        <div class="clfe-td">
                            <label class="clfe-switch">
                                <input type="checkbox" <?= $settings['cart_products_remove_button_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                                <span class="clfe-slider clfe-round"></span>
                                <input type="hidden" name="cart_products_remove_button_is_active" value="<?= $settings['cart_products_remove_button_is_active'] ?>">
                            </label>


                            <?php
                            $activeOptions = [
                                'modalTitle' => Lang_clfe::__('Cart product remove button style', 'clfe'),
                                'styleAttachedTo' => '.clfe-button-delete',
                                'font' => 'yes',
                                'border' => 'yes',
                                'padding' => 'yes',
                                'background' => 'yes'
                            ];
                            $adminStyle->getAllCss('cart_products_remove_button_style', $settings['cart_products_remove_button_style'], $activeOptions);
                            ?>

                        </div>
                    </div>
                    <div class="clfe-row">
                        <div class="clfe-td-full">


                            <div class="clfe-input-group">
                                <input type="text" name="cart_products_remove_button_text" value="<?= $settings['cart_products_remove_button_text'] ?>" placeholder="<?= Lang_clfe::_e('Remove button text', 'clfe') ?>">
                                <div class="clfe-alert clfe-alert-info">
                                    <?= Lang_clfe::_e('Leave it empty to only show the icon', 'clfe') ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>