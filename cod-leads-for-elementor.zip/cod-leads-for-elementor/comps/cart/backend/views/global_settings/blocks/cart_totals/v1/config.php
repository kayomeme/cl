<?php return array (
  'setting' => 
  array (
    'cart_totals_is_active' => 'yes',
    'cart_totals_version' => 'v1',
    'cart_totals_regular_price_is_active' => 'yes',
    'cart_totals_sale_price_is_active' => 'yes',
  ),
  'lang' => 
  array (
    'cart_totals_title' => 'Cart Totals',
    'cart_totals_subtotal_label' => 'Subtotal',
    'cart_totals_total_label' => 'Total to pay',
  ),
  'style' => 
  array (
    'cart_totals_container_style' => 'border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:#eee2e2;border-style:solid;border-radius:0px;padding:15px;margin:0px;background-color:#ffffff;',
    'cart_totals_label_style' => 'font-size:16px;color:#000000;font-weight:700;text-align:left;',
    'cart_totals_regular_price_style' => '',
    'cart_totals_sale_price_style' => '',
  ),
);