<?php return array (
  'setting' => 
  array (
    'cart_totals_is_active' => 'yes',
    'cart_totals_version' => 'v1',
    'cart_totals_regular_price_is_active' => 'yes',
    'cart_totals_sale_price_is_active' => 'yes',
  ),
  'lang' => 
  array (
    'cart_totals_subtotal_label' => 'Sous-total',
    'cart_totals_total_label' => 'Total à payer',
  ),
  'style' => 
  array (
    'cart_totals_container_style' => 'background-color:#f9fafb;padding:16px;border-radius:8px;',
    'cart_totals_label_style' => 'font-size:14px;color:#4b5563;font-weight:normal;',
    'cart_totals_regular_price_style' => 'font-size:14px;color:#6b7280;font-weight:normal;',
    'cart_totals_sale_price_style' => 'font-size:16px;color:#111827;font-weight:600;',
  ),
);