<style>
.clfe_cart_empty {
    display: flex;
    flex-direction: column;
    gap: 10px;
    align-items: center;
    justify-content: center;
    <?= $settings['cart_empty_container_style'] ?>
}
.clfe_cart_empty > div {
    width: 100%;
    text-align: center;
}

.clfe_cart_empty .cart-empty-icon svg {
    width: 100%;
    height: auto;
    <?= $settings['cart_empty_icon_style'] ?>
}

.clfe_cart_empty .cart-empty-text {
    <?= $settings['cart_empty_text_style'] ?>
}

.clfe_cart_empty .cart-empty-subtext {
    <?= $settings['cart_empty_subtext_style'] ?>
}

.clfe_cart_empty .cart-empty-actions {
    display: flex;
    column-gap: 10px;
    justify-content: center;
}

.clfe_cart_empty .continue-button {
    text-decoration: none;
    display: inline-block;
    <?= $settings['cart_empty_continue_button_style'] ?>
}
</style>