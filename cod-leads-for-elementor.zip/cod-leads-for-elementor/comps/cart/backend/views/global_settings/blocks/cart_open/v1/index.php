<div class="cart-modal-settings">
    <div class="cl-th-full">

        <!-- Open Cart Button settings section -->
        <div class="cl-row">
            <div class="cl-th">
                <?= Lang_cl::_e('Open Cart Button', 'cl') ?>
            </div>
            <div class="cl-td cl-sub-section">
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Is active', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getSwitchButton([
                            'name' => 'cart_open_is_active',
                            'value' => $settings['cart_open_is_active']
                        ]);
                        
                        $styleManager->getAllCss('cart_open_container_style');
                        ?>
                    </div>
                </div>
                <?php $styleManager->getFlexLayout('cart_open_elements_layout_style'); ?>
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Position', 'cl') ?>
                    </div>
                    <div class="cl-td">
                        <select name="cart_open_position">
                            <option value="bottom_right" <?= $settings['cart_open_position'] == 'bottom_right' ? 'selected' : '' ?>><?= Lang_cl::_e('Bottom Right', 'cl') ?></option>
                            <option value="bottom_left" <?= $settings['cart_open_position'] == 'bottom_left' ? 'selected' : '' ?>><?= Lang_cl::_e('Bottom Left', 'cl') ?></option>
                            <option value="top_right" <?= $settings['cart_open_position'] == 'top_right' ? 'selected' : '' ?>><?= Lang_cl::_e('Top Right', 'cl') ?></option>
                            <option value="top_left" <?= $settings['cart_open_position'] == 'top_left' ? 'selected' : '' ?>><?= Lang_cl::_e('Top Left', 'cl') ?></option>
                        </select>
                    </div>
                </div>
                
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Button text', 'cl') ?>
                    </div>
                    <div class="cl-td cl-sub-section">
                        <div class="cl-row">
                            <div class="cl-td-full cl-style-container">
                                <?php
                                $styleManager->getSwitchButton([
                                    'name' => 'cart_open_text_is_active',
                                    'value' => $settings['cart_open_text_is_active']
                                ]);
                                
                                $styleManager->getAllCss('cart_open_text_style');
                                ?>
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-td-full">
                                <input type="text" name="cart_open_text" value="<?= $settings['cart_open_text'] ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Icon', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php 
                        $styleManager->getSwitchButton([
                            'name' => 'cart_open_icon_is_active',
                            'value' => $settings['cart_open_icon_is_active']
                        ]);
                        
                        IconsSelectorBK_cl::getButton([
                            'name' => 'cart_open_icon_id',
                            'value' => $settings['cart_open_icon_id'],
                        ]);

                        $styleManager->getAllCss('cart_open_icon_style');
                        ?>
                    </div>
                </div>
                <div class="cl-row">
                    <div class="cl-th">
                        <?= Lang_cl::_e('Count Number', 'cl') ?>
                    </div>
                    <div class="cl-td cl-style-container">
                        <?php
                        $styleManager->getSwitchButton([
                            'name' => 'cart_open_count_is_active',
                            'value' => $settings['cart_open_count_is_active']
                        ]);
                        
                        $styleManager->getAllCss('cart_open_count_style');
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>