<?php

/**
 * Cart Summary Block
 */
return array(
    'setting' => [
        'cart_summary_is_active' => 'yes',
        'cart_summary_version' => 'v1',
        'cart_summary_promo_is_active' => 'yes',
        'cart_summary_total_is_active' => 'yes',
        'cart_summary_goto_checkout_is_active' => 'yes',
    ],
    'lang' => [
        'cart_summary_promo_placeholder' => 'Enter promo code',
        'cart_summary_apply_button_text' => 'Apply',
        'cart_summary_total_label' => 'Total to pay',
        'cart_summary_goto_checkout_text' => 'Proceed to Checkout',
        'cart_summary_currency_label' => 'USD',
        'cart_summary_discount_label' => 'Discount applied',
        'cart_summary_invalid_code' => 'Invalid promo code',
        'cart_summary_code_applied' => 'Promo code applied successfully',
    ],
    'style' => [
        'cart_summary_container_style' => 'border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:#eee2e2;border-style:solid;border-radius:0px;padding:15px;margin:0px;background-color:#ffffff;box-shadow:0 0px 8px 0 #ccc;',
        'cart_summary_promo_container_style' => 'margin-top:15px;margin-bottom:15px;',
        'cart_summary_apply_button_style' => 'font-size:14px;color:#3b82f6;font-weight:500;text-align:center;border:1px solid #3b82f6;border-radius:4px;padding:8px 16px;background-color:#ffffff;',
        'cart_summary_total_label_style' => 'font-size:15px;color:#000000;font-weight:600;text-align:left;',
        'cart_summary_total_value_style' => 'font-size:15px;color:#000000;font-weight:600;text-align:right;',
        'cart_summary_goto_checkout_style' => 'width:100%;font-size:16px;color:#ffffff;font-weight:600;text-align:center;border:none;border-radius:4px;padding:12px 24px;margin-top:15px;background-color:#22c55e;',
    ]
);

