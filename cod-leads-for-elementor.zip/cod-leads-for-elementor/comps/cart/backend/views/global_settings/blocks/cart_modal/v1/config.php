<?php return array (
  'setting' => 
  array (
    'cart_modal_version' => 'v1',
  ),
  'lang' => 
  array (
    'cart_modal_header_close_text' => 'Fermer',
    'cart_modal_header_title' => 'Panier',
  ),
  'style' => 
  array (
    'cart_modal_container_style' => 'background-color:#ffffff;',
    'cart_modal_header_container_style' => 'padding:16px;border-bottom-width:1px;border-color:#e5e7eb;border-style:solid;',
    'cart_modal_header_title_style' => 'font-size:18px;color:#111827;font-weight:600;',
    'cart_modal_header_close_style' => 'font-size:14px;color:#6b7280;',
  ),
);