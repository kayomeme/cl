<style>
    /*-----open cart button----*/
    .cart_open {
        display: flex;
        align-items: center;
        cursor: pointer;
        position: fixed;
        <?php 
        // Set position based on user selection
        switch($settings['cart_open_position']) {
            case 'top_left':
                echo 'top: 10px; left: 10px;';
                break;
            case 'top_right':
                echo 'top: 10px; right: 10px;';
                break;
            case 'bottom_left':
                echo 'bottom: 10px; left: 10px;';
                break;
            case 'bottom_right':
            default:
                echo 'bottom: 10px; right: 10px;';
                break;
        }
        ?>
        <?= $settings['cart_open_container_style'] ?>
        <?= $settings['cart_open_elements_layout_style'] ?>
        
    }

    .cart_open:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.12);
    }
    
    .cart_open .cl-icon {
        <?= $settings['cart_open_icon_style'] ?>
    }
    
    .cart_open .cl_count_products {
        <?= $settings['cart_open_count_style'] ?>
    }
    
    .cart-icon-and-count {
        display: flex;
        align-items: center;
        gap: 4px;
    }
    
    .cart_open .cart_open-button-text {
        <?= $settings['cart_open_text_style'] ?>
    }
</style>