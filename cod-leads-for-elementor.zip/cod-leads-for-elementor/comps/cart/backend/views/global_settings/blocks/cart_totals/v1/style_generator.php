<?php
return array(
    'cart_totals_container_style' => [
        'modal_title' => Lang_cl::__('Cart Totals: Container styling', 'cl'),
        'style_attached_to' => '.cl_cart_totals',
        'single_css_supported' => ['margin-top'],
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes', 
        'background' => 'yes'
    ],
    'cart_totals_label_style' => [
        'modal_title' => Lang_cl::__('Total label styling', 'cl'),
        'style_attached_to' => '.cl_cart_totals .total .key-name',
        'font' => 'yes'
    ],
    'cart_totals_regular_price_style' => [
        'modal_title' => Lang_cl::__('Cart product regular price style', 'cl'),
        'style_attached_to' => '.cl-cart-product-regular-price',
        'font' => 'yes'
    ],
    'cart_totals_sale_price_style' => [
        'modal_title' => Lang_cl::__('Cart product sale price style', 'cl'),
        'style_attached_to' => '.cl-cart-product-sale-price',
        'font' => 'yes'
    ],
);