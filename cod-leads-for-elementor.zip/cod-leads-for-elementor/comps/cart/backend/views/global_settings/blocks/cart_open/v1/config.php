<?php return array (
  'setting' => 
  array (
    'cart_open_version' => 'v1',
    'cart_open_is_active' => 'yes',
    'cart_open_position' => 'bottom_right',
    'cart_open_text_is_active' => 'no',
    'cart_open_icon_is_active' => 'yes',
    'cart_open_icon_id' => '8',
    'cart_open_count_is_active' => 'yes',
  ),
  'lang' => 
  array (
    'cart_open_text' => 'Panier',
  ),
  'style' => 
  array (
    'cart_open_container_style' => 'background-color:#3b82f6;border-radius:9999px;padding:12px;box-shadow:0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);',
    'cart_open_elements_layout_style' => '',
    'cart_open_text_style' => 'font-size:14px;color:#ffffff;font-weight:600;',
    'cart_open_icon_style' => 'font-size:24px;color:#ffffff;',
    'cart_open_count_style' => 'font-size:12px;color:#3b82f6;font-weight:700;background-color:#ffffff;border-radius:9999px;padding: 2px 6px;',
  ),
);