<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Empty Cart Message', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_empty_is_active',
                        'value' => $settings['cart_empty_is_active']
                    ]);
                    
                    $styleManager->getAllCss('cart_empty_container_style');
                    ?>
                </div>
            </div>

            <?php $styleManager->getSingleCss('margin-top', 'cart_empty_container_style'); ?>
            <?php $styleManager->getSingleCss('margin-bottom', 'cart_empty_container_style'); ?>

            <!-- Empty Cart Icon -->
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Show Icon', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_empty_show_icon',
                        'value' => $settings['cart_empty_show_icon']
                    ]);

                    $styleManager->getAllCss('cart_empty_icon_style');
                    ?>
                </div>
            </div>

            <!-- Main Empty Cart Text -->
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Empty Cart Text', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <input type="text" name="cart_empty_text" value="<?= $settings['cart_empty_text'] ?>" placeholder="Empty cart text">

                    <?php
                    $styleManager->getAllCss('cart_empty_text_style');
                    ?>
                </div>
            </div>

            <!-- Additional Subtext -->
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Additional Message', 'cl') ?>
                </div>
                <div class="cl-td">
                    <div class="cl-sub-section">
                        <div class="cl-row">
                            <div class="cl-td-full cl-style-container">
                                <?php
                                $styleManager->getSwitchButton([
                                    'name' => 'cart_empty_subtext_is_active',
                                    'value' => $settings['cart_empty_subtext_is_active']
                                ]);
                                $styleManager->getAllCss('cart_empty_subtext_style');
                                ?>
                            </div>
                        </div>
                        <textarea name="cart_empty_subtext" placeholder="Additional message for empty cart"><?= $settings['cart_empty_subtext'] ?></textarea>
                    </div>
                    
                </div>
            </div>

            <!-- Empty Cart Continue Shopping Button -->
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Continue Shopping Button', 'cl') ?>
                </div>
                <div class="cl-td">
                    <div class="cl-sub-section">
                        <div class="cl-row">
                            <div class="cl-td-full cl-style-container">
                                <?php
                    $styleManager->getSwitchButton([
                                    'name' => 'cart_empty_continue_is_active',
                                    'value' => $settings['cart_empty_continue_is_active']
                                ]);
                                $styleManager->getAllCss('cart_empty_continue_button_style');
                                ?>
                            </div>
                        </div>
                        <div class="cl-row">
                            <div class="cl-td-full">
                                <input type="text" name="cart_empty_continue_text" value="<?= $settings['cart_empty_continue_text'] ?>" placeholder="Continue shopping text">

                            </div>
                        </div>
                    <!-- Custom URL Toggle -->
                    <div class="cl-row" style="margin-top: 10px;">
                        <div class="cl-th-full">
                            <?= Lang_cl::_e('Custom Redirect URL', 'cl') ?>
                        </div>
                        <div class="cl-td-full">
                            <?php
                            $styleManager->getSwitchButton([
                                'name' => 'cart_empty_continue_custom_url_is_active',
                                'value' => $settings['cart_empty_continue_custom_url_is_active']
                            ]);
                            ?>
                            <input type="text" name="cart_empty_continue_custom_url" value="<?= $settings['cart_empty_continue_custom_url'] ?>" placeholder="https://example.com/shop">
                        </div>
                        <p class="cl-description">
                                    <?= Lang_cl::_e('By default, the button links to the homepage. Enable this to set a custom URL.', 'cl') ?>
                        </p>
                    </div>
                    </div>
                    
                    
                    <?php

                    ?>



                    <?php
                    
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>