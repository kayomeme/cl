<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Empty Cart Message', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_empty_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_empty_is_active" value="<?= $settings['cart_empty_is_active'] ?>">
                    </label>
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Empty Cart: Container styling', 'clfe'),
                        'styleAttachedTo' => '#clfe_cart_empty',
                        'border' => 'yes', 'padding' => 'yes', 'background' => 'yes', 'text-align' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_empty_container_style', $settings['cart_empty_container_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <?php $adminStyle->getSingleCss('margin-top', 'cart_empty_container_style', $settings['cart_empty_container_style']); ?>
            <?php $adminStyle->getSingleCss('margin-bottom', 'cart_empty_container_style', $settings['cart_empty_container_style']); ?>

            <!-- Empty Cart Icon -->
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Show Icon', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_empty_show_icon'] == 'yes' ? 'checked="checked"' : '' ?> >
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_empty_show_icon" value="<?= $settings['cart_empty_show_icon'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Empty cart icon style', 'clfe'),
                        'styleAttachedTo' => '.clfe_cart_empty .cart-empty-icon',
                        'font' => 'yes',
                        'max-width' => 'yes',
                    ];
                    $adminStyle->getAllCss('cart_empty_icon_style', $settings['cart_empty_icon_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <!-- Main Empty Cart Text -->
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Empty Cart Text', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <input type="text" name="cart_empty_text" value="<?= $settings['cart_empty_text'] ?>" placeholder="Empty cart text">

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Empty cart text style', 'clfe'),
                        'styleAttachedTo' => '.clfe_cart_empty .cart-empty-text',
                        'font' => 'yes', 'margin' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_empty_text_style', $settings['cart_empty_text_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <!-- Additional Subtext -->
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Additional Message', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_empty_subtext_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_empty_subtext_is_active" value="<?= $settings['cart_empty_subtext_is_active'] ?>">
                    </label>
                    <textarea name="cart_empty_subtext" placeholder="Additional message for empty cart"><?= $settings['cart_empty_subtext'] ?></textarea>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Additional message style', 'clfe'),
                        'styleAttachedTo' => '.clfe_cart_empty .cart-empty-subtext',
                        'font' => 'yes', 'margin' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_empty_subtext_style', $settings['cart_empty_subtext_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <!-- Empty Cart Continue Shopping Button -->
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Continue Shopping Button', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_empty_continue_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_empty_continue_is_active" value="<?= $settings['cart_empty_continue_is_active'] ?>">
                    </label>
                    <input type="text" name="cart_empty_continue_text" value="<?= $settings['cart_empty_continue_text'] ?>" placeholder="Continue shopping text">

                    <!-- Custom URL Toggle -->
                    <div class="clfe-row" style="margin-top: 10px;">
                        <div class="clfe-th">
                            <label>
                                <?= Lang_clfe::_e('Custom Redirect URL', 'clfe') ?>
                            </label>
                        </div>
                        <div class="clfe-td">
                            <label class="clfe-switch">
                                <input type="checkbox" <?= $settings['cart_empty_continue_custom_url_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                                <span class="clfe-slider clfe-round"></span>
                                <input type="hidden" name="cart_empty_continue_custom_url_is_active" value="<?= $settings['cart_empty_continue_custom_url_is_active'] ?>">
                            </label>
                            <input type="text" name="cart_empty_continue_custom_url" value="<?= $settings['cart_empty_continue_custom_url'] ?>" placeholder="https://example.com/shop">
                            <p class="clfe-description"><?= Lang_clfe::_e('By default, the button links to the homepage. Enable this to set a custom URL.', 'clfe') ?></p>
                        </div>
                    </div>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Continue button style', 'clfe'),
                        'styleAttachedTo' => '.clfe_cart_empty .continue-button',
                        'font' => 'yes', 'border' => 'yes', 'padding' => 'yes', 'background' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_empty_continue_button_style', $settings['cart_empty_continue_button_style'], $activeOptions);
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>