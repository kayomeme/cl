<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Cart Totals Section', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_totals_is_active',
                        'value' => $settings['cart_totals_is_active']
                    ]);
                    
                    $styleManager->getAllCss('cart_totals_container_style'); 
                    ?>
                </div>
            </div>
            <?php $styleManager->getSingleCss('margin-top', 'cart_totals_container_style'); ?>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Total Label', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <input type="text" name="cart_totals_total_label" value="<?= $settings['cart_totals_total_label'] ?>">
                    <?php 
                    $styleManager->getAllCss('cart_totals_label_style'); 
                    ?>
                </div>
            </div>
            
            
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Regular price', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_totals_regular_price_is_active',
                        'value' => $settings['cart_totals_regular_price_is_active']
                    ]);
                    
                    $styleManager->getAllCss('cart_totals_regular_price_style');
                    ?>
                </div>
            </div>
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Sale price', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_totals_sale_price_is_active',
                        'value' => $settings['cart_totals_sale_price_is_active']
                    ]);
                    $styleManager->getAllCss('cart_totals_sale_price_style');
                    ?>
                </div>
            </div>
            
        </div>
    </div>
</div>