
<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Cart Totals Section', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['cart_totals_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="cart_totals_is_active" value="<?= $settings['cart_totals_is_active'] ?>">
                    </label>
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Cart Totals: Container styling', 'clfe'),
                            'styleAttachedTo' => '.clfe_cart_totals',
                            'border' => 'yes', 'padding' => 'yes', 'background' => 'yes'
                        ];
                        $adminStyle->getAllCss('cart_totals_container_style', $settings['cart_totals_container_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            <?php $adminStyle->getSingleCss('margin-top', 'cart_totals_container_style', $settings['cart_totals_container_style']); ?>
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Total Label', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <input type="text" name="cart_totals_total_label" value="<?= $settings['cart_totals_total_label'] ?>">
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Total label styling', 'clfe'),
                            'styleAttachedTo' => '.clfe_cart_totals .total .key-name',
                            'font' => 'yes'
                        ];
                        $adminStyle->getAllCss('cart_totals_label_style', $settings['cart_totals_label_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            
            
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Regular price', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_totals_regular_price_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_totals_regular_price_is_active" value="<?= $settings['cart_totals_regular_price_is_active'] ?>">
                    </label>
                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Cart product regular price style', 'clfe'),
                        'styleAttachedTo' => '.clfe-cart-product-regular-price',
                        'font' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_totals_regular_price_style', $settings['cart_totals_regular_price_style'], $activeOptions);
                    ?>
                </div>
            </div>

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Sale price', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                        <input type="checkbox" <?= $settings['cart_totals_sale_price_is_active'] == 'yes' ? 'checked="checked"' : '' ?>>
                        <span class="clfe-slider clfe-round"></span>
                        <input type="hidden" name="cart_totals_sale_price_is_active" value="<?= $settings['cart_totals_sale_price_is_active'] ?>">
                    </label>

                    <?php
                    $activeOptions = [
                        'modalTitle' => Lang_clfe::__('Cart product sale price style', 'clfe'),
                        'styleAttachedTo' => '.clfe-cart-product-sale-price',
                        'font' => 'yes'
                    ];
                    $adminStyle->getAllCss('cart_totals_sale_price_style', $settings['cart_totals_sale_price_style'], $activeOptions);
                    ?>
                </div>
            </div>
            
        </div>
    </div>
</div>