<?php
return array(
    'cart_open_container_style' => [
        'modal_title' => Lang_cl::__('Open cart container style', 'cl'),
        'style_attached_to' => '.cart_open',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'box-shadow' => 'yes'
    ],
    'cart_open_elements_layout_style' => [
        'modal_title' => Lang_cl::__('Open cart container style', 'cl'),
        'style_attached_to' => '.cart_open',
        'flex-layout' => [
            'title' => Lang_cl::__('Elements layout', 'cl'),
            'options' => [
                'flex-direction' => [
                    'title' => Lang_cl::__('Elements order', 'cl'),
                    'items' => [
                        'row' => Lang_cl::__('Row', 'cl'),
                        'row-reverse' => Lang_cl::__('Row Reverse', 'cl'),
                        'column' => Lang_cl::__('Column', 'cl'),
                        'column-reverse' => Lang_cl::__('Column Reverse', 'cl')
                    ]
                ],
                'gap' => [
                    'title' => Lang_cl::__('Space between elements', 'cl'),
                ]
            ]
        ],
    ],
    'cart_open_text_style' => [
        'modal_title' => Lang_cl::__('Button text style', 'cl'),
        'style_attached_to' => '.cart_open-button-text',
        'font' => 'yes',
    ],
    'cart_open_icon_style' => [
        'modal_title' => Lang_cl::__('Icon style', 'cl'),
        'style_attached_to' => '.cart_open .cl-icon',
        'font' => 'yes'
    ],
    'cart_open_count_style' => [
        'modal_title' => Lang_cl::__('Count Number style', 'cl'),
        'style_attached_to' => '.cart_open .cl_count_products',
        'font' => 'yes',
        'padding' => 'yes'
    ],
);