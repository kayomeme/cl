<?php
return array(
    'cart_products_container_style' => [
        'modal_title' => Lang_cl::__('Cart : Container styling', 'cl'),
        'style_attached_to' => '.cl_cart_products',
        'single_css_supported' => ['margin-top'],
        'border' => 'yes',
        'border-radius' => 'yes',
        'background' => 'yes',
        'padding' => 'yes',
    ],
    'cart_products_header_container_style' => [
        'modal_title' => Lang_cl::__('Cart Products Header container style', 'cl'),
        'style_attached_to' => '.cl_cart_products .cl_toggle_header',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
    ],
    'cart_products_header_title_style' => [
        'modal_title' => Lang_cl::__('Cart products title style', 'cl'),
        'style_attached_to' => '.cl-cart-products-header-title',
        'font' => 'yes'
    ],
    'cart_products_header_count_text_style' => [
        'modal_title' => Lang_cl::__('Cart products count text style', 'cl'),
        'style_attached_to' => '.cart-products-header-count-text',
        'font' => 'yes'
    ],
    'cart_products_header_icon_style' => [
        'modal_title' => Lang_cl::__('Cart products header icons style', 'cl'),
        'style_attached_to' => '.cl_cart_products .cl_toggle_header .cl-icon',
        'font' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
    ],
    'cart_products_preview_style' => [
        'modal_title' => Lang_cl::__('Selected value display style', 'cl'),
        'style_attached_to' => '.cart_products_preview',
        'font' => 'yes',
        'padding' => 'yes'
    ],
    'cart_products_body_container_style' => [
        'modal_title' => Lang_cl::__('Cart products body container style', 'cl'),
        'style_attached_to' => '.cl_cart_products .cl_toggle_body',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes',
        'box-shadow' => 'yes'
    ],
    'cart_product_container_style' => [
        'modal_title' => Lang_cl::__('Product container style', 'cl'),
        'style_attached_to' => '.cart-product',
        'min-height' => 'yes',
        'max-height' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'linear-gradient' => 'yes'
    ],
    'cart_products_title_style' => [
        'modal_title' => Lang_cl::__('Cart product title style', 'cl'),
        'style_attached_to' => '.cl-cart-product-title',
        'font' => 'yes'
    ],
    'cart_products_img_style' => [
        'modal_title' => Lang_cl::__('Cart product image style', 'cl'),
        'style_attached_to' => '.cl-cart-product-img',
        'width' => 'yes',
        'border' => 'yes'
    ],
    'cart_products_variations_style' => [
        'modal_title' => Lang_cl::__('Cart product variations items style', 'cl'),
        'style_attached_to' => '.cl-cart-product-variations',
        'font' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
    ],
    'cart_products_regular_price_style' => [
        'modal_title' => Lang_cl::__('Cart product regular price style', 'cl'),
        'style_attached_to' => '.cl-cart-product-regular-price',
        'font' => 'yes'
    ],
    'cart_products_sale_price_style' => [
        'modal_title' => Lang_cl::__('Cart product sale price style', 'cl'),
        'style_attached_to' => '.cl-cart-product-sale-price',
        'font' => 'yes'
    ],
    'cart_products_edit_button_style' => [
        'modal_title' => Lang_cl::__('Cart product edit button style', 'cl'),
        'style_attached_to' => '.cl-button-update',
        'font' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes'
    ],
    'cart_products_remove_button_style' => [
        'modal_title' => Lang_cl::__('Cart product remove button style', 'cl'),
        'style_attached_to' => '.cl-button-delete',
        'font' => 'yes',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes'
    ],
);