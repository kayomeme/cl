<?php
return array(
    'cart_modal_container_style' => [
        'modal_title' => Lang_cl::__('Cart Modal container style', 'cl'),
        'style_attached_to' => '#cl-cartside',
        'border' => 'yes',
        'border-radius' => 'yes',
        'background' => 'yes'
    ],
    'cart_modal_header_container_style' => [
        'modal_title' => Lang_cl::__('Modal header container style', 'cl'),
        'style_attached_to' => '.cart-modal-header',
        'border' => 'yes',
        'border-radius' => 'yes',
        'padding' => 'yes',
        'background' => 'yes'
    ],
    'cart_modal_header_title_style' => [
        'modal_title' => Lang_cl::__('Modal title style', 'cl'),
        'style_attached_to' => '.cart-modal-title',
        'font' => 'yes'
    ],
    'cart_modal_header_close_style' => [
        'modal_title' => Lang_cl::__('Close button style', 'cl'),
        'style_attached_to' => '.cart-modal-close-button',
        'font' => 'yes', 
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes', 
        'linear-gradient' => 'yes'
    ],
);