<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Cart Summary Section', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['cart_summary_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="cart_summary_is_active" value="<?= $settings['cart_summary_is_active'] ?>">
                    </label>

                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Cart Summary: Container styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_cart_summary',
                            'border' => 'yes', 'padding' => 'yes', 'background' => 'yes'
                        ];
                        $adminStyle->getAllCss('cart_summary_container_style', $settings['cart_summary_container_style'], $activeOptions); 
                    ?>
                </div>
            </div>

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Promo Section', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['cart_summary_promo_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="cart_summary_promo_is_active" value="<?= $settings['cart_summary_promo_is_active'] ?>">
                    </label>
                    <input type="text" name="cart_summary_promo_placeholder" value="<?= $settings['cart_summary_promo_placeholder'] ?>" placeholder="Enter promo placeholder">
                    <input type="text" name="cart_summary_apply_button_text" value="<?= $settings['cart_summary_apply_button_text'] ?>" placeholder="Apply button text">
                </div>
            </div>

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Total Label', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td clfe-style-container">
                    <input type="text" name="cart_summary_total_label" value="<?= $settings['cart_summary_total_label'] ?>">
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Total label styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_cart_summary .total .key-name',
                            'font' => 'yes'
                        ];
                        $adminStyle->getAllCss('cart_summary_total_label_style', $settings['cart_summary_total_label_style'], $activeOptions); 
                    ?>
                </div>
            </div>

            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Checkout Button', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['cart_summary_goto_checkout_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="cart_summary_goto_checkout_is_active" value="<?= $settings['cart_summary_goto_checkout_is_active'] ?>">
                    </label>
                    <input type="text" name="cart_summary_goto_checkout_text" value="<?= $settings['cart_summary_goto_checkout_text'] ?>" placeholder="Checkout button text">
                </div>
            </div>
        </div>
    </div>
</div>