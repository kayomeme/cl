<?php return array (
  'setting' => 
  array (
    'cart_empty_is_active' => 'yes',
    'cart_empty_version' => 'v1',
    'cart_empty_show_icon' => 'yes',
    'cart_empty_subtext_is_active' => 'yes',
    'cart_empty_continue_is_active' => 'yes',
    'cart_empty_continue_custom_url_is_active' => 'no',
    'cart_empty_continue_custom_url' => '',
  ),
  'lang' => 
  array (
    'cart_empty_text' => 'Votre panier est vide 111',
    'cart_empty_subtext' => 'Il semble que vous n\'ayez pas encore ajouté d\'articles à votre panier 11111',
    'cart_empty_continue_text' => 'Continuer vos achats 22',
  ),
  'style' => 
  array (
    'cart_empty_container_style' => 'padding-top:40px;padding-right:16px;padding-bottom:40px;padding-left:16px;text-align:center;',
    'cart_empty_icon_style' => 'font-size:48px;color:#9ca3af;',
    'cart_empty_text_style' => 'font-size:18px;color:#111827;font-weight:600;margin-top:16px;',
    'cart_empty_subtext_style' => 'font-size:14px;color:#6b7280;margin-top:8px;',
    'cart_empty_continue_button_style' => 'font-size:14px;color:#ffffff;font-weight:600;border-radius:6px;padding-top:10px;padding-right:20px;padding-bottom:10px;padding-left:20px;margin-top:24px;background-color:#3b82f6;',
  ),
);