<style>
    #cl-cartside {
        inset-block: .001px 0;
        display: flex;
        flex-direction: column;
        transform: none;
        right: <?= $sharedSettings['cart_mode'] == 'modal_right' ? 0 : 'auto' ?>;
        left: <?= $sharedSettings['cart_mode'] == 'modal_left' ? 0 : 'auto' ?>;
        position: fixed;
        overflow: hidden;
        z-index: 1000000;
        width: min(340px, 100vw);
        background-color: #fff;
        <?= $settings['cart_modal_container_style'] ?>
    }
    .cart-modal-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        <?= $settings['cart_modal_header_container_style'] ?>
    }
    .cart-modal-body {
        display: flex;
        flex-direction: column;
        height: 100%;
        justify-content: space-between;
    }
    .cart-modal-body > div:last-child {
        /*flex-grow: 1;*/
        /*flex-direction: column;*/
        display: flex;
        justify-content: flex-end;
    }
    .cart-modal-title {
        <?= $settings['cart_modal_header_title_style'] ?>
    }
    #cart-modal-close-button {
        <?= $settings['cart_modal_header_close_style'] ?>
    }

    /*.cartside-start-part {
        overflow-y: scroll;
        scrollbar-width: initial;
        scrollbar-color: #00BCD4 transparent;
        height: 60vh;
    }*/
    
    /*---custom for cart_products block ----*/
    #cl-cartside .cart-product {
        /* min-width: 85%;*/
        max-width: 100%;
    }
    #cl-cartside .cl_cart_products_display {
        flex-wrap: wrap;
        column-gap: 2px;
    }
    #cl-cartside .cl_cart_products {
        overflow-y: auto;
        scrollbar-width: initial;
        scrollbar-color: #00BCD4 transparent;
        max-height: 55vh; /*-this hsould be a setting-*/
    }

    /*---custom for cart_actions block ----*/
    #cl-cartside .cart-product-actions {
    /*flex-direction: column;
        padding: 0;*/
    }
    #cl-cartside .cart-product-actions .cl-button {
        /*min-width: 40%;*/
    }
</style>