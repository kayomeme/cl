<style>
.clfe_cart_coupon {
    display: flex;
    flex-direction: column;
    gap: 5px;
    <?= $settings['cart_coupon_container_style'] ?>
}
.clfe_cart_coupon .coupon-header {
    display: flex;
    justify-content: space-between;
}
.clfe_cart_coupon .promo-input-group {
    display: flex;
    gap: 8px;
}
.clfe_cart_coupon .promo-input {
    <?= $settings['cart_coupon_input_style'] ?>
}
.clfe_cart_coupon .apply-button {
    <?= $settings['cart_coupon_button_style'] ?>
}
</style>