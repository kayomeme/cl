<style>
.cl_cart_coupon {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    gap: 5px;
    <?= $settings['cart_coupon_container_style'] ?>
}
.cl_cart_coupon .coupon-header {
    display: flex;
    justify-content: space-between;
}
.cl_cart_coupon .promo-input-group {
    display: flex;
    gap: 8px;
}
.cl_cart_coupon .promo-input {
    <?= $settings['cart_coupon_input_style'] ?>
}
.cl_cart_coupon .apply-button {
    <?= $settings['cart_coupon_button_style'] ?>
}
</style>