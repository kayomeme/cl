<?php
return array(
    'cart_empty_container_style' => [
        'modal_title' => Lang_cl::__('Empty Cart: Container styling', 'cl'),
        'style_attached_to' => '#cl_cart_empty',
        'single_css_supported' => ['margin-top', 'margin-bottom'],
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes', 
        'background' => 'yes'
    ],
    'cart_empty_icon_style' => [
        'modal_title' => Lang_cl::__('Empty cart icon style', 'cl'),
        'style_attached_to' => '.cl_cart_empty .cart-empty-icon',
        'font' => 'yes',
    ],
    'cart_empty_text_style' => [
        'modal_title' => Lang_cl::__('Empty cart text style', 'cl'),
        'style_attached_to' => '.cl_cart_empty .cart-empty-text',
        'font' => 'yes', 
        'margin' => 'yes'
    ],
    'cart_empty_subtext_style' => [
        'modal_title' => Lang_cl::__('Additional message style', 'cl'),
        'style_attached_to' => '.cl_cart_empty .cart-empty-subtext',
        'font' => 'yes', 
        'margin' => 'yes'
    ],
    'cart_empty_continue_button_style' => [
        'modal_title' => Lang_cl::__('Continue button style', 'cl'),
        'style_attached_to' => '.cl_cart_empty .continue-button',
        'font' => 'yes', 
        'border' => 'yes',
        'border-radius' => 'yes', 
        'padding' => 'yes', 
        'background' => 'yes'
    ],
);