<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Cart Coupon Section', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['cart_coupon_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="cart_coupon_is_active" value="<?= $settings['cart_coupon_is_active'] ?>">
                    </label>
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Cart Coupon: Container styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_cart_coupon',
                            'border' => 'yes', 'padding' => 'yes', 'background' => 'yes'
                        ];
                        $adminStyle->getAllCss('cart_coupon_container_style', $settings['cart_coupon_container_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            <?php $adminStyle->getSingleCss('margin-top', 'cart_coupon_container_style', $settings['cart_coupon_container_style']); ?>
            <div class="clfe-row">
                <div class="clfe-td">
                    <input type="text" name="cart_coupon_placeholder" value="<?= $settings['cart_coupon_placeholder'] ?>" placeholder="Enter promo placeholder">
                    <input type="text" name="cart_coupon_button_text" value="<?= $settings['cart_coupon_button_text'] ?>" placeholder="Apply button text">
                </div>
            </div>
        </div>
    </div>
</div>