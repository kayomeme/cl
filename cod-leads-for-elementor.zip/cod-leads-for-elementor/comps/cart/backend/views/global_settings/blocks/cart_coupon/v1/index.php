<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Cart Coupon Section', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_coupon_is_active',
                        'value' => $settings['cart_coupon_is_active']
                    ]);
                    
                    $styleManager->getAllCss('cart_coupon_container_style'); 
                    ?>
                </div>
            </div>
            <?php $styleManager->getSingleCss('margin-top', 'cart_coupon_container_style'); ?>
            <div class="cl-row">
                <div class="cl-td">
                    <input type="text" name="cart_coupon_placeholder" value="<?= $settings['cart_coupon_placeholder'] ?>" placeholder="Enter promo placeholder">
                    <input type="text" name="cart_coupon_button_text" value="<?= $settings['cart_coupon_button_text'] ?>" placeholder="Apply button text">
                </div>
            </div>
        </div>
    </div>
</div>