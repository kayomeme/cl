<div class="cl-row">
    <div class="cl-th">
        <?= Lang_cl::_e('Cart Actions Section', 'cl') ?>
    </div>
    <div class="cl-td">
        <div class="cl-sub-section">
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Is Active', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_actions_is_active',
                        'value' => $settings['cart_actions_is_active']
                    ]);
                    
                    $styleManager->getAllCss('cart_actions_container_style'); 
                    ?>
                </div>
            </div>
            
            <?php $styleManager->getSingleCss('margin-top', 'cart_actions_container_style'); ?>
            <!-- Checkout Button -->
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Checkout Button', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_actions_checkout_is_active',
                        'value' => $settings['cart_actions_checkout_is_active']
                    ]);
                    ?>
                    <input type="text" name="cart_actions_checkout_text" value="<?= $settings['cart_actions_checkout_text'] ?>" placeholder="Checkout button text">
                    
                    <?php 
                    $styleManager->getAllCss('cart_actions_checkout_button_style'); 
                    ?>
                </div>
            </div>
            <!-- Continue Shopping Button -->
            <div class="cl-row">
                <div class="cl-th">
                    <?= Lang_cl::_e('Continue Shopping Button', 'cl') ?>
                </div>
                <div class="cl-td cl-style-container">
                    <?php
                    $styleManager->getSwitchButton([
                        'name' => 'cart_actions_continue_is_active',
                        'value' => $settings['cart_actions_continue_is_active']
                    ]);
                    ?>
                    <input type="text" name="cart_actions_continue_text" value="<?= $settings['cart_actions_continue_text'] ?>" placeholder="Continue shopping text">
                    
                    <?php 
                    $styleManager->getAllCss('cart_actions_continue_button_style'); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>