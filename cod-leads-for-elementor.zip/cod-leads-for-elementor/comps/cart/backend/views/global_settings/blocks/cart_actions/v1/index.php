<div class="clfe-row">
    <div class="clfe-th">
        <label>
            <?= Lang_clfe::_e('Cart Actions Section', 'clfe') ?>
        </label>
    </div>
    <div class="clfe-td">
        <div class="clfe-sub-section">
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Is Active', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['cart_actions_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="cart_actions_is_active" value="<?= $settings['cart_actions_is_active'] ?>">
                    </label>
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Cart Actions: Container styling', 'clfe'),
                            'styleAttachedTo' => '#clfe_cart_actions',
                            'border' => 'yes', 'padding' => 'yes', 'background' => 'yes'
                        ];
                        $adminStyle->getAllCss('cart_actions_container_style', $settings['cart_actions_container_style'], $activeOptions); 
                    ?>
                </div>
            </div>
            
            <?php $adminStyle->getSingleCss('margin-top', 'cart_actions_container_style', $settings['cart_actions_container_style']); ?>

            <!-- Checkout Button -->
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Checkout Button', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['cart_actions_checkout_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="cart_actions_checkout_is_active" value="<?= $settings['cart_actions_checkout_is_active'] ?>">
                    </label>
                    <input type="text" name="cart_actions_checkout_text" value="<?= $settings['cart_actions_checkout_text'] ?>" placeholder="Checkout button text">
                    
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Checkout button style', 'clfe'),
                            'styleAttachedTo' => '.clfe_cart_actions .goto-checkout-button',
                            'font' => 'yes', 'border' => 'yes', 'padding' => 'yes', 'background' => 'yes'
                        ];
                        $adminStyle->getAllCss('cart_actions_checkout_button_style', $settings['cart_actions_checkout_button_style'], $activeOptions); 
                    ?>
                </div>
            </div>

            <!-- Continue Shopping Button -->
            <div class="clfe-row">
                <div class="clfe-th">
                    <label>
                        <?= Lang_clfe::_e('Continue Shopping Button', 'clfe') ?>
                    </label>
                </div>
                <div class="clfe-td">
                    <label class="clfe-switch">
                      <input type="checkbox" <?= $settings['cart_actions_continue_is_active'] == 'yes' ? 'checked="checked"' : '' ?> >
                      <span class="clfe-slider clfe-round"></span>
                      <input type="hidden" name="cart_actions_continue_is_active" value="<?= $settings['cart_actions_continue_is_active'] ?>">
                    </label>
                    <input type="text" name="cart_actions_continue_text" value="<?= $settings['cart_actions_continue_text'] ?>" placeholder="Continue shopping text">
                    
                    <?php 
                        $activeOptions = [
                            'modalTitle' => Lang_clfe::__('Continue button style', 'clfe'),
                            'styleAttachedTo' => '.clfe_cart_actions .continue-button',
                            'font' => 'yes', 'border' => 'yes', 'padding' => 'yes', 'background' => 'yes'
                        ];
                        $adminStyle->getAllCss('cart_actions_continue_button_style', $settings['cart_actions_continue_button_style'], $activeOptions); 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>