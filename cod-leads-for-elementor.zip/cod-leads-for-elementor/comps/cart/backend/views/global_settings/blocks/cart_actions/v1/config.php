<?php return array (
  'setting' => 
  array (
    'cart_actions_is_active' => 'yes',
    'cart_actions_version' => 'v1',
    'cart_actions_checkout_is_active' => 'yes',
    'cart_actions_continue_is_active' => 'yes',
  ),
  'lang' => 
  array (
    'cart_actions_checkout_text' => 'Proceed to Checkout',
    'cart_actions_continue_text' => 'Continue Shopping',
    'cart_actions_loading_text' => 'Processing...',
  ),
  'style' => 
  array (
    'cart_actions_container_style' => 'border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:#eee2e2;border-style:solid;border-radius:0px;padding:15px;margin:0px;background-color:#ffffff;',
    'cart_actions_checkout_button_style' => 'width:100%;font-size:16px;color:#ffffff;font-weight:600;text-align:center;border:none;border-radius:4px;padding:12px 24px;margin-top:15px;background-color:#22c55e;',
    'cart_actions_continue_button_style' => 'width:100%;font-size:16px;color:#3b82f6;font-weight:600;text-align:center;border:1px solid #3b82f6;border-radius:4px;padding:12px 24px;margin-top:10px;background-color:#ffffff;',
  ),
);