<?php return array (
  'setting' => 
  array (
    'cart_actions_is_active' => 'yes',
    'cart_actions_version' => 'v1',
    'cart_actions_checkout_is_active' => 'yes',
    'cart_actions_continue_is_active' => 'no',
  ),
  'lang' => 
  array (
    'cart_actions_checkout_text' => 'Procéder au paiement',
    'cart_actions_continue_text' => 'Continuer vos achats',
    'cart_actions_loading_text' => 'En cours de traitement...',
  ),
  'style' => 
  array (
    'cart_actions_container_style' => 'margin-top:16px;',
    'cart_actions_checkout_button_style' => 'width:100%;font-size:16px;color:#ffffff;font-weight:600;text-align:center;border-radius:8px;padding:14px 24px;background-color:#10b981;',
    'cart_actions_continue_button_style' => '',
  ),
);