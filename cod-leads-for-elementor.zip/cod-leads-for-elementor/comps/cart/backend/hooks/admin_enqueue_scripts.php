<?php
if( isset($_REQUEST['page']) && $_REQUEST['page'] == 'clfe_global_settings' && isset($_REQUEST['compo']) && $_REQUEST['compo'] == 'cart' ) {
    //wp_enqueue_style( MainApp_clfe::$assetsPrefix.$hook['compName'], MainApp_clfe::$compsUrl.$hook['compName']. '/backend/assets/css/mystore_bk.css', [], $assetsVersion );
    wp_enqueue_script( MainApp_clfe::$assetsPrefix.$hook['compName'], MainApp_clfe::$compsUrl.$hook['compName']. '/backend/assets/js/cart_bk.js', [], $assetsVersion );

}