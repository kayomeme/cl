<?php

class CartSettingsControllerBK_clfe
{
    public static function index($settingsModelId, $settings, $urlArgs)
    {
        $compoName = 'cart';
        $tabName = isset($urlArgs['tab']) ? $urlArgs['tab'] : 'general';

        $sharedSettings = AdminCompo_clfe::getSharedSettings($settingsModelId);
        $defaultSettings    = AdminCompo_clfe::getDefaultSettings($compoName, $settings);
        
        $adminStyle         = new AdminStyle_clfe($defaultSettings);

        $cartBlocksOrder = adminUtils_clfe::getElementsOrder($defaultSettings['cart_blocks_order'], $settings['cart_blocks_order']);   
        $settings['cart_blocks_order'] = implode(',', $cartBlocksOrder);
        
        $editorArgs = [
            'textarea_rows'  => 5,
            'teeny' => false,
            'quicktags' => true,
            'media_buttons' => true,
            'tinymce'       => [
                'directionality' => $sharedSettings['lang_dir'],
                'toolbar1'      => 'bullist,numlist,forecolor,bold,italic,underline,separator,alignleft,aligncenter,alignright,separator,link,unlink,undo,redo',
                'toolbar2'      => '',
                'toolbar3'      => '',
            ],
        ];
        
        include AdminApp_clfe::$viewsPath . 'global_settings/index.php';
    }
    public static function save_settings($compoName, $settingsModelId, $args)
    {
        $response = AdminCompo_clfe::saveSettings($compoName, $settingsModelId, $args);
        
        if( $response ) {
            return $response;
        }
    }

    private static function getSharedSettings($args)
    {
        $sharedSettings = [];

        return $sharedSettings;
    }
}
