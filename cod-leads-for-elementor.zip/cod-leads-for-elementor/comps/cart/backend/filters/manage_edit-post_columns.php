<?php

$columns['clfe_bt_action'] = Lang_clfe::__('Cod leads', 'clfe');


