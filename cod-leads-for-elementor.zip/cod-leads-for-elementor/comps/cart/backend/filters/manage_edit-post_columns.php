<?php

$columns['cl_bt_action'] = Lang_cl::__('Cod leads', 'cl');


