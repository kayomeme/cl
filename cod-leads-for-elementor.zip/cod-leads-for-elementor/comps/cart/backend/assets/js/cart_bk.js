(function( $ ) {
	'use strict';

        $(document).ready( function () {

            // dragable elemnts
            $("#cl-cart-elements").sortable({
                update: function( event, ui ) {
                    var fieldsFileName = $('#cl-cart-elements div').map(function () { return $(this).attr("_attachedsection"); });
                    $("input[name=cart_blocks_order]").val(fieldsFileName.toArray());
                    $("input[name=cart_blocks_order]").change();
                    
                    AdminFn_cl.autoSaveSettings();
                }
            });

        } );

})( jQuery );