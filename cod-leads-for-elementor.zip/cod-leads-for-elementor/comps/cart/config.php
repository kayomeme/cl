<?php

/**
 * general
 */
return array(
    'setting' => [
        'cart_is_active' => 'yes',
        'active_blocks' => 'cart_empty,cart_products,cart_totals,cart_coupon,cart_actions,cart_modal,cart_open',
        'cart_blocks_order' => 'cart_empty,cart_products,cart_totals,cart_coupon,cart_actions',
    ],
    'lang' => [
    ],
    'style' => [
        'cart_container_style' => '',
    ]
);
