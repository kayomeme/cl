<?php

/**
 * general
 */
return array(
    'setting' => [
        'cart_is_active' => 'yes',
        'active_blocks' => 'cart_empty,cart_products,cart_totals,cart_coupon,cart_actions',
        'cart_blocks_order' => 'cart_empty,cart_products,cart_totals,cart_coupon,cart_actions',
    ],
    'lang' => [
        'cart_modal_close_text' => 'Close',
        'cart_modal_title' => 'Cart',
    ],
    'style' => [
        'cart_container_style' => '',
        'cart_modal_title_style' => '',
        'cart_modal_close_style' => '',
    ]
);
