<?php
$checkoutSettings = [];

if ( ($isCartPage && in_array($salesFunnel_cl->checkout_mode, ['modal'])) && !$checkout_cl ) {
    $checkout_cl = new CheckoutControllerFR_cl([]);
}

if( $checkout_cl ) {
    $checkoutSettings = $checkout_cl->getSettings();
}

// todo - optimize this to only load when used
if ( $product_id || $isCheckoutPage || $isCartPage || is_tax('product_cat') || is_page() || is_home() ) {
    $cart_cl = new CartControllerFR_cl($checkoutSettings);
    return;
}

/*$cart_modes = ['modal_left', 'modal_right', 'in_product'];
$checkout_modes = ['modal', 'in_product'];
if ( $product_id  &&  (in_array($salesFunnel_cl->cart_mode, $cart_modes) || in_array($salesFunnel_cl->checkout_mode, $checkout_modes) ) ) {
    $cart_cl = new CartControllerFR_cl($settingsModelId);
}*/