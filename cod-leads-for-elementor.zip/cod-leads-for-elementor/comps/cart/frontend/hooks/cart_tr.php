<?php
$checkoutSettings = [];

if ( ($isCartPage && in_array($salesFunnel_clfe->checkoutMode, ['modal'])) && !$checkout_clfe ) {
    $checkout_clfe = new CheckoutControllerFR_clfe([]);
}

if( $checkout_clfe ) {
    $checkoutSettings = $checkout_clfe->getSettings();
}

if ( $product_id || $isCheckoutPage || $isCartPage || is_tax('product_cat') ) {
    $cart_clfe = new CartControllerFR_clfe($checkoutSettings);
    return;
}

/*$cartModes = ['modal_left', 'modal_right', 'in_product'];
$checkoutModes = ['modal', 'in_product'];
if ( $product_id  &&  (in_array($salesFunnel_clfe->cartMode, $cartModes) || in_array($salesFunnel_clfe->checkoutMode, $checkoutModes) ) ) {
    $cart_clfe = new CartControllerFR_clfe($settingsModelId);
}*/