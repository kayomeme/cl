<?php
if( ! $cart_clfe ) {
    return;
}
//include $compsPath.$hook['compName'].'/frontend/views/head/index.php';

if( isset( $allCompsGeneratedCss['cart'] ) ) {
    echo $allCompsGeneratedCss['cart'];
}
?>
<script> 
// wp_head cart
<?php if($cart_clfe) { ?>
let jsCart = JSON.parse('<?= $cart_clfe->getJsCart() ?>');
<?php } ?>
</script>