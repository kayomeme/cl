<?php
if( !$cart_clfe ) {
    return;
}

$settings = $cart_clfe->getSettings();
include MainApp_clfe::$compsPath . 'cart/frontend/views/cart_modal.php';


