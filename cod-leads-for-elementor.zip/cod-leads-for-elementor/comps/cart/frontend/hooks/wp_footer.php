<?php
if( !$cart_cl ) {
    return;
}

$settings = $cart_cl->getSettings();
include MainApp_cl::$compsPath . 'cart/frontend/views/blocks/cart_modal/'.$settings['cart_modal_version'].'/cart_modal.php';

if ($settings['cart_open_is_active'] == 'yes' && !$isCartPage) {
    include MainApp_cl::$compsPath . 'cart/frontend/views/blocks/cart_open/'.$settings['cart_open_version'].'/cart_open.php';
}


