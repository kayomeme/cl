<?php
//$hook['compName']
if( $cart_clfe ) {
    wp_enqueue_style( 'clfe_cart_public_css', MainApp_clfe::$compsUrl.'cart/frontend/assets/css/cart.css', [], MainApp_clfe::$assetsVersion );
    wp_enqueue_script( 'clfe_cart_public_js', MainApp_clfe::$compsUrl.'cart/frontend/assets/js/cart.js', array( 'jquery' ), MainApp_clfe::$assetsVersion );
}