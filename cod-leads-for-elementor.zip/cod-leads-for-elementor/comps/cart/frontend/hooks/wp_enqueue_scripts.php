<?php
//$hook['compName']
if( $cart_cl ) {
    wp_enqueue_style( 'cl_cart_public_css', MainApp_cl::$compsUrl.'cart/frontend/assets/css/cart.css', [], MainApp_cl::$assetsVersion );
    wp_enqueue_script( 'cl_cart_public_js', MainApp_cl::$compsUrl.'cart/frontend/assets/js/cart.js', array( 'jquery' ), MainApp_cl::$assetsVersion );
}