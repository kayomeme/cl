(function ($) {
    //'use strict';

    cart_clfe = {
        products: [],
        handleVariationSelectionButton(buttonElement) {
            const $parent = buttonElement.closest(".clfe-variation-parent");
            $parent.find("li").removeClass("vr-is-selected");
            buttonElement.addClass("vr-is-selected");
            $parent.find(".clfe-variation-title .selected-value").text(`: ${buttonElement.attr("text_value")}`);
            $parent.find(".clfe-variation-error-msg").hide();
        },

        handleVariationSelectionSelect(selectElement) {
            const $parent = selectElement.closest(".clfe-variation-parent");
            $parent.find("li").removeClass("vr-is-selected");
            const clfe_li_mask_id = selectElement.find(":selected").attr("clfe_li_mask");
            $parent.find(`li#${clfe_li_mask_id}`).click();
            $parent.find(".clfe-variation-error-msg").hide();
        },
        /*
         * this function should be triggered after the prodcut page loaded,
         * this will automatically set the product varaitions based on the cart   
         */
        setVariationsFromCart: function () {
            //const product = cart_clfe.getProductById(jsProduct.id);
            
            this.products.forEach((product, index) => {
                if ($.isArray(product.variations) && product.variations !== "undefined") {
                    const qty = Number(product.qty) || 1;

                    $("input[name=product_qty]").val(qty);

                    // duplicate the existing varation based on the quantity
                    if(typeof product_clfe === 'object') {
                        product_clfe.setVariationForQtyOffers(qty);
                    }

                    product.variations.forEach((productV, indexV1) => {
                        var ntchild = indexV1 + 1;

                        productV.forEach((productV2, indexV2) => {
                            var variationClassIndex = ".clfe_product_"+product.product_id + " .clfe_variation_element:nth-child(" + ntchild + ")" + " .clfe-variation-" + indexV2;
                            console.log(variationClassIndex);
                            $(variationClassIndex + ".clfe-variations-" + productV2.v_type + " select option[clfe_li_mask='clfe_li_mask_" + productV2.v_index + "']").attr("selected", "selected");
                            $(variationClassIndex + ".clfe-variations-" + productV2.v_type + " li[v_index='" + productV2.v_index + "']").click();
                        });
                    });
                    $(".clfe-variation-parent select").change();
                }
            
            });
        },
        existVariationErrors: function ($parentContainer) {
            var result = false;

            $parentContainer.find(".clfe-variation-error-msg").hide();
            $parentContainer.find(".clfe-variation-parent").each(function () {
                var isRequired = $(this).attr("is_required");
                if (isRequired === "yes" && $(this).find("li.vr-is-selected").length === 0) {
                    $(this).find(".clfe-variation-error-msg").addClass("clfe_shake_animation").show();

                    // this help the user to notice that there is an error and he should select a variation to add to cart
                    if ($(this).closest(".clfe_variation_element").find(".clfe_toggle_header").attr("is_open") === "no") {
                        $(this).closest(".clfe_variation_element").find(".clfe_toggle_header").click();
                    }

                    result = true;
                }
            });

            return result;
        },
        getProductVariations: function ($container) {
            var qtyVariations = [];
            var $container = $($container);
            $container.find(".clfe-variations-items").each(function () {
                var variations = [];
                $(this).find(".clfe-variation-parent li.vr-is-selected").each(function () {
                    variations.push({
                        slug: $(this).closest(".clfe-variation-parent").find(".clfe-variation-title").attr("vr_slug"),
                        value: $(this).attr("text_value"),
                        v_index: parseInt($(this).attr("v_index")),
                        fees: parseFloat($(this).attr("extra_fees")),
                        v_type: $(this).attr("v_type")
                    });
                });

                qtyVariations.push(variations);
            });
            
            console.log($container.attr('class'));

            return qtyVariations;
        },
        addCurrentItem: function (pdata) {

            if (pdata) {
                var productToAdd = pdata;
            } else {
                const qty = parseInt($("input[name=product_qty]").val());
                const discountPerProduct = this.getOfferDiscountPerProduct(qty);
                const sale_price = jsProduct.regular_price >= discountPerProduct ? jsProduct.regular_price - discountPerProduct : jsProduct.regular_price;

                var productToAdd = {
                    added_via: 'product_page',
                    product_id: jsProduct.id,
                    title: jsProduct.title,
                    regular_price: jsProduct.regular_price,
                    sale_price: sale_price,
                    discount_per_product: discountPerProduct,
                    qty: qty,
                    short_image_url: jsProduct.short_image_url,
                    custom_fields: [],
                    variations: this.getProductVariations('.clfe_product'),
                    offer: this.getProdcutQtyOffer()
                };
            }
            
            this.products.forEach((product, index) => {
                if (product.product_id === productToAdd.product_id) {
                    this.removeItem(index);
                }
            });
            

            //this.products.push(product);
            this.products.unshift(productToAdd);
            this.saveToStorage();
        },
        getProdcutQtyOffer: function () {
            var qtyOffer = {};

            if ($(".is-selected-qtyoffer").length > 0) {
                const qty = parseInt($(".is-selected-qtyoffer").attr("quantity"));
                qtyOffer = {
                    type: 'qty_offer',
                    title: $(".is-selected-qtyoffer").attr("offer_title"),
                    created_date: new Date().toISOString().slice(0, 19).replace('T', ' ')
                            /*qty: qty,
                             discount_per_product: parseFloat($(".is-selected-qtyoffer").attr("discount_per_product")),
                             total_discount: jsProduct.regular_price * qty*/

                };
                $(".clfe-product-discount .key-name .p_discount_label").text(qtyOffer.title);
            }

            return qtyOffer;
        },
        getOfferDiscountPerProduct: function (currentQty) {
            var discountPerProduct = jsProduct.discount_value;

            if ($(".is-selected-qtyoffer").length > 0) {
                discountPerProduct = parseFloat($(".is-selected-qtyoffer").attr("discount_per_product"));
            } else {
                /* if the user not choose an offer and select a qty > the existing max offer
                 * then you should retourn this max offer discoint
                 */
                const maxOfferQty = parseInt($(".clfe-qty-offers-items .clfe-qty-offer:last-child").attr("quantity"));
                if (currentQty > maxOfferQty) {
                    discountPerProduct = parseFloat($(".clfe-qty-offers-items .clfe-qty-offer:last-child").attr("discount_per_product"));
                }
            }


            return discountPerProduct;
        },
        getProductById: function (product_id) {
            var productResult = false;
            this.products.forEach((product, index) => {
                if (product.product_id === product_id) {
                    productResult = product;
                }
            });

            return productResult;
        },
        automaticallyAddCurrentProduct: function (pdata) {
            cart_clfe.addCurrentItem(pdata);
            cart_clfe.updateCartDisplay();

            if (typeof checkout_clfe !== 'undefined' && checkout_clfe) {
                checkout_clfe.updateSummary();
            }
        },
        removeItem: function (index) {
            this.products.splice(index, 1);
        },
        saveToStorage: function () {
            localStorage.setItem('clfe_cart_products', JSON.stringify(this.products));
        },
        loadFromStorage: function () {
            let storedCart = localStorage.getItem('clfe_cart_products');
            if (storedCart) {
                this.products = JSON.parse(storedCart);
            }
        },
        clearCart: function () {
            this.products = [];
            this.saveToStorage();
        },
        removeFromCart: function (index) {
            this.removeItem(index);
            this.saveToStorage();
            this.updateCartDisplay();
        },
        showEmptyCart: function () {
            // Hide all other cart blocks
            $('.clfe_cart_totals, #clfe_cart_actions, .clfe_cart_products').hide();
            $('#clfe_form, #clfe_shipping_options, #clfe_submit_button, #clfe_summary').hide();

            // Show only the empty cart block
            $('.clfe_cart_empty').show();
        },
        hideEmptyCart: function () {
            // Hide all other cart blocks
            $('.clfe_cart_totals, #clfe_cart_actions, .clfe_cart_products').show();
            $('#clfe_form, #clfe_shipping_options, #clfe_submit_button, #clfe_summary').show();

            // Show only the empty cart block
            $('.clfe_cart_empty').hide();
        },
        updateCartDisplay: function () {
            
            if (this.products.length === 0) {
                //$(".clfe_cart_products_display").html('<div class="cart_empty_text">'+jsCart.cart_empty_text+'</div>');
                this.showEmptyCart();
                return;
            }
            $(".clfe_cart_products_display").empty();
            this.hideEmptyCart();

            var totalRegularPrice = 0;
            var totalSalePrice = 0;

            this.products.forEach((product, index) => {
                const qty = Number(product.qty) || 1;
                var cartItem = $(".clfe_cart_empty-element .cart-product").clone(true);
                console.log(cartItem.attr('class'));

                if (product.short_image_url) {
                    cartItem.find(".clfe-cart-product-img img").attr("src", product.short_image_url);
                }

                cartItem.find(".clfe-cart-product-title").text(product.title + " x " + qty);

                var regularPrice = (product.regular_price * qty);
                var salePrice = (regularPrice) - (product.discount_per_product * qty);

                var totalExtraFees = 0;
                var productVariationsTexts = '';
                if ($.isArray(product.variations) && product.variations !== "undefined") {
                    product.variations.forEach((productV, indexV1) => {
                        var productQtyVariations = '<div class="qty_choise_variation">';
                        productV.forEach((productV2, indexV2) => {
                            var extraFeesText = "";
                            var extraFees = parseFloat(productV2.fees);
                            if (extraFees !== 0) {
                                if (extraFees > 0) {
                                    extraFeesText = `<span class="cart-variation-extra-fees cart-variation-extra-fees-plus">+ ${extraFees} ${jsMystore.currency_code}</span>`;

                                    regularPrice = regularPrice + Math.abs(extraFees);
                                    salePrice = salePrice + Math.abs(extraFees);
                                } else {
                                    extraFeesText = `<span class="cart-variation-extra-fees cart-variation-extra-fees-minus">- ${Math.abs(extraFees)} ${jsMystore.currency_code}</span>`;

                                    regularPrice = regularPrice - Math.abs(extraFees);
                                    salePrice = salePrice - Math.abs(extraFees);
                                }
                            }
                            productQtyVariations += `<span> ${productV2.slug} :  ${productV2.value} ${extraFeesText} </span> `;
                        });
                        productQtyVariations += '</div>';

                        // don't add emty variations
                        if (productQtyVariations !== '<div class="qty_choise_variation"></div>') {
                            productVariationsTexts += productQtyVariations;
                        }
                    });

                    cartItem.find(".clfe-cart-product-variations").html(productVariationsTexts);
                }

                cartItem.find(".clfe-cart-product-sale-price span:first-child").text(salePrice);
                cartItem.find(".clfe-cart-product-regular-price span:first-child").text(regularPrice);

                if( product.offer ) {
                    const qtyOffer = product.offer;
                    if (Object.keys(qtyOffer).length !== 0 && qtyOffer.type === 'qty_offer') {
                        cartItem.find(".cart-product-offer .clfe-title").text(`${qtyOffer.title}`);
                        cartItem.find(".cart-product-offer .clfe-value").text(`- ${qty * product.discount_per_product} ${jsMystore.currency_code}`);
                    }
                }

                cartItem.find(".cart-product-actions .clfe-button-update").attr("href", jsArgs.site_url + '?p=' + product.product_id);
                cartItem.find(".cart-product-actions .cart-remove-product").attr("product_index", index);

                // disable the ability to delete the current product from the cart when the popup checkout is not activated

                if (jsSalesFunnel.mode === '1step' && product.product_id === jsProduct.id) {
                    console.log(jsProduct.id);
                    cartItem.find(".cart-product-actions .cart-remove-product").remove();
                }

                var variationsIndexs = "cartvariation_" + product.product_id;
                //var productVariationsTexts = this.getProductVariationsTextsForCart(product.variations);

                cartItem.addClass(variationsIndexs);

                $(".clfe_cart_products_display").append(cartItem);

                totalRegularPrice = totalRegularPrice + regularPrice;
                totalSalePrice = totalSalePrice + salePrice;
            });

            $('.cart-regular-total').text(`${totalRegularPrice} ${jsMystore.currency_label}`);
            $('.cart-sale-total').text(`${totalSalePrice} ${jsMystore.currency_label}`);
        },
        getProductVariationsTextsForCart: function (productVariations) {
            var productVariationsTexts = '';
            if ($.isArray(productVariations) && productVariations !== "undefined") {
                productVariations.forEach((productV, indexV1) => {
                    var productQtyVariations = '<div class="qty_choise_variation">';
                    productV.forEach((productV2, indexV2) => {
                        var extraFeesText = "";
                        var extraFees = parseFloat(productV2.fees);
                        if (extraFees !== 0) {
                            if (extraFees > 0) {
                                extraFeesText = `<span class="cart-variation-extra-fees">+ ${extraFees} ${jsMystore.currency_code}</span>`;
                            } else {
                                extraFees = Math.abs(extraFees);
                                extraFeesText = `<span class="cart-variation-extra-fees">- ${extraFees} ${jsMystore.currency_code}</span>`;
                            }

                        }
                        productQtyVariations += `<span> ${productV2.slug} :  ${productV2.value} ${extraFeesText} </span> `;
                    });
                    productQtyVariations += '</div>';
                    productVariationsTexts += productQtyVariations;
                });
            }

            return productVariationsTexts;
        }
    };

    $(document).ready(function () {
        $("#clfe-cartside").hide();

        // to_update you shoul attach this to a button so the user can empty the cart
        //cart_clfe.clearCart();
        // cart
        cart_clfe.loadFromStorage();
        cart_clfe.updateCartDisplay();
        
        
        // variations elements
        $(".clfe-variation-parent li").on('click', function () { cart_clfe.handleVariationSelectionButton($(this)); });
        $(".clfe-variation-parent select").on('change', function () { cart_clfe.handleVariationSelectionSelect($(this)); });

        // is important to place here after the variations event click so that can work 
        cart_clfe.setVariationsFromCart();
        

        $(".cart-remove-product").on('click', function (ev) {
            ev.preventDefault();
            if (!confirm(jsCart.delete_confirm_msg)) {
                return;
            }

            const product_index = parseInt($(this).attr("product_index"));
            cart_clfe.removeFromCart(product_index);
        });

        // Handle add to cart button across different page types (shop, category, product)
        $("#clfe-addtocart-button, .add-to-cart-bt-button").on('click', function (ev) {
            ev.preventDefault();

            // Check if the clicked button has pdata attribute
            var $clickedButton = $(this);
            var pdata = $clickedButton.attr('pdata') || false;
            const $container = $(this).closest('.clfe_product');
            console.log($container);

            // If pdata exists, parse it, otherwise keep it as false
            if (pdata) {
                console.log(pdata);
                pdata = JSON.parse(pdata);
                pdata.variations = cart_clfe.getProductVariations($container);
            }

            // Pass pdata (or false) to cart functions
            if (!cart_clfe.existVariationErrors($container)) {
                cart_clfe.automaticallyAddCurrentProduct(pdata);

                switch (jsSalesFunnel.cart_mode) {
                    case 'modal_left':
                    case 'modal_right':
                        $("#clfe-cartside").show();
                        break;
                    case 'in_product':
                        if (jsSalesFunnel.checkout_mode == 'modal') {
                            $("#clfe-modal-form").modal({
                                escapeClose: false,
                                clickClose: false,
                                showClose: true
                            });
                        }
                        if (jsSalesFunnel.checkout_mode == 'in_product') {
                            document.getElementById('clfe_form').scrollIntoView();
                        }
                        if (jsSalesFunnel.checkout_mode == 'in_page') {
                            window.location.href = jsSalesFunnel.checkout_page_url;
                        }
                        break;
                    case 'in_page':
                        window.location.href = jsSalesFunnel.cart_page_url;
                        break;
                }
            }

            return false;
        });

        $(".goto-checkout-button").on('click', function (ev) {
            //ev.preventDefault();

            switch (jsSalesFunnel.checkout_mode) {
                case 'modal':
                    $("#clfe-modal-form").modal({
                        escapeClose: false,
                        clickClose: false,
                        showClose: true
                    });

                    return;
                case 'in_product':
                    $("#clfe-cartside").hide();
                    document.getElementById('clfe_form').scrollIntoView();
                    return;
                case 'in_page':
                    window.location.href = jsSalesFunnel.checkout_page_url;
                    return;
            }


        });

        $("#cart-modal-close-button").on('click', function (ev) {
            ev.preventDefault();
            $("#clfe-cartside").hide();
        });



    });

})(jQuery);
