(function ($) {
    'use strict'; // Enable strict mode for better error catching

    // Main cart object
    const cart_cl = {
        products: [],

        /**
         * Initialize the cart system
         * @OLD init
         */
        init() {
            //this.clearCart();
            this.loadFromStorage();
            this.updateCartDisplay();
            this._bindEvents();

            // Hide cart initially
            $("#cl-cartside").hide();
        },

        /**
         * Bind all event handlers
         * @OLD _bindEvents
         */
        _bindEvents() {
            // Cart open button
            $('.cart_open').on('click', (ev) => {
                ev.preventDefault();
                this.openCartStep();
            });

            // Checkout button
            $('.goto-checkout-button').on('click', (ev) => {
                ev.preventDefault();
                this.openCheckoutStep();
            });

            // Cart removal - using event delegation
            $(".cl_cart_products_display").on('click', '.cart-remove-product', (ev) => {
                ev.preventDefault();
                if (!confirm(jsCart.delete_confirm_msg)) {
                    return;
                }

                const productIndex = parseInt($(ev.currentTarget).attr("product_index"));
                this.removeFromCart(productIndex);
            });

            // Product update button - using event delegation
            $(".cl_cart_products_display").on('click', '.cl-button-update', (ev) => {
                ev.preventDefault();
                const productId = parseInt($(ev.currentTarget).attr("product_id"));

                if (isProductPage && jsProduct.id === productId) {
                    $("#cl-cartside").hide();
                    if ($.modal.isActive()) {
                        $.modal.close();
                    }
                } else {
                    window.location.href = jsArgs.site_url + '?p=' + productId;
                }
            });

            // Add to cart button - single product page
            $(document).on('click', "#cl-addtocart-button", (ev) => {
                ev.preventDefault();
                const $clickedButton = $(ev.currentTarget);
                const $container = $clickedButton.closest('.cl_product');
                
                // Check for variations errors first
                if (typeof variations_cl !== 'undefined' && variations_cl.hasErrors($container)) {
                    return; // Don't add to cart if there are validation errors
                }

                this.addProduct();
                this.openCartStep();
            });
            
            // Add to cart button - products Listing
            $(document).on('click', ".add-to-cart-bt-button", (ev) => {
                ev.preventDefault();
                const $clickedButton = $(ev.currentTarget);
                const $container = $clickedButton.closest('.cl_product');
                
                let currentProductId = $container.attr('product_id');
                if ( !cart_cl.isProductInCart(currentProductId) ) {
                    this.addProduct(currentProductId);
                }
                this.openCartStep();
            });

            // Cart modal close button
            $("#cart-modal-close-button").on('click', (ev) => {
                ev.preventDefault();
                $("#cl-cartside").hide();
            });
        },
        
        /**
         * Get product by ID
         * @OLD getProductById
         * @param {number} productId - Product ID to find
         * @return {Object|false} Product object or false if not found
         */
        getProductById(productId) {
            return this.products.find(product => product.product_id === productId) || false;
        },
        
        /**
         * Check if a product exists in the cart
         * @param {number} productId - Product ID to check
         * @return {boolean} True if product exists in cart, false otherwise
         */
        isProductInCart(productId) {
            // Convert productId to number to ensure proper comparison
            const numericProductId = parseInt(productId);
            
            // Return false if productId is not a valid number
            if (isNaN(numericProductId)) {
                return false;
            }
            
            // Check if any product in cart matches the given product ID
            return this.products.some(product => product.product_id === numericProductId);
        },

        /**
         * Get product data for cart addition
         * @OLD N/A (new method)
         * @param {Number|null} currentProductId - External Product Id or null for current product
         * @return {Object|null} Product data object or null if unavailable
         */
        getProductData(currentProductId = null) {
           /*
            * This can happen in add to cart from listing products
            * todo - change this so it can get the json product data from a json loaded in js
            */
            if (typeof product_cl === 'undefined') {
                const $container = $('.cl_list .cl_product_'+currentProductId);
                const pdata = JSON.parse($container.find('.add-to-cart-bt-button').attr('pdata'));
                
                /*if (typeof variations_cl !== 'undefined') {
                    pdata.variations = variations_cl.getSelectedOptions($container);
                }*/
                
                return pdata;
            }

            const qty = parseInt($("input[name=product_qty]").val());
            const discountPerProduct = typeof qtyoffer_cl !== 'undefined' ? qtyoffer_cl.getDiscountPerProduct(qty) : jsProduct.discount_value;

            const pdata = {
                added_via: 'product_page',
                product_id: jsProduct.id,
                title: jsProduct.title,
                regular_price: jsProduct.regular_price,
                sale_price: Math.max(0, jsProduct.regular_price - discountPerProduct),
                discount_per_product: discountPerProduct,
                qty: qty,
                short_image_url: jsProduct.short_image_url,
                custom_fields: [],
                variations: typeof variations_cl !== 'undefined' ? variations_cl.getSelectedOptions('.cl_product') : [],
                qty_offer: typeof qtyoffer_cl !== 'undefined' ? qtyoffer_cl.getSelectedOptions() : {}
            };
            
            return pdata;
        },
        /**
        * Add current product to cart and update cart display
        * @param currentProductId
        */
        addProduct(currentProductId = null) {
           const productToAdd = this.getProductData(currentProductId);
           if( typeof productToAdd.product_id === 'undefined' ) {
               return;
           }
           // Remove existing product with same ID
           const existingIndex = this.products.findIndex(p => p.product_id === productToAdd.product_id);
           if (existingIndex !== -1) {
               this._removeItem(existingIndex);
           }
           // Add to beginning of array
           this.products.unshift(productToAdd);
           this.saveToStorage();

           this.updateCartDisplay();
           if (typeof checkout_cl !== 'undefined' && checkout_cl) {
               checkout_cl.updateSummary();
           }
        },

        /**
         * Remove item from products array
         * @OLD removeItem
         * @param {number} index - Index to remove
         */
        _removeItem(index) {
            this.products.splice(index, 1);
        },

        /**
         * Save cart to localStorage
         * @OLD saveToStorage
         */
        saveToStorage() {
            try {
                localStorage.setItem('cl_cart_products', JSON.stringify(this.products));
            } catch (error) {
                console.error('Failed to save cart to storage:', error);
                // Implement fallback mechanism if needed
            }
        },

        /**
         * Load cart from localStorage
         * @OLD loadFromStorage
         */
        loadFromStorage() {
            try {
                const storedCart = localStorage.getItem('cl_cart_products');
                if (storedCart) {
                    this.products = JSON.parse(storedCart);
                }
            } catch (error) {
                console.error('Failed to load cart from storage:', error);
                this.products = [];
            }
            //console.log(this.products);
        },

        /**
         * Clear cart completely
         * @OLD clearCart
         */
        clearCart() {
            this.products = [];
            this.saveToStorage();
        },

        /**
         * Remove item from cart and update display
         * @OLD removeFromCart
         * @param {number} index - Index to remove
         */
        removeFromCart(index) {
            this._removeItem(index);
            this.saveToStorage();
            this.updateCartDisplay();

            // Update checkout if it exists
            if (typeof checkout_cl !== 'undefined' && checkout_cl) {
                checkout_cl.updateSummary();
            }
        },

        /**
         * Show empty cart state
         * @OLD showEmptyCart
         */
        showEmptyCart() {
            // Hide all other cart blocks
            $('.cl_cart_totals, #cl_cart_actions, .cl_cart_products').hide();
            $('#cl_form, #cl_shipping_options, #cl_submit_button, #cl_summary').hide();

            // Show empty cart block
            $('.cl_cart_empty').show();
        },

        /**
         * Hide empty cart state
         * @OLD hideEmptyCart
         */
        hideEmptyCart() {
            // Show all cart blocks
            $('.cl_cart_totals, #cl_cart_actions, .cl_cart_products').show();
            $('#cl_form, #cl_shipping_options, #cl_submit_button, #cl_summary').show();

            // Hide empty cart block
            $('.cl_cart_empty').hide();
        },

        _createCartItem(product, index) {
            const qty = Number(product.qty) || 1;
            const $template = $(".cl_cart_empty_element .cart-product").first();
            const $cartItem = $template.clone(true);

            // Set product basic info directly
            if (product.short_image_url) {
                $cartItem.find(".cl-cart-product-img img").attr("src", product.short_image_url);
            }
            $cartItem.find(".cl-cart-product-title").text(`${product.title} x ${qty}`);

            // Calculate base prices directly
            let regularPrice, salePrice;
            if (product.qty_offer && Object.keys(product.qty_offer).length !== 0) {
                regularPrice = parseFloat(product.qty_offer.regular_price) || 0;
                salePrice = parseFloat(product.qty_offer.sale_price) || 0;
            } else {
                regularPrice = (product.regular_price * qty);
                salePrice = regularPrice - (product.discount_per_product * qty);
            }

            // Set prices directly
            $cartItem.find(".cl-cart-product-sale-price span:first-child").text(salePrice);
            if (regularPrice > salePrice) {
                $cartItem.find(".cl-cart-product-regular-price span:first-child").text(regularPrice);
            } else {
                $cartItem.find(".cl-cart-product-regular-price").remove();
            }

            // Set offer info directly
            if (product.qty_offer && Object.keys(product.qty_offer).length !== 0) {
                $cartItem.find(".cart-product-offer .cl-title").text(product.qty_offer.title);
                if(parseInt(product.qty_offer.saving) > 0) {
                    $cartItem.find(".cart-product-offer .cl-value").text(`- ${product.qty_offer.saving} ${jsMystore.currency_code}`);
                }
            }

            // Set action buttons directly
            $cartItem.find(".cart-product-actions .cl-button-update").attr("product_id", product.product_id);
            $cartItem.find(".cart-product-actions .cart-remove-product").attr("product_index", index);
            if (typeof isProductPage !== 'undefined' && isProductPage && jsProduct.id === product.product_id) {
                $cartItem.find(".cart-product-actions .cart-remove-product").remove();
            }

            return { $cartItem, regularPrice, salePrice };
        },

        /**
         * Update cart display with current products
         * @OLD updateCartDisplay
         */
        updateCartDisplay() {
            if (this.products.length === 0) {
                this.showEmptyCart();
                return;
            }

            $('.cl_count_products').text(this.products.length);
            
            const $cartDisplay = $(".cl_cart_products_display");
            $cartDisplay.empty();
            this.hideEmptyCart();

            let totalRegularPrice = 0;
            let totalSalePrice = 0;

            this.products.forEach((product, index) => {
                let {$cartItem, regularPrice, salePrice} = this._createCartItem(product, index);

                if (typeof variations_cl !== 'undefined') {
                    const variationResult = variations_cl.renderSingleProductInCart(product.variations);
                    regularPrice += variationResult.priceAdjustment;
                    salePrice += variationResult.priceAdjustment;
                    
                    $cartItem.find(".cl-cart-product-variations").html(variationResult.html);
                    $cartItem.addClass(`cartvariation_${product.product_id}`);
                }

                totalRegularPrice += regularPrice;
                totalSalePrice += salePrice;
                
                if (typeof product_cl !== 'undefined') {
                    product_cl.updatePricesDisplay(regularPrice, salePrice);
                }
                
                $cartDisplay.append($cartItem);
            });

            $('.cart-regular-total').text(`${totalRegularPrice} ${jsMystore.currency_label}`);
            $('.cart-sale-total').text(`${totalSalePrice} ${jsMystore.currency_label}`);
        },

        /**
         * Open checkout modal
         * @OLD openCheckoutModal
         */
        openCheckoutModal() {
            $('.cl_checkout_modal').show();
            /*$("#cl-modal-form").modal({
                escapeClose: false,
                clickClose: false,
                showClose: true
            });*/
        },

        /**
         * Handle checkout step based on configuration
         * @OLD openCheckoutStep
         */
        openCheckoutStep() {
            // Handle based on page type and checkout mode
            if (typeof isProductPage !== 'undefined' && isProductPage) {
                switch (jsSalesFunnel.checkout_mode) {
                    case 'modal':
                        this.openCheckoutModal();
                        return;
                    case 'in_product':
                        $("#cl-cartside").hide();
                        document.getElementById('cl_form').scrollIntoView();
                        return;
                    case 'in_page':
                    default:
                        window.location.href = jsSalesFunnel.checkout_page_url;
                        return;
                }
            } else {
                switch (jsSalesFunnel.checkout_mode) {
                    case 'modal':
                        this.openCheckoutModal();
                        return;
                    default:
                        window.location.href = jsSalesFunnel.checkout_page_url;
                        return;
                }
            }
        },

        /**
         * Handle cart step based on configuration
         * @OLD openCartStep
         */
        openCartStep() {
            if (typeof isProductPage !== 'undefined' && isProductPage) {
                switch (jsSalesFunnel.cart_mode) {
                    case 'modal_left':
                    case 'modal_right':
                        $("#cl-cartside").show();
                        break;
                    case 'open_checkout':
                    case 'in_product':
                        this.openCheckoutStep();
                        break;
                    case 'in_page':
                    default:
                        window.location.href = jsSalesFunnel.cart_page_url;
                        break;
                }
            } else {
                switch (jsSalesFunnel.cart_mode) {
                    case 'modal_left':
                    case 'modal_right':
                        $("#cl-cartside").show();
                        return;
                    case 'open_checkout':
                        this.openCheckoutStep();
                        break;
                    default:
                        window.location.href = jsSalesFunnel.cart_page_url;
                        return;
                }
            }
        }
    };

    // Export cart object to global scope
    window.cart_cl = cart_cl;

    // Initialize on document ready
    $(document).ready(function () {
        cart_cl.init();
    });

})(jQuery);