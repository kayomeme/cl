<?php

    //include_once $compsPath.$filter['compName'].'/frontend/views/index.php';
