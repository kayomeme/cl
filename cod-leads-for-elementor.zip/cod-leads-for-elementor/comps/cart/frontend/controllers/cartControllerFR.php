<?php

/**
 */
class CartControllerFR_clfe {
    
    public $settings;
    public $settingsModelId;
    public $isCartPage;

    public function __construct($checkoutSettings = null) {
        global $settingsModelId;
        
        $compoName = 'cart';
        $settings = PublicCompo_clfe::getSettings($compoName, $settingsModelId);
        
        if(is_array($checkoutSettings) ) {
            $settings = array_merge($settings, $checkoutSettings);
        }
        
        $this->settings = $settings;
        
    }
    
    public function getSettings() {
        return $this->settings;
    }

    public function index() {
        global $mystore_clfe;
        global $sharedSettings;
        global $isCartPage;
        global $isCheckoutPage;

        $settings = $this->settings;
        $mystoreSettings = $mystore_clfe->settings;
        
        $checkoutBlocksOrder    = isset( $settings['checkout_blocks_order'] ) ? explode(',', $settings['checkout_blocks_order']) : []; 

        require_once MainApp_clfe::$compsPath.'cart/frontend/views/index.php';

    }
    
    public function getJsCart() {
        $jsCart = [];

        $jsCart['delete_confirm_msg'] = Lang_clfe::__('Are you sure you want to remove this item from your cart?', 'clfe');
        $jsCart['cart_empty_text'] = $this->settings['cart_empty_text'];
        
        return jsonEncodeForJs_clfe($jsCart);
    }
    
}
