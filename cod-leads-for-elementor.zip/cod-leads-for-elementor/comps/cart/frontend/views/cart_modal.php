<?php
// is called by cart\frontend\hooks\wp_footer.php

$allBlocksContent = '';
$cartSideBlocksContent = '';
$checkoutModalBlocksContent = '';
$currectBlockContent = '';

$cartModes = ['modal_left', 'modal_right'];
if( in_array($salesFunnel_clfe->cartMode, $cartModes)) {
    $cartStartPart = '';
    $cartBlocksOrder = isset($settings['cart_blocks_order']) ? explode(',', $settings['cart_blocks_order']) : [];
    $countCartBlocks = count($cartBlocksOrder);
    foreach ($cartBlocksOrder as $index => $blockName) {
        ob_start();
        include MainApp_clfe::$compsPath . 'cart/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
        $currectBlockContent = ob_get_clean();

        if( $countCartBlocks > $index + 1 ) {
            $cartStartPart = $cartStartPart.$currectBlockContent;
        }  
    } 
    $cartSideBlocksContent = $cartSideBlocksContent.'<div class="cartside-start-part">'.$cartStartPart.'</div>'.$currectBlockContent;
}
?>

<div id="clfe-cartside" style="display: flex">
    <div class="cart-modal-header">
        <div class="cart-modal-title">
            <?= $settings['cart_modal_title'] ?>
        </div>
        <div>
            <button id="cart-modal-close-button">
                <i class="icon-minus"></i>
                <?= $settings['cart_modal_close_text'] ?> 
            </button>
        </div>
    </div>
    <div class="cart-modal-body">
        <?= $cartSideBlocksContent ?>
    </div>
</div>