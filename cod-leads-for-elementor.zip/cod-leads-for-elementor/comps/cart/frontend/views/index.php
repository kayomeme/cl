<?php
if (!is_admin()) {
    //var_dump($settings);
}
?>    

<?php
include_once MainApp_cl::$compsPath . 'cart/frontend/views/blocks/cart_empty/' . $settings['cart_empty_version'] . '/index.php';
?>
<div class="cl-cart-wrapper">
    <?php
    $cart_blocks_order = explode(',', $settings['cart_blocks_order']);

    foreach ($cart_blocks_order as $cartElement) {
        include_once 'blocks/' . $cartElement . '/' . $settings[$cartElement . '_version'] . '/index.php';
    }
    ?>
</div>
