<?php
if (!is_admin()) {
    //var_dump($settings);
}
?>    

<?php
include_once MainApp_clfe::$compsPath . 'cart/frontend/views/blocks/cart_empty/' . $settings['cart_empty_version'] . '/index.php';
?>
<div class="clfe-cart-wrapper">
    <?php
    $cart_blocks_order = explode(',', $settings['cart_blocks_order']);

    foreach ($cart_blocks_order as $cartElement) {
        include_once 'blocks/' . $cartElement . '/' . $settings[$cartElement . '_version'] . '/index.php';
    }
    ?>
</div>
<?php
$checkoutModalBlocksContent = '';
$checkoutModes = ['modal'];
if (in_array($salesFunnel_clfe->checkoutMode, $checkoutModes)) {
    foreach ($checkoutBlocksOrder as $blockName) {
        ob_start();
        include_once MainApp_clfe::$compsPath . 'checkout/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
        $currectBlockContent = ob_get_clean();

        $checkoutModalBlocksContent = $checkoutModalBlocksContent . $currectBlockContent;
    }
}
?>
<div class="clfe-modals-container">
    <?php
    if ($checkoutModalBlocksContent != '' && !is_admin()) {
        include 'checkout_modal.php';
    }
    ?>
</div>