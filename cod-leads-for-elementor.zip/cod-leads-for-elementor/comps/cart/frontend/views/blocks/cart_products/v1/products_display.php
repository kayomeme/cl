    <div class="cl_cart_products_display">

    </div>
    <?php
    include_once 'product_empty_element.php';
    ?>