<?php
if ($settings['cart_products_is_active'] === 'no') {
    return;
}
if ($settings['cart_products_header_is_active'] == 'no') {
    $settings['cart_products_header_is_open'] = 'yes';
}

/*global $salesFunnel_clfe;
if ($salesFunnel_clfe->mode == '3steps' && $isCheckoutPage) {
    return;
}*/
?>

<div id="clfe_cart_products" class="clfe_cart_products clfe_toggle_is_active" _attachedsection="cart_products">
    <?php if ($settings['cart_products_header_is_active'] == 'yes') { ?>
        <div class="clfe_toggle_header" is_open="<?= $settings['cart_products_header_is_open'] == 'yes' ? 'yes' : 'no' ?>">
            <div class="cart-header-title">
                <span class="icon-cart"></span> &nbsp;
                <span class="cart_products_header_title_is_open clfe_toToggle_is_open<?= $settings['cart_products_header_is_open'] == 'yes' ? '_yes' : '_no' ?>">
                    <?= $settings['cart_products_header_title_is_open'] ?>
                </span>
                <span class="cart_products_header_title_is_closed clfe_toToggle_is_open<?= $settings['cart_products_header_is_open'] == 'yes' ? '_no' : '_yes' ?>">
                    <?= $settings['cart_products_header_title_is_closed'] ?>
                </span>
            </div>
            <div class="cart-header-count-container">
                <span class="cart-header-count-text"><?= $settings['cart_products_header_count_text'] ?></span> 
                <span class="cart-header-count-number">20</span>
            </div>
        </div>
    <?php } ?>
    <div class="clfe_toggle_body <?= $settings['cart_products_header_is_open'] == 'yes' ? 'clfe_is_open_yes' : 'clfe_is_open_no' ?>">
        <?php include 'products_display.php'; ?>
    </div>


</div>