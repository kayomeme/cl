<?php
if ($settings['cart_products_is_active'] === 'no') {
    return;
}
if ($settings['cart_products_header_is_active'] == 'no') {
    $settings['cart_products_header_is_open'] = 'yes';
}

$isOpen = $settings['cart_products_header_is_open'] == 'yes' ? 'yes' : 'no';

// Count cart products
$cartProductsCount = isset($cart_items) ? count($cart_items) : 1;

/*global $salesFunnel_cl;
if ($salesFunnel_cl->mode == '3steps' && $isCheckoutPage) {
    return;
}*/
?>

<div class="cl_cart_products cl_toggle_block cl_product_block" _attachedsection="cart_products" is_open="<?= $isOpen ?>">
    <?php if ($settings['cart_products_header_is_active'] == 'yes') { ?>
        <div class="cl_toggle_header">
            <div class="toggle-title">
                <span class="icon-cart"></span> &nbsp;
                <span show_in_open>
                    <?= $settings['cart_products_header_title_is_open'] ?>
                </span>
                <span show_in_close>
                    <?= $settings['cart_products_header_title_is_closed'] ?>
                </span>
            </div>
            <div class="toggle-close">
                <div class="cart-products-header-count-text">
                    <span class="count_number"><?= $cartProductsCount ?> </span>
                    <span class="count_text"><?= $settings['cart_products_header_count_text'] ?></span>
                </div>
                <?php echo $iconsSelectorFR_cl->getIconCode($sharedSettings['collapse_open_icon_id'], ['class' => 'cl-icon-open']); ?>
                <?php echo $iconsSelectorFR_cl->getIconCode($sharedSettings['collapse_close_icon_id'], ['class' => 'cl-icon-close']); ?>
            </div>
        </div>
        <?php if ($settings['cart_products_preview_is_active'] == 'yes') { ?>
        <div class="cl_toggle_preview" show_in_close>
            <span class="prefix_text"><?= $settings['cart_products_preview_prefix_text'] ?></span>
            <span class="selected_value_text">
                <span class="count_number"><?= $cartProductsCount ?></span>
                <span class="count_text"><?= $settings['cart_products_header_count_text'] ?></span>
            </span>
        </div>
        <?php } ?>
    <?php } ?>
    <div class="cl_toggle_body" show_in_open>
        <?php include 'products_display.php'; ?>
    </div>

</div>