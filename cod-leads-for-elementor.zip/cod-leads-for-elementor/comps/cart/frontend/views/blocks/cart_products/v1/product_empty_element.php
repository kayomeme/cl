<div class="cl_cart_empty_element" style="display: none !important">
    <div class="cart-product">
        <div class="img-and-title">
            <?php if ($settings['cart_products_image_is_active'] == 'yes') { ?>
                <div class="cl-cart-product-img">
                    <img src="" />
                </div>
            <?php } ?>

            <div class="cl-cart-body">

                <div class="cart-product-meta">
                    <?php if ($settings['cart_products_title_is_active'] == 'yes') { ?>
                        <div class="cl-cart-product-title"></div>
                    <?php } ?>
                    <?php if ($settings['cart_products_variations_is_active'] == 'yes') { ?>
                        <div class="cl-cart-product-variations"></div>
                    <?php } ?>    
                </div>


                <div class="cart-product-price-box">
                    <div class="cart-product-price">
                        <?php if ($settings['cart_products_sale_price_is_active'] == 'yes') { ?>
                            <div class="cl-cart-product-sale-price">
                                <span class="sale_price"></span>
                                <span class="cl-currency"><?= $sharedSettings['currency_label'] ?></span>
                            </div>
                        <?php } ?>
                        <?php if ($settings['cart_products_regular_price_is_active'] == 'yes') { ?>
                            <div class="cl-cart-product-regular-price">
                                <span class="regular_price"></span>
                                <span class="cl-currency"><?= $sharedSettings['currency_label'] ?></span>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="cart-product-offer">
                        <span class="cl-title"></span>
                        <span class="cl-value"></span>
                    </div>
                </div>
            </div>

        </div>
        <div class="cart-product-actions">
            <?php if ($settings['cart_products_edit_button_is_active'] == 'yes') { ?>
                <button class="cl-button cl-button-update" title="<?= Lang_cl::__('Update this product.', 'cl') ?>">
                    <i class="cl-icon icon-edit" title="<?= $settings['cart_products_edit_button_text'] ?>"></i>
                    <?= $settings['cart_products_edit_button_text'] ?>
                </button>
            <?php } ?>
            <?php if ($settings['cart_products_remove_button_is_active'] == 'yes') { ?>
                <button class="cart-remove-product cl-button cl-button-delete" title="<?= Lang_cl::__('Remove this item from your shopping cart.', 'cl') ?>">
                    <i class="cl-icon icon-trash-2" title="<?= $settings['cart_products_remove_button_text'] ?>"></i>
                    <?= $settings['cart_products_remove_button_text'] ?>
                </button>
            <?php } ?>
        </div>
    </div>
</div>