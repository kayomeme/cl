<?php
if ($settings['cart_empty_is_active'] === 'no') {
    return;
}

// Only show this block when the cart is empty
if (!empty($cart_items)) {
    return;
}

// Get continue shopping URL
$continueShoppingUrl = home_url();
if ($settings['cart_empty_continue_custom_url_is_active'] === 'yes' && !empty($settings['cart_empty_continue_custom_url'])) {
    $continueShoppingUrl = $settings['cart_empty_continue_custom_url'];
}
?>
<div class="clfe_cart_empty" _attachedsection="cart_empty" style="display: none">
        <?php if ($settings['cart_empty_show_icon'] === 'yes') { ?>
        <div class="cart-empty-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="140" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="8" cy="21" r="1"></circle>
                <circle cx="19" cy="21" r="1"></circle>
                <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"></path>
            </svg>
        </div>
        <?php } ?>
    
        <div class="cart-empty-text">
            <?= $settings['cart_empty_text'] ?>
        </div>
    
        <div class="cart-empty-subtext">
            <?= $settings['cart_empty_subtext'] ?>
        </div>
    
    <?php if ($settings['cart_empty_continue_is_active'] === 'yes') { ?>
        <div class="cart-empty-actions">
            <a class="continue-button" href="<?= $continueShoppingUrl ?>">
                <?= $settings['cart_empty_continue_text'] ?>
            </a>
        </div>
    <?php } ?>
</div>