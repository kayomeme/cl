<?php
if ($settings['cart_totals_is_active'] === 'no') {
    return;
}
global $salesFunnel_cl;
if ($salesFunnel_cl->mode == '3steps' && $isCheckoutPage) {
    return;
}
?>
<div id="cl_cart_totals" class="cl_cart_totals" _attachedsection="cart_totals">
    <div class="total-row">
        <div class="total-label">
            <i class="cl-icon icon-dollar-sign"></i>
            <?= $settings['cart_totals_total_label'] ?>
        </div>
        <div class="total-value">
            <?php if( $settings['cart_totals_sale_price_is_active'] == 'yes' ) { ?>
            <div class="cl-sale cart-sale-total"></div>
            <?php } ?>
            <?php if( $settings['cart_totals_regular_price_is_active'] == 'yes' ) { ?>
            <div class="cl-regular-price cart-regular-total"></div>
            <?php } ?>
        </div>
    </div>
</div>