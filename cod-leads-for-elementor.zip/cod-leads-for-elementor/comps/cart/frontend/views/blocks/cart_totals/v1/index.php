<?php
if ($settings['cart_totals_is_active'] === 'no') {
    return;
}
global $salesFunnel_clfe;
if ($salesFunnel_clfe->mode == '3steps' && $isCheckoutPage) {
    return;
}
?>
<div id="clfe_cart_totals" class="clfe_cart_totals" _attachedsection="cart_totals">
    <div class="total-row">
        <div class="total-label">
            <i class="clfe-icon icon-dollar-sign"></i>
            <?= $settings['cart_totals_total_label'] ?>
        </div>
        <div class="total-value">
            <?php if( $settings['cart_totals_sale_price_is_active'] == 'yes' ) { ?>
            <div class="clfe-sale cart-sale-total"></div>
            <?php } ?>
            <?php if( $settings['cart_totals_regular_price_is_active'] == 'yes' ) { ?>
            <div class="clfe-regular-price cart-regular-total"></div>
            <?php } ?>
        </div>
    </div>
</div>