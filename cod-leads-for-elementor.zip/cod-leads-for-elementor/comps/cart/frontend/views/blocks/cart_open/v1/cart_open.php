<?php
// is called by cart\frontend\hooks\wp_footer.php
?>

    <div class="cart_open" title="<?= Lang_cl::__('Open your cart', 'cl') ?>">
            <?php if ($settings['cart_open_text_is_active'] == 'yes' && !empty($settings['cart_open_text'])) { ?>
            <span class="cart-icon-and-count">
            <?php if ($settings['cart_open_icon_is_active'] == 'yes') {
                echo $iconsSelectorFR_cl->getIconCode($settings['cart_open_icon_id']);
            } ?>
                <?php if ($settings['cart_open_count_is_active'] == 'yes') { ?>
                    <span class="cl_count_products"></span>
                <?php } ?>
            </span>

            <span class="cart_open-button-text">
            <?= $settings['cart_open_text'] ?>
            </span>
        <?php } else { ?>
            <?php if ($settings['cart_open_icon_is_active'] == 'yes') {
                echo $iconsSelectorFR_cl->getIconCode($settings['cart_open_icon_id']);
            } ?>
            <?php if ($settings['cart_open_count_is_active'] == 'yes') { ?>
                <span class="cl_count_products"></span>
            <?php } ?>
    <?php } ?>
    </div>