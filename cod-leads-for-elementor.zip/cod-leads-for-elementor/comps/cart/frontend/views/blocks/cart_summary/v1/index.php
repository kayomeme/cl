<?php
if ($settings['cart_summary_is_active'] === 'no') {
    return;
}

global $salesFunnel_clfe;

if( $salesFunnel_clfe->mode == '3steps' && $isCheckoutPage  ) {
    return;
}

$checkoutPageLink = false;
if( $settings['cart_summary_goto_checkout_is_active'] == 'yes' ) {
    if( $isCartPage && isset( $salesFunnel_clfe->checkoutPageId ) ) {
        $checkoutPageLink = get_the_permalink($salesFunnel_clfe->checkoutPageId);
    }
    
    if( $salesFunnel_clfe->mode == '1step' ) {
        $checkoutPageLink = '#clfe_form';
    }
}
?>
<div id="clfe_cart_summary" _attachedsection="cart_summary" class="clfe-cart-summary">
    <div class="cart-summary-body">
        <div class="cart-summary-total">
            <div class="total-label">
                <?= $settings['cart_summary_total_label'] ?>
            </div>
            <div class="total-value">
                <div class="clfe-sale cart-sale-total"></div>
                <div class="clfe-regular-price cart-regular-total"></div>
            </div>
        </div>
        <?php if ($settings['cart_summary_promo_is_active'] == 'yes') { ?>
            <div class="cart-summary-coupon">
                <div>
                    <span>Do you have a promo code?</span>
                    <span> -20 USD</span>
                </div>
                <div class="promo-input-group">
                    <input type="text" placeholder="<?= $settings['cart_summary_promo_placeholder'] ?>" class="promo-input" />
                    <button class="btn-apply"><?= $settings['cart_summary_apply_button_text'] ?></button>
                </div>
            </div>
        <?php } ?>
    </div>
        <?php if ($checkoutPageLink) { ?>
            <div class="cart-buttons">
                <a class="goto-checkout" href="<?= $checkoutPageLink ?>"><?= $settings['cart_summary_goto_checkout_text'] ?></a>
            </div>
        <?php } ?>
</div>