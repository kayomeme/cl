<?php
/*
 * This block is not called directly. The role of this block is to group all other blocks
 * and display them inside a modal. See the file cart_modal.php for more information.
 */