<?php
// is called by cart\frontend\hooks\wp_footer.php

$allBlocksContent = '';
$cartSideBlocksContent = '';
$checkoutModalBlocksContent = '';
$currectBlockContent = '';

$cart_modes = ['modal_left', 'modal_right'];
if( in_array($salesFunnel_cl->cart_mode, $cart_modes) || !$isProductPage) {
    $cartStartPart = '';
    $cartBlocksOrder = isset($settings['cart_blocks_order']) ? explode(',', $settings['cart_blocks_order']) : [];
    $countCartBlocks = count($cartBlocksOrder);
    foreach ($cartBlocksOrder as $index => $blockName) {
        ob_start();
        include MainApp_cl::$compsPath . 'cart/frontend/views/blocks/' . $blockName . '/' . $settings[$blockName . '_version'] . '/index.php';
        $currectBlockContent = ob_get_clean();

        if( $countCartBlocks > $index + 1 ) {
            $cartStartPart = $cartStartPart.$currectBlockContent;
        }  
    } 
    $cartSideBlocksContent = $cartSideBlocksContent.'<div class="cartside-start-part">'.$cartStartPart.'</div>'.$currectBlockContent;
?>

<div id="cl-cartside" style="display: none">
    <div class="cart-modal-header">
        <div class="cart-modal-title">
            <?= $settings['cart_modal_header_title'] ?>
        </div>
        <div>
            <button id="cart-modal-close-button">
                <i class="icon-minus"></i>
                <?= $settings['cart_modal_header_close_text'] ?> 
            </button>
        </div>
    </div>
    <div class="cart-modal-body">
        <?= $cartSideBlocksContent ?>
    </div>
</div>

<?php } ?>