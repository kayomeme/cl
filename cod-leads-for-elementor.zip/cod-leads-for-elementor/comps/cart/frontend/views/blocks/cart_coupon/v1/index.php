<?php
if ($settings['cart_coupon_is_active'] === 'no') {
    return;
}
global $salesFunnel_cl;
if ($salesFunnel_cl->mode == '3steps' && $isCheckoutPage) {
    return;
}
?>
<div id="cl_cart_coupon" _attachedsection="cart_coupon" class="cl_cart_coupon">
    <div class="coupon-header">
        <span><?= $settings['cart_coupon_title'] ?></span>
        <span class="discount-amount"></span>
    </div>
    <div class="promo-input-group">
        <input 
            type="text" 
            placeholder="<?= $settings['cart_coupon_placeholder'] ?>" 
            class="promo-input" 
        />
        <button class="apply-button">
            <?= $settings['cart_coupon_button_text'] ?>
        </button>
    </div>
</div>