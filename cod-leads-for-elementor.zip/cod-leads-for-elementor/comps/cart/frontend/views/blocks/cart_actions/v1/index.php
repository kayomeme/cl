<?php
if ($settings['cart_actions_is_active'] === 'no') {
    return;
}
global $salesFunnel_cl;

$checkoutPageLink = false;
if ($settings['cart_actions_checkout_is_active'] == 'yes') {
    if ($isCartPage && isset($salesFunnel_cl->checkoutPageId)) {
        $checkoutPageLink = get_the_permalink($salesFunnel_cl->checkoutPageId);
    }
    

        if( $salesFunnel_cl->checkout_mode == 'modal' ) {
            $checkoutPageLink = '#';
        } else {
           $checkoutPageLink = '#cl_form'; 
        }
}
?>
<div id="cl_cart_actions" _attachedsection="cart_actions" class="cl_cart_actions">
    <div class="action-buttons">
        <?php if ($checkoutPageLink && $settings['cart_actions_checkout_is_active'] == 'yes') { ?>
            <a class="goto-checkout-button" href="<?= $checkoutPageLink ?>">
                <?= $settings['cart_actions_checkout_text'] ?>
            </a>
        <?php } ?>
        
        <?php if ($settings['cart_actions_continue_is_active'] == 'yes') { ?>
            <a class="continue-button" href="<?= home_url() ?>">
                <?= $settings['cart_actions_continue_text'] ?>
            </a>
        <?php } ?>
    </div>
</div>