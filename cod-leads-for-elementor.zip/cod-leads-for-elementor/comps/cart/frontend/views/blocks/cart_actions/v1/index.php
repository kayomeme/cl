<?php
if ($settings['cart_actions_is_active'] === 'no') {
    return;
}
global $salesFunnel_clfe;

$checkoutPageLink = false;
if ($settings['cart_actions_checkout_is_active'] == 'yes') {
    if ($isCartPage && isset($salesFunnel_clfe->checkoutPageId)) {
        $checkoutPageLink = get_the_permalink($salesFunnel_clfe->checkoutPageId);
    }
    

        if( $salesFunnel_clfe->checkoutMode == 'modal' ) {
            $checkoutPageLink = '#';
        } else {
           $checkoutPageLink = '#clfe_form'; 
        }
}
?>
<div id="clfe_cart_actions" _attachedsection="cart_actions" class="clfe_cart_actions">
    <div class="action-buttons">
        <?php if ($checkoutPageLink && $settings['cart_actions_checkout_is_active'] == 'yes') { ?>
            <a class="goto-checkout-button" href="<?= $checkoutPageLink ?>">
                <?= $settings['cart_actions_checkout_text'] ?>
            </a>
        <?php } ?>
        
        <?php if ($settings['cart_actions_continue_is_active'] == 'yes') { ?>
            <a class="continue-button" href="<?= home_url() ?>">
                <?= $settings['cart_actions_continue_text'] ?>
            </a>
        <?php } ?>
    </div>
</div>