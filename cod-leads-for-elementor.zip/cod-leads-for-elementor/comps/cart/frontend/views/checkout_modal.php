
<div id="clfe-modal-form" class="modal">
    <div class="clfe-checkout-sections">
    <?php
        echo $checkoutModalBlocksContent;
    ?>
    </div>

    <div class="clfe-popup-footer">
        <a href="#" rel="modal:close"><?= $settings['checkout_modal_footer_text_close'] ?></a>
    </div>
</div>